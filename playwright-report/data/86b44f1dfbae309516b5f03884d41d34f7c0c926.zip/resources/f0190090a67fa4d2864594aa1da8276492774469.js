import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.tsx");const useEffect = __vite__cjsImport0_react["useEffect"];const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=55f59584";
import { useAppDispatch } from "/src/app/store/hooks/hooks.ts";
import { fetchPosts } from "/src/app/store/PostSlice.ts";
import "/src/App.css";
import "/src/styles/styles.scss";
import AppRouter from "/src/routes/AppRouter.tsx";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/App.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
function App() {
	_s();
	const dispatch = useAppDispatch();
	useEffect(() => {
		dispatch(fetchPosts());
	}, [dispatch]);
	return /* @__PURE__ */ _jsxDEV(AppRouter, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 16,
		columnNumber: 10
	}, this);
}
_s(App, "tCJ5bTv2M1spc82sWOaOedZNnhg=", false, function() {
	return [useAppDispatch];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/App.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/App.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxrQkFBa0I7QUFDM0IsT0FBTztBQUNQLE9BQU87QUFDUCxPQUFPLGVBQWU7Ozs7QUFHdEIsU0FBUyxNQUFNOztDQUNiLE1BQU0sV0FBVyxlQUFlO0NBRWhDLGdCQUFnQjtFQUNkLFNBQVMsV0FBVyxDQUFDO0NBQ3ZCLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FFYixPQUFPLHdCQUFDLFdBQUQsQ0FBWTs7Ozs7QUFDckI7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJBcHAudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VBcHBEaXNwYXRjaCB9IGZyb20gXCIuL2FwcC9zdG9yZS9ob29rcy9ob29rcy50c1wiO1xyXG5pbXBvcnQgeyBmZXRjaFBvc3RzIH0gZnJvbSBcIi4vYXBwL3N0b3JlL1Bvc3RTbGljZS50c1wiO1xyXG5pbXBvcnQgJy4vQXBwLmNzcydcclxuaW1wb3J0IFwiLi9zdHlsZXMvc3R5bGVzLnNjc3NcIlxyXG5pbXBvcnQgQXBwUm91dGVyIGZyb20gJy4vcm91dGVzL0FwcFJvdXRlci50c3gnO1xyXG5cclxuXHJcbmZ1bmN0aW9uIEFwcCgpIHtcclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZUFwcERpc3BhdGNoKCk7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBkaXNwYXRjaChmZXRjaFBvc3RzKCkpO1xyXG4gIH0sIFtkaXNwYXRjaF0pO1xyXG5cclxuICByZXR1cm4gPEFwcFJvdXRlciAvPjtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQXBwO1xyXG4iXX0=