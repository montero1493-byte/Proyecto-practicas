import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/ProtectedRoute.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport1_react_jsxDevRuntime["Fragment"];import { Navigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/ProtectedRoute.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
const ProtectedRoute = ({ children }) => {
	const isAuthenticated = localStorage.getItem("isAuthenticated") === "true";
	if (!isAuthenticated) {
		return /* @__PURE__ */ _jsxDEV(Navigate, {
			to: "/",
			replace: true
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 20
		}, this);
	}
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 16
	}, this);
};
_c = ProtectedRoute;
export default ProtectedRoute;
var _c;
$RefreshReg$(_c, "ProtectedRoute");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/ProtectedRoute.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/ProtectedRoute.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/ProtectedRoute.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/ProtectedRoute.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7OztBQU16QixNQUFNLGtCQUFrQixFQUFDLGVBQ0c7Q0FDcEIsTUFBTSxrQkFDRixhQUFhLFFBQ1QsaUJBQWlCLE1BQU07Q0FFL0IsSUFBSSxDQUFDLGlCQUFpQjtFQUNsQixPQUFPLHdCQUFDLFVBQUQ7R0FBVSxJQUFHO0dBQUk7RUFBUzs7Ozs7Q0FDckM7Q0FFQSxPQUFPLHFDQUFHLFNBQVc7Ozs7O0FBQ3pCOztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvdGVjdGVkUm91dGUudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IE5hdmlnYXRlIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuXHJcbnR5cGUgUHJvdGVjdGVkUm91dGVQcm9wcyA9IHtcclxuICAgIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XHJcbn07XHJcblxyXG5jb25zdCBQcm90ZWN0ZWRSb3V0ZSA9ICh7Y2hpbGRyZW59OiBcclxuICAgIFByb3RlY3RlZFJvdXRlUHJvcHMpID0+IHtcclxuICAgICAgICBjb25zdCBpc0F1dGhlbnRpY2F0ZWQgPSBcclxuICAgICAgICAgICAgbG9jYWxTdG9yYWdlLmdldEl0ZW0oXHJcbiAgICAgICAgICAgICAgICBcImlzQXV0aGVudGljYXRlZFwiKSA9PT0gXCJ0cnVlXCI7XHJcblxyXG4gICAgICAgIGlmICghaXNBdXRoZW50aWNhdGVkKSB7XHJcbiAgICAgICAgICAgIHJldHVybiA8TmF2aWdhdGUgdG89XCIvXCIgcmVwbGFjZSAvPjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHJldHVybiA8PntjaGlsZHJlbn08Lz5cclxuICAgIH07XHJcblxyXG4gICAgZXhwb3J0IGRlZmF1bHQgUHJvdGVjdGVkUm91dGUiXX0=