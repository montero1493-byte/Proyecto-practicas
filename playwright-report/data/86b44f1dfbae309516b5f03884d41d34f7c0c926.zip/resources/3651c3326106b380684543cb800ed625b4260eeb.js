import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/routes/AppRouter.tsx");const _jsxDEV = __vite__cjsImport11_react_jsxDevRuntime["jsxDEV"];import { BrowserRouter, Routes, Route } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
import MainLayout from "/src/components/layout/MainLayout.tsx";
import HomePage from "/src/app/pages/home/HomePage.tsx";
import PostsPage from "/src/app/pages/posts/PostPage.tsx";
import CreatePostPage from "/src/app/pages/posts/CreatePostPage.tsx";
import PostDetailPage from "/src/app/pages/posts/PostDetailPage.tsx";
import LoginPage from "/src/app/pages/auth/LoginPage.tsx";
import RegisterPage from "/src/app/pages/auth/RegisterPage.tsx";
import ProfilePage from "/src/app/pages/profile/ProfilePage.tsx";
import DashboardPage from "/src/app/pages/dashboard/DashboardPage.tsx";
import ProtectedRoute from "/src/components/ProtectedRoute.tsx";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/routes/AppRouter.tsx";
import __vite__cjsImport11_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
const AppRouter = () => {
	return /* @__PURE__ */ _jsxDEV(BrowserRouter, { children: /* @__PURE__ */ _jsxDEV(Routes, { children: [
		/* @__PURE__ */ _jsxDEV(Route, {
			element: /* @__PURE__ */ _jsxDEV(MainLayout, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 33
			}, this),
			children: [
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/",
					element: /* @__PURE__ */ _jsxDEV(HomePage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 22,
						columnNumber: 34
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 20,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/posts",
					element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(PostsPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 28,
						columnNumber: 29
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 27,
						columnNumber: 34
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 25,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/posts/create",
					element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(CreatePostPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 29
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 34,
						columnNumber: 34
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/posts/detail/:id",
					element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(PostDetailPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 42,
						columnNumber: 29
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 41,
						columnNumber: 34
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 39,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/profile",
					element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(ProfilePage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 49,
						columnNumber: 29
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 34
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 46,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV(Route, {
					path: "/dashboard",
					element: /* @__PURE__ */ _jsxDEV(ProtectedRoute, { children: /* @__PURE__ */ _jsxDEV(DashboardPage, {}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 56,
						columnNumber: 29
					}, this) }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 55,
						columnNumber: 34
					}, this)
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 53,
					columnNumber: 21
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 19,
			columnNumber: 17
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/login",
			element: /* @__PURE__ */ _jsxDEV(LoginPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 63,
				columnNumber: 30
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 61,
			columnNumber: 17
		}, this),
		/* @__PURE__ */ _jsxDEV(Route, {
			path: "/register",
			element: /* @__PURE__ */ _jsxDEV(RegisterPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 68,
				columnNumber: 30
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 66,
			columnNumber: 17
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 18,
		columnNumber: 13
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 9
	}, this);
};
_c = AppRouter;
export default AppRouter;
var _c;
$RefreshReg$(_c, "AppRouter");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/routes/AppRouter.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/routes/AppRouter.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/routes/AppRouter.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/routes/AppRouter.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlLFFBQVEsYUFBYTtBQUU3QyxPQUFPLGdCQUFnQjtBQUV2QixPQUFPLGNBQWM7QUFDckIsT0FBTyxlQUFlO0FBQ3RCLE9BQU8sb0JBQW9CO0FBQzNCLE9BQU8sb0JBQW9CO0FBQzNCLE9BQU8sZUFBZTtBQUN0QixPQUFPLGtCQUFrQjtBQUN6QixPQUFPLGlCQUFpQjtBQUN4QixPQUFPLG1CQUFtQjtBQUMxQixPQUFPLG9CQUFvQjs7O0FBRTNCLE1BQU0sa0JBQWtCO0NBQ3BCLE9BQ0ksd0JBQUMsZUFBRCxZQUNJLHdCQUFDLFFBQUQ7RUFDSSx3QkFBQyxPQUFEO0dBQU8sU0FBUyx3QkFBQyxZQUFELENBQWE7Ozs7O2FBQTdCO0lBQ0ksd0JBQUMsT0FBRDtLQUNJLE1BQUs7S0FDTCxTQUFTLHdCQUFDLFVBQUQsQ0FBVzs7Ozs7SUFDdkI7Ozs7O0lBRUQsd0JBQUMsT0FBRDtLQUNJLE1BQUs7S0FDTCxTQUFTLHdCQUFDLGdCQUFELFlBQ0wsd0JBQUMsV0FBRCxDQUFZOzs7O2NBQ0k7Ozs7O0lBQ3ZCOzs7OztJQUVELHdCQUFDLE9BQUQ7S0FDSSxNQUFLO0tBQ0wsU0FBUyx3QkFBQyxnQkFBRCxZQUNMLHdCQUFDLGdCQUFELENBQWlCOzs7O2NBQ0Q7Ozs7O0lBQ3ZCOzs7OztJQUVELHdCQUFDLE9BQUQ7S0FDSSxNQUFLO0tBQ0wsU0FBUyx3QkFBQyxnQkFBRCxZQUNMLHdCQUFDLGdCQUFELENBQWlCOzs7O2NBQ0Q7Ozs7O0lBQ3ZCOzs7OztJQUVELHdCQUFDLE9BQUQ7S0FDSSxNQUFLO0tBQ0wsU0FBUyx3QkFBQyxnQkFBRCxZQUNMLHdCQUFDLGFBQUQsQ0FBYzs7OztjQUNFOzs7OztJQUN2Qjs7Ozs7SUFFRCx3QkFBQyxPQUFEO0tBQ0ksTUFBSztLQUNMLFNBQVMsd0JBQUMsZ0JBQUQsWUFDTCx3QkFBQyxlQUFELENBQWdCOzs7O2NBQ0E7Ozs7O0lBQ3ZCOzs7OztHQUNFOzs7Ozs7RUFFUCx3QkFBQyxPQUFEO0dBQ0ksTUFBSztHQUNMLFNBQVMsd0JBQUMsV0FBRCxDQUFZOzs7OztFQUN4Qjs7Ozs7RUFFRCx3QkFBQyxPQUFEO0dBQ0ksTUFBSztHQUNMLFNBQVMsd0JBQUMsY0FBRCxDQUFlOzs7OztFQUMzQjs7Ozs7Q0FDRzs7OztVQUNHOzs7OztBQUV2Qjs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkFwcFJvdXRlci50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQnJvd3NlclJvdXRlciwgUm91dGVzLCBSb3V0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcblxyXG5pbXBvcnQgTWFpbkxheW91dCBmcm9tIFwiLi4vY29tcG9uZW50cy9sYXlvdXQvTWFpbkxheW91dFwiO1xyXG5cclxuaW1wb3J0IEhvbWVQYWdlIGZyb20gXCIuLi9hcHAvcGFnZXMvaG9tZS9Ib21lUGFnZVwiO1xyXG5pbXBvcnQgUG9zdHNQYWdlIGZyb20gXCIuLi9hcHAvcGFnZXMvcG9zdHMvUG9zdFBhZ2VcIjtcclxuaW1wb3J0IENyZWF0ZVBvc3RQYWdlIGZyb20gXCIuLi9hcHAvcGFnZXMvcG9zdHMvQ3JlYXRlUG9zdFBhZ2VcIjtcclxuaW1wb3J0IFBvc3REZXRhaWxQYWdlIGZyb20gXCIuLi9hcHAvcGFnZXMvcG9zdHMvUG9zdERldGFpbFBhZ2VcIjtcclxuaW1wb3J0IExvZ2luUGFnZSBmcm9tIFwiLi4vYXBwL3BhZ2VzL2F1dGgvTG9naW5QYWdlXCI7XHJcbmltcG9ydCBSZWdpc3RlclBhZ2UgZnJvbSBcIi4uL2FwcC9wYWdlcy9hdXRoL1JlZ2lzdGVyUGFnZVwiO1xyXG5pbXBvcnQgUHJvZmlsZVBhZ2UgZnJvbSBcIi4uL2FwcC9wYWdlcy9wcm9maWxlL1Byb2ZpbGVQYWdlXCI7XHJcbmltcG9ydCBEYXNoYm9hcmRQYWdlIGZyb20gXCIuLi9hcHAvcGFnZXMvZGFzaGJvYXJkL0Rhc2hib2FyZFBhZ2VcIjtcclxuaW1wb3J0IFByb3RlY3RlZFJvdXRlIGZyb20gXCIuLi9jb21wb25lbnRzL1Byb3RlY3RlZFJvdXRlXCI7XHJcblxyXG5jb25zdCBBcHBSb3V0ZXIgPSAoKSA9PiB7XHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxCcm93c2VyUm91dGVyPlxyXG4gICAgICAgICAgICA8Um91dGVzPlxyXG4gICAgICAgICAgICAgICAgPFJvdXRlIGVsZW1lbnQ9ezxNYWluTGF5b3V0IC8+fT5cclxuICAgICAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aD1cIi9cIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50PXs8SG9tZVBhZ2UgLz59XHJcbiAgICAgICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICAgICAgPFJvdXRlXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhdGg9XCIvcG9zdHNcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UG9zdHNQYWdlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPn1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgICAgICAgcGF0aD1cIi9wb3N0cy9jcmVhdGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8Q3JlYXRlUG9zdFBhZ2UgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoPVwiL3Bvc3RzL2RldGFpbC86aWRcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UG9zdERldGFpbFBhZ2UgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoPVwiL3Byb2ZpbGVcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICBlbGVtZW50PXs8UHJvdGVjdGVkUm91dGU+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8UHJvZmlsZVBhZ2UgLz5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDwvUHJvdGVjdGVkUm91dGU+fVxyXG4gICAgICAgICAgICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxSb3V0ZVxyXG4gICAgICAgICAgICAgICAgICAgICAgICBwYXRoPVwiL2Rhc2hib2FyZFwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsZW1lbnQ9ezxQcm90ZWN0ZWRSb3V0ZT5cclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDxEYXNoYm9hcmRQYWdlIC8+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA8L1Byb3RlY3RlZFJvdXRlPn1cclxuICAgICAgICAgICAgICAgICAgICAvPlxyXG4gICAgICAgICAgICAgICAgPC9Sb3V0ZT5cclxuXHJcbiAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgICBwYXRoPVwiL2xvZ2luXCJcclxuICAgICAgICAgICAgICAgICAgICBlbGVtZW50PXs8TG9naW5QYWdlIC8+fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuXHJcbiAgICAgICAgICAgICAgICA8Um91dGVcclxuICAgICAgICAgICAgICAgICAgICBwYXRoPVwiL3JlZ2lzdGVyXCJcclxuICAgICAgICAgICAgICAgICAgICBlbGVtZW50PXs8UmVnaXN0ZXJQYWdlIC8+fVxyXG4gICAgICAgICAgICAgICAgLz5cclxuICAgICAgICAgICAgPC9Sb3V0ZXM+XHJcbiAgICAgICAgPC9Ccm93c2VyUm91dGVyPlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IEFwcFJvdXRlcjsiXX0=