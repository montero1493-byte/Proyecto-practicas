import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/pages/posts/PostDetailPage.tsx");const useState = __vite__cjsImport2_react["useState"];const useEffect = __vite__cjsImport6_react["useEffect"];const _jsxDEV = __vite__cjsImport10_react_jsxDevRuntime["jsxDEV"];import { useParams } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
import { useAppSelector } from "/src/app/store/hooks/hooks.ts";
import __vite__cjsImport2_react from "/node_modules/.vite/deps/react.js?v=55f59584";
import { useAppDispatch } from "/src/app/store/hooks/hooks.ts";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
import { updatePost, deletePost } from "/src/app/store/PostSlice.ts";
import __vite__cjsImport6_react from "/node_modules/.vite/deps/react.js?v=55f59584";
import { useToast } from "/src/app/store/hooks/useToast.ts";
import Toast from "/src/components/toast/Toast.tsx";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=6824eab0";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/PostDetailPage.tsx";
import __vite__cjsImport10_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
const PostDetailPage = () => {
	_s();
	const { id } = useParams();
	const dispatch = useAppDispatch();
	const navigate = useNavigate();
	const { t } = useTranslation();
	const isGuest = localStorage.getItem("userType") === "guest";
	const { message, showToast } = useToast();
	const post = useAppSelector((state) => state.posts.posts.find((post) => post.id === Number(id)));
	const [isEditing, setIsEditing] = useState(false);
	const [title, setTitle] = useState("");
	const [body, setBody] = useState("");
	useEffect(() => {
		if (post) {
			setTitle(post.title);
			setBody(post.body);
		}
	}, [post]);
	if (!post) {
		return /* @__PURE__ */ _jsxDEV("p", { children: "Post no encontrado" }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 39,
			columnNumber: 12
		}, this);
	}
	;
	const handleSave = () => {
		dispatch(updatePost({
			userId: post.userId,
			id: post.id,
			title,
			body
		}));
		setIsEditing(false);
		if (!title.trim() || !body.trim()) {
			alert("completa todos los campos");
			return;
		}
		showToast("Post Actualizado");
	};
	const handleDelete = () => {
		const confirmDelete = window.confirm("¿Estás seguro de que deseas eliminar este post?");
		if (!confirmDelete) {
			return;
		}
		dispatch(deletePost(post.id));
		navigate("/posts", { state: { successMessage: "Post eliminado" } });
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "detail-post-page",
		children: [message && /* @__PURE__ */ _jsxDEV(Toast, { message }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 73,
			columnNumber: 20
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "detail-post-card",
			children: [/* @__PURE__ */ _jsxDEV("p", {
				className: "post-id",
				children: ["ID: ", id]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 78,
				columnNumber: 9
			}, this), !isEditing ? /* @__PURE__ */ _jsxDEV("div", { children: [
				/* @__PURE__ */ _jsxDEV("h1", { children: post.title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 82,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "post-content",
					children: post.body
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 84,
					columnNumber: 11
				}, this),
				!isGuest && /* @__PURE__ */ _jsxDEV("div", {
					className: "post-actions",
					children: [/* @__PURE__ */ _jsxDEV("button", {
						className: "app-button",
						onClick: () => setIsEditing(true),
						children: t("app.edit")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 90,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("button", {
						className: "app-button",
						onClick: handleDelete,
						children: t("app.delete")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 91,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 89,
					columnNumber: 13
				}, this)
			] }, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 9
			}, this) : /* @__PURE__ */ _jsxDEV("div", {
				className: "edit-post-form",
				children: [
					/* @__PURE__ */ _jsxDEV("h2", { children: t("app.edit-post") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 97,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: title,
						onChange: (e) => setTitle(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 98,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("textarea", {
						value: body,
						onChange: (e) => setBody(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 103,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "app-button",
						onClick: () => handleSave(),
						children: t("app.save")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 107,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 96,
				columnNumber: 9
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 72,
		columnNumber: 5
	}, this);
};
_s(PostDetailPage, "F/bg3Xv/TC62tT3IEFvqooWOFn0=", false, function() {
	return [
		useParams,
		useAppDispatch,
		useNavigate,
		useTranslation,
		useToast,
		useAppSelector
	];
});
_c = PostDetailPage;
export default PostDetailPage;
var _c;
$RefreshReg$(_c, "PostDetailPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app/pages/posts/PostDetailPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/PostDetailPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/PostDetailPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/PostDetailPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxZQUFZLGtCQUFrQjtBQUN2QyxTQUFTLGlCQUFpQjtBQUMxQixTQUFTLGdCQUFnQjtBQUN6QixPQUFPLFdBQVc7QUFDbEIsU0FBUyxzQkFBc0I7Ozs7QUFHL0IsTUFBTSx1QkFBdUI7O0NBQzNCLE1BQU0sRUFBRSxPQUFPLFVBQVU7Q0FDekIsTUFBTSxXQUFXLGVBQWU7Q0FDaEMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxFQUFFLE1BQU0sZUFBZTtDQUU3QixNQUFNLFVBQVUsYUFBYSxRQUFRLFVBQVUsTUFBTTtDQUVyRCxNQUFNLEVBQUMsU0FBUyxjQUFhLFNBQVM7Q0FFdEMsTUFBTSxPQUFPLGdCQUFnQixVQUFVLE1BQU0sTUFBTSxNQUFNLE1BQU0sU0FBUyxLQUFLLE9BQU8sT0FBTyxFQUFFLENBQUMsQ0FBQztDQUUvRixNQUFNLENBQUMsV0FBVyxnQkFBZ0IsU0FBUyxLQUFLO0NBRWhELE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxFQUFFO0NBQ3JDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxFQUFFO0NBR3JDLGdCQUFnQjtFQUNkLElBQUksTUFBTTtHQUNSLFNBQVMsS0FBSyxLQUFLO0dBQ25CLFFBQVEsS0FBSyxJQUFJO0VBQ25CO0NBQ0YsR0FBRyxDQUFDLElBQUksQ0FBQztDQUVULElBQUksQ0FBQyxNQUFNO0VBQ1AsT0FBTyx3QkFBQyxLQUFELFlBQUcscUJBQXFCOzs7OztDQUNuQztDQUFDO0NBR0QsTUFBTSxtQkFBbUI7RUFDdkIsU0FBUyxXQUFXO0dBQUUsUUFBUSxLQUFLO0dBQVEsSUFBSSxLQUFLO0dBQUk7R0FBTztFQUFLLENBQUMsQ0FBQztFQUN0RSxhQUFhLEtBQUs7RUFFbEIsSUFBSSxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUMsS0FBSyxLQUFLLEdBQUc7R0FDL0IsTUFBTSwyQkFBMkI7R0FDakM7RUFDRjtFQUVGLFVBQVUsa0JBQWtCO0NBQzlCO0NBR0EsTUFBTSxxQkFBcUI7RUFDekIsTUFBTSxnQkFBZ0IsT0FBTyxRQUFRLGlEQUFpRDtFQUN0RixJQUFJLENBQUMsZUFBZTtHQUNsQjtFQUNGO0VBQ0EsU0FBUyxXQUFXLEtBQUssRUFBRSxDQUFDO0VBRzVCLFNBQVMsVUFBVSxFQUNqQixPQUFPLEVBQ0wsZ0JBQWdCLGlCQUNsQixFQUNGLENBQUM7Q0FDSDtDQUVFLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFBZixDQUNHLFdBQVksd0JBQUMsT0FBRCxFQUFnQixRQUFVOzs7O1lBR3ZDLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQWYsQ0FFRSx3QkFBQyxLQUFEO0lBQUcsV0FBVTtjQUFiLENBQXVCLFFBQUssRUFBTTs7Ozs7YUFFL0IsQ0FBQyxZQUNKLHdCQUFDLE9BQUQ7SUFDRSx3QkFBQyxNQUFELFlBQUssS0FBSyxNQUFVOzs7OztJQUVwQix3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUNaLEtBQUs7SUFDSDs7Ozs7SUFFSixDQUFDLFdBQ0Esd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNBLHdCQUFDLFVBQUQ7TUFBUSxXQUFVO01BQWEsZUFBZSxhQUFhLElBQUk7Z0JBQUksRUFBRSxVQUFVO0tBQVU7Ozs7ZUFDekYsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBYSxTQUFTO2dCQUFlLEVBQUUsWUFBWTtLQUFVOzs7O2FBQzFFOzs7Ozs7R0FFSjs7OztjQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWY7S0FDRSx3QkFBQyxNQUFELFlBQUssRUFBRSxlQUFlLEVBQU07Ozs7O0tBQzVCLHdCQUFDLFNBQUQ7TUFDSSxNQUFLO01BQ0wsT0FBTztNQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO0tBQzNDOzs7OztLQUNELHdCQUFDLFlBQUQ7TUFDSSxPQUFPO01BQ1AsV0FBVyxNQUFNLFFBQVEsRUFBRSxPQUFPLEtBQUs7S0FDMUM7Ozs7O0tBQ0Qsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBYSxlQUFlLFdBQVc7Z0JBQUksRUFBRSxVQUFVO0tBQVU7Ozs7O0lBQ2hGOzs7OztXQUVGOzs7OztVQUNGOzs7Ozs7QUFFVDs7Ozs7Ozs7Ozs7O0FBS0EsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJQb3N0RGV0YWlsUGFnZS50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUGFyYW1zIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlQXBwU2VsZWN0b3IgfSBmcm9tIFwiLi4vLi4vc3RvcmUvaG9va3MvaG9va3NcIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlQXBwRGlzcGF0Y2ggfSBmcm9tIFwiLi4vLi4vc3RvcmUvaG9va3MvaG9va3NcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1cGRhdGVQb3N0LCBkZWxldGVQb3N0IH0gZnJvbSBcIi4uLy4uL3N0b3JlL1Bvc3RTbGljZVwiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgdXNlVG9hc3QgfSBmcm9tIFwiLi4vLi4vc3RvcmUvaG9va3MvdXNlVG9hc3RcIjtcclxuaW1wb3J0IFRvYXN0IGZyb20gXCIuLi8uLi8uLi9jb21wb25lbnRzL3RvYXN0L1RvYXN0XCI7XHJcbmltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSBcInJlYWN0LWkxOG5leHRcIjtcclxuXHJcblxyXG5jb25zdCBQb3N0RGV0YWlsUGFnZSA9ICgpID0+IHtcclxuICBjb25zdCB7IGlkIH0gPSB1c2VQYXJhbXMoKTtcclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZUFwcERpc3BhdGNoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcclxuXHJcbiAgY29uc3QgaXNHdWVzdCA9IGxvY2FsU3RvcmFnZS5nZXRJdGVtKFwidXNlclR5cGVcIikgPT09IFwiZ3Vlc3RcIjtcclxuXHJcbiAgY29uc3Qge21lc3NhZ2UsIHNob3dUb2FzdH0gPSB1c2VUb2FzdCgpO1xyXG5cclxuICBjb25zdCBwb3N0ID0gdXNlQXBwU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5wb3N0cy5wb3N0cy5maW5kKChwb3N0KSA9PiBwb3N0LmlkID09PSBOdW1iZXIoaWQpKSk7XHJcblxyXG4gIGNvbnN0IFtpc0VkaXRpbmcsIHNldElzRWRpdGluZ10gPSB1c2VTdGF0ZShmYWxzZSk7XHJcblxyXG4gIGNvbnN0IFt0aXRsZSwgc2V0VGl0bGVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW2JvZHksIHNldEJvZHldID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG5cclxudXNlRWZmZWN0KCgpID0+IHtcclxuICBpZiAocG9zdCkge1xyXG4gICAgc2V0VGl0bGUocG9zdC50aXRsZSk7XHJcbiAgICBzZXRCb2R5KHBvc3QuYm9keSk7XHJcbiAgfVxyXG59LCBbcG9zdF0pO1xyXG5cclxuaWYgKCFwb3N0KSB7XHJcbiAgICByZXR1cm4gPHA+UG9zdCBubyBlbmNvbnRyYWRvPC9wPjtcclxufTtcclxuXHJcblxyXG5jb25zdCBoYW5kbGVTYXZlID0gKCkgPT4ge1xyXG4gIGRpc3BhdGNoKHVwZGF0ZVBvc3QoeyB1c2VySWQ6IHBvc3QudXNlcklkLCBpZDogcG9zdC5pZCwgdGl0bGUsIGJvZHkgfSkpO1xyXG4gIHNldElzRWRpdGluZyhmYWxzZSk7XHJcblxyXG4gIGlmICghdGl0bGUudHJpbSgpIHx8ICFib2R5LnRyaW0oKSkge1xyXG4gICAgICBhbGVydChcImNvbXBsZXRhIHRvZG9zIGxvcyBjYW1wb3NcIik7XHJcbiAgICAgIHJldHVybjtcclxuICAgIH1cclxuXHJcbiAgc2hvd1RvYXN0KFwiUG9zdCBBY3R1YWxpemFkb1wiKTtcclxufTtcclxuXHJcblxyXG5jb25zdCBoYW5kbGVEZWxldGUgPSAoKSA9PiB7XHJcbiAgY29uc3QgY29uZmlybURlbGV0ZSA9IHdpbmRvdy5jb25maXJtKFwiwr9Fc3TDoXMgc2VndXJvIGRlIHF1ZSBkZXNlYXMgZWxpbWluYXIgZXN0ZSBwb3N0P1wiKTtcclxuICBpZiAoIWNvbmZpcm1EZWxldGUpIHtcclxuICAgIHJldHVybjtcclxuICB9XHJcbiAgZGlzcGF0Y2goZGVsZXRlUG9zdChwb3N0LmlkKSk7XHJcblxyXG5cclxuICBuYXZpZ2F0ZShcIi9wb3N0c1wiLCB7XHJcbiAgICBzdGF0ZToge1xyXG4gICAgICBzdWNjZXNzTWVzc2FnZTogXCJQb3N0IGVsaW1pbmFkb1wiLFxyXG4gICAgfSxcclxuICB9KTtcclxufTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZGV0YWlsLXBvc3QtcGFnZVwiPlxyXG4gICAgICB7bWVzc2FnZSAmJiAoPFRvYXN0IG1lc3NhZ2U9e21lc3NhZ2V9IC8+XHJcbiAgICAgICl9XHJcbiAgICBcclxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJkZXRhaWwtcG9zdC1jYXJkXCI+XHJcbiAgICAgICAgXHJcbiAgICAgICAgPHAgY2xhc3NOYW1lPVwicG9zdC1pZFwiPklEOiB7aWR9PC9wPlxyXG5cclxuICAgICAgICAgIHshaXNFZGl0aW5nID8gKFxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8aDE+e3Bvc3QudGl0bGV9PC9oMT5cclxuXHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInBvc3QtY29udGVudFwiPlxyXG4gICAgICAgICAgICB7cG9zdC5ib2R5fVxyXG4gICAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgICAgeyFpc0d1ZXN0ICYmIChcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb3N0LWFjdGlvbnNcIj5cclxuICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhcHAtYnV0dG9uXCIgb25DbGljaz17KCkgPT4gc2V0SXNFZGl0aW5nKHRydWUpfT57dChcImFwcC5lZGl0XCIpfTwvYnV0dG9uPlxyXG4gICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImFwcC1idXR0b25cIiBvbkNsaWNrPXtoYW5kbGVEZWxldGV9Pnt0KFwiYXBwLmRlbGV0ZVwiKX08L2J1dHRvbj5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgKSA6IChcclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImVkaXQtcG9zdC1mb3JtXCI+XHJcbiAgICAgICAgICA8aDI+e3QoXCJhcHAuZWRpdC1wb3N0XCIpfTwvaDI+IFxyXG4gICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICAgIHZhbHVlPXt0aXRsZX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFRpdGxlKGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIC8+XHJcbiAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgICAgICB2YWx1ZT17Ym9keX1cclxuICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldEJvZHkoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYXBwLWJ1dHRvblwiIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNhdmUoKX0+e3QoXCJhcHAuc2F2ZVwiKX08L2J1dHRvbj5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICl9XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcblxyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBvc3REZXRhaWxQYWdlOyJdfQ==