//#region node_modules/.pnpm/redux@5.0.1/node_modules/redux/dist/redux.mjs
var symbol_observable_default = /* @__PURE__ */ (() => typeof Symbol === "function" && Symbol.observable || "@@observable")();
var randomString = () => Math.random().toString(36).substring(7).split("").join(".");
var actionTypes_default = {
	INIT: `@@redux/INIT${/* @__PURE__ */ randomString()}`,
	REPLACE: `@@redux/REPLACE${/* @__PURE__ */ randomString()}`,
	PROBE_UNKNOWN_ACTION: () => `@@redux/PROBE_UNKNOWN_ACTION${randomString()}`
};
function isPlainObject(obj) {
	if (typeof obj !== "object" || obj === null) return false;
	let proto = obj;
	while (Object.getPrototypeOf(proto) !== null) proto = Object.getPrototypeOf(proto);
	return Object.getPrototypeOf(obj) === proto || Object.getPrototypeOf(obj) === null;
}
function miniKindOf(val) {
	if (val === void 0) return "undefined";
	if (val === null) return "null";
	const type = typeof val;
	switch (type) {
		case "boolean":
		case "string":
		case "number":
		case "symbol":
		case "function": return type;
	}
	if (Array.isArray(val)) return "array";
	if (isDate(val)) return "date";
	if (isError(val)) return "error";
	const constructorName = ctorName(val);
	switch (constructorName) {
		case "Symbol":
		case "Promise":
		case "WeakMap":
		case "WeakSet":
		case "Map":
		case "Set": return constructorName;
	}
	return Object.prototype.toString.call(val).slice(8, -1).toLowerCase().replace(/\s/g, "");
}
function ctorName(val) {
	return typeof val.constructor === "function" ? val.constructor.name : null;
}
function isError(val) {
	return val instanceof Error || typeof val.message === "string" && val.constructor && typeof val.constructor.stackTraceLimit === "number";
}
function isDate(val) {
	if (val instanceof Date) return true;
	return typeof val.toDateString === "function" && typeof val.getDate === "function" && typeof val.setDate === "function";
}
function kindOf(val) {
	let typeOfVal = typeof val;
	typeOfVal = miniKindOf(val);
	return typeOfVal;
}
function createStore(reducer, preloadedState, enhancer) {
	if (typeof reducer !== "function") throw new Error(`Expected the root reducer to be a function. Instead, received: '${kindOf(reducer)}'`);
	if (typeof preloadedState === "function" && typeof enhancer === "function" || typeof enhancer === "function" && typeof arguments[3] === "function") throw new Error("It looks like you are passing several store enhancers to createStore(). This is not supported. Instead, compose them together to a single function. See https://redux.js.org/tutorials/fundamentals/part-4-store#creating-a-store-with-enhancers for an example.");
	if (typeof preloadedState === "function" && typeof enhancer === "undefined") {
		enhancer = preloadedState;
		preloadedState = void 0;
	}
	if (typeof enhancer !== "undefined") {
		if (typeof enhancer !== "function") throw new Error(`Expected the enhancer to be a function. Instead, received: '${kindOf(enhancer)}'`);
		return enhancer(createStore)(reducer, preloadedState);
	}
	let currentReducer = reducer;
	let currentState = preloadedState;
	let currentListeners = /* @__PURE__ */ new Map();
	let nextListeners = currentListeners;
	let listenerIdCounter = 0;
	let isDispatching = false;
	function ensureCanMutateNextListeners() {
		if (nextListeners === currentListeners) {
			nextListeners = /* @__PURE__ */ new Map();
			currentListeners.forEach((listener, key) => {
				nextListeners.set(key, listener);
			});
		}
	}
	function getState() {
		if (isDispatching) throw new Error("You may not call store.getState() while the reducer is executing. The reducer has already received the state as an argument. Pass it down from the top reducer instead of reading it from the store.");
		return currentState;
	}
	function subscribe(listener) {
		if (typeof listener !== "function") throw new Error(`Expected the listener to be a function. Instead, received: '${kindOf(listener)}'`);
		if (isDispatching) throw new Error("You may not call store.subscribe() while the reducer is executing. If you would like to be notified after the store has been updated, subscribe from a component and invoke store.getState() in the callback to access the latest state. See https://redux.js.org/api/store#subscribelistener for more details.");
		let isSubscribed = true;
		ensureCanMutateNextListeners();
		const listenerId = listenerIdCounter++;
		nextListeners.set(listenerId, listener);
		return function unsubscribe() {
			if (!isSubscribed) return;
			if (isDispatching) throw new Error("You may not unsubscribe from a store listener while the reducer is executing. See https://redux.js.org/api/store#subscribelistener for more details.");
			isSubscribed = false;
			ensureCanMutateNextListeners();
			nextListeners.delete(listenerId);
			currentListeners = null;
		};
	}
	function dispatch(action) {
		if (!isPlainObject(action)) throw new Error(`Actions must be plain objects. Instead, the actual type was: '${kindOf(action)}'. You may need to add middleware to your store setup to handle dispatching other values, such as 'redux-thunk' to handle dispatching functions. See https://redux.js.org/tutorials/fundamentals/part-4-store#middleware and https://redux.js.org/tutorials/fundamentals/part-6-async-logic#using-the-redux-thunk-middleware for examples.`);
		if (typeof action.type === "undefined") throw new Error("Actions may not have an undefined \"type\" property. You may have misspelled an action type string constant.");
		if (typeof action.type !== "string") throw new Error(`Action "type" property must be a string. Instead, the actual type was: '${kindOf(action.type)}'. Value was: '${action.type}' (stringified)`);
		if (isDispatching) throw new Error("Reducers may not dispatch actions.");
		try {
			isDispatching = true;
			currentState = currentReducer(currentState, action);
		} finally {
			isDispatching = false;
		}
		(currentListeners = nextListeners).forEach((listener) => {
			listener();
		});
		return action;
	}
	function replaceReducer(nextReducer) {
		if (typeof nextReducer !== "function") throw new Error(`Expected the nextReducer to be a function. Instead, received: '${kindOf(nextReducer)}`);
		currentReducer = nextReducer;
		dispatch({ type: actionTypes_default.REPLACE });
	}
	function observable() {
		const outerSubscribe = subscribe;
		return {
			/**
			* The minimal observable subscription method.
			* @param observer Any object that can be used as an observer.
			* The observer object should have a `next` method.
			* @returns An object with an `unsubscribe` method that can
			* be used to unsubscribe the observable from the store, and prevent further
			* emission of values from the observable.
			*/
			subscribe(observer) {
				if (typeof observer !== "object" || observer === null) throw new Error(`Expected the observer to be an object. Instead, received: '${kindOf(observer)}'`);
				function observeState() {
					const observerAsObserver = observer;
					if (observerAsObserver.next) observerAsObserver.next(getState());
				}
				observeState();
				return { unsubscribe: outerSubscribe(observeState) };
			},
			[symbol_observable_default]() {
				return this;
			}
		};
	}
	dispatch({ type: actionTypes_default.INIT });
	return {
		dispatch,
		subscribe,
		getState,
		replaceReducer,
		[symbol_observable_default]: observable
	};
}
function legacy_createStore(reducer, preloadedState, enhancer) {
	return createStore(reducer, preloadedState, enhancer);
}
function warning(message) {
	if (typeof console !== "undefined" && typeof console.error === "function") console.error(message);
	try {
		throw new Error(message);
	} catch (e) {}
}
function getUnexpectedStateShapeWarningMessage(inputState, reducers, action, unexpectedKeyCache) {
	const reducerKeys = Object.keys(reducers);
	const argumentName = action && action.type === actionTypes_default.INIT ? "preloadedState argument passed to createStore" : "previous state received by the reducer";
	if (reducerKeys.length === 0) return "Store does not have a valid reducer. Make sure the argument passed to combineReducers is an object whose values are reducers.";
	if (!isPlainObject(inputState)) return `The ${argumentName} has unexpected type of "${kindOf(inputState)}". Expected argument to be an object with the following keys: "${reducerKeys.join("\", \"")}"`;
	const unexpectedKeys = Object.keys(inputState).filter((key) => !reducers.hasOwnProperty(key) && !unexpectedKeyCache[key]);
	unexpectedKeys.forEach((key) => {
		unexpectedKeyCache[key] = true;
	});
	if (action && action.type === actionTypes_default.REPLACE) return;
	if (unexpectedKeys.length > 0) return `Unexpected ${unexpectedKeys.length > 1 ? "keys" : "key"} "${unexpectedKeys.join("\", \"")}" found in ${argumentName}. Expected to find one of the known reducer keys instead: "${reducerKeys.join("\", \"")}". Unexpected keys will be ignored.`;
}
function assertReducerShape(reducers) {
	Object.keys(reducers).forEach((key) => {
		const reducer = reducers[key];
		if (typeof reducer(void 0, { type: actionTypes_default.INIT }) === "undefined") throw new Error(`The slice reducer for key "${key}" returned undefined during initialization. If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined. If you don't want to set a value for this reducer, you can use null instead of undefined.`);
		if (typeof reducer(void 0, { type: actionTypes_default.PROBE_UNKNOWN_ACTION() }) === "undefined") throw new Error(`The slice reducer for key "${key}" returned undefined when probed with a random type. Don't try to handle '${actionTypes_default.INIT}' or other actions in "redux/*" namespace. They are considered private. Instead, you must return the current state for any unknown actions, unless it is undefined, in which case you must return the initial state, regardless of the action type. The initial state may not be undefined, but can be null.`);
	});
}
function combineReducers(reducers) {
	const reducerKeys = Object.keys(reducers);
	const finalReducers = {};
	for (let i = 0; i < reducerKeys.length; i++) {
		const key = reducerKeys[i];
		if (typeof reducers[key] === "undefined") warning(`No reducer provided for key "${key}"`);
		if (typeof reducers[key] === "function") finalReducers[key] = reducers[key];
	}
	const finalReducerKeys = Object.keys(finalReducers);
	let unexpectedKeyCache = {};
	let shapeAssertionError;
	try {
		assertReducerShape(finalReducers);
	} catch (e) {
		shapeAssertionError = e;
	}
	return function combination(state = {}, action) {
		if (shapeAssertionError) throw shapeAssertionError;
		{
			const warningMessage = getUnexpectedStateShapeWarningMessage(state, finalReducers, action, unexpectedKeyCache);
			if (warningMessage) warning(warningMessage);
		}
		let hasChanged = false;
		const nextState = {};
		for (let i = 0; i < finalReducerKeys.length; i++) {
			const key = finalReducerKeys[i];
			const reducer = finalReducers[key];
			const previousStateForKey = state[key];
			const nextStateForKey = reducer(previousStateForKey, action);
			if (typeof nextStateForKey === "undefined") {
				const actionType = action && action.type;
				throw new Error(`When called with an action of type ${actionType ? `"${String(actionType)}"` : "(unknown type)"}, the slice reducer for key "${key}" returned undefined. To ignore an action, you must explicitly return the previous state. If you want this reducer to hold no value, you can return null instead of undefined.`);
			}
			nextState[key] = nextStateForKey;
			hasChanged = hasChanged || nextStateForKey !== previousStateForKey;
		}
		hasChanged = hasChanged || finalReducerKeys.length !== Object.keys(state).length;
		return hasChanged ? nextState : state;
	};
}
function bindActionCreator(actionCreator, dispatch) {
	return function(...args) {
		return dispatch(actionCreator.apply(this, args));
	};
}
function bindActionCreators(actionCreators, dispatch) {
	if (typeof actionCreators === "function") return bindActionCreator(actionCreators, dispatch);
	if (typeof actionCreators !== "object" || actionCreators === null) throw new Error(`bindActionCreators expected an object or a function, but instead received: '${kindOf(actionCreators)}'. Did you write "import ActionCreators from" instead of "import * as ActionCreators from"?`);
	const boundActionCreators = {};
	for (const key in actionCreators) {
		const actionCreator = actionCreators[key];
		if (typeof actionCreator === "function") boundActionCreators[key] = bindActionCreator(actionCreator, dispatch);
	}
	return boundActionCreators;
}
function compose(...funcs) {
	if (funcs.length === 0) return (arg) => arg;
	if (funcs.length === 1) return funcs[0];
	return funcs.reduce((a, b) => (...args) => a(b(...args)));
}
function applyMiddleware(...middlewares) {
	return (createStore2) => (reducer, preloadedState) => {
		const store = createStore2(reducer, preloadedState);
		let dispatch = () => {
			throw new Error("Dispatching while constructing your middleware is not allowed. Other middleware would not be applied to this dispatch.");
		};
		const middlewareAPI = {
			getState: store.getState,
			dispatch: (action, ...args) => dispatch(action, ...args)
		};
		dispatch = compose(...middlewares.map((middleware) => middleware(middlewareAPI)))(store.dispatch);
		return {
			...store,
			dispatch
		};
	};
}
function isAction(action) {
	return isPlainObject(action) && "type" in action && typeof action.type === "string";
}
//#endregion
//#region node_modules/.pnpm/immer@11.1.21/node_modules/immer/dist/immer.mjs
var NOTHING = Symbol.for("immer-nothing");
var DRAFTABLE = Symbol.for("immer-draftable");
var DRAFT_STATE = Symbol.for("immer-state");
var errors = [
	function(plugin) {
		return `The plugin for '${plugin}' has not been loaded into Immer. To enable the plugin, import and call \`enable${plugin}()\` when initializing your application.`;
	},
	function(thing) {
		return `produce can only be called on things that are draftable: plain objects, arrays, Map, Set or classes that are marked with '[immerable]: true'. Got '${thing}'`;
	},
	"This object has been frozen and should not be mutated",
	function(data) {
		return "Cannot use a proxy that has been revoked. Did you pass an object from inside an immer function to an async process? " + data;
	},
	"An immer producer returned a new value *and* modified its draft. Either return a new value *or* modify the draft.",
	"Immer forbids circular references",
	"The first or second argument to `produce` must be a function",
	"The third argument to `produce` must be a function or undefined",
	"First argument to `createDraft` must be a plain object, an array, or an immerable object",
	"First argument to `finishDraft` must be a draft returned by `createDraft`",
	function(thing) {
		return `'current' expects a draft, got: ${thing}`;
	},
	"Object.defineProperty() cannot be used on an Immer draft",
	"Object.setPrototypeOf() cannot be used on an Immer draft",
	"Immer only supports deleting array indices",
	"Immer only supports setting array indices and the 'length' property",
	function(thing) {
		return `'original' expects a draft, got: ${thing}`;
	}
];
function die(error, ...args) {
	{
		const e = errors[error];
		const msg = isFunction(e) ? e.apply(null, args) : e;
		throw new Error(`[Immer] ${msg}`);
	}
}
var O = Object;
var getPrototypeOf = O.getPrototypeOf;
var CONSTRUCTOR = "constructor";
var PROTOTYPE = "prototype";
var CONFIGURABLE = "configurable";
var ENUMERABLE = "enumerable";
var WRITABLE = "writable";
var VALUE = "value";
var isDraft = (value) => !!value && !!value[DRAFT_STATE];
function isDraftable(value) {
	if (!value) return false;
	return isPlainObject$1(value) || isArray(value) || !!value[DRAFTABLE] || !!value[CONSTRUCTOR]?.[DRAFTABLE] || isMap(value) || isSet(value);
}
var objectCtorString = O[PROTOTYPE][CONSTRUCTOR].toString();
var cachedCtorStrings = /* @__PURE__ */ new WeakMap();
function isPlainObject$1(value) {
	if (!value || !isObjectish(value)) return false;
	const proto = getPrototypeOf(value);
	if (proto === null || proto === O[PROTOTYPE]) return true;
	const Ctor = O.hasOwnProperty.call(proto, CONSTRUCTOR) && proto[CONSTRUCTOR];
	if (Ctor === Object) return true;
	if (!isFunction(Ctor)) return false;
	let ctorString = cachedCtorStrings.get(Ctor);
	if (ctorString === void 0) {
		ctorString = Function.toString.call(Ctor);
		cachedCtorStrings.set(Ctor, ctorString);
	}
	return ctorString === objectCtorString;
}
function original(value) {
	if (!isDraft(value)) die(15, value);
	return value[DRAFT_STATE].base_;
}
function each(obj, iter, strict = true) {
	if (getArchtype(obj) === 0) (strict ? Reflect.ownKeys(obj) : O.keys(obj)).forEach((key) => {
		iter(key, obj[key], obj);
	});
	else obj.forEach((entry, index) => iter(index, entry, obj));
}
function getArchtype(thing) {
	const state = thing[DRAFT_STATE];
	return state ? state.type_ : isArray(thing) ? 1 : isMap(thing) ? 2 : isSet(thing) ? 3 : 0;
}
var has = (thing, prop, type = getArchtype(thing)) => type === 2 ? thing.has(prop) : O[PROTOTYPE].hasOwnProperty.call(thing, prop);
var get = (thing, prop, type = getArchtype(thing)) => type === 2 ? thing.get(prop) : thing[prop];
var set = (thing, propOrOldValue, value, type = getArchtype(thing)) => {
	if (type === 2) thing.set(propOrOldValue, value);
	else if (type === 3) thing.add(value);
	else thing[propOrOldValue] = value;
};
function is(x, y) {
	if (x === y) return x !== 0 || 1 / x === 1 / y;
	else return x !== x && y !== y;
}
var isArray = Array.isArray;
var isMap = (target) => target instanceof Map;
var isSet = (target) => target instanceof Set;
var isObjectish = (target) => typeof target === "object";
var isFunction = (target) => typeof target === "function";
var isBoolean$1 = (target) => typeof target === "boolean";
function isArrayIndex(value) {
	const n = +value;
	return Number.isInteger(n) && String(n) === value;
}
var latest = (state) => state.copy_ || state.base_;
var getFinalValue = (state) => state.modified_ ? state.copy_ : state.base_;
function shallowCopy(base, strict) {
	if (isMap(base)) return new Map(base);
	if (isSet(base)) return new Set(base);
	if (isArray(base)) return Array[PROTOTYPE].slice.call(base);
	const isPlain = isPlainObject$1(base);
	if (strict === true || strict === "class_only" && !isPlain) {
		const descriptors = O.getOwnPropertyDescriptors(base);
		delete descriptors[DRAFT_STATE];
		let keys = Reflect.ownKeys(descriptors);
		for (let i = 0; i < keys.length; i++) {
			const key = keys[i];
			const desc = descriptors[key];
			if (desc[WRITABLE] === false) {
				desc[WRITABLE] = true;
				desc[CONFIGURABLE] = true;
			}
			if (desc.get || desc.set) descriptors[key] = {
				[CONFIGURABLE]: true,
				[WRITABLE]: true,
				[ENUMERABLE]: desc[ENUMERABLE],
				[VALUE]: base[key]
			};
		}
		return O.create(getPrototypeOf(base), descriptors);
	} else {
		const proto = getPrototypeOf(base);
		if (proto !== null && isPlain) return { ...base };
		const obj = O.create(proto);
		return O.assign(obj, base);
	}
}
function freeze(obj, deep = false) {
	if (isFrozen(obj) || isDraft(obj) || !isDraftable(obj)) return obj;
	if (getArchtype(obj) > 1) O.defineProperties(obj, {
		set: dontMutateMethodOverride,
		add: dontMutateMethodOverride,
		clear: dontMutateMethodOverride,
		delete: dontMutateMethodOverride
	});
	O.freeze(obj);
	if (deep) each(obj, (_key, value) => {
		freeze(value, true);
	}, false);
	return obj;
}
function dontMutateFrozenCollections() {
	die(2);
}
var dontMutateMethodOverride = { [VALUE]: dontMutateFrozenCollections };
function isFrozen(obj) {
	if (obj === null || !isObjectish(obj)) return true;
	return O.isFrozen(obj);
}
var PluginMapSet = "MapSet";
var PluginPatches = "Patches";
var PluginArrayMethods = "ArrayMethods";
var plugins = {};
function getPlugin(pluginKey) {
	const plugin = plugins[pluginKey];
	if (!plugin) die(0, pluginKey);
	return plugin;
}
var isPluginLoaded = (pluginKey) => !!plugins[pluginKey];
var currentScope;
var getCurrentScope = () => currentScope;
var createScope = (parent_, immer_) => ({
	drafts_: [],
	parent_,
	immer_,
	canAutoFreeze_: true,
	unfinalizedDrafts_: 0,
	handledSet_: /* @__PURE__ */ new Set(),
	processedForPatches_: /* @__PURE__ */ new Set(),
	mapSetPlugin_: isPluginLoaded(PluginMapSet) ? getPlugin(PluginMapSet) : void 0,
	arrayMethodsPlugin_: isPluginLoaded(PluginArrayMethods) ? getPlugin(PluginArrayMethods) : void 0
});
function usePatchesInScope(scope, patchListener) {
	if (patchListener) {
		scope.patchPlugin_ = getPlugin(PluginPatches);
		scope.patches_ = [];
		scope.inversePatches_ = [];
		scope.patchListener_ = patchListener;
	}
}
function revokeScope(scope) {
	leaveScope(scope);
	scope.drafts_.forEach(revokeDraft);
	scope.drafts_ = null;
}
function leaveScope(scope) {
	if (scope === currentScope) currentScope = scope.parent_;
}
var enterScope = (immer2) => currentScope = createScope(currentScope, immer2);
function revokeDraft(draft) {
	const state = draft[DRAFT_STATE];
	if (state.type_ === 0 || state.type_ === 1) state.revoke_();
	else state.revoked_ = true;
}
function processResult(result, scope) {
	scope.unfinalizedDrafts_ = scope.drafts_.length;
	const baseDraft = scope.drafts_[0];
	if (result !== void 0 && result !== baseDraft) {
		if (baseDraft[DRAFT_STATE].modified_) {
			revokeScope(scope);
			die(4);
		}
		if (isDraftable(result)) result = finalize(scope, result);
		const { patchPlugin_ } = scope;
		if (patchPlugin_) patchPlugin_.generateReplacementPatches_(baseDraft[DRAFT_STATE].base_, result, scope);
	} else result = finalize(scope, baseDraft);
	maybeFreeze(scope, result, true);
	revokeScope(scope);
	if (scope.patches_) scope.patchListener_(scope.patches_, scope.inversePatches_);
	return result !== NOTHING ? result : void 0;
}
function finalize(rootScope, value) {
	if (isFrozen(value)) return value;
	const state = value[DRAFT_STATE];
	if (!state) return handleValue(value, rootScope.handledSet_, rootScope);
	if (!isSameScope(state, rootScope)) return value;
	if (!state.modified_) return state.base_;
	if (!state.finalized_) {
		const { callbacks_ } = state;
		if (callbacks_) while (callbacks_.length > 0) callbacks_.pop()(rootScope);
		generatePatchesAndFinalize(state, rootScope);
	}
	return state.copy_;
}
function maybeFreeze(scope, value, deep = false) {
	if (!scope.parent_ && scope.immer_.autoFreeze_ && scope.canAutoFreeze_) freeze(value, deep);
}
function markStateFinalized(state) {
	state.finalized_ = true;
	state.scope_.unfinalizedDrafts_--;
}
var isSameScope = (state, rootScope) => state.scope_ === rootScope;
var EMPTY_LOCATIONS_RESULT = [];
function updateDraftInParent(parent, draftValue, finalizedValue, originalKey) {
	const parentCopy = latest(parent);
	const parentType = parent.type_;
	if (originalKey !== void 0) {
		if (get(parentCopy, originalKey, parentType) === draftValue) {
			set(parentCopy, originalKey, finalizedValue, parentType);
			return;
		}
	}
	if (!parent.draftLocations_) {
		const draftLocations = parent.draftLocations_ = /* @__PURE__ */ new Map();
		each(parentCopy, (key, value) => {
			if (isDraft(value)) {
				const keys = draftLocations.get(value) || [];
				keys.push(key);
				draftLocations.set(value, keys);
			}
		});
	}
	const locations = parent.draftLocations_.get(draftValue) ?? EMPTY_LOCATIONS_RESULT;
	for (const location of locations) set(parentCopy, location, finalizedValue, parentType);
}
function registerChildFinalizationCallback(parent, child, key) {
	parent.callbacks_.push(function childCleanup(rootScope) {
		const state = child;
		if (!state || !isSameScope(state, rootScope)) return;
		rootScope.mapSetPlugin_?.fixSetContents(state);
		const finalizedValue = getFinalValue(state);
		updateDraftInParent(parent, state.draft_ ?? state, finalizedValue, key);
		generatePatchesAndFinalize(state, rootScope);
	});
}
function generatePatchesAndFinalize(state, rootScope) {
	if (state.modified_ && !state.finalized_ && (state.type_ === 3 || state.type_ === 1 && state.allIndicesReassigned_ || (state.assigned_?.size ?? 0) > 0)) {
		const { patchPlugin_ } = rootScope;
		if (patchPlugin_) {
			const basePath = patchPlugin_.getPath(state);
			if (basePath) patchPlugin_.generatePatches_(state, basePath, rootScope);
		}
		markStateFinalized(state);
	}
}
function handleCrossReference(target, key, value) {
	const { scope_ } = target;
	if (isDraft(value)) {
		const state = value[DRAFT_STATE];
		if (isSameScope(state, scope_)) state.callbacks_.push(function crossReferenceCleanup() {
			prepareCopy(target);
			updateDraftInParent(target, value, getFinalValue(state), key);
		});
	} else if (isDraftable(value)) target.callbacks_.push(function nestedDraftCleanup() {
		const targetCopy = latest(target);
		if (target.type_ === 3) {
			if (targetCopy.has(value)) handleValue(value, scope_.handledSet_, scope_);
		} else if (get(targetCopy, key, target.type_) === value) {
			if (scope_.drafts_.length > 1 && (target.assigned_.get(key) ?? false) === true && target.copy_) handleValue(get(target.copy_, key, target.type_), scope_.handledSet_, scope_);
		}
	});
}
function handleValue(target, handledSet, rootScope) {
	if (!rootScope.immer_.autoFreeze_ && rootScope.unfinalizedDrafts_ < 1) return target;
	if (isDraft(target) || handledSet.has(target) || !isDraftable(target) || isFrozen(target)) return target;
	handledSet.add(target);
	each(target, (key, value) => {
		if (isDraft(value)) {
			const state = value[DRAFT_STATE];
			if (isSameScope(state, rootScope)) {
				set(target, key, getFinalValue(state), target.type_);
				markStateFinalized(state);
			}
		} else if (isDraftable(value)) handleValue(value, handledSet, rootScope);
	});
	return target;
}
function createProxyProxy(base, parent) {
	const baseIsArray = isArray(base);
	const state = {
		type_: baseIsArray ? 1 : 0,
		scope_: parent ? parent.scope_ : getCurrentScope(),
		modified_: false,
		finalized_: false,
		assigned_: void 0,
		parent_: parent,
		base_: base,
		draft_: null,
		copy_: null,
		revoke_: null,
		isManual_: false,
		callbacks_: void 0
	};
	let target = state;
	let traps = objectTraps;
	if (baseIsArray) {
		target = [state];
		traps = arrayTraps;
	}
	const { revoke, proxy } = Proxy.revocable(target, traps);
	state.draft_ = proxy;
	state.revoke_ = revoke;
	return [proxy, state];
}
var objectTraps = {
	get(state, prop) {
		if (prop === DRAFT_STATE) return state;
		let arrayPlugin = state.scope_.arrayMethodsPlugin_;
		const isArrayWithStringProp = state.type_ === 1 && typeof prop === "string";
		if (isArrayWithStringProp) {
			if (arrayPlugin?.isArrayOperationMethod(prop)) return arrayPlugin.createMethodInterceptor(state, prop);
		}
		const source = latest(state);
		if (!has(source, prop, state.type_)) return readPropFromProto(state, source, prop);
		const value = source[prop];
		if (state.finalized_ || !isDraftable(value)) return value;
		if (isArrayWithStringProp && state.operationMethod && arrayPlugin?.isMutatingArrayMethod(state.operationMethod) && isArrayIndex(prop)) return value;
		if (value === peek(state.base_, prop) || isRelocatedBaseRef(state, prop, value)) {
			prepareCopy(state);
			const childKey = state.type_ === 1 ? +prop : prop;
			const childDraft = createProxy(state.scope_, value, state, childKey);
			return state.copy_[childKey] = childDraft;
		}
		return value;
	},
	has(state, prop) {
		return prop in latest(state);
	},
	ownKeys(state) {
		return Reflect.ownKeys(latest(state));
	},
	set(state, prop, value) {
		const desc = getDescriptorFromProto(latest(state), prop);
		if (desc?.set) {
			desc.set.call(state.draft_, value);
			return true;
		}
		if (!state.modified_) {
			const current2 = peek(latest(state), prop);
			const currentState = current2?.[DRAFT_STATE];
			if (currentState && currentState.base_ === value) {
				state.copy_[prop] = value;
				state.assigned_.delete(prop);
				return true;
			}
			if (is(value, current2) && (value !== void 0 || has(state.base_, prop, state.type_))) return true;
			prepareCopy(state);
			markChanged(state);
		}
		if (state.copy_[prop] === value && (value !== void 0 || has(state.copy_, prop, state.type_)) || Number.isNaN(value) && Number.isNaN(state.copy_[prop])) return true;
		state.copy_[prop] = value;
		state.assigned_.set(prop, true);
		handleCrossReference(state, prop, value);
		return true;
	},
	deleteProperty(state, prop) {
		prepareCopy(state);
		if (peek(state.base_, prop) !== void 0 || prop in state.base_) {
			state.assigned_.set(prop, false);
			markChanged(state);
		} else state.assigned_.delete(prop);
		if (state.copy_) delete state.copy_[prop];
		return true;
	},
	getOwnPropertyDescriptor(state, prop) {
		const owner = latest(state);
		const desc = Reflect.getOwnPropertyDescriptor(owner, prop);
		if (!desc) return desc;
		return {
			[WRITABLE]: true,
			[CONFIGURABLE]: state.type_ !== 1 || prop !== "length",
			[ENUMERABLE]: desc[ENUMERABLE],
			[VALUE]: owner[prop]
		};
	},
	defineProperty() {
		die(11);
	},
	getPrototypeOf(state) {
		return getPrototypeOf(state.base_);
	},
	setPrototypeOf() {
		die(12);
	}
};
var arrayTraps = {};
for (let key in objectTraps) {
	let fn = objectTraps[key];
	arrayTraps[key] = function() {
		const args = arguments;
		args[0] = args[0][0];
		return fn.apply(this, args);
	};
}
arrayTraps.deleteProperty = function(state, prop) {
	if (isNaN(parseInt(prop))) die(13);
	return arrayTraps.set.call(this, state, prop, void 0);
};
arrayTraps.set = function(state, prop, value) {
	if (prop !== "length" && isNaN(parseInt(prop))) die(14);
	return objectTraps.set.call(this, state[0], prop, value, state[0]);
};
function peek(draft, prop) {
	const state = draft[DRAFT_STATE];
	return (state ? latest(state) : draft)[prop];
}
function isRelocatedBaseRef(state, prop, value) {
	if (state.type_ !== 1 || !state.allIndicesReassigned_ || state.assigned_?.get(prop) || !isDraftable(value) || value[DRAFT_STATE]) return false;
	return state.baseRefs_.has(value);
}
function readPropFromProto(state, source, prop) {
	const desc = getDescriptorFromProto(source, prop);
	return desc ? VALUE in desc ? desc[VALUE] : desc.get?.call(state.draft_) : void 0;
}
function getDescriptorFromProto(source, prop) {
	if (!(prop in source)) return void 0;
	let proto = getPrototypeOf(source);
	while (proto) {
		const desc = Object.getOwnPropertyDescriptor(proto, prop);
		if (desc) return desc;
		proto = getPrototypeOf(proto);
	}
}
function markChanged(state) {
	if (!state.modified_) {
		state.modified_ = true;
		if (state.parent_) markChanged(state.parent_);
	}
}
function prepareCopy(state) {
	if (!state.copy_) {
		state.assigned_ = /* @__PURE__ */ new Map();
		state.copy_ = shallowCopy(state.base_, state.scope_.immer_.useStrictShallowCopy_);
	}
}
var Immer2 = class {
	constructor(config) {
		this.autoFreeze_ = true;
		this.useStrictShallowCopy_ = false;
		this.useStrictIteration_ = false;
		/**
		* The `produce` function takes a value and a "recipe function" (whose
		* return value often depends on the base state). The recipe function is
		* free to mutate its first argument however it wants. All mutations are
		* only ever applied to a __copy__ of the base state.
		*
		* Pass only a function to create a "curried producer" which relieves you
		* from passing the recipe function every time.
		*
		* Only plain objects and arrays are made mutable. All other objects are
		* considered uncopyable.
		*
		* Note: This function is __bound__ to its `Immer` instance.
		*
		* @param {any} base - the initial state
		* @param {Function} recipe - function that receives a proxy of the base state as first argument and which can be freely modified
		* @param {Function} patchListener - optional function that will be called with all the patches produced here
		* @returns {any} a new state, or the initial state if nothing was modified
		*/
		this.produce = (base, recipe, patchListener) => {
			if (isFunction(base) && !isFunction(recipe)) {
				const defaultBase = recipe;
				recipe = base;
				const self = this;
				return function curriedProduce(base2 = defaultBase, ...args) {
					return self.produce(base2, (draft) => recipe.call(this, draft, ...args));
				};
			}
			if (!isFunction(recipe)) die(6);
			if (patchListener !== void 0 && !isFunction(patchListener)) die(7);
			let result;
			if (isDraftable(base)) {
				const scope = enterScope(this);
				const proxy = createProxy(scope, base, void 0);
				let hasError = true;
				try {
					result = recipe(proxy);
					hasError = false;
				} finally {
					if (hasError) revokeScope(scope);
					else leaveScope(scope);
				}
				usePatchesInScope(scope, patchListener);
				return processResult(result, scope);
			} else if (!base || !isObjectish(base)) {
				result = recipe(base);
				if (result === void 0) result = base;
				if (result === NOTHING) result = void 0;
				if (this.autoFreeze_) freeze(result, true);
				if (patchListener) {
					const p = [];
					const ip = [];
					getPlugin(PluginPatches).generateReplacementPatches_(base, result, {
						patches_: p,
						inversePatches_: ip
					});
					patchListener(p, ip);
				}
				return result;
			} else die(1, base);
		};
		this.produceWithPatches = (base, recipe) => {
			if (isFunction(base)) return (state, ...args) => this.produceWithPatches(state, (draft) => base(draft, ...args));
			let patches, inversePatches;
			return [
				this.produce(base, recipe, (p, ip) => {
					patches = p;
					inversePatches = ip;
				}),
				patches,
				inversePatches
			];
		};
		if (isBoolean$1(config?.autoFreeze)) this.setAutoFreeze(config.autoFreeze);
		if (isBoolean$1(config?.useStrictShallowCopy)) this.setUseStrictShallowCopy(config.useStrictShallowCopy);
		if (isBoolean$1(config?.useStrictIteration)) this.setUseStrictIteration(config.useStrictIteration);
	}
	createDraft(base) {
		if (!isDraftable(base)) die(8);
		if (isDraft(base)) base = current(base);
		const scope = enterScope(this);
		const proxy = createProxy(scope, base, void 0);
		proxy[DRAFT_STATE].isManual_ = true;
		leaveScope(scope);
		return proxy;
	}
	finishDraft(draft, patchListener) {
		const state = draft && draft[DRAFT_STATE];
		if (!state || !state.isManual_) die(9);
		const { scope_: scope } = state;
		usePatchesInScope(scope, patchListener);
		return processResult(void 0, scope);
	}
	/**
	* Pass true to automatically freeze all copies created by Immer.
	*
	* By default, auto-freezing is enabled.
	*/
	setAutoFreeze(value) {
		this.autoFreeze_ = value;
	}
	/**
	* Pass true to enable strict shallow copy.
	*
	* By default, immer does not copy the object descriptors such as getter, setter and non-enumrable properties.
	*/
	setUseStrictShallowCopy(value) {
		this.useStrictShallowCopy_ = value;
	}
	/**
	* Pass false to use faster iteration that skips non-enumerable properties
	* but still handles symbols for compatibility.
	*
	* By default, strict iteration is enabled (includes all own properties).
	*/
	setUseStrictIteration(value) {
		this.useStrictIteration_ = value;
	}
	shouldUseStrictIteration() {
		return this.useStrictIteration_;
	}
	applyPatches(base, patches) {
		let i;
		for (i = patches.length - 1; i >= 0; i--) {
			const patch = patches[i];
			if (patch.path.length === 0 && patch.op === "replace") {
				base = patch.value;
				break;
			}
		}
		if (i > -1) patches = patches.slice(i + 1);
		const applyPatchesImpl = getPlugin(PluginPatches).applyPatches_;
		if (isDraft(base)) return applyPatchesImpl(base, patches);
		return this.produce(base, (draft) => applyPatchesImpl(draft, patches));
	}
};
function createProxy(rootScope, value, parent, key) {
	const [draft, state] = isMap(value) ? getPlugin(PluginMapSet).proxyMap_(value, parent) : isSet(value) ? getPlugin(PluginMapSet).proxySet_(value, parent) : createProxyProxy(value, parent);
	(parent?.scope_ ?? getCurrentScope()).drafts_.push(draft);
	state.callbacks_ = parent?.callbacks_ ?? [];
	state.key_ = key;
	if (parent && key !== void 0) registerChildFinalizationCallback(parent, state, key);
	else state.callbacks_.push(function rootDraftCleanup(rootScope2) {
		rootScope2.mapSetPlugin_?.fixSetContents(state);
		const { patchPlugin_ } = rootScope2;
		if (state.modified_ && patchPlugin_) patchPlugin_.generatePatches_(state, [], rootScope2);
	});
	return draft;
}
function current(value) {
	if (!isDraft(value)) die(10, value);
	return currentImpl(value);
}
function currentImpl(value) {
	if (!isDraftable(value) || isFrozen(value)) return value;
	const state = value[DRAFT_STATE];
	let copy;
	let strict = true;
	if (state) {
		if (!state.modified_) return state.base_;
		state.finalized_ = true;
		copy = shallowCopy(value, state.scope_.immer_.useStrictShallowCopy_);
		strict = state.scope_.immer_.shouldUseStrictIteration();
	} else copy = shallowCopy(value, true);
	each(copy, (key, childValue) => {
		set(copy, key, currentImpl(childValue));
	}, strict);
	if (state) state.finalized_ = false;
	return copy;
}
globalThis.Iterator?.from;
var produce = new Immer2().produce;
//#endregion
//#region node_modules/.pnpm/reselect@5.3.0/node_modules/reselect/dist/reselect.mjs
var CACHE_SIZE_CHECK_THRESHOLD = 1e3;
var runCacheSizeCheck = (cacheSize, funcName) => {
	let stack = void 0;
	try {
		throw new Error();
	} catch (e) {
		({stack} = e);
	}
	console.warn(`A function memoized with weakMapMemoize${funcName ? ` (\`${funcName}\`)` : ""} has seen over ${cacheSize} distinct values for the same primitive argument position.
Results keyed by primitive arguments are held strongly and are only released by \`clearCache()\`, so this cache will keep growing for as long as the function keeps seeing new values.
If it is called with ever-changing primitives (ids, offsets, timestamps), pass the \`maxSize\` option to bound the cache, switch to \`lruMemoize\`, or call \`.clearCache()\` at a suitable point.
See https://reselect.js.org/api/development-only-checks#cachesizecheck for details.`, { stack });
};
var globalDevModeChecks = {
	inputStabilityCheck: "once",
	identityFunctionCheck: "once",
	cacheSizeCheck: "once"
};
var StrongRef = class {
	constructor(value) {
		this.value = value;
	}
	deref() {
		return this.value;
	}
};
var getWeakRef = () => typeof WeakRef === "undefined" ? StrongRef : WeakRef;
var Ref = /* @__PURE__ */ getWeakRef();
var UNTERMINATED = 0;
var TERMINATED = 1;
function createCacheNode() {
	return {
		s: UNTERMINATED,
		v: void 0,
		o: null,
		p: null
	};
}
function maybeDeref(r) {
	if (r instanceof Ref) return r.deref();
	return r;
}
function weakMapMemoize(func, options = {}) {
	let fnNode = createCacheNode();
	const { resultEqualityCheck, maxSize } = options;
	const useGenerations = maxSize !== void 0;
	if (useGenerations && (!Number.isInteger(maxSize) || maxSize < 1)) throw new TypeError(`maxSize must be a positive integer, received: ${maxSize}`);
	let prevNode = null;
	let insertionCount = 0;
	let lastResult;
	let resultsCount = 0;
	let hasWarnedAboutCacheSize = false;
	function maybeFlipGenerations() {
		if (insertionCount >= maxSize) {
			prevNode = fnNode;
			fnNode = createCacheNode();
			insertionCount = 0;
		}
	}
	function memoized() {
		let cacheNode = fnNode;
		const { length } = arguments;
		for (let i = 0, l = length; i < l; i++) {
			const arg = arguments[i];
			if (typeof arg === "function" || typeof arg === "object" && arg !== null) {
				let objectCache = cacheNode.o;
				if (objectCache === null) cacheNode.o = objectCache = /* @__PURE__ */ new WeakMap();
				const objectNode = objectCache.get(arg);
				if (objectNode === void 0) {
					cacheNode = createCacheNode();
					objectCache.set(arg, cacheNode);
				} else cacheNode = objectNode;
			} else {
				let primitiveCache = cacheNode.p;
				if (primitiveCache === null) cacheNode.p = primitiveCache = /* @__PURE__ */ new Map();
				const primitiveNode = primitiveCache.get(arg);
				if (primitiveNode === void 0) {
					cacheNode = createCacheNode();
					primitiveCache.set(arg, cacheNode);
					insertionCount++;
					if (primitiveCache.size > CACHE_SIZE_CHECK_THRESHOLD) {
						const { cacheSizeCheck } = globalDevModeChecks;
						if (cacheSizeCheck === "always" || cacheSizeCheck === "once" && !hasWarnedAboutCacheSize) {
							hasWarnedAboutCacheSize = true;
							runCacheSizeCheck(primitiveCache.size, func.name);
						}
					}
				} else cacheNode = primitiveNode;
			}
		}
		if (cacheNode.s === TERMINATED) return cacheNode.v;
		if (prevNode !== null) {
			let prevCacheNode = prevNode;
			for (let i = 0, l = length; i < l; i++) {
				const arg = arguments[i];
				let next;
				if (typeof arg === "function" || typeof arg === "object" && arg !== null) {
					const prevObjectCache = prevCacheNode.o;
					next = prevObjectCache !== null ? prevObjectCache.get(arg) : void 0;
				} else {
					const prevPrimitiveCache = prevCacheNode.p;
					next = prevPrimitiveCache !== null ? prevPrimitiveCache.get(arg) : void 0;
				}
				if (next === void 0) {
					prevCacheNode = null;
					break;
				}
				prevCacheNode = next;
			}
			if (prevCacheNode !== null && prevCacheNode.s === TERMINATED) {
				const promotedNode = cacheNode;
				promotedNode.s = TERMINATED;
				promotedNode.v = prevCacheNode.v;
				maybeFlipGenerations();
				return prevCacheNode.v;
			}
		}
		const terminatedNode = cacheNode;
		let result = func.apply(null, arguments);
		resultsCount++;
		if (resultEqualityCheck) {
			const lastResultValue = maybeDeref(lastResult);
			if (lastResultValue != null && resultEqualityCheck(lastResultValue, result)) {
				result = lastResultValue;
				resultsCount !== 0 && resultsCount--;
			}
			lastResult = typeof result === "object" && result !== null || typeof result === "function" ? /* @__PURE__ */ new Ref(result) : result;
		}
		terminatedNode.s = TERMINATED;
		terminatedNode.v = result;
		if (useGenerations) maybeFlipGenerations();
		return result;
	}
	memoized.clearCache = () => {
		fnNode = createCacheNode();
		prevNode = null;
		insertionCount = 0;
		memoized.resetResultsCount();
		hasWarnedAboutCacheSize = false;
	};
	memoized.resultsCount = () => resultsCount;
	memoized.resetResultsCount = () => {
		resultsCount = 0;
	};
	return memoized;
}
var runIdentityFunctionCheck = (resultFunc, inputSelectorsResults, outputSelectorResult) => {
	if (inputSelectorsResults.length === 1 && inputSelectorsResults[0] === outputSelectorResult) {
		let isInputSameAsOutput = false;
		try {
			const emptyObject = {};
			if (resultFunc(emptyObject) === emptyObject) isInputSameAsOutput = true;
		} catch {}
		if (isInputSameAsOutput) {
			let stack = void 0;
			try {
				throw new Error();
			} catch (e) {
				({stack} = e);
			}
			console.warn("The result function returned its own inputs without modification. e.g\n`createSelector([state => state.todos], todos => todos)`\nThis could lead to inefficient memoization and unnecessary re-renders.\nEnsure transformation logic is in the result function, and extraction logic is in the input selectors.", { stack });
		}
	}
};
var withoutResultEqualityCheck = (option) => {
	if (option === null || typeof option !== "object" || !("resultEqualityCheck" in option)) return option;
	const optionCopy = { ...option };
	delete optionCopy.resultEqualityCheck;
	return optionCopy;
};
var runInputStabilityCheck = (inputSelectorResultsObject, options, inputSelectorArgs) => {
	const { memoize, memoizeOptions } = options;
	const { inputSelectorResults, inputSelectorResultsCopy } = inputSelectorResultsObject;
	const probeMemoizeOptions = [];
	const { length } = memoizeOptions;
	for (let i = 0; i < length; i++) probeMemoizeOptions.push(withoutResultEqualityCheck(memoizeOptions[i]));
	const createAnEmptyObject = memoize(() => ({}), ...probeMemoizeOptions);
	if (!(createAnEmptyObject.apply(null, inputSelectorResults) === createAnEmptyObject.apply(null, inputSelectorResultsCopy))) {
		let stack = void 0;
		try {
			throw new Error();
		} catch (e) {
			({stack} = e);
		}
		console.warn("An input selector returned a different result when passed same arguments.\nThis means your output selector will likely run more frequently than intended.\nAvoid returning a new reference inside your input selector, e.g.\n`createSelector([state => state.todos.map(todo => todo.id)], todoIds => todoIds.length)`", {
			arguments: inputSelectorArgs,
			firstInputs: inputSelectorResults,
			secondInputs: inputSelectorResultsCopy,
			stack
		});
	}
};
var NOT_FOUND = /* @__PURE__ */ Symbol("NOT_FOUND");
function assertIsFunction(func, errorMessage = `expected a function, instead received ${typeof func}`) {
	if (typeof func !== "function") throw new TypeError(errorMessage);
}
function assertIsArrayOfFunctions(array, errorMessage = `expected all items to be functions, instead received the following types: `) {
	if (!array.every((item) => typeof item === "function")) {
		const itemTypes = array.map((item) => typeof item === "function" ? `function ${item.name || "unnamed"}()` : typeof item).join(", ");
		throw new TypeError(`${errorMessage}[${itemTypes}]`);
	}
}
var ensureIsArray = (item) => {
	return Array.isArray(item) ? item : [item];
};
function getDependencies(createSelectorArgs) {
	const dependencies = Array.isArray(createSelectorArgs[0]) ? createSelectorArgs[0] : createSelectorArgs;
	assertIsArrayOfFunctions(dependencies, `createSelector expects all input-selectors to be functions, but received the following types: `);
	return dependencies;
}
function collectInputSelectorResults(dependencies, inputSelectorArgs) {
	const inputSelectorResults = [];
	const { length } = dependencies;
	for (let i = 0; i < length; i++) inputSelectorResults.push(dependencies[i].apply(null, inputSelectorArgs));
	return inputSelectorResults;
}
function createSelectorCreator(memoizeOrOptions, ...memoizeOptionsFromArgs) {
	const createSelectorCreatorOptions = typeof memoizeOrOptions === "function" ? {
		memoize: memoizeOrOptions,
		memoizeOptions: memoizeOptionsFromArgs
	} : memoizeOrOptions;
	const createSelector2 = (...createSelectorArgs) => {
		let recomputations = 0;
		let dependencyRecomputations = 0;
		let lastResult;
		let directlyPassedOptions = {};
		let resultFunc = createSelectorArgs.pop();
		if (typeof resultFunc === "object") {
			directlyPassedOptions = resultFunc;
			resultFunc = createSelectorArgs.pop();
		}
		assertIsFunction(resultFunc, `createSelector expects an output function after the inputs, but received: [${typeof resultFunc}]`);
		const combinedOptions = {
			...createSelectorCreatorOptions,
			...directlyPassedOptions
		};
		const { memoize, memoizeOptions = [], argsMemoize = weakMapMemoize, argsMemoizeOptions = [] } = combinedOptions;
		const finalMemoizeOptions = ensureIsArray(memoizeOptions);
		const finalArgsMemoizeOptions = ensureIsArray(argsMemoizeOptions);
		const dependencies = getDependencies(createSelectorArgs);
		const memoizedResultFunc = memoize(function recomputationWrapper() {
			recomputations++;
			return resultFunc.apply(null, arguments);
		}, ...finalMemoizeOptions);
		let firstRun = true;
		const selector = argsMemoize(function dependenciesChecker() {
			dependencyRecomputations++;
			const { length } = dependencies;
			const inputSelectorResults = new Array(length);
			for (let i = 0; i < length; i++) inputSelectorResults[i] = dependencies[i].apply(null, arguments);
			lastResult = memoizedResultFunc.apply(null, inputSelectorResults);
			{
				const { devModeChecks } = combinedOptions;
				const identityFunctionCheck = devModeChecks !== void 0 && Object.prototype.hasOwnProperty.call(devModeChecks, "identityFunctionCheck") ? devModeChecks.identityFunctionCheck : globalDevModeChecks.identityFunctionCheck;
				const inputStabilityCheck = devModeChecks !== void 0 && Object.prototype.hasOwnProperty.call(devModeChecks, "inputStabilityCheck") ? devModeChecks.inputStabilityCheck : globalDevModeChecks.inputStabilityCheck;
				if (identityFunctionCheck === "always" || identityFunctionCheck === "once" && firstRun) runIdentityFunctionCheck(resultFunc, inputSelectorResults, lastResult);
				if (inputStabilityCheck === "always" || inputStabilityCheck === "once" && firstRun) runInputStabilityCheck({
					inputSelectorResults,
					inputSelectorResultsCopy: collectInputSelectorResults(dependencies, arguments)
				}, {
					memoize,
					memoizeOptions: finalMemoizeOptions
				}, arguments);
				if (firstRun) firstRun = false;
			}
			return lastResult;
		}, ...finalArgsMemoizeOptions);
		return Object.assign(selector, {
			resultFunc,
			memoizedResultFunc,
			dependencies,
			dependencyRecomputations: () => dependencyRecomputations,
			resetDependencyRecomputations: () => {
				dependencyRecomputations = 0;
			},
			lastResult: () => lastResult,
			recomputations: () => recomputations,
			resetRecomputations: () => {
				recomputations = 0;
			},
			memoize,
			argsMemoize
		});
	};
	Object.assign(createSelector2, { withTypes: () => createSelector2 });
	return createSelector2;
}
var createSelector = /* @__PURE__ */ createSelectorCreator(weakMapMemoize);
function createSingletonCache(equals) {
	let entry;
	return {
		get(key) {
			if (entry && equals(entry.key, key)) return entry.value;
			return NOT_FOUND;
		},
		put(key, value) {
			entry = {
				key,
				value
			};
		},
		findMatchingEntry(value, resultEqualityCheck) {
			const current = entry;
			return current !== void 0 && resultEqualityCheck(current.value, value) ? current : void 0;
		},
		clear() {
			entry = void 0;
		}
	};
}
function createLruCache(maxSize, equals) {
	let entries = [];
	function get(key) {
		const cacheIndex = entries.findIndex((entry) => equals(entry.key, key));
		if (cacheIndex > -1) {
			const entry = entries[cacheIndex];
			if (cacheIndex > 0) {
				entries.splice(cacheIndex, 1);
				entries.unshift(entry);
			}
			return entry.value;
		}
		return NOT_FOUND;
	}
	function put(key, value) {
		entries.unshift({
			key,
			value
		});
		if (entries.length > maxSize) entries.pop();
	}
	function findMatchingEntry(value, resultEqualityCheck) {
		const currentEntries = entries;
		const { length } = currentEntries;
		for (let i = 0; i < length; i++) {
			const entry = currentEntries[i];
			if (resultEqualityCheck(entry.value, value)) return entry;
		}
	}
	function clear() {
		entries = [];
	}
	return {
		get,
		put,
		findMatchingEntry,
		clear
	};
}
var referenceEqualityCheck = (a, b) => a === b;
function createCacheKeyComparator(equalityCheck) {
	return function areArgumentsShallowlyEqual(prev, next) {
		if (prev === null || next === null || prev.length !== next.length) return false;
		const { length } = prev;
		for (let i = 0; i < length; i++) if (!equalityCheck(prev[i], next[i])) return false;
		return true;
	};
}
function lruMemoize(func, equalityCheckOrOptions) {
	const { equalityCheck = referenceEqualityCheck, maxSize = 1, resultEqualityCheck } = typeof equalityCheckOrOptions === "object" ? equalityCheckOrOptions : { equalityCheck: equalityCheckOrOptions };
	const comparator = createCacheKeyComparator(equalityCheck);
	let resultsCount = 0;
	const cache = maxSize <= 1 ? createSingletonCache(comparator) : createLruCache(maxSize, comparator);
	function memoized() {
		let value = cache.get(arguments);
		if (value === NOT_FOUND) {
			value = func.apply(null, arguments);
			resultsCount++;
			if (resultEqualityCheck) {
				const matchingEntry = cache.findMatchingEntry(value, resultEqualityCheck);
				if (matchingEntry) {
					value = matchingEntry.value;
					resultsCount !== 0 && resultsCount--;
				}
			}
			cache.put(arguments, value);
		}
		return value;
	}
	memoized.clearCache = () => {
		cache.clear();
		memoized.resetResultsCount();
	};
	memoized.resultsCount = () => resultsCount;
	memoized.resetResultsCount = () => {
		resultsCount = 0;
	};
	return memoized;
}
//#endregion
//#region node_modules/.pnpm/redux-thunk@3.1.0_redux@5.0.1/node_modules/redux-thunk/dist/redux-thunk.mjs
function createThunkMiddleware(extraArgument) {
	const middleware = ({ dispatch, getState }) => (next) => (action) => {
		if (typeof action === "function") return action(dispatch, getState, extraArgument);
		return next(action);
	};
	return middleware;
}
var thunk = createThunkMiddleware();
var withExtraArgument = createThunkMiddleware;
//#endregion
//#region node_modules/.pnpm/@reduxjs+toolkit@2.13.0_rea_4554d8decdd5aae16255f673b19e1c5d/node_modules/@reduxjs/toolkit/dist/redux-toolkit.modern.mjs
var createDraftSafeSelectorCreator = (...args) => {
	const createSelector = createSelectorCreator(...args);
	const createDraftSafeSelector = Object.assign((...args) => {
		const selector = createSelector(...args);
		const wrappedSelector = (value, ...rest) => selector(isDraft(value) ? current(value) : value, ...rest);
		Object.assign(wrappedSelector, selector);
		return wrappedSelector;
	}, { withTypes: () => createDraftSafeSelector });
	return createDraftSafeSelector;
};
var createDraftSafeSelector = /* @__PURE__ */ createDraftSafeSelectorCreator(weakMapMemoize);
var composeWithDevTools = typeof window !== "undefined" && window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ ? window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ : function() {
	if (arguments.length === 0) return void 0;
	if (typeof arguments[0] === "object") return compose;
	return compose.apply(null, arguments);
};
typeof window !== "undefined" && window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__;
var hasMatchFunction = (v) => {
	return v && typeof v.match === "function";
};
function createAction(type, prepareAction) {
	function actionCreator(...args) {
		if (prepareAction) {
			let prepared = prepareAction(...args);
			if (!prepared) throw new Error("prepareAction did not return an object");
			return {
				type,
				payload: prepared.payload,
				..."meta" in prepared && { meta: prepared.meta },
				..."error" in prepared && { error: prepared.error }
			};
		}
		return {
			type,
			payload: args[0]
		};
	}
	actionCreator.toString = () => `${type}`;
	actionCreator.type = type;
	actionCreator.match = (action) => isAction(action) && action.type === type;
	return actionCreator;
}
function isActionCreator(action) {
	return typeof action === "function" && "type" in action && hasMatchFunction(action);
}
function isFSA(action) {
	return isAction(action) && Object.keys(action).every(isValidKey);
}
function isValidKey(key) {
	return [
		"type",
		"payload",
		"error",
		"meta"
	].indexOf(key) > -1;
}
function getMessage(type) {
	const splitType = type ? `${type}`.split("/") : [];
	const actionName = splitType[splitType.length - 1] || "actionCreator";
	return `Detected an action creator with type "${type || "unknown"}" being dispatched.
Make sure you're calling the action creator before dispatching, i.e. \`dispatch(${actionName}())\` instead of \`dispatch(${actionName})\`. This is necessary even if the action has no payload.`;
}
function createActionCreatorInvariantMiddleware(options = {}) {
	const { isActionCreator: isActionCreator$1 = isActionCreator } = options;
	return () => (next) => (action) => {
		if (isActionCreator$1(action)) console.warn(getMessage(action.type));
		return next(action);
	};
}
function getTimeMeasureUtils(maxDelay, fnName) {
	let elapsed = 0;
	return {
		measureTime(fn) {
			const started = Date.now();
			try {
				return fn();
			} finally {
				elapsed += Date.now() - started;
			}
		},
		warnIfExceeded() {
			if (elapsed > maxDelay) console.warn(`${fnName} took ${elapsed}ms, which is more than the warning threshold of ${maxDelay}ms. 
If your state or actions are very large, you may want to disable the middleware as it might cause too much of a slowdown in development mode. See https://redux-toolkit.js.org/api/getDefaultMiddleware for instructions.
It is disabled in production builds, so you don't need to worry about that.`);
		}
	};
}
var Tuple = class Tuple extends Array {
	constructor(...items) {
		super(...items);
		Object.setPrototypeOf(this, Tuple.prototype);
	}
	static get [Symbol.species]() {
		return Tuple;
	}
	concat(...arr) {
		return super.concat.apply(this, arr);
	}
	prepend(...arr) {
		if (arr.length === 1 && Array.isArray(arr[0])) return new Tuple(...arr[0].concat(this));
		return new Tuple(...arr.concat(this));
	}
};
function freezeDraftable(val) {
	return isDraftable(val) ? produce(val, () => {}) : val;
}
function getOrInsertComputed(map, key, compute) {
	if (map.has(key)) return map.get(key);
	return map.set(key, compute(key)).get(key);
}
function isImmutableDefault(value) {
	return typeof value !== "object" || value == null || Object.isFrozen(value);
}
function trackForMutations(isImmutable, ignoredPaths, obj) {
	const trackedProperties = trackProperties(isImmutable, ignoredPaths, obj);
	return { detectMutations() {
		return detectMutations(isImmutable, ignoredPaths, trackedProperties, obj);
	} };
}
function trackProperties(isImmutable, ignoredPaths = [], obj, path = "", inProgress = /* @__PURE__ */ new Map()) {
	const tracked = { value: obj };
	if (!isImmutable(obj)) {
		const alreadyInProgress = inProgress.get(obj);
		if (alreadyInProgress) return alreadyInProgress;
		tracked.children = {};
		inProgress.set(obj, tracked);
		const hasIgnoredPaths = ignoredPaths.length > 0;
		for (const key in obj) {
			const nestedPath = path ? path + "." + key : key;
			if (hasIgnoredPaths) {
				if (ignoredPaths.some((ignored) => {
					if (ignored instanceof RegExp) return ignored.test(nestedPath);
					return nestedPath === ignored;
				})) continue;
			}
			tracked.children[key] = trackProperties(isImmutable, ignoredPaths, obj[key], nestedPath, inProgress);
		}
		inProgress.delete(obj);
	}
	return tracked;
}
function detectMutations(isImmutable, ignoredPaths = [], trackedProperty, obj, sameParentRef = false, path = "", seen = /* @__PURE__ */ new Map()) {
	const prevObj = trackedProperty ? trackedProperty.value : void 0;
	const sameRef = prevObj === obj;
	if (sameParentRef && !sameRef && !Number.isNaN(obj)) return {
		wasMutated: true,
		path
	};
	if (isImmutable(prevObj) || isImmutable(obj)) return { wasMutated: false };
	let seenValues = seen.get(trackedProperty);
	if (!seenValues) {
		seenValues = /* @__PURE__ */ new Set();
		seen.set(trackedProperty, seenValues);
	} else if (seenValues.has(obj)) return { wasMutated: false };
	seenValues.add(obj);
	const keysToDetect = {};
	for (let key in trackedProperty.children) keysToDetect[key] = true;
	for (let key in obj) keysToDetect[key] = true;
	const hasIgnoredPaths = ignoredPaths.length > 0;
	for (let key in keysToDetect) {
		const nestedPath = path ? path + "." + key : key;
		if (hasIgnoredPaths) {
			if (ignoredPaths.some((ignored) => {
				if (ignored instanceof RegExp) return ignored.test(nestedPath);
				return nestedPath === ignored;
			})) continue;
		}
		const result = detectMutations(isImmutable, ignoredPaths, trackedProperty.children[key], obj[key], sameRef, nestedPath, seen);
		if (result.wasMutated) return result;
	}
	return { wasMutated: false };
}
function createImmutableStateInvariantMiddleware(options = {}) {
	{
		function stringify(obj, serializer, indent, decycler) {
			return JSON.stringify(obj, getSerialize(serializer, decycler), indent);
		}
		function getSerialize(serializer, decycler) {
			let stack = [], keys = [];
			if (!decycler) decycler = function(_, value) {
				if (stack[0] === value) return "[Circular ~]";
				return "[Circular ~." + keys.slice(0, stack.indexOf(value)).join(".") + "]";
			};
			return function(key, value) {
				if (stack.length > 0) {
					var thisPos = stack.indexOf(this);
					if (~thisPos) {
						stack.splice(thisPos + 1);
						keys.splice(thisPos, Infinity, key);
					} else {
						stack.push(this);
						keys.push(key);
					}
					if (~stack.indexOf(value)) value = decycler.call(this, key, value);
				} else stack.push(value);
				return serializer == null ? value : serializer.call(this, key, value);
			};
		}
		let { isImmutable = isImmutableDefault, ignoredPaths, warnAfter = 32 } = options;
		const track = trackForMutations.bind(null, isImmutable, ignoredPaths);
		return ({ getState }) => {
			let state = getState();
			let tracker = track(state);
			let result;
			return (next) => (action) => {
				const measureUtils = getTimeMeasureUtils(warnAfter, "ImmutableStateInvariantMiddleware");
				measureUtils.measureTime(() => {
					state = getState();
					result = tracker.detectMutations();
					tracker = track(state);
					if (result.wasMutated) throw new Error(`A state mutation was detected between dispatches, in the path '${result.path || ""}'.  This may cause incorrect behavior. (https://redux.js.org/style-guide/style-guide#do-not-mutate-state)`);
				});
				const dispatchedAction = next(action);
				measureUtils.measureTime(() => {
					state = getState();
					result = tracker.detectMutations();
					tracker = track(state);
					if (result.wasMutated) throw new Error(`A state mutation was detected inside a dispatch, in the path: ${result.path || ""}. Take a look at the reducer(s) handling the action ${stringify(action)}. (https://redux.js.org/style-guide/style-guide#do-not-mutate-state)`);
				});
				measureUtils.warnIfExceeded();
				return dispatchedAction;
			};
		};
	}
}
function isPlain(val) {
	const type = typeof val;
	return val == null || type === "string" || type === "boolean" || type === "number" || Array.isArray(val) || isPlainObject(val);
}
function findNonSerializableValue(value, path = "", isSerializable = isPlain, getEntries, ignoredPaths = [], cache) {
	let foundNestedSerializable;
	if (!isSerializable(value)) return {
		keyPath: path || "<root>",
		value
	};
	if (typeof value !== "object" || value === null) return false;
	if (cache?.has(value)) return false;
	const entries = getEntries != null ? getEntries(value) : Object.entries(value);
	const hasIgnoredPaths = ignoredPaths.length > 0;
	for (const [key, nestedValue] of entries) {
		const nestedPath = path ? path + "." + key : key;
		if (hasIgnoredPaths) {
			if (ignoredPaths.some((ignored) => {
				if (ignored instanceof RegExp) return ignored.test(nestedPath);
				return nestedPath === ignored;
			})) continue;
		}
		if (!isSerializable(nestedValue)) return {
			keyPath: nestedPath,
			value: nestedValue
		};
		if (typeof nestedValue === "object") {
			foundNestedSerializable = findNonSerializableValue(nestedValue, nestedPath, isSerializable, getEntries, ignoredPaths, cache);
			if (foundNestedSerializable) return foundNestedSerializable;
		}
	}
	if (cache && isNestedFrozen(value)) cache.add(value);
	return false;
}
function isNestedFrozen(value) {
	if (!Object.isFrozen(value)) return false;
	for (const nestedValue of Object.values(value)) {
		if (typeof nestedValue !== "object" || nestedValue === null) continue;
		if (!isNestedFrozen(nestedValue)) return false;
	}
	return true;
}
function createSerializableStateInvariantMiddleware(options = {}) {
	{
		const { isSerializable = isPlain, getEntries, ignoredActions = [], ignoredActionPaths = ["meta.arg", "meta.baseQueryMeta"], ignoredPaths = [], warnAfter = 32, ignoreState = false, ignoreActions = false, disableCache = false } = options;
		const cache = !disableCache && WeakSet ? /* @__PURE__ */ new WeakSet() : void 0;
		return (storeAPI) => (next) => (action) => {
			if (!isAction(action)) return next(action);
			const result = next(action);
			const measureUtils = getTimeMeasureUtils(warnAfter, "SerializableStateInvariantMiddleware");
			if (!ignoreActions && !(ignoredActions.length && ignoredActions.indexOf(action.type) !== -1)) measureUtils.measureTime(() => {
				const foundActionNonSerializableValue = findNonSerializableValue(action, "", isSerializable, getEntries, ignoredActionPaths, cache);
				if (foundActionNonSerializableValue) {
					const { keyPath, value } = foundActionNonSerializableValue;
					console.error(`A non-serializable value was detected in an action, in the path: \`${keyPath}\`. Value:`, value, "\nTake a look at the logic that dispatched this action: ", action, "\n(See https://redux.js.org/faq/actions#why-should-type-be-a-string-why-should-my-action-types-be-constants)", "\n(To allow non-serializable values see: https://redux-toolkit.js.org/usage/usage-guide#working-with-non-serializable-data)");
				}
			});
			if (!ignoreState) {
				measureUtils.measureTime(() => {
					const foundStateNonSerializableValue = findNonSerializableValue(storeAPI.getState(), "", isSerializable, getEntries, ignoredPaths, cache);
					if (foundStateNonSerializableValue) {
						const { keyPath, value } = foundStateNonSerializableValue;
						console.error(`A non-serializable value was detected in the state, in the path: \`${keyPath}\`. Value:`, value, `
Take a look at the reducer(s) handling this action type: ${action.type}.
(See https://redux.js.org/faq/organizing-state#can-i-put-functions-promises-or-other-non-serializable-items-in-my-store-state)`);
					}
				});
				measureUtils.warnIfExceeded();
			}
			return result;
		};
	}
}
function isBoolean(x) {
	return typeof x === "boolean";
}
var buildGetDefaultMiddleware = () => function getDefaultMiddleware(options) {
	const { thunk: thunk$1 = true, immutableCheck = true, serializableCheck = true, actionCreatorCheck = true } = options ?? {};
	let middlewareArray = new Tuple();
	if (thunk$1) {
		if (isBoolean(thunk$1)) middlewareArray.push(thunk);
		else middlewareArray.push(withExtraArgument(thunk$1.extraArgument));
	}
	if (immutableCheck) {
		let immutableOptions = {};
		if (!isBoolean(immutableCheck)) immutableOptions = immutableCheck;
		middlewareArray.unshift(createImmutableStateInvariantMiddleware(immutableOptions));
	}
	if (serializableCheck) {
		let serializableOptions = {};
		if (!isBoolean(serializableCheck)) serializableOptions = serializableCheck;
		middlewareArray.push(createSerializableStateInvariantMiddleware(serializableOptions));
	}
	if (actionCreatorCheck) {
		let actionCreatorOptions = {};
		if (!isBoolean(actionCreatorCheck)) actionCreatorOptions = actionCreatorCheck;
		middlewareArray.unshift(createActionCreatorInvariantMiddleware(actionCreatorOptions));
	}
	return middlewareArray;
};
var SHOULD_AUTOBATCH = "RTK_autoBatch";
var prepareAutoBatched = () => (payload) => ({
	payload,
	meta: { [SHOULD_AUTOBATCH]: true }
});
var createQueueWithTimer = (timeout) => {
	return (notify) => {
		setTimeout(notify, timeout);
	};
};
var createRafWithFallbackTimer = (raf, timeout) => {
	return (notify) => {
		let called = false;
		let rafId;
		let timerId;
		const callback = () => {
			if (called) return;
			called = true;
			cancelAnimationFrame(rafId);
			clearTimeout(timerId);
			notify();
		};
		rafId = raf(callback);
		timerId = setTimeout(callback, timeout);
	};
};
var autoBatchEnhancer = (options = { type: "raf" }) => (next) => (...args) => {
	const store = next(...args);
	let notifying = true;
	let shouldNotifyAtEndOfTick = false;
	let notificationQueued = false;
	const listeners = /* @__PURE__ */ new Set();
	const queueCallback = options.type === "tick" ? queueMicrotask : options.type === "raf" ? typeof window !== "undefined" && window.requestAnimationFrame ? createRafWithFallbackTimer(window.requestAnimationFrame, 100) : createQueueWithTimer(10) : options.type === "callback" ? options.queueNotification : createQueueWithTimer(options.timeout);
	const notifyListeners = () => {
		notificationQueued = false;
		if (shouldNotifyAtEndOfTick) {
			shouldNotifyAtEndOfTick = false;
			listeners.forEach((l) => l());
		}
	};
	return Object.assign({}, store, {
		subscribe(listener) {
			const wrappedListener = () => notifying && listener();
			const unsubscribe = store.subscribe(wrappedListener);
			listeners.add(listener);
			return () => {
				unsubscribe();
				listeners.delete(listener);
			};
		},
		dispatch(action) {
			try {
				notifying = !action?.meta?.[SHOULD_AUTOBATCH];
				shouldNotifyAtEndOfTick = !notifying;
				if (shouldNotifyAtEndOfTick) {
					if (!notificationQueued) {
						notificationQueued = true;
						queueCallback(notifyListeners);
					}
				}
				return store.dispatch(action);
			} finally {
				notifying = true;
			}
		}
	});
};
var buildGetDefaultEnhancers = (middlewareEnhancer) => function getDefaultEnhancers(options) {
	const { autoBatch = true } = options ?? {};
	let enhancerArray = new Tuple(middlewareEnhancer);
	if (autoBatch) enhancerArray.push(autoBatchEnhancer(typeof autoBatch === "object" ? autoBatch : void 0));
	return enhancerArray;
};
function configureStore(options) {
	const getDefaultMiddleware = buildGetDefaultMiddleware();
	const { reducer = void 0, middleware, devTools = true, duplicateMiddlewareCheck = true, preloadedState = void 0, enhancers = void 0 } = options || {};
	let rootReducer;
	if (typeof reducer === "function") rootReducer = reducer;
	else if (isPlainObject(reducer)) rootReducer = combineReducers(reducer);
	else throw new Error("`reducer` is a required argument, and must be a function or an object of functions that can be passed to combineReducers");
	if (middleware && typeof middleware !== "function") throw new Error("`middleware` field must be a callback");
	let finalMiddleware;
	if (typeof middleware === "function") {
		finalMiddleware = middleware(getDefaultMiddleware);
		if (!Array.isArray(finalMiddleware)) throw new Error("when using a middleware builder function, an array of middleware must be returned");
	} else finalMiddleware = getDefaultMiddleware();
	if (finalMiddleware.some((item) => typeof item !== "function")) throw new Error("each middleware provided to configureStore must be a function");
	if (duplicateMiddlewareCheck) {
		let middlewareReferences = /* @__PURE__ */ new Set();
		finalMiddleware.forEach((middleware) => {
			if (middlewareReferences.has(middleware)) throw new Error("Duplicate middleware references found when creating the store. Ensure that each middleware is only included once.");
			middlewareReferences.add(middleware);
		});
	}
	let finalCompose = compose;
	if (devTools) finalCompose = composeWithDevTools({
		trace: true,
		...typeof devTools === "object" && devTools
	});
	const middlewareEnhancer = applyMiddleware(...finalMiddleware);
	const getDefaultEnhancers = buildGetDefaultEnhancers(middlewareEnhancer);
	if (enhancers && typeof enhancers !== "function") throw new Error("`enhancers` field must be a callback");
	let storeEnhancers = typeof enhancers === "function" ? enhancers(getDefaultEnhancers) : getDefaultEnhancers();
	if (!Array.isArray(storeEnhancers)) throw new Error("`enhancers` callback must return an array");
	if (storeEnhancers.some((item) => typeof item !== "function")) throw new Error("each enhancer provided to configureStore must be a function");
	if (finalMiddleware.length && !storeEnhancers.includes(middlewareEnhancer)) console.error("middlewares were provided, but middleware enhancer was not included in final enhancers - make sure to call `getDefaultEnhancers`");
	const composedEnhancer = finalCompose(...storeEnhancers);
	return createStore(rootReducer, preloadedState, composedEnhancer);
}
function executeReducerBuilderCallback(builderCallback) {
	const actionsMap = {};
	const actionMatchers = [];
	let defaultCaseReducer;
	const builder = {
		addCase(typeOrActionCreator, reducer) {
			if (actionMatchers.length > 0) throw new Error("`builder.addCase` should only be called before calling `builder.addMatcher`");
			if (defaultCaseReducer) throw new Error("`builder.addCase` should only be called before calling `builder.addDefaultCase`");
			const type = typeof typeOrActionCreator === "string" ? typeOrActionCreator : typeOrActionCreator.type;
			if (!type) throw new Error("`builder.addCase` cannot be called with an empty action type");
			if (type in actionsMap) throw new Error(`\`builder.addCase\` cannot be called with two reducers for the same action type '${type}'`);
			actionsMap[type] = reducer;
			return builder;
		},
		addAsyncThunk(asyncThunk, reducers) {
			if (defaultCaseReducer) throw new Error("`builder.addAsyncThunk` should only be called before calling `builder.addDefaultCase`");
			if (reducers.pending) actionsMap[asyncThunk.pending.type] = reducers.pending;
			if (reducers.rejected) actionsMap[asyncThunk.rejected.type] = reducers.rejected;
			if (reducers.fulfilled) actionsMap[asyncThunk.fulfilled.type] = reducers.fulfilled;
			if (reducers.settled) actionMatchers.push({
				matcher: asyncThunk.settled,
				reducer: reducers.settled
			});
			return builder;
		},
		addMatcher(matcher, reducer) {
			if (defaultCaseReducer) throw new Error("`builder.addMatcher` should only be called before calling `builder.addDefaultCase`");
			actionMatchers.push({
				matcher,
				reducer
			});
			return builder;
		},
		addDefaultCase(reducer) {
			if (defaultCaseReducer) throw new Error("`builder.addDefaultCase` can only be called once");
			defaultCaseReducer = reducer;
			return builder;
		}
	};
	builderCallback(builder);
	return [
		actionsMap,
		actionMatchers,
		defaultCaseReducer
	];
}
function isStateFunction(x) {
	return typeof x === "function";
}
function createReducer(initialState, mapOrBuilderCallback) {
	if (typeof mapOrBuilderCallback === "object") throw new Error("The object notation for `createReducer` has been removed. Please use the 'builder callback' notation instead: https://redux-toolkit.js.org/api/createReducer");
	let [actionsMap, finalActionMatchers, finalDefaultCaseReducer] = executeReducerBuilderCallback(mapOrBuilderCallback);
	let getInitialState;
	if (isStateFunction(initialState)) getInitialState = () => freezeDraftable(initialState());
	else {
		const frozenInitialState = freezeDraftable(initialState);
		getInitialState = () => frozenInitialState;
	}
	function reducer(state = getInitialState(), action) {
		let caseReducers = [actionsMap[action.type], ...finalActionMatchers.filter(({ matcher }) => matcher(action)).map(({ reducer }) => reducer)];
		if (caseReducers.filter((cr) => !!cr).length === 0) caseReducers = [finalDefaultCaseReducer];
		return caseReducers.reduce((previousState, caseReducer) => {
			if (caseReducer) {
				if (isDraft(previousState)) {
					const result = caseReducer(previousState, action);
					if (result === void 0) return previousState;
					return result;
				} else if (!isDraftable(previousState)) {
					const result = caseReducer(previousState, action);
					if (result === void 0) {
						if (previousState === null) return previousState;
						throw new Error("A case reducer on a non-draftable value must not return undefined");
					}
					return result;
				} else return produce(previousState, (draft) => {
					return caseReducer(draft, action);
				});
			}
			return previousState;
		}, state);
	}
	reducer.getInitialState = getInitialState;
	return reducer;
}
var matches = (matcher, action) => {
	if (hasMatchFunction(matcher)) return matcher.match(action);
	else return matcher(action);
};
function isAnyOf(...matchers) {
	return (action) => {
		return matchers.some((matcher) => matches(matcher, action));
	};
}
function isAllOf(...matchers) {
	return (action) => {
		return matchers.every((matcher) => matches(matcher, action));
	};
}
function hasExpectedRequestMetadata(action, validStatus) {
	if (!action || !action.meta) return false;
	const hasValidRequestId = typeof action.meta.requestId === "string";
	const hasValidRequestStatus = validStatus.indexOf(action.meta.requestStatus) > -1;
	return hasValidRequestId && hasValidRequestStatus;
}
function isAsyncThunkArray(a) {
	return typeof a[0] === "function" && "pending" in a[0] && "fulfilled" in a[0] && "rejected" in a[0];
}
function isPending(...asyncThunks) {
	if (asyncThunks.length === 0) return (action) => hasExpectedRequestMetadata(action, ["pending"]);
	if (!isAsyncThunkArray(asyncThunks)) return isPending()(asyncThunks[0]);
	return isAnyOf(...asyncThunks.map((asyncThunk) => asyncThunk.pending));
}
function isRejected(...asyncThunks) {
	if (asyncThunks.length === 0) return (action) => hasExpectedRequestMetadata(action, ["rejected"]);
	if (!isAsyncThunkArray(asyncThunks)) return isRejected()(asyncThunks[0]);
	return isAnyOf(...asyncThunks.map((asyncThunk) => asyncThunk.rejected));
}
function isRejectedWithValue(...asyncThunks) {
	const hasFlag = (action) => {
		return action && action.meta && action.meta.rejectedWithValue;
	};
	if (asyncThunks.length === 0) return isAllOf(isRejected(...asyncThunks), hasFlag);
	if (!isAsyncThunkArray(asyncThunks)) return isRejectedWithValue()(asyncThunks[0]);
	return isAllOf(isRejected(...asyncThunks), hasFlag);
}
function isFulfilled(...asyncThunks) {
	if (asyncThunks.length === 0) return (action) => hasExpectedRequestMetadata(action, ["fulfilled"]);
	if (!isAsyncThunkArray(asyncThunks)) return isFulfilled()(asyncThunks[0]);
	return isAnyOf(...asyncThunks.map((asyncThunk) => asyncThunk.fulfilled));
}
function isAsyncThunkAction(...asyncThunks) {
	if (asyncThunks.length === 0) return (action) => hasExpectedRequestMetadata(action, [
		"pending",
		"fulfilled",
		"rejected"
	]);
	if (!isAsyncThunkArray(asyncThunks)) return isAsyncThunkAction()(asyncThunks[0]);
	return isAnyOf(...asyncThunks.flatMap((asyncThunk) => [
		asyncThunk.pending,
		asyncThunk.rejected,
		asyncThunk.fulfilled
	]));
}
var urlAlphabet = "ModuleSymbhasOwnPr-0123456789ABCDEFGHNRVfgctiUvz_KqYTJkLxpZXIjQW";
var nanoid = (size = 21) => {
	let id = "";
	let i = size;
	while (i--) id += urlAlphabet[Math.random() * 64 | 0];
	return id;
};
var commonProperties = [
	"name",
	"message",
	"stack",
	"code"
];
var RejectWithValue = class {
	payload;
	meta;
	_type;
	constructor(payload, meta) {
		this.payload = payload;
		this.meta = meta;
	}
};
var FulfillWithMeta = class {
	payload;
	meta;
	_type;
	constructor(payload, meta) {
		this.payload = payload;
		this.meta = meta;
	}
};
var miniSerializeError = (value) => {
	if (typeof value === "object" && value !== null) {
		const simpleError = {};
		for (const property of commonProperties) if (typeof value[property] === "string") simpleError[property] = value[property];
		return simpleError;
	}
	return { message: String(value) };
};
var externalAbortMessage = "External signal was aborted";
var createAsyncThunk = /* @__PURE__ */ (() => {
	function createAsyncThunk(typePrefix, payloadCreator, options) {
		const fulfilled = createAction(typePrefix + "/fulfilled", (payload, requestId, arg, meta) => ({
			payload,
			meta: {
				...meta || {},
				arg,
				requestId,
				requestStatus: "fulfilled"
			}
		}));
		const pending = createAction(typePrefix + "/pending", (requestId, arg, meta) => ({
			payload: void 0,
			meta: {
				...meta || {},
				arg,
				requestId,
				requestStatus: "pending"
			}
		}));
		const rejected = createAction(typePrefix + "/rejected", (error, requestId, arg, payload, meta) => ({
			payload,
			error: (options && options.serializeError || miniSerializeError)(error || "Rejected"),
			meta: {
				...meta || {},
				arg,
				requestId,
				rejectedWithValue: payload !== void 0,
				requestStatus: "rejected",
				aborted: error?.name === "AbortError",
				condition: error?.name === "ConditionError"
			}
		}));
		function actionCreator(arg, { signal } = {}) {
			return (dispatch, getState, extra) => {
				const requestId = options?.idGenerator ? options.idGenerator(arg) : nanoid();
				const abortController = new AbortController();
				let abortHandler;
				let abortReason;
				function abort(reason) {
					abortReason = reason;
					abortController.abort();
				}
				if (signal) {
					if (signal.aborted) abort(externalAbortMessage);
					else signal.addEventListener("abort", () => abort(externalAbortMessage), { once: true });
				}
				const promise = async function() {
					let finalAction;
					try {
						let conditionResult = options?.condition?.(arg, {
							getState,
							extra
						});
						if (isThenable(conditionResult)) conditionResult = await conditionResult;
						if (conditionResult === false) throw {
							name: "ConditionError",
							message: "Aborted due to condition callback returning false."
						};
						if (abortController.signal.aborted) throw {
							name: "AbortError",
							message: abortReason || "Aborted"
						};
						const abortedPromise = new Promise((_, reject) => {
							abortHandler = () => {
								reject({
									name: "AbortError",
									message: abortReason || "Aborted"
								});
							};
							abortController.signal.addEventListener("abort", abortHandler, { once: true });
						});
						dispatch(pending(requestId, arg, options?.getPendingMeta?.({
							requestId,
							arg
						}, {
							getState,
							extra
						})));
						finalAction = await Promise.race([abortedPromise, Promise.resolve(payloadCreator(arg, {
							dispatch,
							getState,
							extra,
							requestId,
							signal: abortController.signal,
							abort,
							rejectWithValue: ((value, meta) => {
								return new RejectWithValue(value, meta);
							}),
							fulfillWithValue: ((value, meta) => {
								return new FulfillWithMeta(value, meta);
							})
						})).then((result) => {
							if (result instanceof RejectWithValue) throw result;
							if (result instanceof FulfillWithMeta) return fulfilled(result.payload, requestId, arg, result.meta);
							return fulfilled(result, requestId, arg);
						})]);
					} catch (err) {
						finalAction = err instanceof RejectWithValue ? rejected(null, requestId, arg, err.payload, err.meta) : rejected(err, requestId, arg);
					} finally {
						if (abortHandler) abortController.signal.removeEventListener("abort", abortHandler);
					}
					if (!(options && !options.dispatchConditionRejection && rejected.match(finalAction) && finalAction.meta.condition)) dispatch(finalAction);
					return finalAction;
				}();
				return Object.assign(promise, {
					abort,
					requestId,
					arg,
					unwrap() {
						return promise.then(unwrapResult);
					}
				});
			};
		}
		return Object.assign(actionCreator, {
			pending,
			rejected,
			fulfilled,
			settled: isAnyOf(rejected, fulfilled),
			typePrefix
		});
	}
	createAsyncThunk.withTypes = () => createAsyncThunk;
	return createAsyncThunk;
})();
function unwrapResult(action) {
	if (action.meta && action.meta.rejectedWithValue) throw action.payload;
	if (action.error) throw action.error;
	return action.payload;
}
function isThenable(value) {
	return value !== null && typeof value === "object" && typeof value.then === "function";
}
var asyncThunkSymbol = /* @__PURE__ */ Symbol.for("rtk-slice-createasyncthunk");
var asyncThunkCreator = { [asyncThunkSymbol]: createAsyncThunk };
var ReducerType = /* @__PURE__ */ function(ReducerType) {
	ReducerType["reducer"] = "reducer";
	ReducerType["reducerWithPrepare"] = "reducerWithPrepare";
	ReducerType["asyncThunk"] = "asyncThunk";
	return ReducerType;
}({});
function getType(slice, actionKey) {
	return `${slice}/${actionKey}`;
}
function buildCreateSlice({ creators } = {}) {
	const cAT = creators?.asyncThunk?.[asyncThunkSymbol];
	return function createSlice(options) {
		const { name, reducerPath = name } = options;
		if (!name) throw new Error("`name` is a required option for createSlice");
		if (typeof process !== "undefined" && true) {
			if (options.initialState === void 0) console.error("You must provide an `initialState` value that is not `undefined`. You may have misspelled `initialState`");
		}
		const reducers = (typeof options.reducers === "function" ? options.reducers(buildReducerCreators()) : options.reducers) || {};
		const reducerNames = Object.keys(reducers);
		const context = {
			sliceCaseReducersByName: {},
			sliceCaseReducersByType: {},
			actionCreators: {},
			sliceMatchers: []
		};
		const contextMethods = {
			addCase(typeOrActionCreator, reducer) {
				const type = typeof typeOrActionCreator === "string" ? typeOrActionCreator : typeOrActionCreator.type;
				if (!type) throw new Error("`context.addCase` cannot be called with an empty action type");
				if (type in context.sliceCaseReducersByType) throw new Error("`context.addCase` cannot be called with two reducers for the same action type: " + type);
				context.sliceCaseReducersByType[type] = reducer;
				return contextMethods;
			},
			addMatcher(matcher, reducer) {
				context.sliceMatchers.push({
					matcher,
					reducer
				});
				return contextMethods;
			},
			exposeAction(name, actionCreator) {
				context.actionCreators[name] = actionCreator;
				return contextMethods;
			},
			exposeCaseReducer(name, reducer) {
				context.sliceCaseReducersByName[name] = reducer;
				return contextMethods;
			}
		};
		reducerNames.forEach((reducerName) => {
			const reducerDefinition = reducers[reducerName];
			const reducerDetails = {
				reducerName,
				type: getType(name, reducerName),
				createNotation: typeof options.reducers === "function"
			};
			if (isAsyncThunkSliceReducerDefinition(reducerDefinition)) handleThunkCaseReducerDefinition(reducerDetails, reducerDefinition, contextMethods, cAT);
			else handleNormalReducerDefinition(reducerDetails, reducerDefinition, contextMethods);
		});
		function buildReducer() {
			if (typeof options.extraReducers === "object") throw new Error("The object notation for `createSlice.extraReducers` has been removed. Please use the 'builder callback' notation instead: https://redux-toolkit.js.org/api/createSlice");
			const [extraReducers = {}, actionMatchers = [], defaultCaseReducer = void 0] = typeof options.extraReducers === "function" ? executeReducerBuilderCallback(options.extraReducers) : [options.extraReducers];
			const finalCaseReducers = {
				...extraReducers,
				...context.sliceCaseReducersByType
			};
			return createReducer(options.initialState, (builder) => {
				for (let key in finalCaseReducers) builder.addCase(key, finalCaseReducers[key]);
				for (let sM of context.sliceMatchers) builder.addMatcher(sM.matcher, sM.reducer);
				for (let m of actionMatchers) builder.addMatcher(m.matcher, m.reducer);
				if (defaultCaseReducer) builder.addDefaultCase(defaultCaseReducer);
			});
		}
		const selectSelf = (state) => state;
		const injectedSelectorCache = /* @__PURE__ */ new Map();
		const injectedStateCache = /* @__PURE__ */ new WeakMap();
		let _reducer;
		function reducer(state, action) {
			if (!_reducer) _reducer = buildReducer();
			return _reducer(state, action);
		}
		function getInitialState() {
			if (!_reducer) _reducer = buildReducer();
			return _reducer.getInitialState();
		}
		function makeSelectorProps(reducerPath, injected = false) {
			function selectSlice(state) {
				let sliceState = state[reducerPath];
				if (typeof sliceState === "undefined") {
					if (injected) sliceState = getOrInsertComputed(injectedStateCache, selectSlice, getInitialState);
					else throw new Error("selectSlice returned undefined for an uninjected slice reducer");
				}
				return sliceState;
			}
			function getSelectors(selectState = selectSelf) {
				return getOrInsertComputed(getOrInsertComputed(injectedSelectorCache, injected, () => /* @__PURE__ */ new WeakMap()), selectState, () => {
					const map = {};
					for (const [name, selector] of Object.entries(options.selectors ?? {})) map[name] = wrapSelector(selector, selectState, () => getOrInsertComputed(injectedStateCache, selectState, getInitialState), injected);
					return map;
				});
			}
			return {
				reducerPath,
				getSelectors,
				get selectors() {
					return getSelectors(selectSlice);
				},
				selectSlice
			};
		}
		const slice = {
			name,
			reducer,
			actions: context.actionCreators,
			caseReducers: context.sliceCaseReducersByName,
			getInitialState,
			...makeSelectorProps(reducerPath),
			injectInto(injectable, { reducerPath: pathOpt, ...config } = {}) {
				const newReducerPath = pathOpt ?? reducerPath;
				injectable.inject({
					reducerPath: newReducerPath,
					reducer
				}, config);
				return {
					...slice,
					...makeSelectorProps(newReducerPath, true)
				};
			}
		};
		return slice;
	};
}
function wrapSelector(selector, selectState, getInitialState, injected) {
	function wrapper(rootState, ...args) {
		let sliceState = selectState(rootState);
		if (typeof sliceState === "undefined") {
			if (injected) sliceState = getInitialState();
			else throw new Error("selectState returned undefined for an uninjected slice reducer");
		}
		return selector(sliceState, ...args);
	}
	wrapper.unwrapped = selector;
	return wrapper;
}
var createSlice = /* @__PURE__ */ buildCreateSlice();
function buildReducerCreators() {
	function asyncThunk(payloadCreator, config) {
		return {
			_reducerDefinitionType: "asyncThunk",
			payloadCreator,
			...config
		};
	}
	asyncThunk.withTypes = () => asyncThunk;
	return {
		reducer(caseReducer) {
			return Object.assign({ [caseReducer.name](...args) {
				return caseReducer(...args);
			} }[caseReducer.name], { _reducerDefinitionType: "reducer" });
		},
		preparedReducer(prepare, reducer) {
			return {
				_reducerDefinitionType: "reducerWithPrepare",
				prepare,
				reducer
			};
		},
		asyncThunk
	};
}
function handleNormalReducerDefinition({ type, reducerName, createNotation }, maybeReducerWithPrepare, context) {
	let caseReducer;
	let prepareCallback;
	if ("reducer" in maybeReducerWithPrepare) {
		if (createNotation && !isCaseReducerWithPrepareDefinition(maybeReducerWithPrepare)) throw new Error("Please use the `create.preparedReducer` notation for prepared action creators with the `create` notation.");
		caseReducer = maybeReducerWithPrepare.reducer;
		prepareCallback = maybeReducerWithPrepare.prepare;
	} else caseReducer = maybeReducerWithPrepare;
	context.addCase(type, caseReducer).exposeCaseReducer(reducerName, caseReducer).exposeAction(reducerName, prepareCallback ? createAction(type, prepareCallback) : createAction(type));
}
function isAsyncThunkSliceReducerDefinition(reducerDefinition) {
	return reducerDefinition._reducerDefinitionType === "asyncThunk";
}
function isCaseReducerWithPrepareDefinition(reducerDefinition) {
	return reducerDefinition._reducerDefinitionType === "reducerWithPrepare";
}
function handleThunkCaseReducerDefinition({ type, reducerName }, reducerDefinition, context, cAT) {
	if (!cAT) throw new Error("Cannot use `create.asyncThunk` in the built-in `createSlice`. Use `buildCreateSlice({ creators: { asyncThunk: asyncThunkCreator } })` to create a customised version of `createSlice`.");
	const { payloadCreator, fulfilled, pending, rejected, settled, options } = reducerDefinition;
	const thunk = cAT(type, payloadCreator, options);
	context.exposeAction(reducerName, thunk);
	if (fulfilled) context.addCase(thunk.fulfilled, fulfilled);
	if (pending) context.addCase(thunk.pending, pending);
	if (rejected) context.addCase(thunk.rejected, rejected);
	if (settled) context.addMatcher(thunk.settled, settled);
	context.exposeCaseReducer(reducerName, {
		fulfilled: fulfilled || noop$1,
		pending: pending || noop$1,
		rejected: rejected || noop$1,
		settled: settled || noop$1
	});
}
function noop$1() {}
function getInitialEntityState() {
	return {
		ids: [],
		entities: {}
	};
}
function createInitialStateFactory(stateAdapter) {
	function getInitialState(additionalState = {}, entities) {
		const state = Object.assign(getInitialEntityState(), additionalState);
		return entities ? stateAdapter.setAll(state, entities) : state;
	}
	return { getInitialState };
}
function createSelectorsFactory() {
	function getSelectors(selectState, options = {}) {
		const { createSelector = createDraftSafeSelector } = options;
		const selectIds = (state) => state.ids;
		const selectEntities = (state) => state.entities;
		const selectAll = createSelector(selectIds, selectEntities, (ids, entities) => ids.map((id) => entities[id]));
		const selectId = (_, id) => id;
		const selectById = (entities, id) => entities[id];
		const selectTotal = createSelector(selectIds, (ids) => ids.length);
		if (!selectState) return {
			selectIds,
			selectEntities,
			selectAll,
			selectTotal,
			selectById: createSelector(selectEntities, selectId, selectById)
		};
		const selectGlobalizedEntities = createSelector(selectState, selectEntities);
		return {
			selectIds: createSelector(selectState, selectIds),
			selectEntities: selectGlobalizedEntities,
			selectAll: createSelector(selectState, selectAll),
			selectTotal: createSelector(selectState, selectTotal),
			selectById: createSelector(selectGlobalizedEntities, selectId, selectById)
		};
	}
	return { getSelectors };
}
var isDraftTyped = isDraft;
function createSingleArgumentStateOperator(mutator) {
	const operator = createStateOperator((_, state) => mutator(state));
	return function operation(state) {
		return operator(state, void 0);
	};
}
function createStateOperator(mutator) {
	return function operation(state, arg) {
		function isPayloadActionArgument(arg) {
			return isFSA(arg);
		}
		const runMutator = (draft) => {
			if (isPayloadActionArgument(arg)) mutator(arg.payload, draft);
			else mutator(arg, draft);
		};
		if (isDraftTyped(state)) {
			runMutator(state);
			return state;
		}
		return produce(state, runMutator);
	};
}
function selectIdValue(entity, selectId) {
	const key = selectId(entity);
	if (key === void 0) console.warn("The entity passed to the `selectId` implementation returned undefined.", "You should probably provide your own `selectId` implementation.", "The entity that was passed:", entity, "The `selectId` implementation:", selectId.toString());
	return key;
}
function ensureEntitiesArray(entities) {
	if (!Array.isArray(entities)) entities = Object.values(entities);
	return entities;
}
function getCurrent(value) {
	return isDraft(value) ? current(value) : value;
}
function splitAddedUpdatedEntities(newEntities, selectId, state) {
	newEntities = ensureEntitiesArray(newEntities);
	const existingIdsArray = getCurrent(state.ids);
	const existingIds = new Set(existingIdsArray);
	const added = [];
	const addedIds = /* @__PURE__ */ new Set([]);
	const updated = [];
	for (const entity of newEntities) {
		const id = selectIdValue(entity, selectId);
		if (existingIds.has(id) || addedIds.has(id)) updated.push({
			id,
			changes: entity
		});
		else {
			addedIds.add(id);
			added.push(entity);
		}
	}
	return [
		added,
		updated,
		existingIdsArray
	];
}
function createUnsortedStateAdapter(selectId) {
	function addOneMutably(entity, state) {
		const key = selectIdValue(entity, selectId);
		if (key in state.entities) return;
		state.ids.push(key);
		state.entities[key] = entity;
	}
	function addManyMutably(newEntities, state) {
		newEntities = ensureEntitiesArray(newEntities);
		for (const entity of newEntities) addOneMutably(entity, state);
	}
	function setOneMutably(entity, state) {
		const key = selectIdValue(entity, selectId);
		if (!(key in state.entities)) state.ids.push(key);
		state.entities[key] = entity;
	}
	function setManyMutably(newEntities, state) {
		newEntities = ensureEntitiesArray(newEntities);
		for (const entity of newEntities) setOneMutably(entity, state);
	}
	function setAllMutably(newEntities, state) {
		newEntities = ensureEntitiesArray(newEntities);
		state.ids = [];
		state.entities = {};
		setManyMutably(newEntities, state);
	}
	function removeOneMutably(key, state) {
		return removeManyMutably([key], state);
	}
	function removeManyMutably(keys, state) {
		let didMutate = false;
		keys.forEach((key) => {
			if (key in state.entities) {
				delete state.entities[key];
				didMutate = true;
			}
		});
		if (didMutate) state.ids = state.ids.filter((id) => id in state.entities);
	}
	function removeAllMutably(state) {
		Object.assign(state, {
			ids: [],
			entities: {}
		});
	}
	function takeNewKey(keys, update, state) {
		const original = state.entities[update.id];
		if (original === void 0) return false;
		const updated = Object.assign({}, original, update.changes);
		const newKey = selectIdValue(updated, selectId);
		const hasNewKey = newKey !== update.id;
		if (hasNewKey) {
			keys[update.id] = newKey;
			delete state.entities[update.id];
		}
		state.entities[newKey] = updated;
		return hasNewKey;
	}
	function updateOneMutably(update, state) {
		return updateManyMutably([update], state);
	}
	function updateManyMutably(updates, state) {
		const newKeys = {};
		const updatesPerEntity = {};
		updates.forEach((update) => {
			if (update.id in state.entities) updatesPerEntity[update.id] = {
				id: update.id,
				changes: {
					...updatesPerEntity[update.id]?.changes,
					...update.changes
				}
			};
		});
		updates = Object.values(updatesPerEntity);
		if (updates.length > 0) {
			if (updates.filter((update) => takeNewKey(newKeys, update, state)).length > 0) state.ids = Object.values(state.entities).map((e) => selectIdValue(e, selectId));
		}
	}
	function upsertOneMutably(entity, state) {
		return upsertManyMutably([entity], state);
	}
	function upsertManyMutably(newEntities, state) {
		const [added, updated] = splitAddedUpdatedEntities(newEntities, selectId, state);
		addManyMutably(added, state);
		updateManyMutably(updated, state);
	}
	return {
		removeAll: createSingleArgumentStateOperator(removeAllMutably),
		addOne: createStateOperator(addOneMutably),
		addMany: createStateOperator(addManyMutably),
		setOne: createStateOperator(setOneMutably),
		setMany: createStateOperator(setManyMutably),
		setAll: createStateOperator(setAllMutably),
		updateOne: createStateOperator(updateOneMutably),
		updateMany: createStateOperator(updateManyMutably),
		upsertOne: createStateOperator(upsertOneMutably),
		upsertMany: createStateOperator(upsertManyMutably),
		removeOne: createStateOperator(removeOneMutably),
		removeMany: createStateOperator(removeManyMutably)
	};
}
function findInsertIndex(sortedItems, item, comparisonFunction) {
	let lowIndex = 0;
	let highIndex = sortedItems.length;
	while (lowIndex < highIndex) {
		let middleIndex = lowIndex + highIndex >>> 1;
		const currentItem = sortedItems[middleIndex];
		if (comparisonFunction(item, currentItem) >= 0) lowIndex = middleIndex + 1;
		else highIndex = middleIndex;
	}
	return lowIndex;
}
function insert(sortedItems, item, comparisonFunction) {
	const insertAtIndex = findInsertIndex(sortedItems, item, comparisonFunction);
	sortedItems.splice(insertAtIndex, 0, item);
	return sortedItems;
}
function createSortedStateAdapter(selectId, comparer) {
	const { removeOne, removeMany, removeAll } = createUnsortedStateAdapter(selectId);
	function addOneMutably(entity, state) {
		return addManyMutably([entity], state);
	}
	function addManyMutably(newEntities, state, existingIds) {
		newEntities = ensureEntitiesArray(newEntities);
		const existingKeys = new Set(existingIds ?? getCurrent(state.ids));
		const addedKeys = /* @__PURE__ */ new Set();
		const models = newEntities.filter((model) => {
			const modelId = selectIdValue(model, selectId);
			const notAdded = !addedKeys.has(modelId);
			if (notAdded) addedKeys.add(modelId);
			return !existingKeys.has(modelId) && notAdded;
		});
		if (models.length !== 0) mergeFunction(state, models);
	}
	function setOneMutably(entity, state) {
		return setManyMutably([entity], state);
	}
	function setManyMutably(newEntities, state) {
		let deduplicatedEntities = {};
		newEntities = ensureEntitiesArray(newEntities);
		if (newEntities.length !== 0) {
			for (const item of newEntities) {
				const entityId = selectId(item);
				deduplicatedEntities[entityId] = item;
				delete state.entities[entityId];
			}
			newEntities = ensureEntitiesArray(deduplicatedEntities);
			mergeFunction(state, newEntities);
		}
	}
	function setAllMutably(newEntities, state) {
		newEntities = ensureEntitiesArray(newEntities);
		state.entities = {};
		state.ids = [];
		setManyMutably(newEntities, state);
	}
	function updateOneMutably(update, state) {
		return updateManyMutably([update], state);
	}
	function updateManyMutably(updates, state) {
		let appliedUpdates = false;
		let replacedIds = false;
		const updatesPerEntity = {};
		for (const update of updates) if (update.id in state.entities) updatesPerEntity[update.id] = {
			id: update.id,
			changes: {
				...updatesPerEntity[update.id]?.changes,
				...update.changes
			}
		};
		for (const update of Object.values(updatesPerEntity)) {
			const entity = state.entities[update.id];
			if (!entity) continue;
			appliedUpdates = true;
			Object.assign(entity, update.changes);
			const newId = selectId(entity);
			if (update.id !== newId) {
				replacedIds = true;
				delete state.entities[update.id];
				const oldIndex = state.ids.indexOf(update.id);
				state.ids[oldIndex] = newId;
				state.entities[newId] = entity;
			}
		}
		if (appliedUpdates) mergeFunction(state, [], appliedUpdates, replacedIds);
	}
	function upsertOneMutably(entity, state) {
		return upsertManyMutably([entity], state);
	}
	function upsertManyMutably(newEntities, state) {
		const [added, updated, existingIdsArray] = splitAddedUpdatedEntities(newEntities, selectId, state);
		if (added.length) addManyMutably(added, state, existingIdsArray);
		if (updated.length) updateManyMutably(updated, state);
	}
	function areArraysEqual(a, b) {
		if (a.length !== b.length) return false;
		for (let i = 0; i < a.length; i++) {
			if (a[i] === b[i]) continue;
			return false;
		}
		return true;
	}
	function mergeFunction(state, addedItems, appliedUpdates, replacedIds) {
		const currentEntities = getCurrent(state.entities);
		const currentIds = getCurrent(state.ids);
		const stateEntities = state.entities;
		let ids = currentIds;
		if (replacedIds) ids = new Set(currentIds);
		let sortedEntities = [];
		for (const id of ids) {
			const entity = currentEntities[id];
			if (entity) sortedEntities.push(entity);
		}
		const wasPreviouslyEmpty = sortedEntities.length === 0;
		for (const item of addedItems) {
			stateEntities[selectId(item)] = item;
			if (!wasPreviouslyEmpty) insert(sortedEntities, item, comparer);
		}
		if (wasPreviouslyEmpty) sortedEntities = addedItems.slice().sort(comparer);
		else if (appliedUpdates) sortedEntities.sort(comparer);
		const newSortedIds = sortedEntities.map(selectId);
		if (!areArraysEqual(currentIds, newSortedIds)) state.ids = newSortedIds;
	}
	return {
		removeOne,
		removeMany,
		removeAll,
		addOne: createStateOperator(addOneMutably),
		updateOne: createStateOperator(updateOneMutably),
		upsertOne: createStateOperator(upsertOneMutably),
		setOne: createStateOperator(setOneMutably),
		setMany: createStateOperator(setManyMutably),
		setAll: createStateOperator(setAllMutably),
		addMany: createStateOperator(addManyMutably),
		updateMany: createStateOperator(updateManyMutably),
		upsertMany: createStateOperator(upsertManyMutably)
	};
}
function createEntityAdapter(options = {}) {
	const { selectId, sortComparer } = {
		sortComparer: false,
		selectId: (instance) => instance.id,
		...options
	};
	const stateAdapter = sortComparer ? createSortedStateAdapter(selectId, sortComparer) : createUnsortedStateAdapter(selectId);
	const stateFactory = createInitialStateFactory(stateAdapter);
	const selectorsFactory = createSelectorsFactory();
	return {
		selectId,
		sortComparer,
		...stateFactory,
		...selectorsFactory,
		...stateAdapter
	};
}
var task = "task";
var listener = "listener";
var completed = "completed";
var cancelled = "cancelled";
var taskCancelled = `task-${cancelled}`;
var taskCompleted = `task-${completed}`;
var listenerCancelled = `${listener}-${cancelled}`;
var listenerCompleted = `${listener}-${completed}`;
var TaskAbortError = class {
	code;
	name = "TaskAbortError";
	message;
	constructor(code) {
		this.code = code;
		this.message = `${task} ${cancelled} (reason: ${code})`;
	}
};
var assertFunction = (func, expected) => {
	if (typeof func !== "function") throw new TypeError(`${expected} is not a function`);
};
var noop = () => {};
var catchRejection = (promise, onError = noop) => {
	promise.catch(onError);
	return promise;
};
var addAbortSignalListener = (abortSignal, callback) => {
	abortSignal.addEventListener("abort", callback, { once: true });
	return () => abortSignal.removeEventListener("abort", callback);
};
var validateActive = (signal) => {
	if (signal.aborted) throw new TaskAbortError(signal.reason);
};
function raceWithSignal(signal, promise) {
	let cleanup = noop;
	return new Promise((resolve, reject) => {
		const notifyRejection = () => reject(new TaskAbortError(signal.reason));
		if (signal.aborted) {
			notifyRejection();
			return;
		}
		cleanup = addAbortSignalListener(signal, notifyRejection);
		promise.finally(() => cleanup()).then(resolve, reject);
	}).finally(() => {
		cleanup = noop;
	});
}
var runTask = async (task, cleanUp) => {
	try {
		await Promise.resolve();
		return {
			status: "ok",
			value: await task()
		};
	} catch (error) {
		return {
			status: error instanceof TaskAbortError ? "cancelled" : "rejected",
			error
		};
	} finally {
		cleanUp?.();
	}
};
var createPause = (signal) => {
	return (promise) => {
		return catchRejection(raceWithSignal(signal, promise).then((output) => {
			validateActive(signal);
			return output;
		}));
	};
};
var createDelay = (signal) => {
	const pause = createPause(signal);
	return (timeoutMs) => {
		return pause(new Promise((resolve) => setTimeout(resolve, timeoutMs)));
	};
};
var { assign } = Object;
var INTERNAL_NIL_TOKEN = {};
var alm = "listenerMiddleware";
var createFork = (parentAbortSignal, parentBlockingPromises) => {
	const linkControllers = (controller) => addAbortSignalListener(parentAbortSignal, () => controller.abort(parentAbortSignal.reason));
	return (taskExecutor, opts) => {
		assertFunction(taskExecutor, "taskExecutor");
		const childAbortController = new AbortController();
		linkControllers(childAbortController);
		const result = runTask(async () => {
			validateActive(parentAbortSignal);
			validateActive(childAbortController.signal);
			const result = await taskExecutor({
				pause: createPause(childAbortController.signal),
				delay: createDelay(childAbortController.signal),
				signal: childAbortController.signal
			});
			validateActive(childAbortController.signal);
			return result;
		}, () => childAbortController.abort(taskCompleted));
		if (opts?.autoJoin) parentBlockingPromises.push(result.catch(noop));
		return {
			result: createPause(parentAbortSignal)(result),
			cancel() {
				childAbortController.abort(taskCancelled);
			}
		};
	};
};
var createTakePattern = (startListening, signal) => {
	const take = async (predicate, timeout) => {
		validateActive(signal);
		let unsubscribe = () => {};
		const promises = [new Promise((resolve, reject) => {
			let stopListening = startListening({
				predicate,
				effect: (action, listenerApi) => {
					listenerApi.unsubscribe();
					resolve([
						action,
						listenerApi.getState(),
						listenerApi.getOriginalState()
					]);
				}
			});
			unsubscribe = () => {
				stopListening();
				reject();
			};
		})];
		if (timeout != null) promises.push(new Promise((resolve) => setTimeout(resolve, timeout, null)));
		try {
			const output = await raceWithSignal(signal, Promise.race(promises));
			validateActive(signal);
			return output;
		} finally {
			unsubscribe();
		}
	};
	return ((predicate, timeout) => catchRejection(take(predicate, timeout)));
};
var getListenerEntryPropsFrom = (options) => {
	let { type, actionCreator, matcher, predicate, effect } = options;
	if (type) predicate = createAction(type).match;
	else if (actionCreator) {
		type = actionCreator.type;
		predicate = actionCreator.match;
	} else if (matcher) predicate = matcher;
	else if (predicate) {} else throw new Error("Creating or removing a listener requires one of the known fields for matching an action");
	assertFunction(effect, "options.listener");
	return {
		predicate,
		type,
		effect
	};
};
var createListenerEntry = /* @__PURE__ */ assign((options) => {
	const { type, predicate, effect } = getListenerEntryPropsFrom(options);
	return {
		id: nanoid(),
		effect,
		type,
		predicate,
		pending: /* @__PURE__ */ new Set(),
		unsubscribe: () => {
			throw new Error("Unsubscribe not initialized");
		}
	};
}, { withTypes: () => createListenerEntry });
var findListenerEntry = (listenerMap, options) => {
	const { type, effect, predicate } = getListenerEntryPropsFrom(options);
	return Array.from(listenerMap.values()).find((entry) => {
		return (typeof type === "string" ? entry.type === type : entry.predicate === predicate) && entry.effect === effect;
	});
};
var cancelActiveListeners = (entry) => {
	entry.pending.forEach((controller) => {
		controller.abort(listenerCancelled);
	});
};
var createClearListenerMiddleware = (listenerMap, executingListeners) => {
	return () => {
		for (const listener of executingListeners.keys()) cancelActiveListeners(listener);
		listenerMap.clear();
	};
};
var safelyNotifyError = (errorHandler, errorToNotify, errorInfo) => {
	try {
		errorHandler(errorToNotify, errorInfo);
	} catch (errorHandlerError) {
		setTimeout(() => {
			throw errorHandlerError;
		}, 0);
	}
};
var addListener = /* @__PURE__ */ assign(/* @__PURE__ */ createAction(`${alm}/add`), { withTypes: () => addListener });
var clearAllListeners = /* @__PURE__ */ createAction(`${alm}/removeAll`);
var removeListener = /* @__PURE__ */ assign(/* @__PURE__ */ createAction(`${alm}/remove`), { withTypes: () => removeListener });
var defaultErrorHandler = (...args) => {
	console.error(`${alm}/error`, ...args);
};
var createListenerMiddleware = (middlewareOptions = {}) => {
	const listenerMap = /* @__PURE__ */ new Map();
	const executingListeners = /* @__PURE__ */ new Map();
	const trackExecutingListener = (entry) => {
		const count = executingListeners.get(entry) ?? 0;
		executingListeners.set(entry, count + 1);
	};
	const untrackExecutingListener = (entry) => {
		const count = executingListeners.get(entry) ?? 1;
		if (count === 1) executingListeners.delete(entry);
		else executingListeners.set(entry, count - 1);
	};
	const { extra, onError = defaultErrorHandler } = middlewareOptions;
	assertFunction(onError, "onError");
	const insertEntry = (entry) => {
		entry.unsubscribe = () => listenerMap.delete(entry.id);
		listenerMap.set(entry.id, entry);
		return (cancelOptions) => {
			entry.unsubscribe();
			if (cancelOptions?.cancelActive) cancelActiveListeners(entry);
		};
	};
	const startListening = ((options) => {
		const entry = findListenerEntry(listenerMap, options) ?? createListenerEntry(options);
		return insertEntry(entry);
	});
	assign(startListening, { withTypes: () => startListening });
	const stopListening = (options) => {
		const entry = findListenerEntry(listenerMap, options);
		if (entry) {
			entry.unsubscribe();
			if (options.cancelActive) cancelActiveListeners(entry);
		}
		return !!entry;
	};
	assign(stopListening, { withTypes: () => stopListening });
	const notifyListener = async (entry, action, api, getOriginalState) => {
		const internalTaskController = new AbortController();
		const take = createTakePattern(startListening, internalTaskController.signal);
		const autoJoinPromises = [];
		try {
			entry.pending.add(internalTaskController);
			trackExecutingListener(entry);
			await Promise.resolve(entry.effect(action, assign({}, api, {
				getOriginalState,
				condition: (predicate, timeout) => take(predicate, timeout).then(Boolean),
				take,
				delay: createDelay(internalTaskController.signal),
				pause: createPause(internalTaskController.signal),
				extra,
				signal: internalTaskController.signal,
				fork: createFork(internalTaskController.signal, autoJoinPromises),
				unsubscribe: entry.unsubscribe,
				subscribe: () => {
					listenerMap.set(entry.id, entry);
				},
				cancelActiveListeners: () => {
					entry.pending.forEach((controller, _, set) => {
						if (controller !== internalTaskController) {
							controller.abort(listenerCancelled);
							set.delete(controller);
						}
					});
				},
				cancel: () => {
					internalTaskController.abort(listenerCancelled);
					entry.pending.delete(internalTaskController);
				},
				throwIfCancelled: () => {
					validateActive(internalTaskController.signal);
				}
			})));
		} catch (listenerError) {
			if (!(listenerError instanceof TaskAbortError)) safelyNotifyError(onError, listenerError, { raisedBy: "effect" });
		} finally {
			await Promise.all(autoJoinPromises);
			internalTaskController.abort(listenerCompleted);
			untrackExecutingListener(entry);
			entry.pending.delete(internalTaskController);
		}
	};
	const clearListenerMiddleware = createClearListenerMiddleware(listenerMap, executingListeners);
	const middleware = (api) => (next) => (action) => {
		if (!isAction(action)) return next(action);
		if (addListener.match(action)) return startListening(action.payload);
		if (clearAllListeners.match(action)) {
			clearListenerMiddleware();
			return;
		}
		if (removeListener.match(action)) return stopListening(action.payload);
		let originalState = api.getState();
		const getOriginalState = () => {
			if (originalState === INTERNAL_NIL_TOKEN) throw new Error(`${alm}: getOriginalState can only be called synchronously`);
			return originalState;
		};
		let result;
		try {
			result = next(action);
			if (listenerMap.size > 0) {
				const currentState = api.getState();
				const listenerEntries = Array.from(listenerMap.values());
				for (const entry of listenerEntries) {
					let runListener = false;
					try {
						runListener = entry.predicate(action, currentState, originalState);
					} catch (predicateError) {
						runListener = false;
						safelyNotifyError(onError, predicateError, { raisedBy: "predicate" });
					}
					if (!runListener) continue;
					notifyListener(entry, action, api, getOriginalState);
				}
			}
		} finally {
			originalState = INTERNAL_NIL_TOKEN;
		}
		return result;
	};
	return {
		middleware,
		startListening,
		stopListening,
		clearListeners: clearListenerMiddleware
	};
};
var createMiddlewareEntry = (middleware) => ({
	middleware,
	applied: /* @__PURE__ */ new Map()
});
var matchInstance = (instanceId) => (action) => action?.meta?.instanceId === instanceId;
var createDynamicMiddleware = () => {
	const instanceId = nanoid();
	const middlewareMap = /* @__PURE__ */ new Map();
	let middlewareVersion = 0;
	const withMiddleware = Object.assign(createAction("dynamicMiddleware/add", (...middlewares) => ({
		payload: middlewares,
		meta: { instanceId }
	})), { withTypes: () => withMiddleware });
	const addMiddleware = Object.assign(function addMiddleware(...middlewares) {
		const previousSize = middlewareMap.size;
		middlewares.forEach((middleware) => {
			getOrInsertComputed(middlewareMap, middleware, createMiddlewareEntry);
		});
		if (middlewareMap.size !== previousSize) middlewareVersion++;
	}, { withTypes: () => addMiddleware });
	const getFinalMiddleware = (api) => {
		return compose(...Array.from(middlewareMap.values()).map((entry) => getOrInsertComputed(entry.applied, api, entry.middleware)));
	};
	const isWithMiddleware = isAllOf(withMiddleware, matchInstance(instanceId));
	const middleware = (api) => (next) => {
		let appliedVersion = -1;
		let dispatch = next;
		return (action) => {
			if (isWithMiddleware(action)) {
				addMiddleware(...action.payload);
				return api.dispatch;
			}
			if (appliedVersion !== middlewareVersion) {
				dispatch = getFinalMiddleware(api)(next);
				appliedVersion = middlewareVersion;
			}
			return dispatch(action);
		};
	};
	return {
		middleware,
		addMiddleware,
		withMiddleware,
		instanceId
	};
};
var isSliceLike = (maybeSliceLike) => "reducerPath" in maybeSliceLike && typeof maybeSliceLike.reducerPath === "string";
var getReducers = (slices) => slices.flatMap((sliceOrMap) => isSliceLike(sliceOrMap) ? [[sliceOrMap.reducerPath, sliceOrMap.reducer]] : Object.entries(sliceOrMap));
var ORIGINAL_STATE = Symbol.for("rtk-state-proxy-original");
var isStateProxy = (value) => !!value && !!value[ORIGINAL_STATE];
var createStateProxy = (stateProxyMap, state, reducerMap, initialStateCache) => getOrInsertComputed(stateProxyMap, state, () => new Proxy(state, { get: (target, prop, receiver) => {
	if (prop === ORIGINAL_STATE) return target;
	const result = Reflect.get(target, prop, receiver);
	if (typeof result === "undefined") {
		const cached = initialStateCache[prop];
		if (typeof cached !== "undefined") return cached;
		const reducer = reducerMap[prop];
		if (reducer) {
			const reducerResult = reducer(void 0, { type: nanoid() });
			if (typeof reducerResult === "undefined") throw new Error(`The slice reducer for key "${prop.toString()}" returned undefined when called for selector(). If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined. If you don't want to set a value for this reducer, you can use null instead of undefined.`);
			initialStateCache[prop] = reducerResult;
			return reducerResult;
		}
	}
	return result;
} }));
var original$1 = (state) => {
	if (!isStateProxy(state)) throw new Error("original must be used on state Proxy");
	return state[ORIGINAL_STATE];
};
var emptyObject = {};
var noopReducer = (state = emptyObject) => state;
function combineSlices(...slices) {
	const stateProxyMap = /* @__PURE__ */ new WeakMap();
	const reducerMap = Object.fromEntries(getReducers(slices));
	const getReducer = () => Object.keys(reducerMap).length ? combineReducers(reducerMap) : noopReducer;
	let reducer = getReducer();
	function combinedReducer(state, action) {
		return reducer(state, action);
	}
	combinedReducer.withLazyLoadedSlices = () => combinedReducer;
	const initialStateCache = {};
	const inject = (slice, config = {}) => {
		const { reducerPath, reducer: reducerToInject } = slice;
		const currentReducer = reducerMap[reducerPath];
		if (!config.overrideExisting && currentReducer && currentReducer !== reducerToInject) {
			if (typeof process !== "undefined" && true) console.error(`called \`inject\` to override already-existing reducer ${reducerPath} without specifying \`overrideExisting: true\``);
			return combinedReducer;
		}
		if (config.overrideExisting && currentReducer !== reducerToInject) delete initialStateCache[reducerPath];
		reducerMap[reducerPath] = reducerToInject;
		reducer = getReducer();
		return combinedReducer;
	};
	const selector = Object.assign(function makeSelector(selectorFn, selectState) {
		return function selector(state, ...args) {
			return selectorFn(createStateProxy(stateProxyMap, selectState ? selectState(state, ...args) : state, reducerMap, initialStateCache), ...args);
		};
	}, { original: original$1 });
	return Object.assign(combinedReducer, {
		inject,
		selector
	});
}
function formatProdErrorMessage(code) {
	return `Minified Redux Toolkit error #${code}; visit https://redux-toolkit.js.org/Errors?code=${code} for the full message or use the non-minified dev environment for full errors. `;
}
//#endregion
export { ReducerType, SHOULD_AUTOBATCH, TaskAbortError, Tuple, actionTypes_default as __DO_NOT_USE__ActionTypes, addListener, applyMiddleware, asyncThunkCreator, autoBatchEnhancer, bindActionCreators, buildCreateSlice, clearAllListeners, combineReducers, combineSlices, compose, configureStore, createAction, createActionCreatorInvariantMiddleware, createAsyncThunk, createDraftSafeSelector, createDraftSafeSelectorCreator, createDynamicMiddleware, createEntityAdapter, createImmutableStateInvariantMiddleware, createListenerMiddleware, produce as createNextState, createReducer, createSelector, createSelectorCreator, createSerializableStateInvariantMiddleware, createSlice, createStore, current, findNonSerializableValue, formatProdErrorMessage, freeze, isAction, isActionCreator, isAllOf, isAnyOf, isAsyncThunkAction, isDraft, isFSA as isFluxStandardAction, isFulfilled, isImmutableDefault, isPending, isPlain, isPlainObject, isRejected, isRejectedWithValue, legacy_createStore, lruMemoize, miniSerializeError, nanoid, original, prepareAutoBatched, removeListener, unwrapResult, weakMapMemoize };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiQHJlZHV4anNfdG9vbGtpdC5qcyIsIm5hbWVzIjpbImlzUGxhaW5PYmplY3QiLCJpc0Jvb2xlYW4iLCJjcmVhdGVOZXh0U3RhdGUiLCJjb21iaW5lUmVkdWNlcnMkMSJdLCJzb3VyY2VzIjpbIi4uLy4uLy5wbnBtL3JlZHV4QDUuMC4xL25vZGVfbW9kdWxlcy9yZWR1eC9kaXN0L3JlZHV4Lm1qcyIsIi4uLy4uLy5wbnBtL2ltbWVyQDExLjEuMjEvbm9kZV9tb2R1bGVzL2ltbWVyL2Rpc3QvaW1tZXIubWpzIiwiLi4vLi4vLnBucG0vcmVzZWxlY3RANS4zLjAvbm9kZV9tb2R1bGVzL3Jlc2VsZWN0L2Rpc3QvcmVzZWxlY3QubWpzIiwiLi4vLi4vLnBucG0vcmVkdXgtdGh1bmtAMy4xLjBfcmVkdXhANS4wLjEvbm9kZV9tb2R1bGVzL3JlZHV4LXRodW5rL2Rpc3QvcmVkdXgtdGh1bmsubWpzIiwiLi4vLi4vLnBucG0vQHJlZHV4anMrdG9vbGtpdEAyLjEzLjBfcmVhXzQ1NTRkOGRlY2RkNWFhZTE2MjU1ZjY3M2IxOWUxYzVkL25vZGVfbW9kdWxlcy9AcmVkdXhqcy90b29sa2l0L2Rpc3QvcmVkdXgtdG9vbGtpdC5tb2Rlcm4ubWpzIl0sInNvdXJjZXNDb250ZW50IjpbIi8vIHNyYy91dGlscy9mb3JtYXRQcm9kRXJyb3JNZXNzYWdlLnRzXG5mdW5jdGlvbiBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKGNvZGUpIHtcbiAgcmV0dXJuIGBNaW5pZmllZCBSZWR1eCBlcnJvciAjJHtjb2RlfTsgdmlzaXQgaHR0cHM6Ly9yZWR1eC5qcy5vcmcvRXJyb3JzP2NvZGU9JHtjb2RlfSBmb3IgdGhlIGZ1bGwgbWVzc2FnZSBvciB1c2UgdGhlIG5vbi1taW5pZmllZCBkZXYgZW52aXJvbm1lbnQgZm9yIGZ1bGwgZXJyb3JzLiBgO1xufVxuXG4vLyBzcmMvdXRpbHMvc3ltYm9sLW9ic2VydmFibGUudHNcbnZhciAkJG9ic2VydmFibGUgPSAvKiBAX19QVVJFX18gKi8gKCgpID0+IHR5cGVvZiBTeW1ib2wgPT09IFwiZnVuY3Rpb25cIiAmJiBTeW1ib2wub2JzZXJ2YWJsZSB8fCBcIkBAb2JzZXJ2YWJsZVwiKSgpO1xudmFyIHN5bWJvbF9vYnNlcnZhYmxlX2RlZmF1bHQgPSAkJG9ic2VydmFibGU7XG5cbi8vIHNyYy91dGlscy9hY3Rpb25UeXBlcy50c1xudmFyIHJhbmRvbVN0cmluZyA9ICgpID0+IE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMzYpLnN1YnN0cmluZyg3KS5zcGxpdChcIlwiKS5qb2luKFwiLlwiKTtcbnZhciBBY3Rpb25UeXBlcyA9IHtcbiAgSU5JVDogYEBAcmVkdXgvSU5JVCR7LyogQF9fUFVSRV9fICovIHJhbmRvbVN0cmluZygpfWAsXG4gIFJFUExBQ0U6IGBAQHJlZHV4L1JFUExBQ0Ukey8qIEBfX1BVUkVfXyAqLyByYW5kb21TdHJpbmcoKX1gLFxuICBQUk9CRV9VTktOT1dOX0FDVElPTjogKCkgPT4gYEBAcmVkdXgvUFJPQkVfVU5LTk9XTl9BQ1RJT04ke3JhbmRvbVN0cmluZygpfWBcbn07XG52YXIgYWN0aW9uVHlwZXNfZGVmYXVsdCA9IEFjdGlvblR5cGVzO1xuXG4vLyBzcmMvdXRpbHMvaXNQbGFpbk9iamVjdC50c1xuZnVuY3Rpb24gaXNQbGFpbk9iamVjdChvYmopIHtcbiAgaWYgKHR5cGVvZiBvYmogIT09IFwib2JqZWN0XCIgfHwgb2JqID09PSBudWxsKVxuICAgIHJldHVybiBmYWxzZTtcbiAgbGV0IHByb3RvID0gb2JqO1xuICB3aGlsZSAoT2JqZWN0LmdldFByb3RvdHlwZU9mKHByb3RvKSAhPT0gbnVsbCkge1xuICAgIHByb3RvID0gT2JqZWN0LmdldFByb3RvdHlwZU9mKHByb3RvKTtcbiAgfVxuICByZXR1cm4gT2JqZWN0LmdldFByb3RvdHlwZU9mKG9iaikgPT09IHByb3RvIHx8IE9iamVjdC5nZXRQcm90b3R5cGVPZihvYmopID09PSBudWxsO1xufVxuXG4vLyBzcmMvdXRpbHMva2luZE9mLnRzXG5mdW5jdGlvbiBtaW5pS2luZE9mKHZhbCkge1xuICBpZiAodmFsID09PSB2b2lkIDApXG4gICAgcmV0dXJuIFwidW5kZWZpbmVkXCI7XG4gIGlmICh2YWwgPT09IG51bGwpXG4gICAgcmV0dXJuIFwibnVsbFwiO1xuICBjb25zdCB0eXBlID0gdHlwZW9mIHZhbDtcbiAgc3dpdGNoICh0eXBlKSB7XG4gICAgY2FzZSBcImJvb2xlYW5cIjpcbiAgICBjYXNlIFwic3RyaW5nXCI6XG4gICAgY2FzZSBcIm51bWJlclwiOlxuICAgIGNhc2UgXCJzeW1ib2xcIjpcbiAgICBjYXNlIFwiZnVuY3Rpb25cIjoge1xuICAgICAgcmV0dXJuIHR5cGU7XG4gICAgfVxuICB9XG4gIGlmIChBcnJheS5pc0FycmF5KHZhbCkpXG4gICAgcmV0dXJuIFwiYXJyYXlcIjtcbiAgaWYgKGlzRGF0ZSh2YWwpKVxuICAgIHJldHVybiBcImRhdGVcIjtcbiAgaWYgKGlzRXJyb3IodmFsKSlcbiAgICByZXR1cm4gXCJlcnJvclwiO1xuICBjb25zdCBjb25zdHJ1Y3Rvck5hbWUgPSBjdG9yTmFtZSh2YWwpO1xuICBzd2l0Y2ggKGNvbnN0cnVjdG9yTmFtZSkge1xuICAgIGNhc2UgXCJTeW1ib2xcIjpcbiAgICBjYXNlIFwiUHJvbWlzZVwiOlxuICAgIGNhc2UgXCJXZWFrTWFwXCI6XG4gICAgY2FzZSBcIldlYWtTZXRcIjpcbiAgICBjYXNlIFwiTWFwXCI6XG4gICAgY2FzZSBcIlNldFwiOlxuICAgICAgcmV0dXJuIGNvbnN0cnVjdG9yTmFtZTtcbiAgfVxuICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbCkuc2xpY2UoOCwgLTEpLnRvTG93ZXJDYXNlKCkucmVwbGFjZSgvXFxzL2csIFwiXCIpO1xufVxuZnVuY3Rpb24gY3Rvck5hbWUodmFsKSB7XG4gIHJldHVybiB0eXBlb2YgdmFsLmNvbnN0cnVjdG9yID09PSBcImZ1bmN0aW9uXCIgPyB2YWwuY29uc3RydWN0b3IubmFtZSA6IG51bGw7XG59XG5mdW5jdGlvbiBpc0Vycm9yKHZhbCkge1xuICByZXR1cm4gdmFsIGluc3RhbmNlb2YgRXJyb3IgfHwgdHlwZW9mIHZhbC5tZXNzYWdlID09PSBcInN0cmluZ1wiICYmIHZhbC5jb25zdHJ1Y3RvciAmJiB0eXBlb2YgdmFsLmNvbnN0cnVjdG9yLnN0YWNrVHJhY2VMaW1pdCA9PT0gXCJudW1iZXJcIjtcbn1cbmZ1bmN0aW9uIGlzRGF0ZSh2YWwpIHtcbiAgaWYgKHZhbCBpbnN0YW5jZW9mIERhdGUpXG4gICAgcmV0dXJuIHRydWU7XG4gIHJldHVybiB0eXBlb2YgdmFsLnRvRGF0ZVN0cmluZyA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiB2YWwuZ2V0RGF0ZSA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiB2YWwuc2V0RGF0ZSA9PT0gXCJmdW5jdGlvblwiO1xufVxuZnVuY3Rpb24ga2luZE9mKHZhbCkge1xuICBsZXQgdHlwZU9mVmFsID0gdHlwZW9mIHZhbDtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIHR5cGVPZlZhbCA9IG1pbmlLaW5kT2YodmFsKTtcbiAgfVxuICByZXR1cm4gdHlwZU9mVmFsO1xufVxuXG4vLyBzcmMvY3JlYXRlU3RvcmUudHNcbmZ1bmN0aW9uIGNyZWF0ZVN0b3JlKHJlZHVjZXIsIHByZWxvYWRlZFN0YXRlLCBlbmhhbmNlcikge1xuICBpZiAodHlwZW9mIHJlZHVjZXIgIT09IFwiZnVuY3Rpb25cIikge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDIpIDogYEV4cGVjdGVkIHRoZSByb290IHJlZHVjZXIgdG8gYmUgYSBmdW5jdGlvbi4gSW5zdGVhZCwgcmVjZWl2ZWQ6ICcke2tpbmRPZihyZWR1Y2VyKX0nYCk7XG4gIH1cbiAgaWYgKHR5cGVvZiBwcmVsb2FkZWRTdGF0ZSA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiBlbmhhbmNlciA9PT0gXCJmdW5jdGlvblwiIHx8IHR5cGVvZiBlbmhhbmNlciA9PT0gXCJmdW5jdGlvblwiICYmIHR5cGVvZiBhcmd1bWVudHNbM10gPT09IFwiZnVuY3Rpb25cIikge1xuICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDApIDogXCJJdCBsb29rcyBsaWtlIHlvdSBhcmUgcGFzc2luZyBzZXZlcmFsIHN0b3JlIGVuaGFuY2VycyB0byBjcmVhdGVTdG9yZSgpLiBUaGlzIGlzIG5vdCBzdXBwb3J0ZWQuIEluc3RlYWQsIGNvbXBvc2UgdGhlbSB0b2dldGhlciB0byBhIHNpbmdsZSBmdW5jdGlvbi4gU2VlIGh0dHBzOi8vcmVkdXguanMub3JnL3R1dG9yaWFscy9mdW5kYW1lbnRhbHMvcGFydC00LXN0b3JlI2NyZWF0aW5nLWEtc3RvcmUtd2l0aC1lbmhhbmNlcnMgZm9yIGFuIGV4YW1wbGUuXCIpO1xuICB9XG4gIGlmICh0eXBlb2YgcHJlbG9hZGVkU3RhdGUgPT09IFwiZnVuY3Rpb25cIiAmJiB0eXBlb2YgZW5oYW5jZXIgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBlbmhhbmNlciA9IHByZWxvYWRlZFN0YXRlO1xuICAgIHByZWxvYWRlZFN0YXRlID0gdm9pZCAwO1xuICB9XG4gIGlmICh0eXBlb2YgZW5oYW5jZXIgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBpZiAodHlwZW9mIGVuaGFuY2VyICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDEpIDogYEV4cGVjdGVkIHRoZSBlbmhhbmNlciB0byBiZSBhIGZ1bmN0aW9uLiBJbnN0ZWFkLCByZWNlaXZlZDogJyR7a2luZE9mKGVuaGFuY2VyKX0nYCk7XG4gICAgfVxuICAgIHJldHVybiBlbmhhbmNlcihjcmVhdGVTdG9yZSkocmVkdWNlciwgcHJlbG9hZGVkU3RhdGUpO1xuICB9XG4gIGxldCBjdXJyZW50UmVkdWNlciA9IHJlZHVjZXI7XG4gIGxldCBjdXJyZW50U3RhdGUgPSBwcmVsb2FkZWRTdGF0ZTtcbiAgbGV0IGN1cnJlbnRMaXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICBsZXQgbmV4dExpc3RlbmVycyA9IGN1cnJlbnRMaXN0ZW5lcnM7XG4gIGxldCBsaXN0ZW5lcklkQ291bnRlciA9IDA7XG4gIGxldCBpc0Rpc3BhdGNoaW5nID0gZmFsc2U7XG4gIGZ1bmN0aW9uIGVuc3VyZUNhbk11dGF0ZU5leHRMaXN0ZW5lcnMoKSB7XG4gICAgaWYgKG5leHRMaXN0ZW5lcnMgPT09IGN1cnJlbnRMaXN0ZW5lcnMpIHtcbiAgICAgIG5leHRMaXN0ZW5lcnMgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgICAgY3VycmVudExpc3RlbmVycy5mb3JFYWNoKChsaXN0ZW5lciwga2V5KSA9PiB7XG4gICAgICAgIG5leHRMaXN0ZW5lcnMuc2V0KGtleSwgbGlzdGVuZXIpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGdldFN0YXRlKCkge1xuICAgIGlmIChpc0Rpc3BhdGNoaW5nKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgzKSA6IFwiWW91IG1heSBub3QgY2FsbCBzdG9yZS5nZXRTdGF0ZSgpIHdoaWxlIHRoZSByZWR1Y2VyIGlzIGV4ZWN1dGluZy4gVGhlIHJlZHVjZXIgaGFzIGFscmVhZHkgcmVjZWl2ZWQgdGhlIHN0YXRlIGFzIGFuIGFyZ3VtZW50LiBQYXNzIGl0IGRvd24gZnJvbSB0aGUgdG9wIHJlZHVjZXIgaW5zdGVhZCBvZiByZWFkaW5nIGl0IGZyb20gdGhlIHN0b3JlLlwiKTtcbiAgICB9XG4gICAgcmV0dXJuIGN1cnJlbnRTdGF0ZTtcbiAgfVxuICBmdW5jdGlvbiBzdWJzY3JpYmUobGlzdGVuZXIpIHtcbiAgICBpZiAodHlwZW9mIGxpc3RlbmVyICE9PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDQpIDogYEV4cGVjdGVkIHRoZSBsaXN0ZW5lciB0byBiZSBhIGZ1bmN0aW9uLiBJbnN0ZWFkLCByZWNlaXZlZDogJyR7a2luZE9mKGxpc3RlbmVyKX0nYCk7XG4gICAgfVxuICAgIGlmIChpc0Rpc3BhdGNoaW5nKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSg1KSA6IFwiWW91IG1heSBub3QgY2FsbCBzdG9yZS5zdWJzY3JpYmUoKSB3aGlsZSB0aGUgcmVkdWNlciBpcyBleGVjdXRpbmcuIElmIHlvdSB3b3VsZCBsaWtlIHRvIGJlIG5vdGlmaWVkIGFmdGVyIHRoZSBzdG9yZSBoYXMgYmVlbiB1cGRhdGVkLCBzdWJzY3JpYmUgZnJvbSBhIGNvbXBvbmVudCBhbmQgaW52b2tlIHN0b3JlLmdldFN0YXRlKCkgaW4gdGhlIGNhbGxiYWNrIHRvIGFjY2VzcyB0aGUgbGF0ZXN0IHN0YXRlLiBTZWUgaHR0cHM6Ly9yZWR1eC5qcy5vcmcvYXBpL3N0b3JlI3N1YnNjcmliZWxpc3RlbmVyIGZvciBtb3JlIGRldGFpbHMuXCIpO1xuICAgIH1cbiAgICBsZXQgaXNTdWJzY3JpYmVkID0gdHJ1ZTtcbiAgICBlbnN1cmVDYW5NdXRhdGVOZXh0TGlzdGVuZXJzKCk7XG4gICAgY29uc3QgbGlzdGVuZXJJZCA9IGxpc3RlbmVySWRDb3VudGVyKys7XG4gICAgbmV4dExpc3RlbmVycy5zZXQobGlzdGVuZXJJZCwgbGlzdGVuZXIpO1xuICAgIHJldHVybiBmdW5jdGlvbiB1bnN1YnNjcmliZSgpIHtcbiAgICAgIGlmICghaXNTdWJzY3JpYmVkKSB7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGlmIChpc0Rpc3BhdGNoaW5nKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDYpIDogXCJZb3UgbWF5IG5vdCB1bnN1YnNjcmliZSBmcm9tIGEgc3RvcmUgbGlzdGVuZXIgd2hpbGUgdGhlIHJlZHVjZXIgaXMgZXhlY3V0aW5nLiBTZWUgaHR0cHM6Ly9yZWR1eC5qcy5vcmcvYXBpL3N0b3JlI3N1YnNjcmliZWxpc3RlbmVyIGZvciBtb3JlIGRldGFpbHMuXCIpO1xuICAgICAgfVxuICAgICAgaXNTdWJzY3JpYmVkID0gZmFsc2U7XG4gICAgICBlbnN1cmVDYW5NdXRhdGVOZXh0TGlzdGVuZXJzKCk7XG4gICAgICBuZXh0TGlzdGVuZXJzLmRlbGV0ZShsaXN0ZW5lcklkKTtcbiAgICAgIGN1cnJlbnRMaXN0ZW5lcnMgPSBudWxsO1xuICAgIH07XG4gIH1cbiAgZnVuY3Rpb24gZGlzcGF0Y2goYWN0aW9uKSB7XG4gICAgaWYgKCFpc1BsYWluT2JqZWN0KGFjdGlvbikpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDcpIDogYEFjdGlvbnMgbXVzdCBiZSBwbGFpbiBvYmplY3RzLiBJbnN0ZWFkLCB0aGUgYWN0dWFsIHR5cGUgd2FzOiAnJHtraW5kT2YoYWN0aW9uKX0nLiBZb3UgbWF5IG5lZWQgdG8gYWRkIG1pZGRsZXdhcmUgdG8geW91ciBzdG9yZSBzZXR1cCB0byBoYW5kbGUgZGlzcGF0Y2hpbmcgb3RoZXIgdmFsdWVzLCBzdWNoIGFzICdyZWR1eC10aHVuaycgdG8gaGFuZGxlIGRpc3BhdGNoaW5nIGZ1bmN0aW9ucy4gU2VlIGh0dHBzOi8vcmVkdXguanMub3JnL3R1dG9yaWFscy9mdW5kYW1lbnRhbHMvcGFydC00LXN0b3JlI21pZGRsZXdhcmUgYW5kIGh0dHBzOi8vcmVkdXguanMub3JnL3R1dG9yaWFscy9mdW5kYW1lbnRhbHMvcGFydC02LWFzeW5jLWxvZ2ljI3VzaW5nLXRoZS1yZWR1eC10aHVuay1taWRkbGV3YXJlIGZvciBleGFtcGxlcy5gKTtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBhY3Rpb24udHlwZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoOCkgOiAnQWN0aW9ucyBtYXkgbm90IGhhdmUgYW4gdW5kZWZpbmVkIFwidHlwZVwiIHByb3BlcnR5LiBZb3UgbWF5IGhhdmUgbWlzc3BlbGxlZCBhbiBhY3Rpb24gdHlwZSBzdHJpbmcgY29uc3RhbnQuJyk7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgYWN0aW9uLnR5cGUgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDE3KSA6IGBBY3Rpb24gXCJ0eXBlXCIgcHJvcGVydHkgbXVzdCBiZSBhIHN0cmluZy4gSW5zdGVhZCwgdGhlIGFjdHVhbCB0eXBlIHdhczogJyR7a2luZE9mKGFjdGlvbi50eXBlKX0nLiBWYWx1ZSB3YXM6ICcke2FjdGlvbi50eXBlfScgKHN0cmluZ2lmaWVkKWApO1xuICAgIH1cbiAgICBpZiAoaXNEaXNwYXRjaGluZykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoOSkgOiBcIlJlZHVjZXJzIG1heSBub3QgZGlzcGF0Y2ggYWN0aW9ucy5cIik7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICBpc0Rpc3BhdGNoaW5nID0gdHJ1ZTtcbiAgICAgIGN1cnJlbnRTdGF0ZSA9IGN1cnJlbnRSZWR1Y2VyKGN1cnJlbnRTdGF0ZSwgYWN0aW9uKTtcbiAgICB9IGZpbmFsbHkge1xuICAgICAgaXNEaXNwYXRjaGluZyA9IGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBsaXN0ZW5lcnMgPSBjdXJyZW50TGlzdGVuZXJzID0gbmV4dExpc3RlbmVycztcbiAgICBsaXN0ZW5lcnMuZm9yRWFjaCgobGlzdGVuZXIpID0+IHtcbiAgICAgIGxpc3RlbmVyKCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGFjdGlvbjtcbiAgfVxuICBmdW5jdGlvbiByZXBsYWNlUmVkdWNlcihuZXh0UmVkdWNlcikge1xuICAgIGlmICh0eXBlb2YgbmV4dFJlZHVjZXIgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMTApIDogYEV4cGVjdGVkIHRoZSBuZXh0UmVkdWNlciB0byBiZSBhIGZ1bmN0aW9uLiBJbnN0ZWFkLCByZWNlaXZlZDogJyR7a2luZE9mKG5leHRSZWR1Y2VyKX1gKTtcbiAgICB9XG4gICAgY3VycmVudFJlZHVjZXIgPSBuZXh0UmVkdWNlcjtcbiAgICBkaXNwYXRjaCh7XG4gICAgICB0eXBlOiBhY3Rpb25UeXBlc19kZWZhdWx0LlJFUExBQ0VcbiAgICB9KTtcbiAgfVxuICBmdW5jdGlvbiBvYnNlcnZhYmxlKCkge1xuICAgIGNvbnN0IG91dGVyU3Vic2NyaWJlID0gc3Vic2NyaWJlO1xuICAgIHJldHVybiB7XG4gICAgICAvKipcbiAgICAgICAqIFRoZSBtaW5pbWFsIG9ic2VydmFibGUgc3Vic2NyaXB0aW9uIG1ldGhvZC5cbiAgICAgICAqIEBwYXJhbSBvYnNlcnZlciBBbnkgb2JqZWN0IHRoYXQgY2FuIGJlIHVzZWQgYXMgYW4gb2JzZXJ2ZXIuXG4gICAgICAgKiBUaGUgb2JzZXJ2ZXIgb2JqZWN0IHNob3VsZCBoYXZlIGEgYG5leHRgIG1ldGhvZC5cbiAgICAgICAqIEByZXR1cm5zIEFuIG9iamVjdCB3aXRoIGFuIGB1bnN1YnNjcmliZWAgbWV0aG9kIHRoYXQgY2FuXG4gICAgICAgKiBiZSB1c2VkIHRvIHVuc3Vic2NyaWJlIHRoZSBvYnNlcnZhYmxlIGZyb20gdGhlIHN0b3JlLCBhbmQgcHJldmVudCBmdXJ0aGVyXG4gICAgICAgKiBlbWlzc2lvbiBvZiB2YWx1ZXMgZnJvbSB0aGUgb2JzZXJ2YWJsZS5cbiAgICAgICAqL1xuICAgICAgc3Vic2NyaWJlKG9ic2VydmVyKSB7XG4gICAgICAgIGlmICh0eXBlb2Ygb2JzZXJ2ZXIgIT09IFwib2JqZWN0XCIgfHwgb2JzZXJ2ZXIgPT09IG51bGwpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxMSkgOiBgRXhwZWN0ZWQgdGhlIG9ic2VydmVyIHRvIGJlIGFuIG9iamVjdC4gSW5zdGVhZCwgcmVjZWl2ZWQ6ICcke2tpbmRPZihvYnNlcnZlcil9J2ApO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIG9ic2VydmVTdGF0ZSgpIHtcbiAgICAgICAgICBjb25zdCBvYnNlcnZlckFzT2JzZXJ2ZXIgPSBvYnNlcnZlcjtcbiAgICAgICAgICBpZiAob2JzZXJ2ZXJBc09ic2VydmVyLm5leHQpIHtcbiAgICAgICAgICAgIG9ic2VydmVyQXNPYnNlcnZlci5uZXh0KGdldFN0YXRlKCkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBvYnNlcnZlU3RhdGUoKTtcbiAgICAgICAgY29uc3QgdW5zdWJzY3JpYmUgPSBvdXRlclN1YnNjcmliZShvYnNlcnZlU3RhdGUpO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHVuc3Vic2NyaWJlXG4gICAgICAgIH07XG4gICAgICB9LFxuICAgICAgW3N5bWJvbF9vYnNlcnZhYmxlX2RlZmF1bHRdKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH1cbiAgICB9O1xuICB9XG4gIGRpc3BhdGNoKHtcbiAgICB0eXBlOiBhY3Rpb25UeXBlc19kZWZhdWx0LklOSVRcbiAgfSk7XG4gIGNvbnN0IHN0b3JlID0ge1xuICAgIGRpc3BhdGNoLFxuICAgIHN1YnNjcmliZSxcbiAgICBnZXRTdGF0ZSxcbiAgICByZXBsYWNlUmVkdWNlcixcbiAgICBbc3ltYm9sX29ic2VydmFibGVfZGVmYXVsdF06IG9ic2VydmFibGVcbiAgfTtcbiAgcmV0dXJuIHN0b3JlO1xufVxuZnVuY3Rpb24gbGVnYWN5X2NyZWF0ZVN0b3JlKHJlZHVjZXIsIHByZWxvYWRlZFN0YXRlLCBlbmhhbmNlcikge1xuICByZXR1cm4gY3JlYXRlU3RvcmUocmVkdWNlciwgcHJlbG9hZGVkU3RhdGUsIGVuaGFuY2VyKTtcbn1cblxuLy8gc3JjL3V0aWxzL3dhcm5pbmcudHNcbmZ1bmN0aW9uIHdhcm5pbmcobWVzc2FnZSkge1xuICBpZiAodHlwZW9mIGNvbnNvbGUgIT09IFwidW5kZWZpbmVkXCIgJiYgdHlwZW9mIGNvbnNvbGUuZXJyb3IgPT09IFwiZnVuY3Rpb25cIikge1xuICAgIGNvbnNvbGUuZXJyb3IobWVzc2FnZSk7XG4gIH1cbiAgdHJ5IHtcbiAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZSk7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgfVxufVxuXG4vLyBzcmMvY29tYmluZVJlZHVjZXJzLnRzXG5mdW5jdGlvbiBnZXRVbmV4cGVjdGVkU3RhdGVTaGFwZVdhcm5pbmdNZXNzYWdlKGlucHV0U3RhdGUsIHJlZHVjZXJzLCBhY3Rpb24sIHVuZXhwZWN0ZWRLZXlDYWNoZSkge1xuICBjb25zdCByZWR1Y2VyS2V5cyA9IE9iamVjdC5rZXlzKHJlZHVjZXJzKTtcbiAgY29uc3QgYXJndW1lbnROYW1lID0gYWN0aW9uICYmIGFjdGlvbi50eXBlID09PSBhY3Rpb25UeXBlc19kZWZhdWx0LklOSVQgPyBcInByZWxvYWRlZFN0YXRlIGFyZ3VtZW50IHBhc3NlZCB0byBjcmVhdGVTdG9yZVwiIDogXCJwcmV2aW91cyBzdGF0ZSByZWNlaXZlZCBieSB0aGUgcmVkdWNlclwiO1xuICBpZiAocmVkdWNlcktleXMubGVuZ3RoID09PSAwKSB7XG4gICAgcmV0dXJuIFwiU3RvcmUgZG9lcyBub3QgaGF2ZSBhIHZhbGlkIHJlZHVjZXIuIE1ha2Ugc3VyZSB0aGUgYXJndW1lbnQgcGFzc2VkIHRvIGNvbWJpbmVSZWR1Y2VycyBpcyBhbiBvYmplY3Qgd2hvc2UgdmFsdWVzIGFyZSByZWR1Y2Vycy5cIjtcbiAgfVxuICBpZiAoIWlzUGxhaW5PYmplY3QoaW5wdXRTdGF0ZSkpIHtcbiAgICByZXR1cm4gYFRoZSAke2FyZ3VtZW50TmFtZX0gaGFzIHVuZXhwZWN0ZWQgdHlwZSBvZiBcIiR7a2luZE9mKGlucHV0U3RhdGUpfVwiLiBFeHBlY3RlZCBhcmd1bWVudCB0byBiZSBhbiBvYmplY3Qgd2l0aCB0aGUgZm9sbG93aW5nIGtleXM6IFwiJHtyZWR1Y2VyS2V5cy5qb2luKCdcIiwgXCInKX1cImA7XG4gIH1cbiAgY29uc3QgdW5leHBlY3RlZEtleXMgPSBPYmplY3Qua2V5cyhpbnB1dFN0YXRlKS5maWx0ZXIoKGtleSkgPT4gIXJlZHVjZXJzLmhhc093blByb3BlcnR5KGtleSkgJiYgIXVuZXhwZWN0ZWRLZXlDYWNoZVtrZXldKTtcbiAgdW5leHBlY3RlZEtleXMuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgdW5leHBlY3RlZEtleUNhY2hlW2tleV0gPSB0cnVlO1xuICB9KTtcbiAgaWYgKGFjdGlvbiAmJiBhY3Rpb24udHlwZSA9PT0gYWN0aW9uVHlwZXNfZGVmYXVsdC5SRVBMQUNFKVxuICAgIHJldHVybjtcbiAgaWYgKHVuZXhwZWN0ZWRLZXlzLmxlbmd0aCA+IDApIHtcbiAgICByZXR1cm4gYFVuZXhwZWN0ZWQgJHt1bmV4cGVjdGVkS2V5cy5sZW5ndGggPiAxID8gXCJrZXlzXCIgOiBcImtleVwifSBcIiR7dW5leHBlY3RlZEtleXMuam9pbignXCIsIFwiJyl9XCIgZm91bmQgaW4gJHthcmd1bWVudE5hbWV9LiBFeHBlY3RlZCB0byBmaW5kIG9uZSBvZiB0aGUga25vd24gcmVkdWNlciBrZXlzIGluc3RlYWQ6IFwiJHtyZWR1Y2VyS2V5cy5qb2luKCdcIiwgXCInKX1cIi4gVW5leHBlY3RlZCBrZXlzIHdpbGwgYmUgaWdub3JlZC5gO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnRSZWR1Y2VyU2hhcGUocmVkdWNlcnMpIHtcbiAgT2JqZWN0LmtleXMocmVkdWNlcnMpLmZvckVhY2goKGtleSkgPT4ge1xuICAgIGNvbnN0IHJlZHVjZXIgPSByZWR1Y2Vyc1trZXldO1xuICAgIGNvbnN0IGluaXRpYWxTdGF0ZSA9IHJlZHVjZXIodm9pZCAwLCB7XG4gICAgICB0eXBlOiBhY3Rpb25UeXBlc19kZWZhdWx0LklOSVRcbiAgICB9KTtcbiAgICBpZiAodHlwZW9mIGluaXRpYWxTdGF0ZSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMTIpIDogYFRoZSBzbGljZSByZWR1Y2VyIGZvciBrZXkgXCIke2tleX1cIiByZXR1cm5lZCB1bmRlZmluZWQgZHVyaW5nIGluaXRpYWxpemF0aW9uLiBJZiB0aGUgc3RhdGUgcGFzc2VkIHRvIHRoZSByZWR1Y2VyIGlzIHVuZGVmaW5lZCwgeW91IG11c3QgZXhwbGljaXRseSByZXR1cm4gdGhlIGluaXRpYWwgc3RhdGUuIFRoZSBpbml0aWFsIHN0YXRlIG1heSBub3QgYmUgdW5kZWZpbmVkLiBJZiB5b3UgZG9uJ3Qgd2FudCB0byBzZXQgYSB2YWx1ZSBmb3IgdGhpcyByZWR1Y2VyLCB5b3UgY2FuIHVzZSBudWxsIGluc3RlYWQgb2YgdW5kZWZpbmVkLmApO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHJlZHVjZXIodm9pZCAwLCB7XG4gICAgICB0eXBlOiBhY3Rpb25UeXBlc19kZWZhdWx0LlBST0JFX1VOS05PV05fQUNUSU9OKClcbiAgICB9KSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMTMpIDogYFRoZSBzbGljZSByZWR1Y2VyIGZvciBrZXkgXCIke2tleX1cIiByZXR1cm5lZCB1bmRlZmluZWQgd2hlbiBwcm9iZWQgd2l0aCBhIHJhbmRvbSB0eXBlLiBEb24ndCB0cnkgdG8gaGFuZGxlICcke2FjdGlvblR5cGVzX2RlZmF1bHQuSU5JVH0nIG9yIG90aGVyIGFjdGlvbnMgaW4gXCJyZWR1eC8qXCIgbmFtZXNwYWNlLiBUaGV5IGFyZSBjb25zaWRlcmVkIHByaXZhdGUuIEluc3RlYWQsIHlvdSBtdXN0IHJldHVybiB0aGUgY3VycmVudCBzdGF0ZSBmb3IgYW55IHVua25vd24gYWN0aW9ucywgdW5sZXNzIGl0IGlzIHVuZGVmaW5lZCwgaW4gd2hpY2ggY2FzZSB5b3UgbXVzdCByZXR1cm4gdGhlIGluaXRpYWwgc3RhdGUsIHJlZ2FyZGxlc3Mgb2YgdGhlIGFjdGlvbiB0eXBlLiBUaGUgaW5pdGlhbCBzdGF0ZSBtYXkgbm90IGJlIHVuZGVmaW5lZCwgYnV0IGNhbiBiZSBudWxsLmApO1xuICAgIH1cbiAgfSk7XG59XG5mdW5jdGlvbiBjb21iaW5lUmVkdWNlcnMocmVkdWNlcnMpIHtcbiAgY29uc3QgcmVkdWNlcktleXMgPSBPYmplY3Qua2V5cyhyZWR1Y2Vycyk7XG4gIGNvbnN0IGZpbmFsUmVkdWNlcnMgPSB7fTtcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCByZWR1Y2VyS2V5cy5sZW5ndGg7IGkrKykge1xuICAgIGNvbnN0IGtleSA9IHJlZHVjZXJLZXlzW2ldO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICAgIGlmICh0eXBlb2YgcmVkdWNlcnNba2V5XSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICB3YXJuaW5nKGBObyByZWR1Y2VyIHByb3ZpZGVkIGZvciBrZXkgXCIke2tleX1cImApO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAodHlwZW9mIHJlZHVjZXJzW2tleV0gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgZmluYWxSZWR1Y2Vyc1trZXldID0gcmVkdWNlcnNba2V5XTtcbiAgICB9XG4gIH1cbiAgY29uc3QgZmluYWxSZWR1Y2VyS2V5cyA9IE9iamVjdC5rZXlzKGZpbmFsUmVkdWNlcnMpO1xuICBsZXQgdW5leHBlY3RlZEtleUNhY2hlO1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgdW5leHBlY3RlZEtleUNhY2hlID0ge307XG4gIH1cbiAgbGV0IHNoYXBlQXNzZXJ0aW9uRXJyb3I7XG4gIHRyeSB7XG4gICAgYXNzZXJ0UmVkdWNlclNoYXBlKGZpbmFsUmVkdWNlcnMpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgc2hhcGVBc3NlcnRpb25FcnJvciA9IGU7XG4gIH1cbiAgcmV0dXJuIGZ1bmN0aW9uIGNvbWJpbmF0aW9uKHN0YXRlID0ge30sIGFjdGlvbikge1xuICAgIGlmIChzaGFwZUFzc2VydGlvbkVycm9yKSB7XG4gICAgICB0aHJvdyBzaGFwZUFzc2VydGlvbkVycm9yO1xuICAgIH1cbiAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICBjb25zdCB3YXJuaW5nTWVzc2FnZSA9IGdldFVuZXhwZWN0ZWRTdGF0ZVNoYXBlV2FybmluZ01lc3NhZ2Uoc3RhdGUsIGZpbmFsUmVkdWNlcnMsIGFjdGlvbiwgdW5leHBlY3RlZEtleUNhY2hlKTtcbiAgICAgIGlmICh3YXJuaW5nTWVzc2FnZSkge1xuICAgICAgICB3YXJuaW5nKHdhcm5pbmdNZXNzYWdlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbGV0IGhhc0NoYW5nZWQgPSBmYWxzZTtcbiAgICBjb25zdCBuZXh0U3RhdGUgPSB7fTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGZpbmFsUmVkdWNlcktleXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGtleSA9IGZpbmFsUmVkdWNlcktleXNbaV07XG4gICAgICBjb25zdCByZWR1Y2VyID0gZmluYWxSZWR1Y2Vyc1trZXldO1xuICAgICAgY29uc3QgcHJldmlvdXNTdGF0ZUZvcktleSA9IHN0YXRlW2tleV07XG4gICAgICBjb25zdCBuZXh0U3RhdGVGb3JLZXkgPSByZWR1Y2VyKHByZXZpb3VzU3RhdGVGb3JLZXksIGFjdGlvbik7XG4gICAgICBpZiAodHlwZW9mIG5leHRTdGF0ZUZvcktleSA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICBjb25zdCBhY3Rpb25UeXBlID0gYWN0aW9uICYmIGFjdGlvbi50eXBlO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxNCkgOiBgV2hlbiBjYWxsZWQgd2l0aCBhbiBhY3Rpb24gb2YgdHlwZSAke2FjdGlvblR5cGUgPyBgXCIke1N0cmluZyhhY3Rpb25UeXBlKX1cImAgOiBcIih1bmtub3duIHR5cGUpXCJ9LCB0aGUgc2xpY2UgcmVkdWNlciBmb3Iga2V5IFwiJHtrZXl9XCIgcmV0dXJuZWQgdW5kZWZpbmVkLiBUbyBpZ25vcmUgYW4gYWN0aW9uLCB5b3UgbXVzdCBleHBsaWNpdGx5IHJldHVybiB0aGUgcHJldmlvdXMgc3RhdGUuIElmIHlvdSB3YW50IHRoaXMgcmVkdWNlciB0byBob2xkIG5vIHZhbHVlLCB5b3UgY2FuIHJldHVybiBudWxsIGluc3RlYWQgb2YgdW5kZWZpbmVkLmApO1xuICAgICAgfVxuICAgICAgbmV4dFN0YXRlW2tleV0gPSBuZXh0U3RhdGVGb3JLZXk7XG4gICAgICBoYXNDaGFuZ2VkID0gaGFzQ2hhbmdlZCB8fCBuZXh0U3RhdGVGb3JLZXkgIT09IHByZXZpb3VzU3RhdGVGb3JLZXk7XG4gICAgfVxuICAgIGhhc0NoYW5nZWQgPSBoYXNDaGFuZ2VkIHx8IGZpbmFsUmVkdWNlcktleXMubGVuZ3RoICE9PSBPYmplY3Qua2V5cyhzdGF0ZSkubGVuZ3RoO1xuICAgIHJldHVybiBoYXNDaGFuZ2VkID8gbmV4dFN0YXRlIDogc3RhdGU7XG4gIH07XG59XG5cbi8vIHNyYy9iaW5kQWN0aW9uQ3JlYXRvcnMudHNcbmZ1bmN0aW9uIGJpbmRBY3Rpb25DcmVhdG9yKGFjdGlvbkNyZWF0b3IsIGRpc3BhdGNoKSB7XG4gIHJldHVybiBmdW5jdGlvbiguLi5hcmdzKSB7XG4gICAgcmV0dXJuIGRpc3BhdGNoKGFjdGlvbkNyZWF0b3IuYXBwbHkodGhpcywgYXJncykpO1xuICB9O1xufVxuZnVuY3Rpb24gYmluZEFjdGlvbkNyZWF0b3JzKGFjdGlvbkNyZWF0b3JzLCBkaXNwYXRjaCkge1xuICBpZiAodHlwZW9mIGFjdGlvbkNyZWF0b3JzID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICByZXR1cm4gYmluZEFjdGlvbkNyZWF0b3IoYWN0aW9uQ3JlYXRvcnMsIGRpc3BhdGNoKTtcbiAgfVxuICBpZiAodHlwZW9mIGFjdGlvbkNyZWF0b3JzICE9PSBcIm9iamVjdFwiIHx8IGFjdGlvbkNyZWF0b3JzID09PSBudWxsKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMTYpIDogYGJpbmRBY3Rpb25DcmVhdG9ycyBleHBlY3RlZCBhbiBvYmplY3Qgb3IgYSBmdW5jdGlvbiwgYnV0IGluc3RlYWQgcmVjZWl2ZWQ6ICcke2tpbmRPZihhY3Rpb25DcmVhdG9ycyl9Jy4gRGlkIHlvdSB3cml0ZSBcImltcG9ydCBBY3Rpb25DcmVhdG9ycyBmcm9tXCIgaW5zdGVhZCBvZiBcImltcG9ydCAqIGFzIEFjdGlvbkNyZWF0b3JzIGZyb21cIj9gKTtcbiAgfVxuICBjb25zdCBib3VuZEFjdGlvbkNyZWF0b3JzID0ge307XG4gIGZvciAoY29uc3Qga2V5IGluIGFjdGlvbkNyZWF0b3JzKSB7XG4gICAgY29uc3QgYWN0aW9uQ3JlYXRvciA9IGFjdGlvbkNyZWF0b3JzW2tleV07XG4gICAgaWYgKHR5cGVvZiBhY3Rpb25DcmVhdG9yID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgIGJvdW5kQWN0aW9uQ3JlYXRvcnNba2V5XSA9IGJpbmRBY3Rpb25DcmVhdG9yKGFjdGlvbkNyZWF0b3IsIGRpc3BhdGNoKTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGJvdW5kQWN0aW9uQ3JlYXRvcnM7XG59XG5cbi8vIHNyYy9jb21wb3NlLnRzXG5mdW5jdGlvbiBjb21wb3NlKC4uLmZ1bmNzKSB7XG4gIGlmIChmdW5jcy5sZW5ndGggPT09IDApIHtcbiAgICByZXR1cm4gKGFyZykgPT4gYXJnO1xuICB9XG4gIGlmIChmdW5jcy5sZW5ndGggPT09IDEpIHtcbiAgICByZXR1cm4gZnVuY3NbMF07XG4gIH1cbiAgcmV0dXJuIGZ1bmNzLnJlZHVjZSgoYSwgYikgPT4gKC4uLmFyZ3MpID0+IGEoYiguLi5hcmdzKSkpO1xufVxuXG4vLyBzcmMvYXBwbHlNaWRkbGV3YXJlLnRzXG5mdW5jdGlvbiBhcHBseU1pZGRsZXdhcmUoLi4ubWlkZGxld2FyZXMpIHtcbiAgcmV0dXJuIChjcmVhdGVTdG9yZTIpID0+IChyZWR1Y2VyLCBwcmVsb2FkZWRTdGF0ZSkgPT4ge1xuICAgIGNvbnN0IHN0b3JlID0gY3JlYXRlU3RvcmUyKHJlZHVjZXIsIHByZWxvYWRlZFN0YXRlKTtcbiAgICBsZXQgZGlzcGF0Y2ggPSAoKSA9PiB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxNSkgOiBcIkRpc3BhdGNoaW5nIHdoaWxlIGNvbnN0cnVjdGluZyB5b3VyIG1pZGRsZXdhcmUgaXMgbm90IGFsbG93ZWQuIE90aGVyIG1pZGRsZXdhcmUgd291bGQgbm90IGJlIGFwcGxpZWQgdG8gdGhpcyBkaXNwYXRjaC5cIik7XG4gICAgfTtcbiAgICBjb25zdCBtaWRkbGV3YXJlQVBJID0ge1xuICAgICAgZ2V0U3RhdGU6IHN0b3JlLmdldFN0YXRlLFxuICAgICAgZGlzcGF0Y2g6IChhY3Rpb24sIC4uLmFyZ3MpID0+IGRpc3BhdGNoKGFjdGlvbiwgLi4uYXJncylcbiAgICB9O1xuICAgIGNvbnN0IGNoYWluID0gbWlkZGxld2FyZXMubWFwKChtaWRkbGV3YXJlKSA9PiBtaWRkbGV3YXJlKG1pZGRsZXdhcmVBUEkpKTtcbiAgICBkaXNwYXRjaCA9IGNvbXBvc2UoLi4uY2hhaW4pKHN0b3JlLmRpc3BhdGNoKTtcbiAgICByZXR1cm4ge1xuICAgICAgLi4uc3RvcmUsXG4gICAgICBkaXNwYXRjaFxuICAgIH07XG4gIH07XG59XG5cbi8vIHNyYy91dGlscy9pc0FjdGlvbi50c1xuZnVuY3Rpb24gaXNBY3Rpb24oYWN0aW9uKSB7XG4gIHJldHVybiBpc1BsYWluT2JqZWN0KGFjdGlvbikgJiYgXCJ0eXBlXCIgaW4gYWN0aW9uICYmIHR5cGVvZiBhY3Rpb24udHlwZSA9PT0gXCJzdHJpbmdcIjtcbn1cbmV4cG9ydCB7XG4gIGFjdGlvblR5cGVzX2RlZmF1bHQgYXMgX19ET19OT1RfVVNFX19BY3Rpb25UeXBlcyxcbiAgYXBwbHlNaWRkbGV3YXJlLFxuICBiaW5kQWN0aW9uQ3JlYXRvcnMsXG4gIGNvbWJpbmVSZWR1Y2VycyxcbiAgY29tcG9zZSxcbiAgY3JlYXRlU3RvcmUsXG4gIGlzQWN0aW9uLFxuICBpc1BsYWluT2JqZWN0LFxuICBsZWdhY3lfY3JlYXRlU3RvcmVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZWR1eC5tanMubWFwIiwiLy8gc3JjL3V0aWxzL2Vudi50c1xudmFyIE5PVEhJTkcgPSBTeW1ib2wuZm9yKFwiaW1tZXItbm90aGluZ1wiKTtcbnZhciBEUkFGVEFCTEUgPSBTeW1ib2wuZm9yKFwiaW1tZXItZHJhZnRhYmxlXCIpO1xudmFyIERSQUZUX1NUQVRFID0gU3ltYm9sLmZvcihcImltbWVyLXN0YXRlXCIpO1xuXG4vLyBzcmMvdXRpbHMvZXJyb3JzLnRzXG52YXIgZXJyb3JzID0gcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiID8gW1xuICAvLyBBbGwgZXJyb3IgY29kZXMsIHN0YXJ0aW5nIGJ5IDA6XG4gIGZ1bmN0aW9uKHBsdWdpbikge1xuICAgIHJldHVybiBgVGhlIHBsdWdpbiBmb3IgJyR7cGx1Z2lufScgaGFzIG5vdCBiZWVuIGxvYWRlZCBpbnRvIEltbWVyLiBUbyBlbmFibGUgdGhlIHBsdWdpbiwgaW1wb3J0IGFuZCBjYWxsIFxcYGVuYWJsZSR7cGx1Z2lufSgpXFxgIHdoZW4gaW5pdGlhbGl6aW5nIHlvdXIgYXBwbGljYXRpb24uYDtcbiAgfSxcbiAgZnVuY3Rpb24odGhpbmcpIHtcbiAgICByZXR1cm4gYHByb2R1Y2UgY2FuIG9ubHkgYmUgY2FsbGVkIG9uIHRoaW5ncyB0aGF0IGFyZSBkcmFmdGFibGU6IHBsYWluIG9iamVjdHMsIGFycmF5cywgTWFwLCBTZXQgb3IgY2xhc3NlcyB0aGF0IGFyZSBtYXJrZWQgd2l0aCAnW2ltbWVyYWJsZV06IHRydWUnLiBHb3QgJyR7dGhpbmd9J2A7XG4gIH0sXG4gIFwiVGhpcyBvYmplY3QgaGFzIGJlZW4gZnJvemVuIGFuZCBzaG91bGQgbm90IGJlIG11dGF0ZWRcIixcbiAgZnVuY3Rpb24oZGF0YSkge1xuICAgIHJldHVybiBcIkNhbm5vdCB1c2UgYSBwcm94eSB0aGF0IGhhcyBiZWVuIHJldm9rZWQuIERpZCB5b3UgcGFzcyBhbiBvYmplY3QgZnJvbSBpbnNpZGUgYW4gaW1tZXIgZnVuY3Rpb24gdG8gYW4gYXN5bmMgcHJvY2Vzcz8gXCIgKyBkYXRhO1xuICB9LFxuICBcIkFuIGltbWVyIHByb2R1Y2VyIHJldHVybmVkIGEgbmV3IHZhbHVlICphbmQqIG1vZGlmaWVkIGl0cyBkcmFmdC4gRWl0aGVyIHJldHVybiBhIG5ldyB2YWx1ZSAqb3IqIG1vZGlmeSB0aGUgZHJhZnQuXCIsXG4gIFwiSW1tZXIgZm9yYmlkcyBjaXJjdWxhciByZWZlcmVuY2VzXCIsXG4gIFwiVGhlIGZpcnN0IG9yIHNlY29uZCBhcmd1bWVudCB0byBgcHJvZHVjZWAgbXVzdCBiZSBhIGZ1bmN0aW9uXCIsXG4gIFwiVGhlIHRoaXJkIGFyZ3VtZW50IHRvIGBwcm9kdWNlYCBtdXN0IGJlIGEgZnVuY3Rpb24gb3IgdW5kZWZpbmVkXCIsXG4gIFwiRmlyc3QgYXJndW1lbnQgdG8gYGNyZWF0ZURyYWZ0YCBtdXN0IGJlIGEgcGxhaW4gb2JqZWN0LCBhbiBhcnJheSwgb3IgYW4gaW1tZXJhYmxlIG9iamVjdFwiLFxuICBcIkZpcnN0IGFyZ3VtZW50IHRvIGBmaW5pc2hEcmFmdGAgbXVzdCBiZSBhIGRyYWZ0IHJldHVybmVkIGJ5IGBjcmVhdGVEcmFmdGBcIixcbiAgZnVuY3Rpb24odGhpbmcpIHtcbiAgICByZXR1cm4gYCdjdXJyZW50JyBleHBlY3RzIGEgZHJhZnQsIGdvdDogJHt0aGluZ31gO1xuICB9LFxuICBcIk9iamVjdC5kZWZpbmVQcm9wZXJ0eSgpIGNhbm5vdCBiZSB1c2VkIG9uIGFuIEltbWVyIGRyYWZ0XCIsXG4gIFwiT2JqZWN0LnNldFByb3RvdHlwZU9mKCkgY2Fubm90IGJlIHVzZWQgb24gYW4gSW1tZXIgZHJhZnRcIixcbiAgXCJJbW1lciBvbmx5IHN1cHBvcnRzIGRlbGV0aW5nIGFycmF5IGluZGljZXNcIixcbiAgXCJJbW1lciBvbmx5IHN1cHBvcnRzIHNldHRpbmcgYXJyYXkgaW5kaWNlcyBhbmQgdGhlICdsZW5ndGgnIHByb3BlcnR5XCIsXG4gIGZ1bmN0aW9uKHRoaW5nKSB7XG4gICAgcmV0dXJuIGAnb3JpZ2luYWwnIGV4cGVjdHMgYSBkcmFmdCwgZ290OiAke3RoaW5nfWA7XG4gIH1cbiAgLy8gTm90ZTogaWYgbW9yZSBlcnJvcnMgYXJlIGFkZGVkLCB0aGUgZXJyb3JPZmZzZXQgaW4gUGF0Y2hlcy50cyBzaG91bGQgYmUgaW5jcmVhc2VkXG4gIC8vIFNlZSBQYXRjaGVzLnRzIGZvciBhZGRpdGlvbmFsIGVycm9yc1xuXSA6IFtdO1xuZnVuY3Rpb24gZGllKGVycm9yLCAuLi5hcmdzKSB7XG4gIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcbiAgICBjb25zdCBlID0gZXJyb3JzW2Vycm9yXTtcbiAgICBjb25zdCBtc2cgPSBpc0Z1bmN0aW9uKGUpID8gZS5hcHBseShudWxsLCBhcmdzKSA6IGU7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBbSW1tZXJdICR7bXNnfWApO1xuICB9XG4gIHRocm93IG5ldyBFcnJvcihcbiAgICBgW0ltbWVyXSBtaW5pZmllZCBlcnJvciBucjogJHtlcnJvcn0uIEZ1bGwgZXJyb3IgYXQ6IGh0dHBzOi8vYml0Lmx5LzNjWEVLV2ZgXG4gICk7XG59XG5cbi8vIHNyYy91dGlscy9jb21tb24udHNcbnZhciBPID0gT2JqZWN0O1xudmFyIGdldFByb3RvdHlwZU9mID0gTy5nZXRQcm90b3R5cGVPZjtcbnZhciBDT05TVFJVQ1RPUiA9IFwiY29uc3RydWN0b3JcIjtcbnZhciBQUk9UT1RZUEUgPSBcInByb3RvdHlwZVwiO1xudmFyIENPTkZJR1VSQUJMRSA9IFwiY29uZmlndXJhYmxlXCI7XG52YXIgRU5VTUVSQUJMRSA9IFwiZW51bWVyYWJsZVwiO1xudmFyIFdSSVRBQkxFID0gXCJ3cml0YWJsZVwiO1xudmFyIFZBTFVFID0gXCJ2YWx1ZVwiO1xudmFyIGlzRHJhZnQgPSAodmFsdWUpID0+ICEhdmFsdWUgJiYgISF2YWx1ZVtEUkFGVF9TVEFURV07XG5mdW5jdGlvbiBpc0RyYWZ0YWJsZSh2YWx1ZSkge1xuICBpZiAoIXZhbHVlKVxuICAgIHJldHVybiBmYWxzZTtcbiAgcmV0dXJuIGlzUGxhaW5PYmplY3QodmFsdWUpIHx8IGlzQXJyYXkodmFsdWUpIHx8ICEhdmFsdWVbRFJBRlRBQkxFXSB8fCAhIXZhbHVlW0NPTlNUUlVDVE9SXT8uW0RSQUZUQUJMRV0gfHwgaXNNYXAodmFsdWUpIHx8IGlzU2V0KHZhbHVlKTtcbn1cbnZhciBvYmplY3RDdG9yU3RyaW5nID0gT1tQUk9UT1RZUEVdW0NPTlNUUlVDVE9SXS50b1N0cmluZygpO1xudmFyIGNhY2hlZEN0b3JTdHJpbmdzID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5mdW5jdGlvbiBpc1BsYWluT2JqZWN0KHZhbHVlKSB7XG4gIGlmICghdmFsdWUgfHwgIWlzT2JqZWN0aXNoKHZhbHVlKSlcbiAgICByZXR1cm4gZmFsc2U7XG4gIGNvbnN0IHByb3RvID0gZ2V0UHJvdG90eXBlT2YodmFsdWUpO1xuICBpZiAocHJvdG8gPT09IG51bGwgfHwgcHJvdG8gPT09IE9bUFJPVE9UWVBFXSlcbiAgICByZXR1cm4gdHJ1ZTtcbiAgY29uc3QgQ3RvciA9IE8uaGFzT3duUHJvcGVydHkuY2FsbChwcm90bywgQ09OU1RSVUNUT1IpICYmIHByb3RvW0NPTlNUUlVDVE9SXTtcbiAgaWYgKEN0b3IgPT09IE9iamVjdClcbiAgICByZXR1cm4gdHJ1ZTtcbiAgaWYgKCFpc0Z1bmN0aW9uKEN0b3IpKVxuICAgIHJldHVybiBmYWxzZTtcbiAgbGV0IGN0b3JTdHJpbmcgPSBjYWNoZWRDdG9yU3RyaW5ncy5nZXQoQ3Rvcik7XG4gIGlmIChjdG9yU3RyaW5nID09PSB2b2lkIDApIHtcbiAgICBjdG9yU3RyaW5nID0gRnVuY3Rpb24udG9TdHJpbmcuY2FsbChDdG9yKTtcbiAgICBjYWNoZWRDdG9yU3RyaW5ncy5zZXQoQ3RvciwgY3RvclN0cmluZyk7XG4gIH1cbiAgcmV0dXJuIGN0b3JTdHJpbmcgPT09IG9iamVjdEN0b3JTdHJpbmc7XG59XG5mdW5jdGlvbiBvcmlnaW5hbCh2YWx1ZSkge1xuICBpZiAoIWlzRHJhZnQodmFsdWUpKVxuICAgIGRpZSgxNSwgdmFsdWUpO1xuICByZXR1cm4gdmFsdWVbRFJBRlRfU1RBVEVdLmJhc2VfO1xufVxuZnVuY3Rpb24gZWFjaChvYmosIGl0ZXIsIHN0cmljdCA9IHRydWUpIHtcbiAgaWYgKGdldEFyY2h0eXBlKG9iaikgPT09IDAgLyogT2JqZWN0ICovKSB7XG4gICAgY29uc3Qga2V5cyA9IHN0cmljdCA/IFJlZmxlY3Qub3duS2V5cyhvYmopIDogTy5rZXlzKG9iaik7XG4gICAga2V5cy5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgIGl0ZXIoa2V5LCBvYmpba2V5XSwgb2JqKTtcbiAgICB9KTtcbiAgfSBlbHNlIHtcbiAgICBvYmouZm9yRWFjaCgoZW50cnksIGluZGV4KSA9PiBpdGVyKGluZGV4LCBlbnRyeSwgb2JqKSk7XG4gIH1cbn1cbmZ1bmN0aW9uIGdldEFyY2h0eXBlKHRoaW5nKSB7XG4gIGNvbnN0IHN0YXRlID0gdGhpbmdbRFJBRlRfU1RBVEVdO1xuICByZXR1cm4gc3RhdGUgPyBzdGF0ZS50eXBlXyA6IGlzQXJyYXkodGhpbmcpID8gMSAvKiBBcnJheSAqLyA6IGlzTWFwKHRoaW5nKSA/IDIgLyogTWFwICovIDogaXNTZXQodGhpbmcpID8gMyAvKiBTZXQgKi8gOiAwIC8qIE9iamVjdCAqLztcbn1cbnZhciBoYXMgPSAodGhpbmcsIHByb3AsIHR5cGUgPSBnZXRBcmNodHlwZSh0aGluZykpID0+IHR5cGUgPT09IDIgLyogTWFwICovID8gdGhpbmcuaGFzKHByb3ApIDogT1tQUk9UT1RZUEVdLmhhc093blByb3BlcnR5LmNhbGwodGhpbmcsIHByb3ApO1xudmFyIGdldCA9ICh0aGluZywgcHJvcCwgdHlwZSA9IGdldEFyY2h0eXBlKHRoaW5nKSkgPT4gKFxuICAvLyBAdHMtaWdub3JlXG4gIHR5cGUgPT09IDIgLyogTWFwICovID8gdGhpbmcuZ2V0KHByb3ApIDogdGhpbmdbcHJvcF1cbik7XG52YXIgc2V0ID0gKHRoaW5nLCBwcm9wT3JPbGRWYWx1ZSwgdmFsdWUsIHR5cGUgPSBnZXRBcmNodHlwZSh0aGluZykpID0+IHtcbiAgaWYgKHR5cGUgPT09IDIgLyogTWFwICovKVxuICAgIHRoaW5nLnNldChwcm9wT3JPbGRWYWx1ZSwgdmFsdWUpO1xuICBlbHNlIGlmICh0eXBlID09PSAzIC8qIFNldCAqLykge1xuICAgIHRoaW5nLmFkZCh2YWx1ZSk7XG4gIH0gZWxzZVxuICAgIHRoaW5nW3Byb3BPck9sZFZhbHVlXSA9IHZhbHVlO1xufTtcbmZ1bmN0aW9uIGlzKHgsIHkpIHtcbiAgaWYgKHggPT09IHkpIHtcbiAgICByZXR1cm4geCAhPT0gMCB8fCAxIC8geCA9PT0gMSAvIHk7XG4gIH0gZWxzZSB7XG4gICAgcmV0dXJuIHggIT09IHggJiYgeSAhPT0geTtcbiAgfVxufVxudmFyIGlzQXJyYXkgPSBBcnJheS5pc0FycmF5O1xudmFyIGlzTWFwID0gKHRhcmdldCkgPT4gdGFyZ2V0IGluc3RhbmNlb2YgTWFwO1xudmFyIGlzU2V0ID0gKHRhcmdldCkgPT4gdGFyZ2V0IGluc3RhbmNlb2YgU2V0O1xudmFyIGlzT2JqZWN0aXNoID0gKHRhcmdldCkgPT4gdHlwZW9mIHRhcmdldCA9PT0gXCJvYmplY3RcIjtcbnZhciBpc0Z1bmN0aW9uID0gKHRhcmdldCkgPT4gdHlwZW9mIHRhcmdldCA9PT0gXCJmdW5jdGlvblwiO1xudmFyIGlzQm9vbGVhbiA9ICh0YXJnZXQpID0+IHR5cGVvZiB0YXJnZXQgPT09IFwiYm9vbGVhblwiO1xuZnVuY3Rpb24gaXNBcnJheUluZGV4KHZhbHVlKSB7XG4gIGNvbnN0IG4gPSArdmFsdWU7XG4gIHJldHVybiBOdW1iZXIuaXNJbnRlZ2VyKG4pICYmIFN0cmluZyhuKSA9PT0gdmFsdWU7XG59XG52YXIgZ2V0UHJveHlEcmFmdCA9ICh2YWx1ZSkgPT4ge1xuICBpZiAoIWlzT2JqZWN0aXNoKHZhbHVlKSlcbiAgICByZXR1cm4gbnVsbDtcbiAgcmV0dXJuIHZhbHVlPy5bRFJBRlRfU1RBVEVdO1xufTtcbnZhciBsYXRlc3QgPSAoc3RhdGUpID0+IHN0YXRlLmNvcHlfIHx8IHN0YXRlLmJhc2VfO1xudmFyIGdldFZhbHVlID0gKHZhbHVlKSA9PiB7XG4gIGNvbnN0IHByb3h5RHJhZnQgPSBnZXRQcm94eURyYWZ0KHZhbHVlKTtcbiAgcmV0dXJuIHByb3h5RHJhZnQgPyBnZXRGaW5hbFZhbHVlKHByb3h5RHJhZnQpIDogdmFsdWU7XG59O1xudmFyIGdldEZpbmFsVmFsdWUgPSAoc3RhdGUpID0+IHN0YXRlLm1vZGlmaWVkXyA/IHN0YXRlLmNvcHlfIDogc3RhdGUuYmFzZV87XG5mdW5jdGlvbiBzaGFsbG93Q29weShiYXNlLCBzdHJpY3QpIHtcbiAgaWYgKGlzTWFwKGJhc2UpKSB7XG4gICAgcmV0dXJuIG5ldyBNYXAoYmFzZSk7XG4gIH1cbiAgaWYgKGlzU2V0KGJhc2UpKSB7XG4gICAgcmV0dXJuIG5ldyBTZXQoYmFzZSk7XG4gIH1cbiAgaWYgKGlzQXJyYXkoYmFzZSkpXG4gICAgcmV0dXJuIEFycmF5W1BST1RPVFlQRV0uc2xpY2UuY2FsbChiYXNlKTtcbiAgY29uc3QgaXNQbGFpbiA9IGlzUGxhaW5PYmplY3QoYmFzZSk7XG4gIGlmIChzdHJpY3QgPT09IHRydWUgfHwgc3RyaWN0ID09PSBcImNsYXNzX29ubHlcIiAmJiAhaXNQbGFpbikge1xuICAgIGNvbnN0IGRlc2NyaXB0b3JzID0gTy5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKGJhc2UpO1xuICAgIGRlbGV0ZSBkZXNjcmlwdG9yc1tEUkFGVF9TVEFURV07XG4gICAgbGV0IGtleXMgPSBSZWZsZWN0Lm93bktleXMoZGVzY3JpcHRvcnMpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwga2V5cy5sZW5ndGg7IGkrKykge1xuICAgICAgY29uc3Qga2V5ID0ga2V5c1tpXTtcbiAgICAgIGNvbnN0IGRlc2MgPSBkZXNjcmlwdG9yc1trZXldO1xuICAgICAgaWYgKGRlc2NbV1JJVEFCTEVdID09PSBmYWxzZSkge1xuICAgICAgICBkZXNjW1dSSVRBQkxFXSA9IHRydWU7XG4gICAgICAgIGRlc2NbQ09ORklHVVJBQkxFXSA9IHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoZGVzYy5nZXQgfHwgZGVzYy5zZXQpXG4gICAgICAgIGRlc2NyaXB0b3JzW2tleV0gPSB7XG4gICAgICAgICAgW0NPTkZJR1VSQUJMRV06IHRydWUsXG4gICAgICAgICAgW1dSSVRBQkxFXTogdHJ1ZSxcbiAgICAgICAgICAvLyBjb3VsZCBsaXZlIHdpdGggISFkZXNjLnNldCBhcyB3ZWxsIGhlcmUuLi5cbiAgICAgICAgICBbRU5VTUVSQUJMRV06IGRlc2NbRU5VTUVSQUJMRV0sXG4gICAgICAgICAgW1ZBTFVFXTogYmFzZVtrZXldXG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBPLmNyZWF0ZShnZXRQcm90b3R5cGVPZihiYXNlKSwgZGVzY3JpcHRvcnMpO1xuICB9IGVsc2Uge1xuICAgIGNvbnN0IHByb3RvID0gZ2V0UHJvdG90eXBlT2YoYmFzZSk7XG4gICAgaWYgKHByb3RvICE9PSBudWxsICYmIGlzUGxhaW4pIHtcbiAgICAgIHJldHVybiB7IC4uLmJhc2UgfTtcbiAgICB9XG4gICAgY29uc3Qgb2JqID0gTy5jcmVhdGUocHJvdG8pO1xuICAgIHJldHVybiBPLmFzc2lnbihvYmosIGJhc2UpO1xuICB9XG59XG5mdW5jdGlvbiBmcmVlemUob2JqLCBkZWVwID0gZmFsc2UpIHtcbiAgaWYgKGlzRnJvemVuKG9iaikgfHwgaXNEcmFmdChvYmopIHx8ICFpc0RyYWZ0YWJsZShvYmopKVxuICAgIHJldHVybiBvYmo7XG4gIGlmIChnZXRBcmNodHlwZShvYmopID4gMSkge1xuICAgIE8uZGVmaW5lUHJvcGVydGllcyhvYmosIHtcbiAgICAgIHNldDogZG9udE11dGF0ZU1ldGhvZE92ZXJyaWRlLFxuICAgICAgYWRkOiBkb250TXV0YXRlTWV0aG9kT3ZlcnJpZGUsXG4gICAgICBjbGVhcjogZG9udE11dGF0ZU1ldGhvZE92ZXJyaWRlLFxuICAgICAgZGVsZXRlOiBkb250TXV0YXRlTWV0aG9kT3ZlcnJpZGVcbiAgICB9KTtcbiAgfVxuICBPLmZyZWV6ZShvYmopO1xuICBpZiAoZGVlcClcbiAgICBlYWNoKFxuICAgICAgb2JqLFxuICAgICAgKF9rZXksIHZhbHVlKSA9PiB7XG4gICAgICAgIGZyZWV6ZSh2YWx1ZSwgdHJ1ZSk7XG4gICAgICB9LFxuICAgICAgZmFsc2VcbiAgICApO1xuICByZXR1cm4gb2JqO1xufVxuZnVuY3Rpb24gZG9udE11dGF0ZUZyb3plbkNvbGxlY3Rpb25zKCkge1xuICBkaWUoMik7XG59XG52YXIgZG9udE11dGF0ZU1ldGhvZE92ZXJyaWRlID0ge1xuICBbVkFMVUVdOiBkb250TXV0YXRlRnJvemVuQ29sbGVjdGlvbnNcbn07XG5mdW5jdGlvbiBpc0Zyb3plbihvYmopIHtcbiAgaWYgKG9iaiA9PT0gbnVsbCB8fCAhaXNPYmplY3Rpc2gob2JqKSlcbiAgICByZXR1cm4gdHJ1ZTtcbiAgcmV0dXJuIE8uaXNGcm96ZW4ob2JqKTtcbn1cblxuLy8gc3JjL3V0aWxzL3BsdWdpbnMudHNcbnZhciBQbHVnaW5NYXBTZXQgPSBcIk1hcFNldFwiO1xudmFyIFBsdWdpblBhdGNoZXMgPSBcIlBhdGNoZXNcIjtcbnZhciBQbHVnaW5BcnJheU1ldGhvZHMgPSBcIkFycmF5TWV0aG9kc1wiO1xudmFyIHBsdWdpbnMgPSB7fTtcbmZ1bmN0aW9uIGdldFBsdWdpbihwbHVnaW5LZXkpIHtcbiAgY29uc3QgcGx1Z2luID0gcGx1Z2luc1twbHVnaW5LZXldO1xuICBpZiAoIXBsdWdpbikge1xuICAgIGRpZSgwLCBwbHVnaW5LZXkpO1xuICB9XG4gIHJldHVybiBwbHVnaW47XG59XG52YXIgaXNQbHVnaW5Mb2FkZWQgPSAocGx1Z2luS2V5KSA9PiAhIXBsdWdpbnNbcGx1Z2luS2V5XTtcbmZ1bmN0aW9uIGxvYWRQbHVnaW4ocGx1Z2luS2V5LCBpbXBsZW1lbnRhdGlvbikge1xuICBpZiAoIXBsdWdpbnNbcGx1Z2luS2V5XSlcbiAgICBwbHVnaW5zW3BsdWdpbktleV0gPSBpbXBsZW1lbnRhdGlvbjtcbn1cblxuLy8gc3JjL2NvcmUvc2NvcGUudHNcbnZhciBjdXJyZW50U2NvcGU7XG52YXIgZ2V0Q3VycmVudFNjb3BlID0gKCkgPT4gY3VycmVudFNjb3BlO1xudmFyIGNyZWF0ZVNjb3BlID0gKHBhcmVudF8sIGltbWVyXykgPT4gKHtcbiAgZHJhZnRzXzogW10sXG4gIHBhcmVudF8sXG4gIGltbWVyXyxcbiAgLy8gV2hlbmV2ZXIgdGhlIG1vZGlmaWVkIGRyYWZ0IGNvbnRhaW5zIGEgZHJhZnQgZnJvbSBhbm90aGVyIHNjb3BlLCB3ZVxuICAvLyBuZWVkIHRvIHByZXZlbnQgYXV0by1mcmVlemluZyBzbyB0aGUgdW5vd25lZCBkcmFmdCBjYW4gYmUgZmluYWxpemVkLlxuICBjYW5BdXRvRnJlZXplXzogdHJ1ZSxcbiAgdW5maW5hbGl6ZWREcmFmdHNfOiAwLFxuICBoYW5kbGVkU2V0XzogLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKSxcbiAgcHJvY2Vzc2VkRm9yUGF0Y2hlc186IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG4gIG1hcFNldFBsdWdpbl86IGlzUGx1Z2luTG9hZGVkKFBsdWdpbk1hcFNldCkgPyBnZXRQbHVnaW4oUGx1Z2luTWFwU2V0KSA6IHZvaWQgMCxcbiAgYXJyYXlNZXRob2RzUGx1Z2luXzogaXNQbHVnaW5Mb2FkZWQoUGx1Z2luQXJyYXlNZXRob2RzKSA/IGdldFBsdWdpbihQbHVnaW5BcnJheU1ldGhvZHMpIDogdm9pZCAwXG59KTtcbmZ1bmN0aW9uIHVzZVBhdGNoZXNJblNjb3BlKHNjb3BlLCBwYXRjaExpc3RlbmVyKSB7XG4gIGlmIChwYXRjaExpc3RlbmVyKSB7XG4gICAgc2NvcGUucGF0Y2hQbHVnaW5fID0gZ2V0UGx1Z2luKFBsdWdpblBhdGNoZXMpO1xuICAgIHNjb3BlLnBhdGNoZXNfID0gW107XG4gICAgc2NvcGUuaW52ZXJzZVBhdGNoZXNfID0gW107XG4gICAgc2NvcGUucGF0Y2hMaXN0ZW5lcl8gPSBwYXRjaExpc3RlbmVyO1xuICB9XG59XG5mdW5jdGlvbiByZXZva2VTY29wZShzY29wZSkge1xuICBsZWF2ZVNjb3BlKHNjb3BlKTtcbiAgc2NvcGUuZHJhZnRzXy5mb3JFYWNoKHJldm9rZURyYWZ0KTtcbiAgc2NvcGUuZHJhZnRzXyA9IG51bGw7XG59XG5mdW5jdGlvbiBsZWF2ZVNjb3BlKHNjb3BlKSB7XG4gIGlmIChzY29wZSA9PT0gY3VycmVudFNjb3BlKSB7XG4gICAgY3VycmVudFNjb3BlID0gc2NvcGUucGFyZW50XztcbiAgfVxufVxudmFyIGVudGVyU2NvcGUgPSAoaW1tZXIyKSA9PiBjdXJyZW50U2NvcGUgPSBjcmVhdGVTY29wZShjdXJyZW50U2NvcGUsIGltbWVyMik7XG5mdW5jdGlvbiByZXZva2VEcmFmdChkcmFmdCkge1xuICBjb25zdCBzdGF0ZSA9IGRyYWZ0W0RSQUZUX1NUQVRFXTtcbiAgaWYgKHN0YXRlLnR5cGVfID09PSAwIC8qIE9iamVjdCAqLyB8fCBzdGF0ZS50eXBlXyA9PT0gMSAvKiBBcnJheSAqLylcbiAgICBzdGF0ZS5yZXZva2VfKCk7XG4gIGVsc2VcbiAgICBzdGF0ZS5yZXZva2VkXyA9IHRydWU7XG59XG5cbi8vIHNyYy9jb3JlL2ZpbmFsaXplLnRzXG5mdW5jdGlvbiBwcm9jZXNzUmVzdWx0KHJlc3VsdCwgc2NvcGUpIHtcbiAgc2NvcGUudW5maW5hbGl6ZWREcmFmdHNfID0gc2NvcGUuZHJhZnRzXy5sZW5ndGg7XG4gIGNvbnN0IGJhc2VEcmFmdCA9IHNjb3BlLmRyYWZ0c19bMF07XG4gIGNvbnN0IGlzUmVwbGFjZWQgPSByZXN1bHQgIT09IHZvaWQgMCAmJiByZXN1bHQgIT09IGJhc2VEcmFmdDtcbiAgaWYgKGlzUmVwbGFjZWQpIHtcbiAgICBpZiAoYmFzZURyYWZ0W0RSQUZUX1NUQVRFXS5tb2RpZmllZF8pIHtcbiAgICAgIHJldm9rZVNjb3BlKHNjb3BlKTtcbiAgICAgIGRpZSg0KTtcbiAgICB9XG4gICAgaWYgKGlzRHJhZnRhYmxlKHJlc3VsdCkpIHtcbiAgICAgIHJlc3VsdCA9IGZpbmFsaXplKHNjb3BlLCByZXN1bHQpO1xuICAgIH1cbiAgICBjb25zdCB7IHBhdGNoUGx1Z2luXyB9ID0gc2NvcGU7XG4gICAgaWYgKHBhdGNoUGx1Z2luXykge1xuICAgICAgcGF0Y2hQbHVnaW5fLmdlbmVyYXRlUmVwbGFjZW1lbnRQYXRjaGVzXyhcbiAgICAgICAgYmFzZURyYWZ0W0RSQUZUX1NUQVRFXS5iYXNlXyxcbiAgICAgICAgcmVzdWx0LFxuICAgICAgICBzY29wZVxuICAgICAgKTtcbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgcmVzdWx0ID0gZmluYWxpemUoc2NvcGUsIGJhc2VEcmFmdCk7XG4gIH1cbiAgbWF5YmVGcmVlemUoc2NvcGUsIHJlc3VsdCwgdHJ1ZSk7XG4gIHJldm9rZVNjb3BlKHNjb3BlKTtcbiAgaWYgKHNjb3BlLnBhdGNoZXNfKSB7XG4gICAgc2NvcGUucGF0Y2hMaXN0ZW5lcl8oc2NvcGUucGF0Y2hlc18sIHNjb3BlLmludmVyc2VQYXRjaGVzXyk7XG4gIH1cbiAgcmV0dXJuIHJlc3VsdCAhPT0gTk9USElORyA/IHJlc3VsdCA6IHZvaWQgMDtcbn1cbmZ1bmN0aW9uIGZpbmFsaXplKHJvb3RTY29wZSwgdmFsdWUpIHtcbiAgaWYgKGlzRnJvemVuKHZhbHVlKSlcbiAgICByZXR1cm4gdmFsdWU7XG4gIGNvbnN0IHN0YXRlID0gdmFsdWVbRFJBRlRfU1RBVEVdO1xuICBpZiAoIXN0YXRlKSB7XG4gICAgY29uc3QgZmluYWxWYWx1ZSA9IGhhbmRsZVZhbHVlKHZhbHVlLCByb290U2NvcGUuaGFuZGxlZFNldF8sIHJvb3RTY29wZSk7XG4gICAgcmV0dXJuIGZpbmFsVmFsdWU7XG4gIH1cbiAgaWYgKCFpc1NhbWVTY29wZShzdGF0ZSwgcm9vdFNjb3BlKSkge1xuICAgIHJldHVybiB2YWx1ZTtcbiAgfVxuICBpZiAoIXN0YXRlLm1vZGlmaWVkXykge1xuICAgIHJldHVybiBzdGF0ZS5iYXNlXztcbiAgfVxuICBpZiAoIXN0YXRlLmZpbmFsaXplZF8pIHtcbiAgICBjb25zdCB7IGNhbGxiYWNrc18gfSA9IHN0YXRlO1xuICAgIGlmIChjYWxsYmFja3NfKSB7XG4gICAgICB3aGlsZSAoY2FsbGJhY2tzXy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IGNhbGxiYWNrID0gY2FsbGJhY2tzXy5wb3AoKTtcbiAgICAgICAgY2FsbGJhY2socm9vdFNjb3BlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZ2VuZXJhdGVQYXRjaGVzQW5kRmluYWxpemUoc3RhdGUsIHJvb3RTY29wZSk7XG4gIH1cbiAgcmV0dXJuIHN0YXRlLmNvcHlfO1xufVxuZnVuY3Rpb24gbWF5YmVGcmVlemUoc2NvcGUsIHZhbHVlLCBkZWVwID0gZmFsc2UpIHtcbiAgaWYgKCFzY29wZS5wYXJlbnRfICYmIHNjb3BlLmltbWVyXy5hdXRvRnJlZXplXyAmJiBzY29wZS5jYW5BdXRvRnJlZXplXykge1xuICAgIGZyZWV6ZSh2YWx1ZSwgZGVlcCk7XG4gIH1cbn1cbmZ1bmN0aW9uIG1hcmtTdGF0ZUZpbmFsaXplZChzdGF0ZSkge1xuICBzdGF0ZS5maW5hbGl6ZWRfID0gdHJ1ZTtcbiAgc3RhdGUuc2NvcGVfLnVuZmluYWxpemVkRHJhZnRzXy0tO1xufVxudmFyIGlzU2FtZVNjb3BlID0gKHN0YXRlLCByb290U2NvcGUpID0+IHN0YXRlLnNjb3BlXyA9PT0gcm9vdFNjb3BlO1xudmFyIEVNUFRZX0xPQ0FUSU9OU19SRVNVTFQgPSBbXTtcbmZ1bmN0aW9uIHVwZGF0ZURyYWZ0SW5QYXJlbnQocGFyZW50LCBkcmFmdFZhbHVlLCBmaW5hbGl6ZWRWYWx1ZSwgb3JpZ2luYWxLZXkpIHtcbiAgY29uc3QgcGFyZW50Q29weSA9IGxhdGVzdChwYXJlbnQpO1xuICBjb25zdCBwYXJlbnRUeXBlID0gcGFyZW50LnR5cGVfO1xuICBpZiAob3JpZ2luYWxLZXkgIT09IHZvaWQgMCkge1xuICAgIGNvbnN0IGN1cnJlbnRWYWx1ZSA9IGdldChwYXJlbnRDb3B5LCBvcmlnaW5hbEtleSwgcGFyZW50VHlwZSk7XG4gICAgaWYgKGN1cnJlbnRWYWx1ZSA9PT0gZHJhZnRWYWx1ZSkge1xuICAgICAgc2V0KHBhcmVudENvcHksIG9yaWdpbmFsS2V5LCBmaW5hbGl6ZWRWYWx1ZSwgcGFyZW50VHlwZSk7XG4gICAgICByZXR1cm47XG4gICAgfVxuICB9XG4gIGlmICghcGFyZW50LmRyYWZ0TG9jYXRpb25zXykge1xuICAgIGNvbnN0IGRyYWZ0TG9jYXRpb25zID0gcGFyZW50LmRyYWZ0TG9jYXRpb25zXyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgZWFjaChwYXJlbnRDb3B5LCAoa2V5LCB2YWx1ZSkgPT4ge1xuICAgICAgaWYgKGlzRHJhZnQodmFsdWUpKSB7XG4gICAgICAgIGNvbnN0IGtleXMgPSBkcmFmdExvY2F0aW9ucy5nZXQodmFsdWUpIHx8IFtdO1xuICAgICAgICBrZXlzLnB1c2goa2V5KTtcbiAgICAgICAgZHJhZnRMb2NhdGlvbnMuc2V0KHZhbHVlLCBrZXlzKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICBjb25zdCBsb2NhdGlvbnMgPSBwYXJlbnQuZHJhZnRMb2NhdGlvbnNfLmdldChkcmFmdFZhbHVlKSA/PyBFTVBUWV9MT0NBVElPTlNfUkVTVUxUO1xuICBmb3IgKGNvbnN0IGxvY2F0aW9uIG9mIGxvY2F0aW9ucykge1xuICAgIHNldChwYXJlbnRDb3B5LCBsb2NhdGlvbiwgZmluYWxpemVkVmFsdWUsIHBhcmVudFR5cGUpO1xuICB9XG59XG5mdW5jdGlvbiByZWdpc3RlckNoaWxkRmluYWxpemF0aW9uQ2FsbGJhY2socGFyZW50LCBjaGlsZCwga2V5KSB7XG4gIHBhcmVudC5jYWxsYmFja3NfLnB1c2goZnVuY3Rpb24gY2hpbGRDbGVhbnVwKHJvb3RTY29wZSkge1xuICAgIGNvbnN0IHN0YXRlID0gY2hpbGQ7XG4gICAgaWYgKCFzdGF0ZSB8fCAhaXNTYW1lU2NvcGUoc3RhdGUsIHJvb3RTY29wZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcm9vdFNjb3BlLm1hcFNldFBsdWdpbl8/LmZpeFNldENvbnRlbnRzKHN0YXRlKTtcbiAgICBjb25zdCBmaW5hbGl6ZWRWYWx1ZSA9IGdldEZpbmFsVmFsdWUoc3RhdGUpO1xuICAgIHVwZGF0ZURyYWZ0SW5QYXJlbnQocGFyZW50LCBzdGF0ZS5kcmFmdF8gPz8gc3RhdGUsIGZpbmFsaXplZFZhbHVlLCBrZXkpO1xuICAgIGdlbmVyYXRlUGF0Y2hlc0FuZEZpbmFsaXplKHN0YXRlLCByb290U2NvcGUpO1xuICB9KTtcbn1cbmZ1bmN0aW9uIGdlbmVyYXRlUGF0Y2hlc0FuZEZpbmFsaXplKHN0YXRlLCByb290U2NvcGUpIHtcbiAgY29uc3Qgc2hvdWxkRmluYWxpemUgPSBzdGF0ZS5tb2RpZmllZF8gJiYgIXN0YXRlLmZpbmFsaXplZF8gJiYgKHN0YXRlLnR5cGVfID09PSAzIC8qIFNldCAqLyB8fCBzdGF0ZS50eXBlXyA9PT0gMSAvKiBBcnJheSAqLyAmJiBzdGF0ZS5hbGxJbmRpY2VzUmVhc3NpZ25lZF8gfHwgKHN0YXRlLmFzc2lnbmVkXz8uc2l6ZSA/PyAwKSA+IDApO1xuICBpZiAoc2hvdWxkRmluYWxpemUpIHtcbiAgICBjb25zdCB7IHBhdGNoUGx1Z2luXyB9ID0gcm9vdFNjb3BlO1xuICAgIGlmIChwYXRjaFBsdWdpbl8pIHtcbiAgICAgIGNvbnN0IGJhc2VQYXRoID0gcGF0Y2hQbHVnaW5fLmdldFBhdGgoc3RhdGUpO1xuICAgICAgaWYgKGJhc2VQYXRoKSB7XG4gICAgICAgIHBhdGNoUGx1Z2luXy5nZW5lcmF0ZVBhdGNoZXNfKHN0YXRlLCBiYXNlUGF0aCwgcm9vdFNjb3BlKTtcbiAgICAgIH1cbiAgICB9XG4gICAgbWFya1N0YXRlRmluYWxpemVkKHN0YXRlKTtcbiAgfVxufVxuZnVuY3Rpb24gaGFuZGxlQ3Jvc3NSZWZlcmVuY2UodGFyZ2V0LCBrZXksIHZhbHVlKSB7XG4gIGNvbnN0IHsgc2NvcGVfIH0gPSB0YXJnZXQ7XG4gIGlmIChpc0RyYWZ0KHZhbHVlKSkge1xuICAgIGNvbnN0IHN0YXRlID0gdmFsdWVbRFJBRlRfU1RBVEVdO1xuICAgIGlmIChpc1NhbWVTY29wZShzdGF0ZSwgc2NvcGVfKSkge1xuICAgICAgc3RhdGUuY2FsbGJhY2tzXy5wdXNoKGZ1bmN0aW9uIGNyb3NzUmVmZXJlbmNlQ2xlYW51cCgpIHtcbiAgICAgICAgcHJlcGFyZUNvcHkodGFyZ2V0KTtcbiAgICAgICAgY29uc3QgZmluYWxpemVkVmFsdWUgPSBnZXRGaW5hbFZhbHVlKHN0YXRlKTtcbiAgICAgICAgdXBkYXRlRHJhZnRJblBhcmVudCh0YXJnZXQsIHZhbHVlLCBmaW5hbGl6ZWRWYWx1ZSwga2V5KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgfSBlbHNlIGlmIChpc0RyYWZ0YWJsZSh2YWx1ZSkpIHtcbiAgICB0YXJnZXQuY2FsbGJhY2tzXy5wdXNoKGZ1bmN0aW9uIG5lc3RlZERyYWZ0Q2xlYW51cCgpIHtcbiAgICAgIGNvbnN0IHRhcmdldENvcHkgPSBsYXRlc3QodGFyZ2V0KTtcbiAgICAgIGlmICh0YXJnZXQudHlwZV8gPT09IDMgLyogU2V0ICovKSB7XG4gICAgICAgIGlmICh0YXJnZXRDb3B5Lmhhcyh2YWx1ZSkpIHtcbiAgICAgICAgICBoYW5kbGVWYWx1ZSh2YWx1ZSwgc2NvcGVfLmhhbmRsZWRTZXRfLCBzY29wZV8pO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBpZiAoZ2V0KHRhcmdldENvcHksIGtleSwgdGFyZ2V0LnR5cGVfKSA9PT0gdmFsdWUpIHtcbiAgICAgICAgICBpZiAoc2NvcGVfLmRyYWZ0c18ubGVuZ3RoID4gMSAmJiAodGFyZ2V0LmFzc2lnbmVkXy5nZXQoa2V5KSA/PyBmYWxzZSkgPT09IHRydWUgJiYgdGFyZ2V0LmNvcHlfKSB7XG4gICAgICAgICAgICBoYW5kbGVWYWx1ZShcbiAgICAgICAgICAgICAgZ2V0KHRhcmdldC5jb3B5Xywga2V5LCB0YXJnZXQudHlwZV8pLFxuICAgICAgICAgICAgICBzY29wZV8uaGFuZGxlZFNldF8sXG4gICAgICAgICAgICAgIHNjb3BlX1xuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufVxuZnVuY3Rpb24gaGFuZGxlVmFsdWUodGFyZ2V0LCBoYW5kbGVkU2V0LCByb290U2NvcGUpIHtcbiAgaWYgKCFyb290U2NvcGUuaW1tZXJfLmF1dG9GcmVlemVfICYmIHJvb3RTY29wZS51bmZpbmFsaXplZERyYWZ0c18gPCAxKSB7XG4gICAgcmV0dXJuIHRhcmdldDtcbiAgfVxuICBpZiAoaXNEcmFmdCh0YXJnZXQpIHx8IGhhbmRsZWRTZXQuaGFzKHRhcmdldCkgfHwgIWlzRHJhZnRhYmxlKHRhcmdldCkgfHwgaXNGcm96ZW4odGFyZ2V0KSkge1xuICAgIHJldHVybiB0YXJnZXQ7XG4gIH1cbiAgaGFuZGxlZFNldC5hZGQodGFyZ2V0KTtcbiAgZWFjaCh0YXJnZXQsIChrZXksIHZhbHVlKSA9PiB7XG4gICAgaWYgKGlzRHJhZnQodmFsdWUpKSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHZhbHVlW0RSQUZUX1NUQVRFXTtcbiAgICAgIGlmIChpc1NhbWVTY29wZShzdGF0ZSwgcm9vdFNjb3BlKSkge1xuICAgICAgICBjb25zdCB1cGRhdGVkVmFsdWUgPSBnZXRGaW5hbFZhbHVlKHN0YXRlKTtcbiAgICAgICAgc2V0KHRhcmdldCwga2V5LCB1cGRhdGVkVmFsdWUsIHRhcmdldC50eXBlXyk7XG4gICAgICAgIG1hcmtTdGF0ZUZpbmFsaXplZChzdGF0ZSk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChpc0RyYWZ0YWJsZSh2YWx1ZSkpIHtcbiAgICAgIGhhbmRsZVZhbHVlKHZhbHVlLCBoYW5kbGVkU2V0LCByb290U2NvcGUpO1xuICAgIH1cbiAgfSk7XG4gIHJldHVybiB0YXJnZXQ7XG59XG5cbi8vIHNyYy9jb3JlL3Byb3h5LnRzXG5mdW5jdGlvbiBjcmVhdGVQcm94eVByb3h5KGJhc2UsIHBhcmVudCkge1xuICBjb25zdCBiYXNlSXNBcnJheSA9IGlzQXJyYXkoYmFzZSk7XG4gIGNvbnN0IHN0YXRlID0ge1xuICAgIHR5cGVfOiBiYXNlSXNBcnJheSA/IDEgLyogQXJyYXkgKi8gOiAwIC8qIE9iamVjdCAqLyxcbiAgICAvLyBUcmFjayB3aGljaCBwcm9kdWNlIGNhbGwgdGhpcyBpcyBhc3NvY2lhdGVkIHdpdGguXG4gICAgc2NvcGVfOiBwYXJlbnQgPyBwYXJlbnQuc2NvcGVfIDogZ2V0Q3VycmVudFNjb3BlKCksXG4gICAgLy8gVHJ1ZSBmb3IgYm90aCBzaGFsbG93IGFuZCBkZWVwIGNoYW5nZXMuXG4gICAgbW9kaWZpZWRfOiBmYWxzZSxcbiAgICAvLyBVc2VkIGR1cmluZyBmaW5hbGl6YXRpb24uXG4gICAgZmluYWxpemVkXzogZmFsc2UsXG4gICAgLy8gVHJhY2sgd2hpY2ggcHJvcGVydGllcyBoYXZlIGJlZW4gYXNzaWduZWQgKHRydWUpIG9yIGRlbGV0ZWQgKGZhbHNlKS5cbiAgICAvLyBhY3R1YWxseSBpbnN0YW50aWF0ZWQgaW4gYHByZXBhcmVDb3B5KClgXG4gICAgYXNzaWduZWRfOiB2b2lkIDAsXG4gICAgLy8gVGhlIHBhcmVudCBkcmFmdCBzdGF0ZS5cbiAgICBwYXJlbnRfOiBwYXJlbnQsXG4gICAgLy8gVGhlIGJhc2Ugc3RhdGUuXG4gICAgYmFzZV86IGJhc2UsXG4gICAgLy8gVGhlIGJhc2UgcHJveHkuXG4gICAgZHJhZnRfOiBudWxsLFxuICAgIC8vIHNldCBiZWxvd1xuICAgIC8vIFRoZSBiYXNlIGNvcHkgd2l0aCBhbnkgdXBkYXRlZCB2YWx1ZXMuXG4gICAgY29weV86IG51bGwsXG4gICAgLy8gQ2FsbGVkIGJ5IHRoZSBgcHJvZHVjZWAgZnVuY3Rpb24uXG4gICAgcmV2b2tlXzogbnVsbCxcbiAgICBpc01hbnVhbF86IGZhbHNlLFxuICAgIC8vIGBjYWxsYmFja3NgIGFjdHVhbGx5IGdldHMgYXNzaWduZWQgaW4gYGNyZWF0ZVByb3h5YFxuICAgIGNhbGxiYWNrc186IHZvaWQgMFxuICB9O1xuICBsZXQgdGFyZ2V0ID0gc3RhdGU7XG4gIGxldCB0cmFwcyA9IG9iamVjdFRyYXBzO1xuICBpZiAoYmFzZUlzQXJyYXkpIHtcbiAgICB0YXJnZXQgPSBbc3RhdGVdO1xuICAgIHRyYXBzID0gYXJyYXlUcmFwcztcbiAgfVxuICBjb25zdCB7IHJldm9rZSwgcHJveHkgfSA9IFByb3h5LnJldm9jYWJsZSh0YXJnZXQsIHRyYXBzKTtcbiAgc3RhdGUuZHJhZnRfID0gcHJveHk7XG4gIHN0YXRlLnJldm9rZV8gPSByZXZva2U7XG4gIHJldHVybiBbcHJveHksIHN0YXRlXTtcbn1cbnZhciBvYmplY3RUcmFwcyA9IHtcbiAgZ2V0KHN0YXRlLCBwcm9wKSB7XG4gICAgaWYgKHByb3AgPT09IERSQUZUX1NUQVRFKVxuICAgICAgcmV0dXJuIHN0YXRlO1xuICAgIGxldCBhcnJheVBsdWdpbiA9IHN0YXRlLnNjb3BlXy5hcnJheU1ldGhvZHNQbHVnaW5fO1xuICAgIGNvbnN0IGlzQXJyYXlXaXRoU3RyaW5nUHJvcCA9IHN0YXRlLnR5cGVfID09PSAxIC8qIEFycmF5ICovICYmIHR5cGVvZiBwcm9wID09PSBcInN0cmluZ1wiO1xuICAgIGlmIChpc0FycmF5V2l0aFN0cmluZ1Byb3ApIHtcbiAgICAgIGlmIChhcnJheVBsdWdpbj8uaXNBcnJheU9wZXJhdGlvbk1ldGhvZChwcm9wKSkge1xuICAgICAgICByZXR1cm4gYXJyYXlQbHVnaW4uY3JlYXRlTWV0aG9kSW50ZXJjZXB0b3Ioc3RhdGUsIHByb3ApO1xuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCBzb3VyY2UgPSBsYXRlc3Qoc3RhdGUpO1xuICAgIGlmICghaGFzKHNvdXJjZSwgcHJvcCwgc3RhdGUudHlwZV8pKSB7XG4gICAgICByZXR1cm4gcmVhZFByb3BGcm9tUHJvdG8oc3RhdGUsIHNvdXJjZSwgcHJvcCk7XG4gICAgfVxuICAgIGNvbnN0IHZhbHVlID0gc291cmNlW3Byb3BdO1xuICAgIGlmIChzdGF0ZS5maW5hbGl6ZWRfIHx8ICFpc0RyYWZ0YWJsZSh2YWx1ZSkpIHtcbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gICAgaWYgKGlzQXJyYXlXaXRoU3RyaW5nUHJvcCAmJiBzdGF0ZS5vcGVyYXRpb25NZXRob2QgJiYgYXJyYXlQbHVnaW4/LmlzTXV0YXRpbmdBcnJheU1ldGhvZChcbiAgICAgIHN0YXRlLm9wZXJhdGlvbk1ldGhvZFxuICAgICkgJiYgaXNBcnJheUluZGV4KHByb3ApKSB7XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGlmICh2YWx1ZSA9PT0gcGVlayhzdGF0ZS5iYXNlXywgcHJvcCkgfHwgaXNSZWxvY2F0ZWRCYXNlUmVmKHN0YXRlLCBwcm9wLCB2YWx1ZSkpIHtcbiAgICAgIHByZXBhcmVDb3B5KHN0YXRlKTtcbiAgICAgIGNvbnN0IGNoaWxkS2V5ID0gc3RhdGUudHlwZV8gPT09IDEgLyogQXJyYXkgKi8gPyArcHJvcCA6IHByb3A7XG4gICAgICBjb25zdCBjaGlsZERyYWZ0ID0gY3JlYXRlUHJveHkoc3RhdGUuc2NvcGVfLCB2YWx1ZSwgc3RhdGUsIGNoaWxkS2V5KTtcbiAgICAgIHJldHVybiBzdGF0ZS5jb3B5X1tjaGlsZEtleV0gPSBjaGlsZERyYWZ0O1xuICAgIH1cbiAgICByZXR1cm4gdmFsdWU7XG4gIH0sXG4gIGhhcyhzdGF0ZSwgcHJvcCkge1xuICAgIHJldHVybiBwcm9wIGluIGxhdGVzdChzdGF0ZSk7XG4gIH0sXG4gIG93bktleXMoc3RhdGUpIHtcbiAgICByZXR1cm4gUmVmbGVjdC5vd25LZXlzKGxhdGVzdChzdGF0ZSkpO1xuICB9LFxuICBzZXQoc3RhdGUsIHByb3AsIHZhbHVlKSB7XG4gICAgY29uc3QgZGVzYyA9IGdldERlc2NyaXB0b3JGcm9tUHJvdG8obGF0ZXN0KHN0YXRlKSwgcHJvcCk7XG4gICAgaWYgKGRlc2M/LnNldCkge1xuICAgICAgZGVzYy5zZXQuY2FsbChzdGF0ZS5kcmFmdF8sIHZhbHVlKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpZiAoIXN0YXRlLm1vZGlmaWVkXykge1xuICAgICAgY29uc3QgY3VycmVudDIgPSBwZWVrKGxhdGVzdChzdGF0ZSksIHByb3ApO1xuICAgICAgY29uc3QgY3VycmVudFN0YXRlID0gY3VycmVudDI/LltEUkFGVF9TVEFURV07XG4gICAgICBpZiAoY3VycmVudFN0YXRlICYmIGN1cnJlbnRTdGF0ZS5iYXNlXyA9PT0gdmFsdWUpIHtcbiAgICAgICAgc3RhdGUuY29weV9bcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgc3RhdGUuYXNzaWduZWRfLmRlbGV0ZShwcm9wKTtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgICBpZiAoaXModmFsdWUsIGN1cnJlbnQyKSAmJiAodmFsdWUgIT09IHZvaWQgMCB8fCBoYXMoc3RhdGUuYmFzZV8sIHByb3AsIHN0YXRlLnR5cGVfKSkpXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgcHJlcGFyZUNvcHkoc3RhdGUpO1xuICAgICAgbWFya0NoYW5nZWQoc3RhdGUpO1xuICAgIH1cbiAgICBpZiAoc3RhdGUuY29weV9bcHJvcF0gPT09IHZhbHVlICYmIC8vIHNwZWNpYWwgY2FzZTogaGFuZGxlIG5ldyBwcm9wcyB3aXRoIHZhbHVlICd1bmRlZmluZWQnXG4gICAgKHZhbHVlICE9PSB2b2lkIDAgfHwgaGFzKHN0YXRlLmNvcHlfLCBwcm9wLCBzdGF0ZS50eXBlXykpIHx8IC8vIHNwZWNpYWwgY2FzZTogTmFOXG4gICAgTnVtYmVyLmlzTmFOKHZhbHVlKSAmJiBOdW1iZXIuaXNOYU4oc3RhdGUuY29weV9bcHJvcF0pKVxuICAgICAgcmV0dXJuIHRydWU7XG4gICAgc3RhdGUuY29weV9bcHJvcF0gPSB2YWx1ZTtcbiAgICBzdGF0ZS5hc3NpZ25lZF8uc2V0KHByb3AsIHRydWUpO1xuICAgIGhhbmRsZUNyb3NzUmVmZXJlbmNlKHN0YXRlLCBwcm9wLCB2YWx1ZSk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIGRlbGV0ZVByb3BlcnR5KHN0YXRlLCBwcm9wKSB7XG4gICAgcHJlcGFyZUNvcHkoc3RhdGUpO1xuICAgIGlmIChwZWVrKHN0YXRlLmJhc2VfLCBwcm9wKSAhPT0gdm9pZCAwIHx8IHByb3AgaW4gc3RhdGUuYmFzZV8pIHtcbiAgICAgIHN0YXRlLmFzc2lnbmVkXy5zZXQocHJvcCwgZmFsc2UpO1xuICAgICAgbWFya0NoYW5nZWQoc3RhdGUpO1xuICAgIH0gZWxzZSB7XG4gICAgICBzdGF0ZS5hc3NpZ25lZF8uZGVsZXRlKHByb3ApO1xuICAgIH1cbiAgICBpZiAoc3RhdGUuY29weV8pIHtcbiAgICAgIGRlbGV0ZSBzdGF0ZS5jb3B5X1twcm9wXTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG4gIH0sXG4gIC8vIE5vdGU6IFdlIG5ldmVyIGNvZXJjZSBgZGVzYy52YWx1ZWAgaW50byBhbiBJbW1lciBkcmFmdCwgYmVjYXVzZSB3ZSBjYW4ndCBtYWtlXG4gIC8vIHRoZSBzYW1lIGd1YXJhbnRlZSBpbiBFUzUgbW9kZS5cbiAgZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHN0YXRlLCBwcm9wKSB7XG4gICAgY29uc3Qgb3duZXIgPSBsYXRlc3Qoc3RhdGUpO1xuICAgIGNvbnN0IGRlc2MgPSBSZWZsZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihvd25lciwgcHJvcCk7XG4gICAgaWYgKCFkZXNjKVxuICAgICAgcmV0dXJuIGRlc2M7XG4gICAgcmV0dXJuIHtcbiAgICAgIFtXUklUQUJMRV06IHRydWUsXG4gICAgICBbQ09ORklHVVJBQkxFXTogc3RhdGUudHlwZV8gIT09IDEgLyogQXJyYXkgKi8gfHwgcHJvcCAhPT0gXCJsZW5ndGhcIixcbiAgICAgIFtFTlVNRVJBQkxFXTogZGVzY1tFTlVNRVJBQkxFXSxcbiAgICAgIFtWQUxVRV06IG93bmVyW3Byb3BdXG4gICAgfTtcbiAgfSxcbiAgZGVmaW5lUHJvcGVydHkoKSB7XG4gICAgZGllKDExKTtcbiAgfSxcbiAgZ2V0UHJvdG90eXBlT2Yoc3RhdGUpIHtcbiAgICByZXR1cm4gZ2V0UHJvdG90eXBlT2Yoc3RhdGUuYmFzZV8pO1xuICB9LFxuICBzZXRQcm90b3R5cGVPZigpIHtcbiAgICBkaWUoMTIpO1xuICB9XG59O1xudmFyIGFycmF5VHJhcHMgPSB7fTtcbmZvciAobGV0IGtleSBpbiBvYmplY3RUcmFwcykge1xuICBsZXQgZm4gPSBvYmplY3RUcmFwc1trZXldO1xuICBhcnJheVRyYXBzW2tleV0gPSBmdW5jdGlvbigpIHtcbiAgICBjb25zdCBhcmdzID0gYXJndW1lbnRzO1xuICAgIGFyZ3NbMF0gPSBhcmdzWzBdWzBdO1xuICAgIHJldHVybiBmbi5hcHBseSh0aGlzLCBhcmdzKTtcbiAgfTtcbn1cbmFycmF5VHJhcHMuZGVsZXRlUHJvcGVydHkgPSBmdW5jdGlvbihzdGF0ZSwgcHJvcCkge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGlzTmFOKHBhcnNlSW50KHByb3ApKSlcbiAgICBkaWUoMTMpO1xuICByZXR1cm4gYXJyYXlUcmFwcy5zZXQuY2FsbCh0aGlzLCBzdGF0ZSwgcHJvcCwgdm9pZCAwKTtcbn07XG5hcnJheVRyYXBzLnNldCA9IGZ1bmN0aW9uKHN0YXRlLCBwcm9wLCB2YWx1ZSkge1xuICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIHByb3AgIT09IFwibGVuZ3RoXCIgJiYgaXNOYU4ocGFyc2VJbnQocHJvcCkpKVxuICAgIGRpZSgxNCk7XG4gIHJldHVybiBvYmplY3RUcmFwcy5zZXQuY2FsbCh0aGlzLCBzdGF0ZVswXSwgcHJvcCwgdmFsdWUsIHN0YXRlWzBdKTtcbn07XG5mdW5jdGlvbiBwZWVrKGRyYWZ0LCBwcm9wKSB7XG4gIGNvbnN0IHN0YXRlID0gZHJhZnRbRFJBRlRfU1RBVEVdO1xuICBjb25zdCBzb3VyY2UgPSBzdGF0ZSA/IGxhdGVzdChzdGF0ZSkgOiBkcmFmdDtcbiAgcmV0dXJuIHNvdXJjZVtwcm9wXTtcbn1cbmZ1bmN0aW9uIGlzUmVsb2NhdGVkQmFzZVJlZihzdGF0ZSwgcHJvcCwgdmFsdWUpIHtcbiAgaWYgKHN0YXRlLnR5cGVfICE9PSAxIC8qIEFycmF5ICovIHx8ICFzdGF0ZS5hbGxJbmRpY2VzUmVhc3NpZ25lZF8gfHwgc3RhdGUuYXNzaWduZWRfPy5nZXQocHJvcCkgfHwgIWlzRHJhZnRhYmxlKHZhbHVlKSB8fCB2YWx1ZVtEUkFGVF9TVEFURV0pIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgcmV0dXJuIHN0YXRlLmJhc2VSZWZzXy5oYXModmFsdWUpO1xufVxuZnVuY3Rpb24gcmVhZFByb3BGcm9tUHJvdG8oc3RhdGUsIHNvdXJjZSwgcHJvcCkge1xuICBjb25zdCBkZXNjID0gZ2V0RGVzY3JpcHRvckZyb21Qcm90byhzb3VyY2UsIHByb3ApO1xuICByZXR1cm4gZGVzYyA/IFZBTFVFIGluIGRlc2MgPyBkZXNjW1ZBTFVFXSA6IChcbiAgICAvLyBUaGlzIGlzIGEgdmVyeSBzcGVjaWFsIGNhc2UsIGlmIHRoZSBwcm9wIGlzIGEgZ2V0dGVyIGRlZmluZWQgYnkgdGhlXG4gICAgLy8gcHJvdG90eXBlLCB3ZSBzaG91bGQgaW52b2tlIGl0IHdpdGggdGhlIGRyYWZ0IGFzIGNvbnRleHQhXG4gICAgZGVzYy5nZXQ/LmNhbGwoc3RhdGUuZHJhZnRfKVxuICApIDogdm9pZCAwO1xufVxuZnVuY3Rpb24gZ2V0RGVzY3JpcHRvckZyb21Qcm90byhzb3VyY2UsIHByb3ApIHtcbiAgaWYgKCEocHJvcCBpbiBzb3VyY2UpKVxuICAgIHJldHVybiB2b2lkIDA7XG4gIGxldCBwcm90byA9IGdldFByb3RvdHlwZU9mKHNvdXJjZSk7XG4gIHdoaWxlIChwcm90bykge1xuICAgIGNvbnN0IGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHByb3RvLCBwcm9wKTtcbiAgICBpZiAoZGVzYylcbiAgICAgIHJldHVybiBkZXNjO1xuICAgIHByb3RvID0gZ2V0UHJvdG90eXBlT2YocHJvdG8pO1xuICB9XG4gIHJldHVybiB2b2lkIDA7XG59XG5mdW5jdGlvbiBtYXJrQ2hhbmdlZChzdGF0ZSkge1xuICBpZiAoIXN0YXRlLm1vZGlmaWVkXykge1xuICAgIHN0YXRlLm1vZGlmaWVkXyA9IHRydWU7XG4gICAgaWYgKHN0YXRlLnBhcmVudF8pIHtcbiAgICAgIG1hcmtDaGFuZ2VkKHN0YXRlLnBhcmVudF8pO1xuICAgIH1cbiAgfVxufVxuZnVuY3Rpb24gcHJlcGFyZUNvcHkoc3RhdGUpIHtcbiAgaWYgKCFzdGF0ZS5jb3B5Xykge1xuICAgIHN0YXRlLmFzc2lnbmVkXyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgc3RhdGUuY29weV8gPSBzaGFsbG93Q29weShcbiAgICAgIHN0YXRlLmJhc2VfLFxuICAgICAgc3RhdGUuc2NvcGVfLmltbWVyXy51c2VTdHJpY3RTaGFsbG93Q29weV9cbiAgICApO1xuICB9XG59XG5cbi8vIHNyYy9jb3JlL2ltbWVyQ2xhc3MudHNcbnZhciBJbW1lcjIgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKGNvbmZpZykge1xuICAgIHRoaXMuYXV0b0ZyZWV6ZV8gPSB0cnVlO1xuICAgIHRoaXMudXNlU3RyaWN0U2hhbGxvd0NvcHlfID0gZmFsc2U7XG4gICAgdGhpcy51c2VTdHJpY3RJdGVyYXRpb25fID0gZmFsc2U7XG4gICAgLyoqXG4gICAgICogVGhlIGBwcm9kdWNlYCBmdW5jdGlvbiB0YWtlcyBhIHZhbHVlIGFuZCBhIFwicmVjaXBlIGZ1bmN0aW9uXCIgKHdob3NlXG4gICAgICogcmV0dXJuIHZhbHVlIG9mdGVuIGRlcGVuZHMgb24gdGhlIGJhc2Ugc3RhdGUpLiBUaGUgcmVjaXBlIGZ1bmN0aW9uIGlzXG4gICAgICogZnJlZSB0byBtdXRhdGUgaXRzIGZpcnN0IGFyZ3VtZW50IGhvd2V2ZXIgaXQgd2FudHMuIEFsbCBtdXRhdGlvbnMgYXJlXG4gICAgICogb25seSBldmVyIGFwcGxpZWQgdG8gYSBfX2NvcHlfXyBvZiB0aGUgYmFzZSBzdGF0ZS5cbiAgICAgKlxuICAgICAqIFBhc3Mgb25seSBhIGZ1bmN0aW9uIHRvIGNyZWF0ZSBhIFwiY3VycmllZCBwcm9kdWNlclwiIHdoaWNoIHJlbGlldmVzIHlvdVxuICAgICAqIGZyb20gcGFzc2luZyB0aGUgcmVjaXBlIGZ1bmN0aW9uIGV2ZXJ5IHRpbWUuXG4gICAgICpcbiAgICAgKiBPbmx5IHBsYWluIG9iamVjdHMgYW5kIGFycmF5cyBhcmUgbWFkZSBtdXRhYmxlLiBBbGwgb3RoZXIgb2JqZWN0cyBhcmVcbiAgICAgKiBjb25zaWRlcmVkIHVuY29weWFibGUuXG4gICAgICpcbiAgICAgKiBOb3RlOiBUaGlzIGZ1bmN0aW9uIGlzIF9fYm91bmRfXyB0byBpdHMgYEltbWVyYCBpbnN0YW5jZS5cbiAgICAgKlxuICAgICAqIEBwYXJhbSB7YW55fSBiYXNlIC0gdGhlIGluaXRpYWwgc3RhdGVcbiAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSByZWNpcGUgLSBmdW5jdGlvbiB0aGF0IHJlY2VpdmVzIGEgcHJveHkgb2YgdGhlIGJhc2Ugc3RhdGUgYXMgZmlyc3QgYXJndW1lbnQgYW5kIHdoaWNoIGNhbiBiZSBmcmVlbHkgbW9kaWZpZWRcbiAgICAgKiBAcGFyYW0ge0Z1bmN0aW9ufSBwYXRjaExpc3RlbmVyIC0gb3B0aW9uYWwgZnVuY3Rpb24gdGhhdCB3aWxsIGJlIGNhbGxlZCB3aXRoIGFsbCB0aGUgcGF0Y2hlcyBwcm9kdWNlZCBoZXJlXG4gICAgICogQHJldHVybnMge2FueX0gYSBuZXcgc3RhdGUsIG9yIHRoZSBpbml0aWFsIHN0YXRlIGlmIG5vdGhpbmcgd2FzIG1vZGlmaWVkXG4gICAgICovXG4gICAgdGhpcy5wcm9kdWNlID0gKGJhc2UsIHJlY2lwZSwgcGF0Y2hMaXN0ZW5lcikgPT4ge1xuICAgICAgaWYgKGlzRnVuY3Rpb24oYmFzZSkgJiYgIWlzRnVuY3Rpb24ocmVjaXBlKSkge1xuICAgICAgICBjb25zdCBkZWZhdWx0QmFzZSA9IHJlY2lwZTtcbiAgICAgICAgcmVjaXBlID0gYmFzZTtcbiAgICAgICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgICAgIHJldHVybiBmdW5jdGlvbiBjdXJyaWVkUHJvZHVjZShiYXNlMiA9IGRlZmF1bHRCYXNlLCAuLi5hcmdzKSB7XG4gICAgICAgICAgcmV0dXJuIHNlbGYucHJvZHVjZShiYXNlMiwgKGRyYWZ0KSA9PiByZWNpcGUuY2FsbCh0aGlzLCBkcmFmdCwgLi4uYXJncykpO1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgaWYgKCFpc0Z1bmN0aW9uKHJlY2lwZSkpXG4gICAgICAgIGRpZSg2KTtcbiAgICAgIGlmIChwYXRjaExpc3RlbmVyICE9PSB2b2lkIDAgJiYgIWlzRnVuY3Rpb24ocGF0Y2hMaXN0ZW5lcikpXG4gICAgICAgIGRpZSg3KTtcbiAgICAgIGxldCByZXN1bHQ7XG4gICAgICBpZiAoaXNEcmFmdGFibGUoYmFzZSkpIHtcbiAgICAgICAgY29uc3Qgc2NvcGUgPSBlbnRlclNjb3BlKHRoaXMpO1xuICAgICAgICBjb25zdCBwcm94eSA9IGNyZWF0ZVByb3h5KHNjb3BlLCBiYXNlLCB2b2lkIDApO1xuICAgICAgICBsZXQgaGFzRXJyb3IgPSB0cnVlO1xuICAgICAgICB0cnkge1xuICAgICAgICAgIHJlc3VsdCA9IHJlY2lwZShwcm94eSk7XG4gICAgICAgICAgaGFzRXJyb3IgPSBmYWxzZTtcbiAgICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgICBpZiAoaGFzRXJyb3IpXG4gICAgICAgICAgICByZXZva2VTY29wZShzY29wZSk7XG4gICAgICAgICAgZWxzZVxuICAgICAgICAgICAgbGVhdmVTY29wZShzY29wZSk7XG4gICAgICAgIH1cbiAgICAgICAgdXNlUGF0Y2hlc0luU2NvcGUoc2NvcGUsIHBhdGNoTGlzdGVuZXIpO1xuICAgICAgICByZXR1cm4gcHJvY2Vzc1Jlc3VsdChyZXN1bHQsIHNjb3BlKTtcbiAgICAgIH0gZWxzZSBpZiAoIWJhc2UgfHwgIWlzT2JqZWN0aXNoKGJhc2UpKSB7XG4gICAgICAgIHJlc3VsdCA9IHJlY2lwZShiYXNlKTtcbiAgICAgICAgaWYgKHJlc3VsdCA9PT0gdm9pZCAwKVxuICAgICAgICAgIHJlc3VsdCA9IGJhc2U7XG4gICAgICAgIGlmIChyZXN1bHQgPT09IE5PVEhJTkcpXG4gICAgICAgICAgcmVzdWx0ID0gdm9pZCAwO1xuICAgICAgICBpZiAodGhpcy5hdXRvRnJlZXplXylcbiAgICAgICAgICBmcmVlemUocmVzdWx0LCB0cnVlKTtcbiAgICAgICAgaWYgKHBhdGNoTGlzdGVuZXIpIHtcbiAgICAgICAgICBjb25zdCBwID0gW107XG4gICAgICAgICAgY29uc3QgaXAgPSBbXTtcbiAgICAgICAgICBnZXRQbHVnaW4oUGx1Z2luUGF0Y2hlcykuZ2VuZXJhdGVSZXBsYWNlbWVudFBhdGNoZXNfKGJhc2UsIHJlc3VsdCwge1xuICAgICAgICAgICAgcGF0Y2hlc186IHAsXG4gICAgICAgICAgICBpbnZlcnNlUGF0Y2hlc186IGlwXG4gICAgICAgICAgfSk7XG4gICAgICAgICAgcGF0Y2hMaXN0ZW5lcihwLCBpcCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgIH0gZWxzZVxuICAgICAgICBkaWUoMSwgYmFzZSk7XG4gICAgfTtcbiAgICB0aGlzLnByb2R1Y2VXaXRoUGF0Y2hlcyA9IChiYXNlLCByZWNpcGUpID0+IHtcbiAgICAgIGlmIChpc0Z1bmN0aW9uKGJhc2UpKSB7XG4gICAgICAgIHJldHVybiAoc3RhdGUsIC4uLmFyZ3MpID0+IHRoaXMucHJvZHVjZVdpdGhQYXRjaGVzKHN0YXRlLCAoZHJhZnQpID0+IGJhc2UoZHJhZnQsIC4uLmFyZ3MpKTtcbiAgICAgIH1cbiAgICAgIGxldCBwYXRjaGVzLCBpbnZlcnNlUGF0Y2hlcztcbiAgICAgIGNvbnN0IHJlc3VsdCA9IHRoaXMucHJvZHVjZShiYXNlLCByZWNpcGUsIChwLCBpcCkgPT4ge1xuICAgICAgICBwYXRjaGVzID0gcDtcbiAgICAgICAgaW52ZXJzZVBhdGNoZXMgPSBpcDtcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuIFtyZXN1bHQsIHBhdGNoZXMsIGludmVyc2VQYXRjaGVzXTtcbiAgICB9O1xuICAgIGlmIChpc0Jvb2xlYW4oY29uZmlnPy5hdXRvRnJlZXplKSlcbiAgICAgIHRoaXMuc2V0QXV0b0ZyZWV6ZShjb25maWcuYXV0b0ZyZWV6ZSk7XG4gICAgaWYgKGlzQm9vbGVhbihjb25maWc/LnVzZVN0cmljdFNoYWxsb3dDb3B5KSlcbiAgICAgIHRoaXMuc2V0VXNlU3RyaWN0U2hhbGxvd0NvcHkoY29uZmlnLnVzZVN0cmljdFNoYWxsb3dDb3B5KTtcbiAgICBpZiAoaXNCb29sZWFuKGNvbmZpZz8udXNlU3RyaWN0SXRlcmF0aW9uKSlcbiAgICAgIHRoaXMuc2V0VXNlU3RyaWN0SXRlcmF0aW9uKGNvbmZpZy51c2VTdHJpY3RJdGVyYXRpb24pO1xuICB9XG4gIGNyZWF0ZURyYWZ0KGJhc2UpIHtcbiAgICBpZiAoIWlzRHJhZnRhYmxlKGJhc2UpKVxuICAgICAgZGllKDgpO1xuICAgIGlmIChpc0RyYWZ0KGJhc2UpKVxuICAgICAgYmFzZSA9IGN1cnJlbnQoYmFzZSk7XG4gICAgY29uc3Qgc2NvcGUgPSBlbnRlclNjb3BlKHRoaXMpO1xuICAgIGNvbnN0IHByb3h5ID0gY3JlYXRlUHJveHkoc2NvcGUsIGJhc2UsIHZvaWQgMCk7XG4gICAgcHJveHlbRFJBRlRfU1RBVEVdLmlzTWFudWFsXyA9IHRydWU7XG4gICAgbGVhdmVTY29wZShzY29wZSk7XG4gICAgcmV0dXJuIHByb3h5O1xuICB9XG4gIGZpbmlzaERyYWZ0KGRyYWZ0LCBwYXRjaExpc3RlbmVyKSB7XG4gICAgY29uc3Qgc3RhdGUgPSBkcmFmdCAmJiBkcmFmdFtEUkFGVF9TVEFURV07XG4gICAgaWYgKCFzdGF0ZSB8fCAhc3RhdGUuaXNNYW51YWxfKVxuICAgICAgZGllKDkpO1xuICAgIGNvbnN0IHsgc2NvcGVfOiBzY29wZSB9ID0gc3RhdGU7XG4gICAgdXNlUGF0Y2hlc0luU2NvcGUoc2NvcGUsIHBhdGNoTGlzdGVuZXIpO1xuICAgIHJldHVybiBwcm9jZXNzUmVzdWx0KHZvaWQgMCwgc2NvcGUpO1xuICB9XG4gIC8qKlxuICAgKiBQYXNzIHRydWUgdG8gYXV0b21hdGljYWxseSBmcmVlemUgYWxsIGNvcGllcyBjcmVhdGVkIGJ5IEltbWVyLlxuICAgKlxuICAgKiBCeSBkZWZhdWx0LCBhdXRvLWZyZWV6aW5nIGlzIGVuYWJsZWQuXG4gICAqL1xuICBzZXRBdXRvRnJlZXplKHZhbHVlKSB7XG4gICAgdGhpcy5hdXRvRnJlZXplXyA9IHZhbHVlO1xuICB9XG4gIC8qKlxuICAgKiBQYXNzIHRydWUgdG8gZW5hYmxlIHN0cmljdCBzaGFsbG93IGNvcHkuXG4gICAqXG4gICAqIEJ5IGRlZmF1bHQsIGltbWVyIGRvZXMgbm90IGNvcHkgdGhlIG9iamVjdCBkZXNjcmlwdG9ycyBzdWNoIGFzIGdldHRlciwgc2V0dGVyIGFuZCBub24tZW51bXJhYmxlIHByb3BlcnRpZXMuXG4gICAqL1xuICBzZXRVc2VTdHJpY3RTaGFsbG93Q29weSh2YWx1ZSkge1xuICAgIHRoaXMudXNlU3RyaWN0U2hhbGxvd0NvcHlfID0gdmFsdWU7XG4gIH1cbiAgLyoqXG4gICAqIFBhc3MgZmFsc2UgdG8gdXNlIGZhc3RlciBpdGVyYXRpb24gdGhhdCBza2lwcyBub24tZW51bWVyYWJsZSBwcm9wZXJ0aWVzXG4gICAqIGJ1dCBzdGlsbCBoYW5kbGVzIHN5bWJvbHMgZm9yIGNvbXBhdGliaWxpdHkuXG4gICAqXG4gICAqIEJ5IGRlZmF1bHQsIHN0cmljdCBpdGVyYXRpb24gaXMgZW5hYmxlZCAoaW5jbHVkZXMgYWxsIG93biBwcm9wZXJ0aWVzKS5cbiAgICovXG4gIHNldFVzZVN0cmljdEl0ZXJhdGlvbih2YWx1ZSkge1xuICAgIHRoaXMudXNlU3RyaWN0SXRlcmF0aW9uXyA9IHZhbHVlO1xuICB9XG4gIHNob3VsZFVzZVN0cmljdEl0ZXJhdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy51c2VTdHJpY3RJdGVyYXRpb25fO1xuICB9XG4gIGFwcGx5UGF0Y2hlcyhiYXNlLCBwYXRjaGVzKSB7XG4gICAgbGV0IGk7XG4gICAgZm9yIChpID0gcGF0Y2hlcy5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgY29uc3QgcGF0Y2ggPSBwYXRjaGVzW2ldO1xuICAgICAgaWYgKHBhdGNoLnBhdGgubGVuZ3RoID09PSAwICYmIHBhdGNoLm9wID09PSBcInJlcGxhY2VcIikge1xuICAgICAgICBiYXNlID0gcGF0Y2gudmFsdWU7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cbiAgICBpZiAoaSA+IC0xKSB7XG4gICAgICBwYXRjaGVzID0gcGF0Y2hlcy5zbGljZShpICsgMSk7XG4gICAgfVxuICAgIGNvbnN0IGFwcGx5UGF0Y2hlc0ltcGwgPSBnZXRQbHVnaW4oUGx1Z2luUGF0Y2hlcykuYXBwbHlQYXRjaGVzXztcbiAgICBpZiAoaXNEcmFmdChiYXNlKSkge1xuICAgICAgcmV0dXJuIGFwcGx5UGF0Y2hlc0ltcGwoYmFzZSwgcGF0Y2hlcyk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnByb2R1Y2UoXG4gICAgICBiYXNlLFxuICAgICAgKGRyYWZ0KSA9PiBhcHBseVBhdGNoZXNJbXBsKGRyYWZ0LCBwYXRjaGVzKVxuICAgICk7XG4gIH1cbn07XG5mdW5jdGlvbiBjcmVhdGVQcm94eShyb290U2NvcGUsIHZhbHVlLCBwYXJlbnQsIGtleSkge1xuICBjb25zdCBbZHJhZnQsIHN0YXRlXSA9IGlzTWFwKHZhbHVlKSA/IGdldFBsdWdpbihQbHVnaW5NYXBTZXQpLnByb3h5TWFwXyh2YWx1ZSwgcGFyZW50KSA6IGlzU2V0KHZhbHVlKSA/IGdldFBsdWdpbihQbHVnaW5NYXBTZXQpLnByb3h5U2V0Xyh2YWx1ZSwgcGFyZW50KSA6IGNyZWF0ZVByb3h5UHJveHkodmFsdWUsIHBhcmVudCk7XG4gIGNvbnN0IHNjb3BlID0gcGFyZW50Py5zY29wZV8gPz8gZ2V0Q3VycmVudFNjb3BlKCk7XG4gIHNjb3BlLmRyYWZ0c18ucHVzaChkcmFmdCk7XG4gIHN0YXRlLmNhbGxiYWNrc18gPSBwYXJlbnQ/LmNhbGxiYWNrc18gPz8gW107XG4gIHN0YXRlLmtleV8gPSBrZXk7XG4gIGlmIChwYXJlbnQgJiYga2V5ICE9PSB2b2lkIDApIHtcbiAgICByZWdpc3RlckNoaWxkRmluYWxpemF0aW9uQ2FsbGJhY2socGFyZW50LCBzdGF0ZSwga2V5KTtcbiAgfSBlbHNlIHtcbiAgICBzdGF0ZS5jYWxsYmFja3NfLnB1c2goZnVuY3Rpb24gcm9vdERyYWZ0Q2xlYW51cChyb290U2NvcGUyKSB7XG4gICAgICByb290U2NvcGUyLm1hcFNldFBsdWdpbl8/LmZpeFNldENvbnRlbnRzKHN0YXRlKTtcbiAgICAgIGNvbnN0IHsgcGF0Y2hQbHVnaW5fIH0gPSByb290U2NvcGUyO1xuICAgICAgaWYgKHN0YXRlLm1vZGlmaWVkXyAmJiBwYXRjaFBsdWdpbl8pIHtcbiAgICAgICAgcGF0Y2hQbHVnaW5fLmdlbmVyYXRlUGF0Y2hlc18oc3RhdGUsIFtdLCByb290U2NvcGUyKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxuICByZXR1cm4gZHJhZnQ7XG59XG5cbi8vIHNyYy9jb3JlL2N1cnJlbnQudHNcbmZ1bmN0aW9uIGN1cnJlbnQodmFsdWUpIHtcbiAgaWYgKCFpc0RyYWZ0KHZhbHVlKSlcbiAgICBkaWUoMTAsIHZhbHVlKTtcbiAgcmV0dXJuIGN1cnJlbnRJbXBsKHZhbHVlKTtcbn1cbmZ1bmN0aW9uIGN1cnJlbnRJbXBsKHZhbHVlKSB7XG4gIGlmICghaXNEcmFmdGFibGUodmFsdWUpIHx8IGlzRnJvemVuKHZhbHVlKSlcbiAgICByZXR1cm4gdmFsdWU7XG4gIGNvbnN0IHN0YXRlID0gdmFsdWVbRFJBRlRfU1RBVEVdO1xuICBsZXQgY29weTtcbiAgbGV0IHN0cmljdCA9IHRydWU7XG4gIGlmIChzdGF0ZSkge1xuICAgIGlmICghc3RhdGUubW9kaWZpZWRfKVxuICAgICAgcmV0dXJuIHN0YXRlLmJhc2VfO1xuICAgIHN0YXRlLmZpbmFsaXplZF8gPSB0cnVlO1xuICAgIGNvcHkgPSBzaGFsbG93Q29weSh2YWx1ZSwgc3RhdGUuc2NvcGVfLmltbWVyXy51c2VTdHJpY3RTaGFsbG93Q29weV8pO1xuICAgIHN0cmljdCA9IHN0YXRlLnNjb3BlXy5pbW1lcl8uc2hvdWxkVXNlU3RyaWN0SXRlcmF0aW9uKCk7XG4gIH0gZWxzZSB7XG4gICAgY29weSA9IHNoYWxsb3dDb3B5KHZhbHVlLCB0cnVlKTtcbiAgfVxuICBlYWNoKFxuICAgIGNvcHksXG4gICAgKGtleSwgY2hpbGRWYWx1ZSkgPT4ge1xuICAgICAgc2V0KGNvcHksIGtleSwgY3VycmVudEltcGwoY2hpbGRWYWx1ZSkpO1xuICAgIH0sXG4gICAgc3RyaWN0XG4gICk7XG4gIGlmIChzdGF0ZSkge1xuICAgIHN0YXRlLmZpbmFsaXplZF8gPSBmYWxzZTtcbiAgfVxuICByZXR1cm4gY29weTtcbn1cblxuLy8gc3JjL3BsdWdpbnMvcGF0Y2hlcy50c1xuZnVuY3Rpb24gZW5hYmxlUGF0Y2hlcygpIHtcbiAgY29uc3QgZXJyb3JPZmZzZXQgPSAxNjtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgIGVycm9ycy5wdXNoKFxuICAgICAgJ1NldHMgY2Fubm90IGhhdmUgXCJyZXBsYWNlXCIgcGF0Y2hlcy4nLFxuICAgICAgZnVuY3Rpb24ob3ApIHtcbiAgICAgICAgcmV0dXJuIFwiVW5zdXBwb3J0ZWQgcGF0Y2ggb3BlcmF0aW9uOiBcIiArIG9wO1xuICAgICAgfSxcbiAgICAgIGZ1bmN0aW9uKHBhdGgpIHtcbiAgICAgICAgcmV0dXJuIFwiQ2Fubm90IGFwcGx5IHBhdGNoLCBwYXRoIGRvZXNuJ3QgcmVzb2x2ZTogXCIgKyBwYXRoO1xuICAgICAgfSxcbiAgICAgIFwiUGF0Y2hpbmcgcmVzZXJ2ZWQgYXR0cmlidXRlcyBsaWtlIF9fcHJvdG9fXywgcHJvdG90eXBlIGFuZCBjb25zdHJ1Y3RvciBpcyBub3QgYWxsb3dlZFwiXG4gICAgKTtcbiAgfVxuICBmdW5jdGlvbiBnZXRQYXRoKHN0YXRlLCBwYXRoID0gW10pIHtcbiAgICBpZiAoc3RhdGUua2V5XyAhPT0gdm9pZCAwKSB7XG4gICAgICBjb25zdCBwYXJlbnRDb3B5ID0gc3RhdGUucGFyZW50Xy5jb3B5XyA/PyBzdGF0ZS5wYXJlbnRfLmJhc2VfO1xuICAgICAgY29uc3QgcHJveHlEcmFmdCA9IGdldFByb3h5RHJhZnQoZ2V0KHBhcmVudENvcHksIHN0YXRlLmtleV8pKTtcbiAgICAgIGNvbnN0IHZhbHVlQXRLZXkgPSBnZXQocGFyZW50Q29weSwgc3RhdGUua2V5Xyk7XG4gICAgICBpZiAodmFsdWVBdEtleSA9PT0gdm9pZCAwKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgaWYgKHZhbHVlQXRLZXkgIT09IHN0YXRlLmRyYWZ0XyAmJiB2YWx1ZUF0S2V5ICE9PSBzdGF0ZS5iYXNlXyAmJiB2YWx1ZUF0S2V5ICE9PSBzdGF0ZS5jb3B5Xykge1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cbiAgICAgIGlmIChwcm94eURyYWZ0ICE9IG51bGwgJiYgcHJveHlEcmFmdC5iYXNlXyAhPT0gc3RhdGUuYmFzZV8pIHtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG4gICAgICBjb25zdCBpc1NldDIgPSBzdGF0ZS5wYXJlbnRfLnR5cGVfID09PSAzIC8qIFNldCAqLztcbiAgICAgIGxldCBrZXk7XG4gICAgICBpZiAoaXNTZXQyKSB7XG4gICAgICAgIGNvbnN0IHNldFBhcmVudCA9IHN0YXRlLnBhcmVudF87XG4gICAgICAgIGtleSA9IEFycmF5LmZyb20oc2V0UGFyZW50LmRyYWZ0c18ua2V5cygpKS5pbmRleE9mKHN0YXRlLmtleV8pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAga2V5ID0gc3RhdGUua2V5XztcbiAgICAgIH1cbiAgICAgIGlmICghKGlzU2V0MiAmJiBwYXJlbnRDb3B5LnNpemUgPiBrZXkgfHwgaGFzKHBhcmVudENvcHksIGtleSkpKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuICAgICAgcGF0aC5wdXNoKGtleSk7XG4gICAgfVxuICAgIGlmIChzdGF0ZS5wYXJlbnRfKSB7XG4gICAgICByZXR1cm4gZ2V0UGF0aChzdGF0ZS5wYXJlbnRfLCBwYXRoKTtcbiAgICB9XG4gICAgcGF0aC5yZXZlcnNlKCk7XG4gICAgdHJ5IHtcbiAgICAgIHJlc29sdmVQYXRoKHN0YXRlLmNvcHlfLCBwYXRoKTtcbiAgICB9IGNhdGNoIChlKSB7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgcmV0dXJuIHBhdGg7XG4gIH1cbiAgZnVuY3Rpb24gcmVzb2x2ZVBhdGgoYmFzZSwgcGF0aCkge1xuICAgIGxldCBjdXJyZW50MiA9IGJhc2U7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBwYXRoLmxlbmd0aCAtIDE7IGkrKykge1xuICAgICAgY29uc3Qga2V5ID0gcGF0aFtpXTtcbiAgICAgIGN1cnJlbnQyID0gZ2V0KGN1cnJlbnQyLCBrZXkpO1xuICAgICAgaWYgKCFpc09iamVjdGlzaChjdXJyZW50MikgfHwgY3VycmVudDIgPT09IG51bGwpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBDYW5ub3QgcmVzb2x2ZSBwYXRoIGF0ICcke3BhdGguam9pbihcIi9cIil9J2ApO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gY3VycmVudDI7XG4gIH1cbiAgY29uc3QgUkVQTEFDRSA9IFwicmVwbGFjZVwiO1xuICBjb25zdCBBREQgPSBcImFkZFwiO1xuICBjb25zdCBSRU1PVkUgPSBcInJlbW92ZVwiO1xuICBmdW5jdGlvbiBnZW5lcmF0ZVBhdGNoZXNfKHN0YXRlLCBiYXNlUGF0aCwgc2NvcGUpIHtcbiAgICBpZiAoc3RhdGUuc2NvcGVfLnByb2Nlc3NlZEZvclBhdGNoZXNfLmhhcyhzdGF0ZSkpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgc3RhdGUuc2NvcGVfLnByb2Nlc3NlZEZvclBhdGNoZXNfLmFkZChzdGF0ZSk7XG4gICAgY29uc3QgeyBwYXRjaGVzXywgaW52ZXJzZVBhdGNoZXNfIH0gPSBzY29wZTtcbiAgICBzd2l0Y2ggKHN0YXRlLnR5cGVfKSB7XG4gICAgICBjYXNlIDAgLyogT2JqZWN0ICovOlxuICAgICAgY2FzZSAyIC8qIE1hcCAqLzpcbiAgICAgICAgcmV0dXJuIGdlbmVyYXRlUGF0Y2hlc0Zyb21Bc3NpZ25lZChcbiAgICAgICAgICBzdGF0ZSxcbiAgICAgICAgICBiYXNlUGF0aCxcbiAgICAgICAgICBwYXRjaGVzXyxcbiAgICAgICAgICBpbnZlcnNlUGF0Y2hlc19cbiAgICAgICAgKTtcbiAgICAgIGNhc2UgMSAvKiBBcnJheSAqLzpcbiAgICAgICAgcmV0dXJuIGdlbmVyYXRlQXJyYXlQYXRjaGVzKFxuICAgICAgICAgIHN0YXRlLFxuICAgICAgICAgIGJhc2VQYXRoLFxuICAgICAgICAgIHBhdGNoZXNfLFxuICAgICAgICAgIGludmVyc2VQYXRjaGVzX1xuICAgICAgICApO1xuICAgICAgY2FzZSAzIC8qIFNldCAqLzpcbiAgICAgICAgcmV0dXJuIGdlbmVyYXRlU2V0UGF0Y2hlcyhcbiAgICAgICAgICBzdGF0ZSxcbiAgICAgICAgICBiYXNlUGF0aCxcbiAgICAgICAgICBwYXRjaGVzXyxcbiAgICAgICAgICBpbnZlcnNlUGF0Y2hlc19cbiAgICAgICAgKTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gZ2VuZXJhdGVBcnJheVBhdGNoZXMoc3RhdGUsIGJhc2VQYXRoLCBwYXRjaGVzLCBpbnZlcnNlUGF0Y2hlcykge1xuICAgIGxldCB7IGJhc2VfLCBhc3NpZ25lZF8gfSA9IHN0YXRlO1xuICAgIGxldCBjb3B5XyA9IHN0YXRlLmNvcHlfO1xuICAgIGlmIChjb3B5Xy5sZW5ndGggPCBiYXNlXy5sZW5ndGgpIHtcbiAgICAgIDtcbiAgICAgIFtiYXNlXywgY29weV9dID0gW2NvcHlfLCBiYXNlX107XG4gICAgICBbcGF0Y2hlcywgaW52ZXJzZVBhdGNoZXNdID0gW2ludmVyc2VQYXRjaGVzLCBwYXRjaGVzXTtcbiAgICB9XG4gICAgY29uc3QgYWxsUmVhc3NpZ25lZCA9IHN0YXRlLmFsbEluZGljZXNSZWFzc2lnbmVkXyA9PT0gdHJ1ZTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJhc2VfLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBjb3BpZWRJdGVtID0gY29weV9baV07XG4gICAgICBjb25zdCBiYXNlSXRlbSA9IGJhc2VfW2ldO1xuICAgICAgY29uc3QgaXNBc3NpZ25lZCA9IGFsbFJlYXNzaWduZWQgfHwgYXNzaWduZWRfPy5nZXQoaS50b1N0cmluZygpKTtcbiAgICAgIGlmIChpc0Fzc2lnbmVkICYmIGNvcGllZEl0ZW0gIT09IGJhc2VJdGVtKSB7XG4gICAgICAgIGNvbnN0IGNoaWxkU3RhdGUgPSBjb3BpZWRJdGVtPy5bRFJBRlRfU1RBVEVdO1xuICAgICAgICBpZiAoY2hpbGRTdGF0ZSAmJiBjaGlsZFN0YXRlLm1vZGlmaWVkXykge1xuICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHBhdGggPSBiYXNlUGF0aC5jb25jYXQoW2ldKTtcbiAgICAgICAgcGF0Y2hlcy5wdXNoKHtcbiAgICAgICAgICBvcDogUkVQTEFDRSxcbiAgICAgICAgICBwYXRoLFxuICAgICAgICAgIC8vIE5lZWQgdG8gbWF5YmUgY2xvbmUgaXQsIGFzIGl0IGNhbiBpbiBmYWN0IGJlIHRoZSBvcmlnaW5hbCB2YWx1ZVxuICAgICAgICAgIC8vIGR1ZSB0byB0aGUgYmFzZS9jb3B5IGludmVyc2lvbiBhdCB0aGUgc3RhcnQgb2YgdGhpcyBmdW5jdGlvblxuICAgICAgICAgIHZhbHVlOiBjbG9uZVBhdGNoVmFsdWVJZk5lZWRlZChjb3BpZWRJdGVtKVxuICAgICAgICB9KTtcbiAgICAgICAgaW52ZXJzZVBhdGNoZXMucHVzaCh7XG4gICAgICAgICAgb3A6IFJFUExBQ0UsXG4gICAgICAgICAgcGF0aCxcbiAgICAgICAgICB2YWx1ZTogY2xvbmVQYXRjaFZhbHVlSWZOZWVkZWQoYmFzZUl0ZW0pXG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICBmb3IgKGxldCBpID0gYmFzZV8ubGVuZ3RoOyBpIDwgY29weV8ubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IHBhdGggPSBiYXNlUGF0aC5jb25jYXQoW2ldKTtcbiAgICAgIHBhdGNoZXMucHVzaCh7XG4gICAgICAgIG9wOiBBREQsXG4gICAgICAgIHBhdGgsXG4gICAgICAgIC8vIE5lZWQgdG8gbWF5YmUgY2xvbmUgaXQsIGFzIGl0IGNhbiBpbiBmYWN0IGJlIHRoZSBvcmlnaW5hbCB2YWx1ZVxuICAgICAgICAvLyBkdWUgdG8gdGhlIGJhc2UvY29weSBpbnZlcnNpb24gYXQgdGhlIHN0YXJ0IG9mIHRoaXMgZnVuY3Rpb25cbiAgICAgICAgdmFsdWU6IGNsb25lUGF0Y2hWYWx1ZUlmTmVlZGVkKGNvcHlfW2ldKVxuICAgICAgfSk7XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSBjb3B5Xy5sZW5ndGggLSAxOyBiYXNlXy5sZW5ndGggPD0gaTsgLS1pKSB7XG4gICAgICBjb25zdCBwYXRoID0gYmFzZVBhdGguY29uY2F0KFtpXSk7XG4gICAgICBpbnZlcnNlUGF0Y2hlcy5wdXNoKHtcbiAgICAgICAgb3A6IFJFTU9WRSxcbiAgICAgICAgcGF0aFxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGdlbmVyYXRlUGF0Y2hlc0Zyb21Bc3NpZ25lZChzdGF0ZSwgYmFzZVBhdGgsIHBhdGNoZXMsIGludmVyc2VQYXRjaGVzKSB7XG4gICAgY29uc3QgeyBiYXNlXywgY29weV8sIHR5cGVfIH0gPSBzdGF0ZTtcbiAgICBlYWNoKHN0YXRlLmFzc2lnbmVkXywgKGtleSwgYXNzaWduZWRWYWx1ZSkgPT4ge1xuICAgICAgY29uc3Qgb3JpZ1ZhbHVlID0gZ2V0KGJhc2VfLCBrZXksIHR5cGVfKTtcbiAgICAgIGNvbnN0IHZhbHVlID0gZ2V0KGNvcHlfLCBrZXksIHR5cGVfKTtcbiAgICAgIGNvbnN0IG9wID0gIWFzc2lnbmVkVmFsdWUgPyBSRU1PVkUgOiBoYXMoYmFzZV8sIGtleSkgPyBSRVBMQUNFIDogQUREO1xuICAgICAgaWYgKG9yaWdWYWx1ZSA9PT0gdmFsdWUgJiYgb3AgPT09IFJFUExBQ0UpXG4gICAgICAgIHJldHVybjtcbiAgICAgIGNvbnN0IHBhdGggPSBiYXNlUGF0aC5jb25jYXQoa2V5KTtcbiAgICAgIHBhdGNoZXMucHVzaChcbiAgICAgICAgb3AgPT09IFJFTU9WRSA/IHsgb3AsIHBhdGggfSA6IHsgb3AsIHBhdGgsIHZhbHVlOiBjbG9uZVBhdGNoVmFsdWVJZk5lZWRlZCh2YWx1ZSkgfVxuICAgICAgKTtcbiAgICAgIGludmVyc2VQYXRjaGVzLnB1c2goXG4gICAgICAgIG9wID09PSBBREQgPyB7IG9wOiBSRU1PVkUsIHBhdGggfSA6IG9wID09PSBSRU1PVkUgPyB7IG9wOiBBREQsIHBhdGgsIHZhbHVlOiBjbG9uZVBhdGNoVmFsdWVJZk5lZWRlZChvcmlnVmFsdWUpIH0gOiB7IG9wOiBSRVBMQUNFLCBwYXRoLCB2YWx1ZTogY2xvbmVQYXRjaFZhbHVlSWZOZWVkZWQob3JpZ1ZhbHVlKSB9XG4gICAgICApO1xuICAgIH0pO1xuICB9XG4gIGZ1bmN0aW9uIGdlbmVyYXRlU2V0UGF0Y2hlcyhzdGF0ZSwgYmFzZVBhdGgsIHBhdGNoZXMsIGludmVyc2VQYXRjaGVzKSB7XG4gICAgbGV0IHsgYmFzZV8sIGNvcHlfIH0gPSBzdGF0ZTtcbiAgICBsZXQgaSA9IDA7XG4gICAgYmFzZV8uZm9yRWFjaCgodmFsdWUpID0+IHtcbiAgICAgIGlmICghY29weV8uaGFzKHZhbHVlKSkge1xuICAgICAgICBjb25zdCBwYXRoID0gYmFzZVBhdGguY29uY2F0KFtpXSk7XG4gICAgICAgIHBhdGNoZXMucHVzaCh7XG4gICAgICAgICAgb3A6IFJFTU9WRSxcbiAgICAgICAgICBwYXRoLFxuICAgICAgICAgIHZhbHVlXG4gICAgICAgIH0pO1xuICAgICAgICBpbnZlcnNlUGF0Y2hlcy51bnNoaWZ0KHtcbiAgICAgICAgICBvcDogQURELFxuICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgdmFsdWVcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpKys7XG4gICAgfSk7XG4gICAgaSA9IDA7XG4gICAgY29weV8uZm9yRWFjaCgodmFsdWUpID0+IHtcbiAgICAgIGlmICghYmFzZV8uaGFzKHZhbHVlKSkge1xuICAgICAgICBjb25zdCBwYXRoID0gYmFzZVBhdGguY29uY2F0KFtpXSk7XG4gICAgICAgIHBhdGNoZXMucHVzaCh7XG4gICAgICAgICAgb3A6IEFERCxcbiAgICAgICAgICBwYXRoLFxuICAgICAgICAgIHZhbHVlXG4gICAgICAgIH0pO1xuICAgICAgICBpbnZlcnNlUGF0Y2hlcy51bnNoaWZ0KHtcbiAgICAgICAgICBvcDogUkVNT1ZFLFxuICAgICAgICAgIHBhdGgsXG4gICAgICAgICAgdmFsdWVcbiAgICAgICAgfSk7XG4gICAgICB9XG4gICAgICBpKys7XG4gICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gZ2VuZXJhdGVSZXBsYWNlbWVudFBhdGNoZXNfKGJhc2VWYWx1ZSwgcmVwbGFjZW1lbnQsIHNjb3BlKSB7XG4gICAgY29uc3QgeyBwYXRjaGVzXywgaW52ZXJzZVBhdGNoZXNfIH0gPSBzY29wZTtcbiAgICBwYXRjaGVzXy5wdXNoKHtcbiAgICAgIG9wOiBSRVBMQUNFLFxuICAgICAgcGF0aDogW10sXG4gICAgICB2YWx1ZTogcmVwbGFjZW1lbnQgPT09IE5PVEhJTkcgPyB2b2lkIDAgOiByZXBsYWNlbWVudFxuICAgIH0pO1xuICAgIGludmVyc2VQYXRjaGVzXy5wdXNoKHtcbiAgICAgIG9wOiBSRVBMQUNFLFxuICAgICAgcGF0aDogW10sXG4gICAgICB2YWx1ZTogYmFzZVZhbHVlXG4gICAgfSk7XG4gIH1cbiAgZnVuY3Rpb24gYXBwbHlQYXRjaGVzXyhkcmFmdCwgcGF0Y2hlcykge1xuICAgIHBhdGNoZXMuZm9yRWFjaCgocGF0Y2gpID0+IHtcbiAgICAgIGNvbnN0IHsgcGF0aCwgb3AgfSA9IHBhdGNoO1xuICAgICAgbGV0IGJhc2UgPSBkcmFmdDtcbiAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcGF0aC5sZW5ndGggLSAxOyBpKyspIHtcbiAgICAgICAgY29uc3QgcGFyZW50VHlwZSA9IGdldEFyY2h0eXBlKGJhc2UpO1xuICAgICAgICBsZXQgcCA9IHBhdGhbaV07XG4gICAgICAgIGlmICh0eXBlb2YgcCAhPT0gXCJzdHJpbmdcIiAmJiB0eXBlb2YgcCAhPT0gXCJudW1iZXJcIikge1xuICAgICAgICAgIHAgPSBcIlwiICsgcDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoKHBhcmVudFR5cGUgPT09IDAgLyogT2JqZWN0ICovIHx8IHBhcmVudFR5cGUgPT09IDEgLyogQXJyYXkgKi8pICYmIChwID09PSBcIl9fcHJvdG9fX1wiIHx8IHAgPT09IENPTlNUUlVDVE9SKSlcbiAgICAgICAgICBkaWUoZXJyb3JPZmZzZXQgKyAzKTtcbiAgICAgICAgaWYgKGlzRnVuY3Rpb24oYmFzZSkgJiYgcCA9PT0gUFJPVE9UWVBFKVxuICAgICAgICAgIGRpZShlcnJvck9mZnNldCArIDMpO1xuICAgICAgICBiYXNlID0gZ2V0KGJhc2UsIHApO1xuICAgICAgICBpZiAoYmFzZSA9PT0gbnVsbCB8fCAhaXNPYmplY3Rpc2goYmFzZSkpXG4gICAgICAgICAgZGllKGVycm9yT2Zmc2V0ICsgMiwgcGF0aC5qb2luKFwiL1wiKSk7XG4gICAgICB9XG4gICAgICBjb25zdCB0eXBlID0gZ2V0QXJjaHR5cGUoYmFzZSk7XG4gICAgICBjb25zdCB2YWx1ZSA9IGRlZXBDbG9uZVBhdGNoVmFsdWUocGF0Y2gudmFsdWUpO1xuICAgICAgY29uc3Qga2V5ID0gcGF0aFtwYXRoLmxlbmd0aCAtIDFdO1xuICAgICAgc3dpdGNoIChvcCkge1xuICAgICAgICBjYXNlIFJFUExBQ0U6XG4gICAgICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgICAgICBjYXNlIDIgLyogTWFwICovOlxuICAgICAgICAgICAgICByZXR1cm4gYmFzZS5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICAgICAgICBjYXNlIDMgLyogU2V0ICovOlxuICAgICAgICAgICAgICBkaWUoZXJyb3JPZmZzZXQpO1xuICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgcmV0dXJuIGJhc2Vba2V5XSA9IHZhbHVlO1xuICAgICAgICAgIH1cbiAgICAgICAgY2FzZSBBREQ6XG4gICAgICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgICAgICBjYXNlIDEgLyogQXJyYXkgKi86XG4gICAgICAgICAgICAgIHJldHVybiBrZXkgPT09IFwiLVwiID8gYmFzZS5wdXNoKHZhbHVlKSA6IGJhc2Uuc3BsaWNlKGtleSwgMCwgdmFsdWUpO1xuICAgICAgICAgICAgY2FzZSAyIC8qIE1hcCAqLzpcbiAgICAgICAgICAgICAgcmV0dXJuIGJhc2Uuc2V0KGtleSwgdmFsdWUpO1xuICAgICAgICAgICAgY2FzZSAzIC8qIFNldCAqLzpcbiAgICAgICAgICAgICAgcmV0dXJuIGJhc2UuYWRkKHZhbHVlKTtcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgIHJldHVybiBiYXNlW2tleV0gPSB2YWx1ZTtcbiAgICAgICAgICB9XG4gICAgICAgIGNhc2UgUkVNT1ZFOlxuICAgICAgICAgIHN3aXRjaCAodHlwZSkge1xuICAgICAgICAgICAgY2FzZSAxIC8qIEFycmF5ICovOlxuICAgICAgICAgICAgICByZXR1cm4gYmFzZS5zcGxpY2Uoa2V5LCAxKTtcbiAgICAgICAgICAgIGNhc2UgMiAvKiBNYXAgKi86XG4gICAgICAgICAgICAgIHJldHVybiBiYXNlLmRlbGV0ZShrZXkpO1xuICAgICAgICAgICAgY2FzZSAzIC8qIFNldCAqLzpcbiAgICAgICAgICAgICAgcmV0dXJuIGJhc2UuZGVsZXRlKHBhdGNoLnZhbHVlKTtcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgIHJldHVybiBkZWxldGUgYmFzZVtrZXldO1xuICAgICAgICAgIH1cbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICBkaWUoZXJyb3JPZmZzZXQgKyAxLCBvcCk7XG4gICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGRyYWZ0O1xuICB9XG4gIGZ1bmN0aW9uIGRlZXBDbG9uZVBhdGNoVmFsdWUob2JqKSB7XG4gICAgaWYgKCFpc0RyYWZ0YWJsZShvYmopKVxuICAgICAgcmV0dXJuIG9iajtcbiAgICBpZiAoaXNBcnJheShvYmopKVxuICAgICAgcmV0dXJuIG9iai5tYXAoZGVlcENsb25lUGF0Y2hWYWx1ZSk7XG4gICAgaWYgKGlzTWFwKG9iaikpXG4gICAgICByZXR1cm4gbmV3IE1hcChcbiAgICAgICAgQXJyYXkuZnJvbShvYmouZW50cmllcygpKS5tYXAoKFtrLCB2XSkgPT4gW2ssIGRlZXBDbG9uZVBhdGNoVmFsdWUodildKVxuICAgICAgKTtcbiAgICBpZiAoaXNTZXQob2JqKSlcbiAgICAgIHJldHVybiBuZXcgU2V0KEFycmF5LmZyb20ob2JqKS5tYXAoZGVlcENsb25lUGF0Y2hWYWx1ZSkpO1xuICAgIGNvbnN0IGNsb25lZCA9IE9iamVjdC5jcmVhdGUoZ2V0UHJvdG90eXBlT2Yob2JqKSk7XG4gICAgZm9yIChjb25zdCBrZXkgaW4gb2JqKVxuICAgICAgY2xvbmVkW2tleV0gPSBkZWVwQ2xvbmVQYXRjaFZhbHVlKG9ialtrZXldKTtcbiAgICBpZiAoaGFzKG9iaiwgRFJBRlRBQkxFKSlcbiAgICAgIGNsb25lZFtEUkFGVEFCTEVdID0gb2JqW0RSQUZUQUJMRV07XG4gICAgcmV0dXJuIGNsb25lZDtcbiAgfVxuICBmdW5jdGlvbiBjbG9uZVBhdGNoVmFsdWVJZk5lZWRlZChvYmopIHtcbiAgICBpZiAoaXNEcmFmdChvYmopKSB7XG4gICAgICByZXR1cm4gZGVlcENsb25lUGF0Y2hWYWx1ZShvYmopO1xuICAgIH0gZWxzZVxuICAgICAgcmV0dXJuIG9iajtcbiAgfVxuICBsb2FkUGx1Z2luKFBsdWdpblBhdGNoZXMsIHtcbiAgICBhcHBseVBhdGNoZXNfLFxuICAgIGdlbmVyYXRlUGF0Y2hlc18sXG4gICAgZ2VuZXJhdGVSZXBsYWNlbWVudFBhdGNoZXNfLFxuICAgIGdldFBhdGhcbiAgfSk7XG59XG5cbi8vIHNyYy9wbHVnaW5zL21hcHNldC50c1xudmFyIF9nbG9iYWxJdGVyYXRvciA9IGdsb2JhbFRoaXMuSXRlcmF0b3I7XG52YXIgaGFzSXRlcmF0b3JGcm9tID0gdHlwZW9mIF9nbG9iYWxJdGVyYXRvcj8uZnJvbSA9PT0gXCJmdW5jdGlvblwiO1xuZnVuY3Rpb24gZW5hYmxlTWFwU2V0KCkge1xuICBjbGFzcyBEcmFmdE1hcCBleHRlbmRzIE1hcCB7XG4gICAgY29uc3RydWN0b3IodGFyZ2V0LCBwYXJlbnQpIHtcbiAgICAgIHN1cGVyKCk7XG4gICAgICB0aGlzW0RSQUZUX1NUQVRFXSA9IHtcbiAgICAgICAgdHlwZV86IDIgLyogTWFwICovLFxuICAgICAgICBwYXJlbnRfOiBwYXJlbnQsXG4gICAgICAgIHNjb3BlXzogcGFyZW50ID8gcGFyZW50LnNjb3BlXyA6IGdldEN1cnJlbnRTY29wZSgpLFxuICAgICAgICBtb2RpZmllZF86IGZhbHNlLFxuICAgICAgICBmaW5hbGl6ZWRfOiBmYWxzZSxcbiAgICAgICAgY29weV86IHZvaWQgMCxcbiAgICAgICAgYXNzaWduZWRfOiB2b2lkIDAsXG4gICAgICAgIGJhc2VfOiB0YXJnZXQsXG4gICAgICAgIGRyYWZ0XzogdGhpcyxcbiAgICAgICAgaXNNYW51YWxfOiBmYWxzZSxcbiAgICAgICAgcmV2b2tlZF86IGZhbHNlLFxuICAgICAgICBjYWxsYmFja3NfOiBbXVxuICAgICAgfTtcbiAgICB9XG4gICAgZ2V0IHNpemUoKSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIHJldHVybiBsYXRlc3Qoc3RhdGUpLnNpemU7XG4gICAgfVxuICAgIGhhcyhrZXkpIHtcbiAgICAgIGNvbnN0IHN0YXRlID0gdGhpc1tEUkFGVF9TVEFURV07XG4gICAgICBhc3NlcnRVbnJldm9rZWQoc3RhdGUpO1xuICAgICAgcmV0dXJuIGxhdGVzdChzdGF0ZSkuaGFzKGtleSk7XG4gICAgfVxuICAgIHNldChrZXksIHZhbHVlKSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIGlmICghbGF0ZXN0KHN0YXRlKS5oYXMoa2V5KSB8fCBsYXRlc3Qoc3RhdGUpLmdldChrZXkpICE9PSB2YWx1ZSkge1xuICAgICAgICBwcmVwYXJlTWFwQ29weShzdGF0ZSk7XG4gICAgICAgIG1hcmtDaGFuZ2VkKHN0YXRlKTtcbiAgICAgICAgc3RhdGUuYXNzaWduZWRfLnNldChrZXksIHRydWUpO1xuICAgICAgICBzdGF0ZS5jb3B5Xy5zZXQoa2V5LCB2YWx1ZSk7XG4gICAgICAgIHN0YXRlLmFzc2lnbmVkXy5zZXQoa2V5LCB0cnVlKTtcbiAgICAgICAgaGFuZGxlQ3Jvc3NSZWZlcmVuY2Uoc3RhdGUsIGtleSwgdmFsdWUpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGRlbGV0ZShrZXkpIHtcbiAgICAgIGlmICghdGhpcy5oYXMoa2V5KSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIHByZXBhcmVNYXBDb3B5KHN0YXRlKTtcbiAgICAgIG1hcmtDaGFuZ2VkKHN0YXRlKTtcbiAgICAgIGlmIChzdGF0ZS5iYXNlXy5oYXMoa2V5KSkge1xuICAgICAgICBzdGF0ZS5hc3NpZ25lZF8uc2V0KGtleSwgZmFsc2UpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgc3RhdGUuYXNzaWduZWRfLmRlbGV0ZShrZXkpO1xuICAgICAgfVxuICAgICAgc3RhdGUuY29weV8uZGVsZXRlKGtleSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgY2xlYXIoKSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIGlmIChsYXRlc3Qoc3RhdGUpLnNpemUpIHtcbiAgICAgICAgcHJlcGFyZU1hcENvcHkoc3RhdGUpO1xuICAgICAgICBtYXJrQ2hhbmdlZChzdGF0ZSk7XG4gICAgICAgIHN0YXRlLmFzc2lnbmVkXyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgICAgIGVhY2goc3RhdGUuYmFzZV8sIChrZXkpID0+IHtcbiAgICAgICAgICBzdGF0ZS5hc3NpZ25lZF8uc2V0KGtleSwgZmFsc2UpO1xuICAgICAgICB9KTtcbiAgICAgICAgc3RhdGUuY29weV8uY2xlYXIoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgZm9yRWFjaChjYiwgdGhpc0FyZykge1xuICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzW0RSQUZUX1NUQVRFXTtcbiAgICAgIGFzc2VydFVucmV2b2tlZChzdGF0ZSk7XG4gICAgICBsYXRlc3Qoc3RhdGUpLmZvckVhY2goKF92YWx1ZSwga2V5LCBfbWFwKSA9PiB7XG4gICAgICAgIGNiLmNhbGwodGhpc0FyZywgdGhpcy5nZXQoa2V5KSwga2V5LCB0aGlzKTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBnZXQoa2V5KSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIGNvbnN0IHZhbHVlID0gbGF0ZXN0KHN0YXRlKS5nZXQoa2V5KTtcbiAgICAgIGlmIChzdGF0ZS5maW5hbGl6ZWRfIHx8ICFpc0RyYWZ0YWJsZSh2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuICAgICAgaWYgKHZhbHVlICE9PSBzdGF0ZS5iYXNlXy5nZXQoa2V5KSkge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICB9XG4gICAgICBjb25zdCBkcmFmdCA9IGNyZWF0ZVByb3h5KHN0YXRlLnNjb3BlXywgdmFsdWUsIHN0YXRlLCBrZXkpO1xuICAgICAgcHJlcGFyZU1hcENvcHkoc3RhdGUpO1xuICAgICAgc3RhdGUuY29weV8uc2V0KGtleSwgZHJhZnQpO1xuICAgICAgcmV0dXJuIGRyYWZ0O1xuICAgIH1cbiAgICBrZXlzKCkge1xuICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzW0RSQUZUX1NUQVRFXTtcbiAgICAgIGFzc2VydFVucmV2b2tlZChzdGF0ZSk7XG4gICAgICByZXR1cm4gbGF0ZXN0KHN0YXRlKS5rZXlzKCk7XG4gICAgfVxuICAgIHZhbHVlcygpIHtcbiAgICAgIGNvbnN0IGl0ZXJhdG9yID0gdGhpcy5rZXlzKCk7XG4gICAgICByZXR1cm4gaXRlcmF0b3JGcm9tKHtcbiAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHIgPSBpdGVyYXRvci5uZXh0KCk7XG4gICAgICAgICAgaWYgKHIuZG9uZSlcbiAgICAgICAgICAgIHJldHVybiByO1xuICAgICAgICAgIGNvbnN0IHZhbHVlID0gdGhpcy5nZXQoci52YWx1ZSk7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGRvbmU6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWVcbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgZW50cmllcygpIHtcbiAgICAgIGNvbnN0IGl0ZXJhdG9yID0gdGhpcy5rZXlzKCk7XG4gICAgICByZXR1cm4gaXRlcmF0b3JGcm9tKHtcbiAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHIgPSBpdGVyYXRvci5uZXh0KCk7XG4gICAgICAgICAgaWYgKHIuZG9uZSlcbiAgICAgICAgICAgIHJldHVybiByO1xuICAgICAgICAgIGNvbnN0IHZhbHVlID0gdGhpcy5nZXQoci52YWx1ZSk7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGRvbmU6IGZhbHNlLFxuICAgICAgICAgICAgdmFsdWU6IFtyLnZhbHVlLCB2YWx1ZV1cbiAgICAgICAgICB9O1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gICAgWyhEUkFGVF9TVEFURSwgU3ltYm9sLml0ZXJhdG9yKV0oKSB7XG4gICAgICByZXR1cm4gdGhpcy5lbnRyaWVzKCk7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIGl0ZXJhdG9yRnJvbShpdGVyYWJsZSkge1xuICAgIGlmIChoYXNJdGVyYXRvckZyb20pIHtcbiAgICAgIHJldHVybiBfZ2xvYmFsSXRlcmF0b3IuZnJvbShpdGVyYWJsZSk7XG4gICAgfVxuICAgIGNvbnN0IGl0ZXJhdG9yID0ge1xuICAgICAgLi4uaXRlcmFibGUsXG4gICAgICBbU3ltYm9sLml0ZXJhdG9yXTogKCkgPT4gaXRlcmF0b3JcbiAgICB9O1xuICAgIHJldHVybiBpdGVyYXRvcjtcbiAgfVxuICBmdW5jdGlvbiBwcm94eU1hcF8odGFyZ2V0LCBwYXJlbnQpIHtcbiAgICBjb25zdCBtYXAgPSBuZXcgRHJhZnRNYXAodGFyZ2V0LCBwYXJlbnQpO1xuICAgIHJldHVybiBbbWFwLCBtYXBbRFJBRlRfU1RBVEVdXTtcbiAgfVxuICBmdW5jdGlvbiBwcmVwYXJlTWFwQ29weShzdGF0ZSkge1xuICAgIGlmICghc3RhdGUuY29weV8pIHtcbiAgICAgIHN0YXRlLmFzc2lnbmVkXyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG4gICAgICBzdGF0ZS5jb3B5XyA9IG5ldyBNYXAoc3RhdGUuYmFzZV8pO1xuICAgIH1cbiAgfVxuICBjbGFzcyBEcmFmdFNldCBleHRlbmRzIFNldCB7XG4gICAgY29uc3RydWN0b3IodGFyZ2V0LCBwYXJlbnQpIHtcbiAgICAgIHN1cGVyKCk7XG4gICAgICB0aGlzW0RSQUZUX1NUQVRFXSA9IHtcbiAgICAgICAgdHlwZV86IDMgLyogU2V0ICovLFxuICAgICAgICBwYXJlbnRfOiBwYXJlbnQsXG4gICAgICAgIHNjb3BlXzogcGFyZW50ID8gcGFyZW50LnNjb3BlXyA6IGdldEN1cnJlbnRTY29wZSgpLFxuICAgICAgICBtb2RpZmllZF86IGZhbHNlLFxuICAgICAgICBmaW5hbGl6ZWRfOiBmYWxzZSxcbiAgICAgICAgY29weV86IHZvaWQgMCxcbiAgICAgICAgYmFzZV86IHRhcmdldCxcbiAgICAgICAgZHJhZnRfOiB0aGlzLFxuICAgICAgICBkcmFmdHNfOiAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpLFxuICAgICAgICByZXZva2VkXzogZmFsc2UsXG4gICAgICAgIGlzTWFudWFsXzogZmFsc2UsXG4gICAgICAgIGFzc2lnbmVkXzogdm9pZCAwLFxuICAgICAgICBjYWxsYmFja3NfOiBbXVxuICAgICAgfTtcbiAgICB9XG4gICAgZ2V0IHNpemUoKSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIHJldHVybiBsYXRlc3Qoc3RhdGUpLnNpemU7XG4gICAgfVxuICAgIGhhcyh2YWx1ZSkge1xuICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzW0RSQUZUX1NUQVRFXTtcbiAgICAgIGFzc2VydFVucmV2b2tlZChzdGF0ZSk7XG4gICAgICBpZiAoIXN0YXRlLmNvcHlfKSB7XG4gICAgICAgIHJldHVybiBzdGF0ZS5iYXNlXy5oYXModmFsdWUpO1xuICAgICAgfVxuICAgICAgaWYgKHN0YXRlLmNvcHlfLmhhcyh2YWx1ZSkpXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgaWYgKHN0YXRlLmRyYWZ0c18uaGFzKHZhbHVlKSAmJiBzdGF0ZS5jb3B5Xy5oYXMoc3RhdGUuZHJhZnRzXy5nZXQodmFsdWUpKSlcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGFkZCh2YWx1ZSkge1xuICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzW0RSQUZUX1NUQVRFXTtcbiAgICAgIGFzc2VydFVucmV2b2tlZChzdGF0ZSk7XG4gICAgICBpZiAoIXRoaXMuaGFzKHZhbHVlKSkge1xuICAgICAgICBwcmVwYXJlU2V0Q29weShzdGF0ZSk7XG4gICAgICAgIG1hcmtDaGFuZ2VkKHN0YXRlKTtcbiAgICAgICAgc3RhdGUuY29weV8uYWRkKHZhbHVlKTtcbiAgICAgICAgaGFuZGxlQ3Jvc3NSZWZlcmVuY2Uoc3RhdGUsIHZhbHVlLCB2YWx1ZSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZGVsZXRlKHZhbHVlKSB7XG4gICAgICBpZiAoIXRoaXMuaGFzKHZhbHVlKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIHByZXBhcmVTZXRDb3B5KHN0YXRlKTtcbiAgICAgIG1hcmtDaGFuZ2VkKHN0YXRlKTtcbiAgICAgIHJldHVybiBzdGF0ZS5jb3B5Xy5kZWxldGUodmFsdWUpIHx8IChzdGF0ZS5kcmFmdHNfLmhhcyh2YWx1ZSkgPyBzdGF0ZS5jb3B5Xy5kZWxldGUoc3RhdGUuZHJhZnRzXy5nZXQodmFsdWUpKSA6IChcbiAgICAgICAgLyogaXN0YW5idWwgaWdub3JlIG5leHQgKi9cbiAgICAgICAgZmFsc2VcbiAgICAgICkpO1xuICAgIH1cbiAgICBjbGVhcigpIHtcbiAgICAgIGNvbnN0IHN0YXRlID0gdGhpc1tEUkFGVF9TVEFURV07XG4gICAgICBhc3NlcnRVbnJldm9rZWQoc3RhdGUpO1xuICAgICAgaWYgKGxhdGVzdChzdGF0ZSkuc2l6ZSkge1xuICAgICAgICBwcmVwYXJlU2V0Q29weShzdGF0ZSk7XG4gICAgICAgIG1hcmtDaGFuZ2VkKHN0YXRlKTtcbiAgICAgICAgc3RhdGUuY29weV8uY2xlYXIoKTtcbiAgICAgIH1cbiAgICB9XG4gICAgdmFsdWVzKCkge1xuICAgICAgY29uc3Qgc3RhdGUgPSB0aGlzW0RSQUZUX1NUQVRFXTtcbiAgICAgIGFzc2VydFVucmV2b2tlZChzdGF0ZSk7XG4gICAgICBwcmVwYXJlU2V0Q29weShzdGF0ZSk7XG4gICAgICByZXR1cm4gc3RhdGUuY29weV8udmFsdWVzKCk7XG4gICAgfVxuICAgIGVudHJpZXMoKSB7XG4gICAgICBjb25zdCBzdGF0ZSA9IHRoaXNbRFJBRlRfU1RBVEVdO1xuICAgICAgYXNzZXJ0VW5yZXZva2VkKHN0YXRlKTtcbiAgICAgIHByZXBhcmVTZXRDb3B5KHN0YXRlKTtcbiAgICAgIHJldHVybiBzdGF0ZS5jb3B5Xy5lbnRyaWVzKCk7XG4gICAgfVxuICAgIGtleXMoKSB7XG4gICAgICByZXR1cm4gdGhpcy52YWx1ZXMoKTtcbiAgICB9XG4gICAgWyhEUkFGVF9TVEFURSwgU3ltYm9sLml0ZXJhdG9yKV0oKSB7XG4gICAgICByZXR1cm4gdGhpcy52YWx1ZXMoKTtcbiAgICB9XG4gICAgZm9yRWFjaChjYiwgdGhpc0FyZykge1xuICAgICAgY29uc3QgaXRlcmF0b3IgPSB0aGlzLnZhbHVlcygpO1xuICAgICAgbGV0IHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKTtcbiAgICAgIHdoaWxlICghcmVzdWx0LmRvbmUpIHtcbiAgICAgICAgY2IuY2FsbCh0aGlzQXJnLCByZXN1bHQudmFsdWUsIHJlc3VsdC52YWx1ZSwgdGhpcyk7XG4gICAgICAgIHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKTtcbiAgICAgIH1cbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gcHJveHlTZXRfKHRhcmdldCwgcGFyZW50KSB7XG4gICAgY29uc3Qgc2V0MiA9IG5ldyBEcmFmdFNldCh0YXJnZXQsIHBhcmVudCk7XG4gICAgcmV0dXJuIFtzZXQyLCBzZXQyW0RSQUZUX1NUQVRFXV07XG4gIH1cbiAgZnVuY3Rpb24gcHJlcGFyZVNldENvcHkoc3RhdGUpIHtcbiAgICBpZiAoIXN0YXRlLmNvcHlfKSB7XG4gICAgICBzdGF0ZS5jb3B5XyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG4gICAgICBzdGF0ZS5iYXNlXy5mb3JFYWNoKCh2YWx1ZSkgPT4ge1xuICAgICAgICBpZiAoaXNEcmFmdGFibGUodmFsdWUpKSB7XG4gICAgICAgICAgY29uc3QgZHJhZnQgPSBjcmVhdGVQcm94eShzdGF0ZS5zY29wZV8sIHZhbHVlLCBzdGF0ZSwgdmFsdWUpO1xuICAgICAgICAgIHN0YXRlLmRyYWZ0c18uc2V0KHZhbHVlLCBkcmFmdCk7XG4gICAgICAgICAgc3RhdGUuY29weV8uYWRkKGRyYWZ0KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzdGF0ZS5jb3B5Xy5hZGQodmFsdWUpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gYXNzZXJ0VW5yZXZva2VkKHN0YXRlKSB7XG4gICAgaWYgKHN0YXRlLnJldm9rZWRfKVxuICAgICAgZGllKDMsIEpTT04uc3RyaW5naWZ5KGxhdGVzdChzdGF0ZSkpKTtcbiAgfVxuICBmdW5jdGlvbiBmaXhTZXRDb250ZW50cyh0YXJnZXQpIHtcbiAgICBpZiAodGFyZ2V0LnR5cGVfID09PSAzIC8qIFNldCAqLyAmJiB0YXJnZXQuY29weV8pIHtcbiAgICAgIGNvbnN0IGNvcHkgPSBuZXcgU2V0KHRhcmdldC5jb3B5Xyk7XG4gICAgICB0YXJnZXQuY29weV8uY2xlYXIoKTtcbiAgICAgIGNvcHkuZm9yRWFjaCgodmFsdWUpID0+IHtcbiAgICAgICAgdGFyZ2V0LmNvcHlfLmFkZChnZXRWYWx1ZSh2YWx1ZSkpO1xuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIGxvYWRQbHVnaW4oUGx1Z2luTWFwU2V0LCB7IHByb3h5TWFwXywgcHJveHlTZXRfLCBmaXhTZXRDb250ZW50cyB9KTtcbn1cblxuLy8gc3JjL3BsdWdpbnMvYXJyYXlNZXRob2RzLnRzXG5mdW5jdGlvbiBlbmFibGVBcnJheU1ldGhvZHMoKSB7XG4gIGNvbnN0IFNISUZUSU5HX01FVEhPRFMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldChbXCJzaGlmdFwiLCBcInVuc2hpZnRcIl0pO1xuICBjb25zdCBRVUVVRV9NRVRIT0RTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1wicHVzaFwiLCBcInBvcFwiXSk7XG4gIGNvbnN0IFJFU1VMVF9SRVRVUk5JTkdfTUVUSE9EUyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcbiAgICAuLi5RVUVVRV9NRVRIT0RTLFxuICAgIC4uLlNISUZUSU5HX01FVEhPRFNcbiAgXSk7XG4gIGNvbnN0IFJFT1JERVJJTkdfTUVUSE9EUyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcInJldmVyc2VcIiwgXCJzb3J0XCJdKTtcbiAgY29uc3QgTVVUQVRJTkdfTUVUSE9EUyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcbiAgICAuLi5SRVNVTFRfUkVUVVJOSU5HX01FVEhPRFMsXG4gICAgLi4uUkVPUkRFUklOR19NRVRIT0RTLFxuICAgIFwic3BsaWNlXCJcbiAgXSk7XG4gIGNvbnN0IEZJTkRfTUVUSE9EUyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KFtcImZpbmRcIiwgXCJmaW5kTGFzdFwiXSk7XG4gIGNvbnN0IE5PTl9NVVRBVElOR19NRVRIT0RTID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW1xuICAgIFwiZmlsdGVyXCIsXG4gICAgXCJzbGljZVwiLFxuICAgIFwiY29uY2F0XCIsXG4gICAgXCJmbGF0XCIsXG4gICAgLi4uRklORF9NRVRIT0RTLFxuICAgIFwiZmluZEluZGV4XCIsXG4gICAgXCJmaW5kTGFzdEluZGV4XCIsXG4gICAgXCJzb21lXCIsXG4gICAgXCJldmVyeVwiLFxuICAgIFwiaW5kZXhPZlwiLFxuICAgIFwibGFzdEluZGV4T2ZcIixcbiAgICBcImluY2x1ZGVzXCIsXG4gICAgXCJqb2luXCIsXG4gICAgXCJ0b1N0cmluZ1wiLFxuICAgIFwidG9Mb2NhbGVTdHJpbmdcIlxuICBdKTtcbiAgZnVuY3Rpb24gaXNNdXRhdGluZ0FycmF5TWV0aG9kKG1ldGhvZCkge1xuICAgIHJldHVybiBNVVRBVElOR19NRVRIT0RTLmhhcyhtZXRob2QpO1xuICB9XG4gIGZ1bmN0aW9uIGlzTm9uTXV0YXRpbmdBcnJheU1ldGhvZChtZXRob2QpIHtcbiAgICByZXR1cm4gTk9OX01VVEFUSU5HX01FVEhPRFMuaGFzKG1ldGhvZCk7XG4gIH1cbiAgZnVuY3Rpb24gaXNBcnJheU9wZXJhdGlvbk1ldGhvZChtZXRob2QpIHtcbiAgICByZXR1cm4gaXNNdXRhdGluZ0FycmF5TWV0aG9kKG1ldGhvZCkgfHwgaXNOb25NdXRhdGluZ0FycmF5TWV0aG9kKG1ldGhvZCk7XG4gIH1cbiAgZnVuY3Rpb24gZW50ZXJPcGVyYXRpb24oc3RhdGUsIG1ldGhvZCkge1xuICAgIHN0YXRlLm9wZXJhdGlvbk1ldGhvZCA9IG1ldGhvZDtcbiAgfVxuICBmdW5jdGlvbiBleGl0T3BlcmF0aW9uKHN0YXRlKSB7XG4gICAgc3RhdGUub3BlcmF0aW9uTWV0aG9kID0gdm9pZCAwO1xuICB9XG4gIGZ1bmN0aW9uIGV4ZWN1dGVBcnJheU1ldGhvZChzdGF0ZSwgb3BlcmF0aW9uLCBtYXJrTGVuZ3RoID0gdHJ1ZSkge1xuICAgIHByZXBhcmVDb3B5KHN0YXRlKTtcbiAgICBjb25zdCByZXN1bHQgPSBvcGVyYXRpb24oKTtcbiAgICBtYXJrQXJyYXlDaGFuZ2VkKHN0YXRlLCBtYXJrTGVuZ3RoKTtcbiAgICByZXR1cm4gcmVzdWx0O1xuICB9XG4gIGZ1bmN0aW9uIG1hcmtBcnJheUNoYW5nZWQoc3RhdGUsIG1hcmtMZW5ndGggPSB0cnVlKSB7XG4gICAgbWFya0NoYW5nZWQoc3RhdGUpO1xuICAgIGlmIChtYXJrTGVuZ3RoKVxuICAgICAgc3RhdGUuYXNzaWduZWRfLnNldChcImxlbmd0aFwiLCB0cnVlKTtcbiAgfVxuICBmdW5jdGlvbiBtYXJrQWxsSW5kaWNlc1JlYXNzaWduZWQoc3RhdGUpIHtcbiAgICBzdGF0ZS5hbGxJbmRpY2VzUmVhc3NpZ25lZF8gPSB0cnVlO1xuICAgIHN0YXRlLmJhc2VSZWZzXyA9IG5ldyBTZXQoc3RhdGUuYmFzZV8pO1xuICB9XG4gIGZ1bmN0aW9uIG5vcm1hbGl6ZVNsaWNlSW5kZXgoaW5kZXgsIGxlbmd0aCkge1xuICAgIGlmIChpbmRleCA8IDApIHtcbiAgICAgIHJldHVybiBNYXRoLm1heChsZW5ndGggKyBpbmRleCwgMCk7XG4gICAgfVxuICAgIHJldHVybiBNYXRoLm1pbihpbmRleCwgbGVuZ3RoKTtcbiAgfVxuICBmdW5jdGlvbiBoYW5kbGVJbnNlcnRlZFZhbHVlcyhzdGF0ZSwgc3RhcnRJbmRleCwgdmFsdWVzKSB7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB2YWx1ZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGluZGV4ID0gXCJcIiArIChzdGFydEluZGV4ICsgaSk7XG4gICAgICBzdGF0ZS5hc3NpZ25lZF8uc2V0KGluZGV4LCB0cnVlKTtcbiAgICAgIGhhbmRsZUNyb3NzUmVmZXJlbmNlKHN0YXRlLCBpbmRleCwgdmFsdWVzW2ldKTtcbiAgICB9XG4gIH1cbiAgZnVuY3Rpb24gaGFuZGxlU2ltcGxlT3BlcmF0aW9uKHN0YXRlLCBtZXRob2QsIGFyZ3MpIHtcbiAgICBjb25zdCBpc0luc2VydCA9IG1ldGhvZCA9PT0gXCJwdXNoXCIgfHwgbWV0aG9kID09PSBcInVuc2hpZnRcIjtcbiAgICBpZiAoaXNJbnNlcnQgPyBhcmdzLmxlbmd0aCA9PT0gMCA6IGxhdGVzdChzdGF0ZSkubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gaXNJbnNlcnQgPyBsYXRlc3Qoc3RhdGUpLmxlbmd0aCA6IHZvaWQgMDtcbiAgICB9XG4gICAgcHJlcGFyZUNvcHkoc3RhdGUpO1xuICAgIGNvbnN0IGxlbmd0aEJlZm9yZSA9IHN0YXRlLmNvcHlfLmxlbmd0aDtcbiAgICBjb25zdCByZXN1bHQgPSBzdGF0ZS5jb3B5X1ttZXRob2RdKC4uLmFyZ3MpO1xuICAgIG1hcmtBcnJheUNoYW5nZWQoc3RhdGUpO1xuICAgIGlmIChTSElGVElOR19NRVRIT0RTLmhhcyhtZXRob2QpKSB7XG4gICAgICBtYXJrQWxsSW5kaWNlc1JlYXNzaWduZWQoc3RhdGUpO1xuICAgIH1cbiAgICBpZiAobWV0aG9kID09PSBcInB1c2hcIikge1xuICAgICAgaGFuZGxlSW5zZXJ0ZWRWYWx1ZXMoc3RhdGUsIGxlbmd0aEJlZm9yZSwgYXJncyk7XG4gICAgfSBlbHNlIGlmIChtZXRob2QgPT09IFwidW5zaGlmdFwiKSB7XG4gICAgICBoYW5kbGVJbnNlcnRlZFZhbHVlcyhzdGF0ZSwgMCwgYXJncyk7XG4gICAgfVxuICAgIHJldHVybiBSRVNVTFRfUkVUVVJOSU5HX01FVEhPRFMuaGFzKG1ldGhvZCkgPyByZXN1bHQgOiBzdGF0ZS5kcmFmdF87XG4gIH1cbiAgZnVuY3Rpb24gaGFuZGxlUmVvcmRlcmluZ09wZXJhdGlvbihzdGF0ZSwgbWV0aG9kLCBhcmdzKSB7XG4gICAgaWYgKGxhdGVzdChzdGF0ZSkubGVuZ3RoIDw9IDEpXG4gICAgICByZXR1cm4gc3RhdGUuZHJhZnRfO1xuICAgIHJldHVybiBleGVjdXRlQXJyYXlNZXRob2QoXG4gICAgICBzdGF0ZSxcbiAgICAgICgpID0+IHtcbiAgICAgICAgO1xuICAgICAgICBzdGF0ZS5jb3B5X1ttZXRob2RdKC4uLmFyZ3MpO1xuICAgICAgICBtYXJrQWxsSW5kaWNlc1JlYXNzaWduZWQoc3RhdGUpO1xuICAgICAgICByZXR1cm4gc3RhdGUuZHJhZnRfO1xuICAgICAgfSxcbiAgICAgIGZhbHNlXG4gICAgKTtcbiAgfVxuICBmdW5jdGlvbiBjcmVhdGVNZXRob2RJbnRlcmNlcHRvcihzdGF0ZSwgb3JpZ2luYWxNZXRob2QpIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gaW50ZXJjZXB0ZWRNZXRob2QoLi4uYXJncykge1xuICAgICAgY29uc3QgbWV0aG9kID0gb3JpZ2luYWxNZXRob2Q7XG4gICAgICBlbnRlck9wZXJhdGlvbihzdGF0ZSwgbWV0aG9kKTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGlmIChpc011dGF0aW5nQXJyYXlNZXRob2QobWV0aG9kKSkge1xuICAgICAgICAgIGlmIChSRVNVTFRfUkVUVVJOSU5HX01FVEhPRFMuaGFzKG1ldGhvZCkpIHtcbiAgICAgICAgICAgIHJldHVybiBoYW5kbGVTaW1wbGVPcGVyYXRpb24oc3RhdGUsIG1ldGhvZCwgYXJncyk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChSRU9SREVSSU5HX01FVEhPRFMuaGFzKG1ldGhvZCkpIHtcbiAgICAgICAgICAgIHJldHVybiBoYW5kbGVSZW9yZGVyaW5nT3BlcmF0aW9uKHN0YXRlLCBtZXRob2QsIGFyZ3MpO1xuICAgICAgICAgIH1cbiAgICAgICAgICBpZiAobWV0aG9kID09PSBcInNwbGljZVwiKSB7XG4gICAgICAgICAgICBjb25zdCBpbnNlcnRDb3VudCA9IGFyZ3MubGVuZ3RoID4gMiA/IGFyZ3MubGVuZ3RoIC0gMiA6IDA7XG4gICAgICAgICAgICBpZiAoaW5zZXJ0Q291bnQgPT09IDApIHtcbiAgICAgICAgICAgICAgY29uc3QgbGVuZ3RoID0gbGF0ZXN0KHN0YXRlKS5sZW5ndGg7XG4gICAgICAgICAgICAgIGlmIChhcmdzLmxlbmd0aCA9PT0gMCB8fCBub3JtYWxpemVTbGljZUluZGV4KGFyZ3NbMF0gPz8gMCwgbGVuZ3RoKSA9PT0gbGVuZ3RoIHx8IGFyZ3MubGVuZ3RoID4gMSAmJiAhKGFyZ3NbMV0gPj0gMSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHByZXBhcmVDb3B5KHN0YXRlKTtcbiAgICAgICAgICAgIGNvbnN0IHJlcyA9IHN0YXRlLmNvcHlfLnNwbGljZShcbiAgICAgICAgICAgICAgLi4uYXJnc1xuICAgICAgICAgICAgKTtcbiAgICAgICAgICAgIGlmIChyZXMubGVuZ3RoID09PSAwICYmIGluc2VydENvdW50ID09PSAwKSB7XG4gICAgICAgICAgICAgIHJldHVybiByZXM7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBtYXJrQXJyYXlDaGFuZ2VkKHN0YXRlKTtcbiAgICAgICAgICAgIG1hcmtBbGxJbmRpY2VzUmVhc3NpZ25lZChzdGF0ZSk7XG4gICAgICAgICAgICBpZiAoaW5zZXJ0Q291bnQgPiAwKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHN0YXJ0SW5kZXggPSBub3JtYWxpemVTbGljZUluZGV4KFxuICAgICAgICAgICAgICAgIGFyZ3NbMF0gPz8gMCxcbiAgICAgICAgICAgICAgICBzdGF0ZS5jb3B5Xy5sZW5ndGhcbiAgICAgICAgICAgICAgKTtcbiAgICAgICAgICAgICAgaGFuZGxlSW5zZXJ0ZWRWYWx1ZXMoc3RhdGUsIHN0YXJ0SW5kZXgsIGFyZ3Muc2xpY2UoMikpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgcmV0dXJuIGhhbmRsZU5vbk11dGF0aW5nT3BlcmF0aW9uKHN0YXRlLCBtZXRob2QsIGFyZ3MpO1xuICAgICAgICB9XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICBleGl0T3BlcmF0aW9uKHN0YXRlKTtcbiAgICAgIH1cbiAgICB9O1xuICB9XG4gIGZ1bmN0aW9uIGhhbmRsZU5vbk11dGF0aW5nT3BlcmF0aW9uKHN0YXRlLCBtZXRob2QsIGFyZ3MpIHtcbiAgICBjb25zdCBzb3VyY2UgPSBsYXRlc3Qoc3RhdGUpO1xuICAgIGlmIChtZXRob2QgPT09IFwiZmlsdGVyXCIpIHtcbiAgICAgIGNvbnN0IHByZWRpY2F0ZSA9IGFyZ3NbMF07XG4gICAgICBjb25zdCB0aGlzQXJnID0gYXJnc1sxXTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzb3VyY2UubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgaWYgKHByZWRpY2F0ZS5jYWxsKHRoaXNBcmcsIHNvdXJjZVtpXSwgaSwgc291cmNlKSkge1xuICAgICAgICAgIHJlc3VsdC5wdXNoKHN0YXRlLmRyYWZ0X1tpXSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIGlmIChGSU5EX01FVEhPRFMuaGFzKG1ldGhvZCkpIHtcbiAgICAgIGNvbnN0IHByZWRpY2F0ZSA9IGFyZ3NbMF07XG4gICAgICBjb25zdCB0aGlzQXJnID0gYXJnc1sxXTtcbiAgICAgIGNvbnN0IGlzRm9yd2FyZCA9IG1ldGhvZCA9PT0gXCJmaW5kXCI7XG4gICAgICBjb25zdCBzdGVwID0gaXNGb3J3YXJkID8gMSA6IC0xO1xuICAgICAgY29uc3Qgc3RhcnQgPSBpc0ZvcndhcmQgPyAwIDogc291cmNlLmxlbmd0aCAtIDE7XG4gICAgICBmb3IgKGxldCBpID0gc3RhcnQ7IGkgPj0gMCAmJiBpIDwgc291cmNlLmxlbmd0aDsgaSArPSBzdGVwKSB7XG4gICAgICAgIGlmIChwcmVkaWNhdGUuY2FsbCh0aGlzQXJnLCBzb3VyY2VbaV0sIGksIHNvdXJjZSkpIHtcbiAgICAgICAgICByZXR1cm4gc3RhdGUuZHJhZnRfW2ldO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICByZXR1cm4gdm9pZCAwO1xuICAgIH1cbiAgICBpZiAobWV0aG9kID09PSBcInNsaWNlXCIpIHtcbiAgICAgIGNvbnN0IHJhd1N0YXJ0ID0gYXJnc1swXSA/PyAwO1xuICAgICAgY29uc3QgcmF3RW5kID0gYXJnc1sxXSA/PyBzb3VyY2UubGVuZ3RoO1xuICAgICAgY29uc3Qgc3RhcnQgPSBub3JtYWxpemVTbGljZUluZGV4KHJhd1N0YXJ0LCBzb3VyY2UubGVuZ3RoKTtcbiAgICAgIGNvbnN0IGVuZCA9IG5vcm1hbGl6ZVNsaWNlSW5kZXgocmF3RW5kLCBzb3VyY2UubGVuZ3RoKTtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IFtdO1xuICAgICAgZm9yIChsZXQgaSA9IHN0YXJ0OyBpIDwgZW5kOyBpKyspIHtcbiAgICAgICAgcmVzdWx0LnB1c2goc3RhdGUuZHJhZnRfW2ldKTtcbiAgICAgIH1cbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIHJldHVybiBzb3VyY2VbbWV0aG9kXSguLi5hcmdzKTtcbiAgfVxuICBsb2FkUGx1Z2luKFBsdWdpbkFycmF5TWV0aG9kcywge1xuICAgIGNyZWF0ZU1ldGhvZEludGVyY2VwdG9yLFxuICAgIGlzQXJyYXlPcGVyYXRpb25NZXRob2QsXG4gICAgaXNNdXRhdGluZ0FycmF5TWV0aG9kXG4gIH0pO1xufVxuXG4vLyBzcmMvaW1tZXIudHNcbnZhciBpbW1lciA9IG5ldyBJbW1lcjIoKTtcbnZhciBwcm9kdWNlID0gaW1tZXIucHJvZHVjZTtcbnZhciBwcm9kdWNlV2l0aFBhdGNoZXMgPSAvKiBAX19QVVJFX18gKi8gaW1tZXIucHJvZHVjZVdpdGhQYXRjaGVzLmJpbmQoaW1tZXIpO1xudmFyIHNldEF1dG9GcmVlemUgPSAvKiBAX19QVVJFX18gKi8gaW1tZXIuc2V0QXV0b0ZyZWV6ZS5iaW5kKGltbWVyKTtcbnZhciBzZXRVc2VTdHJpY3RTaGFsbG93Q29weSA9IC8qIEBfX1BVUkVfXyAqLyBpbW1lci5zZXRVc2VTdHJpY3RTaGFsbG93Q29weS5iaW5kKGltbWVyKTtcbnZhciBzZXRVc2VTdHJpY3RJdGVyYXRpb24gPSAvKiBAX19QVVJFX18gKi8gaW1tZXIuc2V0VXNlU3RyaWN0SXRlcmF0aW9uLmJpbmQoaW1tZXIpO1xudmFyIGFwcGx5UGF0Y2hlcyA9IC8qIEBfX1BVUkVfXyAqLyBpbW1lci5hcHBseVBhdGNoZXMuYmluZChpbW1lcik7XG52YXIgY3JlYXRlRHJhZnQgPSAvKiBAX19QVVJFX18gKi8gaW1tZXIuY3JlYXRlRHJhZnQuYmluZChpbW1lcik7XG52YXIgZmluaXNoRHJhZnQgPSAvKiBAX19QVVJFX18gKi8gaW1tZXIuZmluaXNoRHJhZnQuYmluZChpbW1lcik7XG52YXIgY2FzdERyYWZ0ID0gKHZhbHVlKSA9PiB2YWx1ZTtcbnZhciBjYXN0SW1tdXRhYmxlID0gKHZhbHVlKSA9PiB2YWx1ZTtcbmV4cG9ydCB7XG4gIEltbWVyMiBhcyBJbW1lcixcbiAgYXBwbHlQYXRjaGVzLFxuICBjYXN0RHJhZnQsXG4gIGNhc3RJbW11dGFibGUsXG4gIGNyZWF0ZURyYWZ0LFxuICBjdXJyZW50LFxuICBlbmFibGVBcnJheU1ldGhvZHMsXG4gIGVuYWJsZU1hcFNldCxcbiAgZW5hYmxlUGF0Y2hlcyxcbiAgZmluaXNoRHJhZnQsXG4gIGZyZWV6ZSxcbiAgRFJBRlRBQkxFIGFzIGltbWVyYWJsZSxcbiAgaXNEcmFmdCxcbiAgaXNEcmFmdGFibGUsXG4gIE5PVEhJTkcgYXMgbm90aGluZyxcbiAgb3JpZ2luYWwsXG4gIHByb2R1Y2UsXG4gIHByb2R1Y2VXaXRoUGF0Y2hlcyxcbiAgc2V0QXV0b0ZyZWV6ZSxcbiAgc2V0VXNlU3RyaWN0SXRlcmF0aW9uLFxuICBzZXRVc2VTdHJpY3RTaGFsbG93Q29weVxufTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWltbWVyLm1qcy5tYXAiLCIvLyBzcmMvZGV2TW9kZUNoZWNrcy9jYWNoZVNpemVDaGVjay50c1xudmFyIENBQ0hFX1NJWkVfQ0hFQ0tfVEhSRVNIT0xEID0gMWUzO1xudmFyIHJ1bkNhY2hlU2l6ZUNoZWNrID0gKGNhY2hlU2l6ZSwgZnVuY05hbWUpID0+IHtcbiAgbGV0IHN0YWNrID0gdm9pZCAwO1xuICB0cnkge1xuICAgIHRocm93IG5ldyBFcnJvcigpO1xuICB9IGNhdGNoIChlKSB7XG4gICAgO1xuICAgICh7IHN0YWNrIH0gPSBlKTtcbiAgfVxuICBjb25zb2xlLndhcm4oXG4gICAgYEEgZnVuY3Rpb24gbWVtb2l6ZWQgd2l0aCB3ZWFrTWFwTWVtb2l6ZSR7ZnVuY05hbWUgPyBgIChcXGAke2Z1bmNOYW1lfVxcYClgIDogXCJcIn0gaGFzIHNlZW4gb3ZlciAke2NhY2hlU2l6ZX0gZGlzdGluY3QgdmFsdWVzIGZvciB0aGUgc2FtZSBwcmltaXRpdmUgYXJndW1lbnQgcG9zaXRpb24uXG5SZXN1bHRzIGtleWVkIGJ5IHByaW1pdGl2ZSBhcmd1bWVudHMgYXJlIGhlbGQgc3Ryb25nbHkgYW5kIGFyZSBvbmx5IHJlbGVhc2VkIGJ5IFxcYGNsZWFyQ2FjaGUoKVxcYCwgc28gdGhpcyBjYWNoZSB3aWxsIGtlZXAgZ3Jvd2luZyBmb3IgYXMgbG9uZyBhcyB0aGUgZnVuY3Rpb24ga2VlcHMgc2VlaW5nIG5ldyB2YWx1ZXMuXG5JZiBpdCBpcyBjYWxsZWQgd2l0aCBldmVyLWNoYW5naW5nIHByaW1pdGl2ZXMgKGlkcywgb2Zmc2V0cywgdGltZXN0YW1wcyksIHBhc3MgdGhlIFxcYG1heFNpemVcXGAgb3B0aW9uIHRvIGJvdW5kIHRoZSBjYWNoZSwgc3dpdGNoIHRvIFxcYGxydU1lbW9pemVcXGAsIG9yIGNhbGwgXFxgLmNsZWFyQ2FjaGUoKVxcYCBhdCBhIHN1aXRhYmxlIHBvaW50LlxuU2VlIGh0dHBzOi8vcmVzZWxlY3QuanMub3JnL2FwaS9kZXZlbG9wbWVudC1vbmx5LWNoZWNrcyNjYWNoZXNpemVjaGVjayBmb3IgZGV0YWlscy5gLFxuICAgIHsgc3RhY2sgfVxuICApO1xufTtcblxuLy8gc3JjL2Rldk1vZGVDaGVja3Mvc2V0R2xvYmFsRGV2TW9kZUNoZWNrcy50c1xudmFyIGdsb2JhbERldk1vZGVDaGVja3MgPSB7XG4gIGlucHV0U3RhYmlsaXR5Q2hlY2s6IFwib25jZVwiLFxuICBpZGVudGl0eUZ1bmN0aW9uQ2hlY2s6IFwib25jZVwiLFxuICBjYWNoZVNpemVDaGVjazogXCJvbmNlXCJcbn07XG52YXIgc2V0R2xvYmFsRGV2TW9kZUNoZWNrcyA9IChkZXZNb2RlQ2hlY2tzKSA9PiB7XG4gIE9iamVjdC5hc3NpZ24oZ2xvYmFsRGV2TW9kZUNoZWNrcywgZGV2TW9kZUNoZWNrcyk7XG59O1xuXG4vLyBzcmMvd2Vha01hcE1lbW9pemUudHNcbnZhciBTdHJvbmdSZWYgPSBjbGFzcyB7XG4gIGNvbnN0cnVjdG9yKHZhbHVlKSB7XG4gICAgdGhpcy52YWx1ZSA9IHZhbHVlO1xuICB9XG4gIGRlcmVmKCkge1xuICAgIHJldHVybiB0aGlzLnZhbHVlO1xuICB9XG59O1xudmFyIGdldFdlYWtSZWYgPSAoKSA9PiB0eXBlb2YgV2Vha1JlZiA9PT0gXCJ1bmRlZmluZWRcIiA/IFN0cm9uZ1JlZiA6IFdlYWtSZWY7XG52YXIgUmVmID0gLyogQF9fUFVSRV9fICovIGdldFdlYWtSZWYoKTtcbnZhciBVTlRFUk1JTkFURUQgPSAwO1xudmFyIFRFUk1JTkFURUQgPSAxO1xuZnVuY3Rpb24gY3JlYXRlQ2FjaGVOb2RlKCkge1xuICByZXR1cm4ge1xuICAgIHM6IFVOVEVSTUlOQVRFRCxcbiAgICB2OiB2b2lkIDAsXG4gICAgbzogbnVsbCxcbiAgICBwOiBudWxsXG4gIH07XG59XG5mdW5jdGlvbiBtYXliZURlcmVmKHIpIHtcbiAgaWYgKHIgaW5zdGFuY2VvZiBSZWYpIHtcbiAgICByZXR1cm4gci5kZXJlZigpO1xuICB9XG4gIHJldHVybiByO1xufVxuZnVuY3Rpb24gd2Vha01hcE1lbW9pemUoZnVuYywgb3B0aW9ucyA9IHt9KSB7XG4gIGxldCBmbk5vZGUgPSBjcmVhdGVDYWNoZU5vZGUoKTtcbiAgY29uc3QgeyByZXN1bHRFcXVhbGl0eUNoZWNrLCBtYXhTaXplIH0gPSBvcHRpb25zO1xuICBjb25zdCB1c2VHZW5lcmF0aW9ucyA9IG1heFNpemUgIT09IHZvaWQgMDtcbiAgaWYgKHVzZUdlbmVyYXRpb25zICYmICghTnVtYmVyLmlzSW50ZWdlcihtYXhTaXplKSB8fCBtYXhTaXplIDwgMSkpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgYG1heFNpemUgbXVzdCBiZSBhIHBvc2l0aXZlIGludGVnZXIsIHJlY2VpdmVkOiAke21heFNpemV9YFxuICAgICk7XG4gIH1cbiAgbGV0IHByZXZOb2RlID0gbnVsbDtcbiAgbGV0IGluc2VydGlvbkNvdW50ID0gMDtcbiAgbGV0IGxhc3RSZXN1bHQ7XG4gIGxldCByZXN1bHRzQ291bnQgPSAwO1xuICBsZXQgaGFzV2FybmVkQWJvdXRDYWNoZVNpemUgPSBmYWxzZTtcbiAgZnVuY3Rpb24gbWF5YmVGbGlwR2VuZXJhdGlvbnMoKSB7XG4gICAgaWYgKGluc2VydGlvbkNvdW50ID49IG1heFNpemUpIHtcbiAgICAgIHByZXZOb2RlID0gZm5Ob2RlO1xuICAgICAgZm5Ob2RlID0gY3JlYXRlQ2FjaGVOb2RlKCk7XG4gICAgICBpbnNlcnRpb25Db3VudCA9IDA7XG4gICAgfVxuICB9XG4gIGZ1bmN0aW9uIG1lbW9pemVkKCkge1xuICAgIGxldCBjYWNoZU5vZGUgPSBmbk5vZGU7XG4gICAgY29uc3QgeyBsZW5ndGggfSA9IGFyZ3VtZW50cztcbiAgICBmb3IgKGxldCBpID0gMCwgbCA9IGxlbmd0aDsgaSA8IGw7IGkrKykge1xuICAgICAgY29uc3QgYXJnID0gYXJndW1lbnRzW2ldO1xuICAgICAgaWYgKHR5cGVvZiBhcmcgPT09IFwiZnVuY3Rpb25cIiB8fCB0eXBlb2YgYXJnID09PSBcIm9iamVjdFwiICYmIGFyZyAhPT0gbnVsbCkge1xuICAgICAgICBsZXQgb2JqZWN0Q2FjaGUgPSBjYWNoZU5vZGUubztcbiAgICAgICAgaWYgKG9iamVjdENhY2hlID09PSBudWxsKSB7XG4gICAgICAgICAgY2FjaGVOb2RlLm8gPSBvYmplY3RDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG9iamVjdE5vZGUgPSBvYmplY3RDYWNoZS5nZXQoYXJnKTtcbiAgICAgICAgaWYgKG9iamVjdE5vZGUgPT09IHZvaWQgMCkge1xuICAgICAgICAgIGNhY2hlTm9kZSA9IGNyZWF0ZUNhY2hlTm9kZSgpO1xuICAgICAgICAgIG9iamVjdENhY2hlLnNldChhcmcsIGNhY2hlTm9kZSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2FjaGVOb2RlID0gb2JqZWN0Tm9kZTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbGV0IHByaW1pdGl2ZUNhY2hlID0gY2FjaGVOb2RlLnA7XG4gICAgICAgIGlmIChwcmltaXRpdmVDYWNoZSA9PT0gbnVsbCkge1xuICAgICAgICAgIGNhY2hlTm9kZS5wID0gcHJpbWl0aXZlQ2FjaGUgPSAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHByaW1pdGl2ZU5vZGUgPSBwcmltaXRpdmVDYWNoZS5nZXQoYXJnKTtcbiAgICAgICAgaWYgKHByaW1pdGl2ZU5vZGUgPT09IHZvaWQgMCkge1xuICAgICAgICAgIGNhY2hlTm9kZSA9IGNyZWF0ZUNhY2hlTm9kZSgpO1xuICAgICAgICAgIHByaW1pdGl2ZUNhY2hlLnNldChhcmcsIGNhY2hlTm9kZSk7XG4gICAgICAgICAgaW5zZXJ0aW9uQ291bnQrKztcbiAgICAgICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICAgICAgICBpZiAocHJpbWl0aXZlQ2FjaGUuc2l6ZSA+IENBQ0hFX1NJWkVfQ0hFQ0tfVEhSRVNIT0xEKSB7XG4gICAgICAgICAgICAgIGNvbnN0IHsgY2FjaGVTaXplQ2hlY2sgfSA9IGdsb2JhbERldk1vZGVDaGVja3M7XG4gICAgICAgICAgICAgIGlmIChjYWNoZVNpemVDaGVjayA9PT0gXCJhbHdheXNcIiB8fCBjYWNoZVNpemVDaGVjayA9PT0gXCJvbmNlXCIgJiYgIWhhc1dhcm5lZEFib3V0Q2FjaGVTaXplKSB7XG4gICAgICAgICAgICAgICAgaGFzV2FybmVkQWJvdXRDYWNoZVNpemUgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHJ1bkNhY2hlU2l6ZUNoZWNrKHByaW1pdGl2ZUNhY2hlLnNpemUsIGZ1bmMubmFtZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgY2FjaGVOb2RlID0gcHJpbWl0aXZlTm9kZTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBpZiAoY2FjaGVOb2RlLnMgPT09IFRFUk1JTkFURUQpIHtcbiAgICAgIHJldHVybiBjYWNoZU5vZGUudjtcbiAgICB9XG4gICAgaWYgKHByZXZOb2RlICE9PSBudWxsKSB7XG4gICAgICBsZXQgcHJldkNhY2hlTm9kZSA9IHByZXZOb2RlO1xuICAgICAgZm9yIChsZXQgaSA9IDAsIGwgPSBsZW5ndGg7IGkgPCBsOyBpKyspIHtcbiAgICAgICAgY29uc3QgYXJnID0gYXJndW1lbnRzW2ldO1xuICAgICAgICBsZXQgbmV4dDtcbiAgICAgICAgaWYgKHR5cGVvZiBhcmcgPT09IFwiZnVuY3Rpb25cIiB8fCB0eXBlb2YgYXJnID09PSBcIm9iamVjdFwiICYmIGFyZyAhPT0gbnVsbCkge1xuICAgICAgICAgIGNvbnN0IHByZXZPYmplY3RDYWNoZSA9IHByZXZDYWNoZU5vZGUubztcbiAgICAgICAgICBuZXh0ID0gcHJldk9iamVjdENhY2hlICE9PSBudWxsID8gcHJldk9iamVjdENhY2hlLmdldChhcmcpIDogdm9pZCAwO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnN0IHByZXZQcmltaXRpdmVDYWNoZSA9IHByZXZDYWNoZU5vZGUucDtcbiAgICAgICAgICBuZXh0ID0gcHJldlByaW1pdGl2ZUNhY2hlICE9PSBudWxsID8gcHJldlByaW1pdGl2ZUNhY2hlLmdldChhcmcpIDogdm9pZCAwO1xuICAgICAgICB9XG4gICAgICAgIGlmIChuZXh0ID09PSB2b2lkIDApIHtcbiAgICAgICAgICBwcmV2Q2FjaGVOb2RlID0gbnVsbDtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBwcmV2Q2FjaGVOb2RlID0gbmV4dDtcbiAgICAgIH1cbiAgICAgIGlmIChwcmV2Q2FjaGVOb2RlICE9PSBudWxsICYmIHByZXZDYWNoZU5vZGUucyA9PT0gVEVSTUlOQVRFRCkge1xuICAgICAgICBjb25zdCBwcm9tb3RlZE5vZGUgPSBjYWNoZU5vZGU7XG4gICAgICAgIHByb21vdGVkTm9kZS5zID0gVEVSTUlOQVRFRDtcbiAgICAgICAgcHJvbW90ZWROb2RlLnYgPSBwcmV2Q2FjaGVOb2RlLnY7XG4gICAgICAgIG1heWJlRmxpcEdlbmVyYXRpb25zKCk7XG4gICAgICAgIHJldHVybiBwcmV2Q2FjaGVOb2RlLnY7XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IHRlcm1pbmF0ZWROb2RlID0gY2FjaGVOb2RlO1xuICAgIGxldCByZXN1bHQgPSBmdW5jLmFwcGx5KG51bGwsIGFyZ3VtZW50cyk7XG4gICAgcmVzdWx0c0NvdW50Kys7XG4gICAgaWYgKHJlc3VsdEVxdWFsaXR5Q2hlY2spIHtcbiAgICAgIGNvbnN0IGxhc3RSZXN1bHRWYWx1ZSA9IG1heWJlRGVyZWYobGFzdFJlc3VsdCk7XG4gICAgICBpZiAobGFzdFJlc3VsdFZhbHVlICE9IG51bGwgJiYgcmVzdWx0RXF1YWxpdHlDaGVjayhsYXN0UmVzdWx0VmFsdWUsIHJlc3VsdCkpIHtcbiAgICAgICAgcmVzdWx0ID0gbGFzdFJlc3VsdFZhbHVlO1xuICAgICAgICByZXN1bHRzQ291bnQgIT09IDAgJiYgcmVzdWx0c0NvdW50LS07XG4gICAgICB9XG4gICAgICBjb25zdCBuZWVkc1dlYWtSZWYgPSB0eXBlb2YgcmVzdWx0ID09PSBcIm9iamVjdFwiICYmIHJlc3VsdCAhPT0gbnVsbCB8fCB0eXBlb2YgcmVzdWx0ID09PSBcImZ1bmN0aW9uXCI7XG4gICAgICBsYXN0UmVzdWx0ID0gbmVlZHNXZWFrUmVmID8gLyogQF9fUFVSRV9fICovIG5ldyBSZWYocmVzdWx0KSA6IHJlc3VsdDtcbiAgICB9XG4gICAgdGVybWluYXRlZE5vZGUucyA9IFRFUk1JTkFURUQ7XG4gICAgdGVybWluYXRlZE5vZGUudiA9IHJlc3VsdDtcbiAgICBpZiAodXNlR2VuZXJhdGlvbnMpIHtcbiAgICAgIG1heWJlRmxpcEdlbmVyYXRpb25zKCk7XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbiAgbWVtb2l6ZWQuY2xlYXJDYWNoZSA9ICgpID0+IHtcbiAgICBmbk5vZGUgPSBjcmVhdGVDYWNoZU5vZGUoKTtcbiAgICBwcmV2Tm9kZSA9IG51bGw7XG4gICAgaW5zZXJ0aW9uQ291bnQgPSAwO1xuICAgIG1lbW9pemVkLnJlc2V0UmVzdWx0c0NvdW50KCk7XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuICAgICAgaGFzV2FybmVkQWJvdXRDYWNoZVNpemUgPSBmYWxzZTtcbiAgICB9XG4gIH07XG4gIG1lbW9pemVkLnJlc3VsdHNDb3VudCA9ICgpID0+IHJlc3VsdHNDb3VudDtcbiAgbWVtb2l6ZWQucmVzZXRSZXN1bHRzQ291bnQgPSAoKSA9PiB7XG4gICAgcmVzdWx0c0NvdW50ID0gMDtcbiAgfTtcbiAgcmV0dXJuIG1lbW9pemVkO1xufVxuXG4vLyBzcmMvZGV2TW9kZUNoZWNrcy9pZGVudGl0eUZ1bmN0aW9uQ2hlY2sudHNcbnZhciBydW5JZGVudGl0eUZ1bmN0aW9uQ2hlY2sgPSAocmVzdWx0RnVuYywgaW5wdXRTZWxlY3RvcnNSZXN1bHRzLCBvdXRwdXRTZWxlY3RvclJlc3VsdCkgPT4ge1xuICBpZiAoaW5wdXRTZWxlY3RvcnNSZXN1bHRzLmxlbmd0aCA9PT0gMSAmJiBpbnB1dFNlbGVjdG9yc1Jlc3VsdHNbMF0gPT09IG91dHB1dFNlbGVjdG9yUmVzdWx0KSB7XG4gICAgbGV0IGlzSW5wdXRTYW1lQXNPdXRwdXQgPSBmYWxzZTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgZW1wdHlPYmplY3QgPSB7fTtcbiAgICAgIGlmIChyZXN1bHRGdW5jKGVtcHR5T2JqZWN0KSA9PT0gZW1wdHlPYmplY3QpIGlzSW5wdXRTYW1lQXNPdXRwdXQgPSB0cnVlO1xuICAgIH0gY2F0Y2gge1xuICAgIH1cbiAgICBpZiAoaXNJbnB1dFNhbWVBc091dHB1dCkge1xuICAgICAgbGV0IHN0YWNrID0gdm9pZCAwO1xuICAgICAgdHJ5IHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCk7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIDtcbiAgICAgICAgKHsgc3RhY2sgfSA9IGUpO1xuICAgICAgfVxuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBcIlRoZSByZXN1bHQgZnVuY3Rpb24gcmV0dXJuZWQgaXRzIG93biBpbnB1dHMgd2l0aG91dCBtb2RpZmljYXRpb24uIGUuZ1xcbmBjcmVhdGVTZWxlY3Rvcihbc3RhdGUgPT4gc3RhdGUudG9kb3NdLCB0b2RvcyA9PiB0b2RvcylgXFxuVGhpcyBjb3VsZCBsZWFkIHRvIGluZWZmaWNpZW50IG1lbW9pemF0aW9uIGFuZCB1bm5lY2Vzc2FyeSByZS1yZW5kZXJzLlxcbkVuc3VyZSB0cmFuc2Zvcm1hdGlvbiBsb2dpYyBpcyBpbiB0aGUgcmVzdWx0IGZ1bmN0aW9uLCBhbmQgZXh0cmFjdGlvbiBsb2dpYyBpcyBpbiB0aGUgaW5wdXQgc2VsZWN0b3JzLlwiLFxuICAgICAgICB7IHN0YWNrIH1cbiAgICAgICk7XG4gICAgfVxuICB9XG59O1xuXG4vLyBzcmMvZGV2TW9kZUNoZWNrcy9pbnB1dFN0YWJpbGl0eUNoZWNrLnRzXG52YXIgd2l0aG91dFJlc3VsdEVxdWFsaXR5Q2hlY2sgPSAob3B0aW9uKSA9PiB7XG4gIGlmIChvcHRpb24gPT09IG51bGwgfHwgdHlwZW9mIG9wdGlvbiAhPT0gXCJvYmplY3RcIiB8fCAhKFwicmVzdWx0RXF1YWxpdHlDaGVja1wiIGluIG9wdGlvbikpIHtcbiAgICByZXR1cm4gb3B0aW9uO1xuICB9XG4gIGNvbnN0IG9wdGlvbkNvcHkgPSB7IC4uLm9wdGlvbiB9O1xuICBkZWxldGUgb3B0aW9uQ29weS5yZXN1bHRFcXVhbGl0eUNoZWNrO1xuICByZXR1cm4gb3B0aW9uQ29weTtcbn07XG52YXIgcnVuSW5wdXRTdGFiaWxpdHlDaGVjayA9IChpbnB1dFNlbGVjdG9yUmVzdWx0c09iamVjdCwgb3B0aW9ucywgaW5wdXRTZWxlY3RvckFyZ3MpID0+IHtcbiAgY29uc3QgeyBtZW1vaXplLCBtZW1vaXplT3B0aW9ucyB9ID0gb3B0aW9ucztcbiAgY29uc3QgeyBpbnB1dFNlbGVjdG9yUmVzdWx0cywgaW5wdXRTZWxlY3RvclJlc3VsdHNDb3B5IH0gPSBpbnB1dFNlbGVjdG9yUmVzdWx0c09iamVjdDtcbiAgY29uc3QgcHJvYmVNZW1vaXplT3B0aW9ucyA9IFtdO1xuICBjb25zdCB7IGxlbmd0aCB9ID0gbWVtb2l6ZU9wdGlvbnM7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgbGVuZ3RoOyBpKyspIHtcbiAgICBwcm9iZU1lbW9pemVPcHRpb25zLnB1c2god2l0aG91dFJlc3VsdEVxdWFsaXR5Q2hlY2sobWVtb2l6ZU9wdGlvbnNbaV0pKTtcbiAgfVxuICBjb25zdCBjcmVhdGVBbkVtcHR5T2JqZWN0ID0gbWVtb2l6ZSgoKSA9PiAoe30pLCAuLi5wcm9iZU1lbW9pemVPcHRpb25zKTtcbiAgY29uc3QgYXJlSW5wdXRTZWxlY3RvclJlc3VsdHNFcXVhbCA9IGNyZWF0ZUFuRW1wdHlPYmplY3QuYXBwbHkobnVsbCwgaW5wdXRTZWxlY3RvclJlc3VsdHMpID09PSBjcmVhdGVBbkVtcHR5T2JqZWN0LmFwcGx5KG51bGwsIGlucHV0U2VsZWN0b3JSZXN1bHRzQ29weSk7XG4gIGlmICghYXJlSW5wdXRTZWxlY3RvclJlc3VsdHNFcXVhbCkge1xuICAgIGxldCBzdGFjayA9IHZvaWQgMDtcbiAgICB0cnkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCk7XG4gICAgfSBjYXRjaCAoZSkge1xuICAgICAgO1xuICAgICAgKHsgc3RhY2sgfSA9IGUpO1xuICAgIH1cbiAgICBjb25zb2xlLndhcm4oXG4gICAgICBcIkFuIGlucHV0IHNlbGVjdG9yIHJldHVybmVkIGEgZGlmZmVyZW50IHJlc3VsdCB3aGVuIHBhc3NlZCBzYW1lIGFyZ3VtZW50cy5cXG5UaGlzIG1lYW5zIHlvdXIgb3V0cHV0IHNlbGVjdG9yIHdpbGwgbGlrZWx5IHJ1biBtb3JlIGZyZXF1ZW50bHkgdGhhbiBpbnRlbmRlZC5cXG5Bdm9pZCByZXR1cm5pbmcgYSBuZXcgcmVmZXJlbmNlIGluc2lkZSB5b3VyIGlucHV0IHNlbGVjdG9yLCBlLmcuXFxuYGNyZWF0ZVNlbGVjdG9yKFtzdGF0ZSA9PiBzdGF0ZS50b2Rvcy5tYXAodG9kbyA9PiB0b2RvLmlkKV0sIHRvZG9JZHMgPT4gdG9kb0lkcy5sZW5ndGgpYFwiLFxuICAgICAge1xuICAgICAgICBhcmd1bWVudHM6IGlucHV0U2VsZWN0b3JBcmdzLFxuICAgICAgICBmaXJzdElucHV0czogaW5wdXRTZWxlY3RvclJlc3VsdHMsXG4gICAgICAgIHNlY29uZElucHV0czogaW5wdXRTZWxlY3RvclJlc3VsdHNDb3B5LFxuICAgICAgICBzdGFja1xuICAgICAgfVxuICAgICk7XG4gIH1cbn07XG5cbi8vIHNyYy91dGlscy50c1xudmFyIE5PVF9GT1VORCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2woXCJOT1RfRk9VTkRcIik7XG5mdW5jdGlvbiBhc3NlcnRJc0Z1bmN0aW9uKGZ1bmMsIGVycm9yTWVzc2FnZSA9IGBleHBlY3RlZCBhIGZ1bmN0aW9uLCBpbnN0ZWFkIHJlY2VpdmVkICR7dHlwZW9mIGZ1bmN9YCkge1xuICBpZiAodHlwZW9mIGZ1bmMgIT09IFwiZnVuY3Rpb25cIikge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoZXJyb3JNZXNzYWdlKTtcbiAgfVxufVxuZnVuY3Rpb24gYXNzZXJ0SXNPYmplY3Qob2JqZWN0LCBlcnJvck1lc3NhZ2UgPSBgZXhwZWN0ZWQgYW4gb2JqZWN0LCBpbnN0ZWFkIHJlY2VpdmVkICR7dHlwZW9mIG9iamVjdH1gKSB7XG4gIGlmICh0eXBlb2Ygb2JqZWN0ICE9PSBcIm9iamVjdFwiKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihlcnJvck1lc3NhZ2UpO1xuICB9XG59XG5mdW5jdGlvbiBhc3NlcnRJc0FycmF5T2ZGdW5jdGlvbnMoYXJyYXksIGVycm9yTWVzc2FnZSA9IGBleHBlY3RlZCBhbGwgaXRlbXMgdG8gYmUgZnVuY3Rpb25zLCBpbnN0ZWFkIHJlY2VpdmVkIHRoZSBmb2xsb3dpbmcgdHlwZXM6IGApIHtcbiAgaWYgKCFhcnJheS5ldmVyeSgoaXRlbSkgPT4gdHlwZW9mIGl0ZW0gPT09IFwiZnVuY3Rpb25cIikpIHtcbiAgICBjb25zdCBpdGVtVHlwZXMgPSBhcnJheS5tYXAoXG4gICAgICAoaXRlbSkgPT4gdHlwZW9mIGl0ZW0gPT09IFwiZnVuY3Rpb25cIiA/IGBmdW5jdGlvbiAke2l0ZW0ubmFtZSB8fCBcInVubmFtZWRcIn0oKWAgOiB0eXBlb2YgaXRlbVxuICAgICkuam9pbihcIiwgXCIpO1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYCR7ZXJyb3JNZXNzYWdlfVske2l0ZW1UeXBlc31dYCk7XG4gIH1cbn1cbnZhciBlbnN1cmVJc0FycmF5ID0gKGl0ZW0pID0+IHtcbiAgcmV0dXJuIEFycmF5LmlzQXJyYXkoaXRlbSkgPyBpdGVtIDogW2l0ZW1dO1xufTtcbmZ1bmN0aW9uIGdldERlcGVuZGVuY2llcyhjcmVhdGVTZWxlY3RvckFyZ3MpIHtcbiAgY29uc3QgZGVwZW5kZW5jaWVzID0gQXJyYXkuaXNBcnJheShjcmVhdGVTZWxlY3RvckFyZ3NbMF0pID8gY3JlYXRlU2VsZWN0b3JBcmdzWzBdIDogY3JlYXRlU2VsZWN0b3JBcmdzO1xuICBhc3NlcnRJc0FycmF5T2ZGdW5jdGlvbnMoXG4gICAgZGVwZW5kZW5jaWVzLFxuICAgIGBjcmVhdGVTZWxlY3RvciBleHBlY3RzIGFsbCBpbnB1dC1zZWxlY3RvcnMgdG8gYmUgZnVuY3Rpb25zLCBidXQgcmVjZWl2ZWQgdGhlIGZvbGxvd2luZyB0eXBlczogYFxuICApO1xuICByZXR1cm4gZGVwZW5kZW5jaWVzO1xufVxuZnVuY3Rpb24gY29sbGVjdElucHV0U2VsZWN0b3JSZXN1bHRzKGRlcGVuZGVuY2llcywgaW5wdXRTZWxlY3RvckFyZ3MpIHtcbiAgY29uc3QgaW5wdXRTZWxlY3RvclJlc3VsdHMgPSBbXTtcbiAgY29uc3QgeyBsZW5ndGggfSA9IGRlcGVuZGVuY2llcztcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgIGlucHV0U2VsZWN0b3JSZXN1bHRzLnB1c2goZGVwZW5kZW5jaWVzW2ldLmFwcGx5KG51bGwsIGlucHV0U2VsZWN0b3JBcmdzKSk7XG4gIH1cbiAgcmV0dXJuIGlucHV0U2VsZWN0b3JSZXN1bHRzO1xufVxuXG4vLyBzcmMvY3JlYXRlU2VsZWN0b3JDcmVhdG9yLnRzXG5mdW5jdGlvbiBjcmVhdGVTZWxlY3RvckNyZWF0b3IobWVtb2l6ZU9yT3B0aW9ucywgLi4ubWVtb2l6ZU9wdGlvbnNGcm9tQXJncykge1xuICBjb25zdCBjcmVhdGVTZWxlY3RvckNyZWF0b3JPcHRpb25zID0gdHlwZW9mIG1lbW9pemVPck9wdGlvbnMgPT09IFwiZnVuY3Rpb25cIiA/IHtcbiAgICBtZW1vaXplOiBtZW1vaXplT3JPcHRpb25zLFxuICAgIG1lbW9pemVPcHRpb25zOiBtZW1vaXplT3B0aW9uc0Zyb21BcmdzXG4gIH0gOiBtZW1vaXplT3JPcHRpb25zO1xuICBjb25zdCBjcmVhdGVTZWxlY3RvcjIgPSAoLi4uY3JlYXRlU2VsZWN0b3JBcmdzKSA9PiB7XG4gICAgbGV0IHJlY29tcHV0YXRpb25zID0gMDtcbiAgICBsZXQgZGVwZW5kZW5jeVJlY29tcHV0YXRpb25zID0gMDtcbiAgICBsZXQgbGFzdFJlc3VsdDtcbiAgICBsZXQgZGlyZWN0bHlQYXNzZWRPcHRpb25zID0ge307XG4gICAgbGV0IHJlc3VsdEZ1bmMgPSBjcmVhdGVTZWxlY3RvckFyZ3MucG9wKCk7XG4gICAgaWYgKHR5cGVvZiByZXN1bHRGdW5jID09PSBcIm9iamVjdFwiKSB7XG4gICAgICBkaXJlY3RseVBhc3NlZE9wdGlvbnMgPSByZXN1bHRGdW5jO1xuICAgICAgcmVzdWx0RnVuYyA9IGNyZWF0ZVNlbGVjdG9yQXJncy5wb3AoKTtcbiAgICB9XG4gICAgYXNzZXJ0SXNGdW5jdGlvbihcbiAgICAgIHJlc3VsdEZ1bmMsXG4gICAgICBgY3JlYXRlU2VsZWN0b3IgZXhwZWN0cyBhbiBvdXRwdXQgZnVuY3Rpb24gYWZ0ZXIgdGhlIGlucHV0cywgYnV0IHJlY2VpdmVkOiBbJHt0eXBlb2YgcmVzdWx0RnVuY31dYFxuICAgICk7XG4gICAgY29uc3QgY29tYmluZWRPcHRpb25zID0ge1xuICAgICAgLi4uY3JlYXRlU2VsZWN0b3JDcmVhdG9yT3B0aW9ucyxcbiAgICAgIC4uLmRpcmVjdGx5UGFzc2VkT3B0aW9uc1xuICAgIH07XG4gICAgY29uc3Qge1xuICAgICAgbWVtb2l6ZSxcbiAgICAgIG1lbW9pemVPcHRpb25zID0gW10sXG4gICAgICBhcmdzTWVtb2l6ZSA9IHdlYWtNYXBNZW1vaXplLFxuICAgICAgYXJnc01lbW9pemVPcHRpb25zID0gW11cbiAgICB9ID0gY29tYmluZWRPcHRpb25zO1xuICAgIGNvbnN0IGZpbmFsTWVtb2l6ZU9wdGlvbnMgPSBlbnN1cmVJc0FycmF5KG1lbW9pemVPcHRpb25zKTtcbiAgICBjb25zdCBmaW5hbEFyZ3NNZW1vaXplT3B0aW9ucyA9IGVuc3VyZUlzQXJyYXkoYXJnc01lbW9pemVPcHRpb25zKTtcbiAgICBjb25zdCBkZXBlbmRlbmNpZXMgPSBnZXREZXBlbmRlbmNpZXMoY3JlYXRlU2VsZWN0b3JBcmdzKTtcbiAgICBjb25zdCBtZW1vaXplZFJlc3VsdEZ1bmMgPSBtZW1vaXplKGZ1bmN0aW9uIHJlY29tcHV0YXRpb25XcmFwcGVyKCkge1xuICAgICAgcmVjb21wdXRhdGlvbnMrKztcbiAgICAgIHJldHVybiByZXN1bHRGdW5jLmFwcGx5KFxuICAgICAgICBudWxsLFxuICAgICAgICBhcmd1bWVudHNcbiAgICAgICk7XG4gICAgfSwgLi4uZmluYWxNZW1vaXplT3B0aW9ucyk7XG4gICAgbGV0IGZpcnN0UnVuID0gdHJ1ZTtcbiAgICBjb25zdCBzZWxlY3RvciA9IGFyZ3NNZW1vaXplKGZ1bmN0aW9uIGRlcGVuZGVuY2llc0NoZWNrZXIoKSB7XG4gICAgICBkZXBlbmRlbmN5UmVjb21wdXRhdGlvbnMrKztcbiAgICAgIGNvbnN0IHsgbGVuZ3RoIH0gPSBkZXBlbmRlbmNpZXM7XG4gICAgICBjb25zdCBpbnB1dFNlbGVjdG9yUmVzdWx0cyA9IG5ldyBBcnJheShsZW5ndGgpO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgICBpbnB1dFNlbGVjdG9yUmVzdWx0c1tpXSA9IGRlcGVuZGVuY2llc1tpXS5hcHBseShudWxsLCBhcmd1bWVudHMpO1xuICAgICAgfVxuICAgICAgbGFzdFJlc3VsdCA9IG1lbW9pemVkUmVzdWx0RnVuYy5hcHBseShudWxsLCBpbnB1dFNlbGVjdG9yUmVzdWx0cyk7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG4gICAgICAgIGNvbnN0IHsgZGV2TW9kZUNoZWNrcyB9ID0gY29tYmluZWRPcHRpb25zO1xuICAgICAgICBjb25zdCBpZGVudGl0eUZ1bmN0aW9uQ2hlY2sgPSBkZXZNb2RlQ2hlY2tzICE9PSB2b2lkIDAgJiYgT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKFxuICAgICAgICAgIGRldk1vZGVDaGVja3MsXG4gICAgICAgICAgXCJpZGVudGl0eUZ1bmN0aW9uQ2hlY2tcIlxuICAgICAgICApID8gZGV2TW9kZUNoZWNrcy5pZGVudGl0eUZ1bmN0aW9uQ2hlY2sgOiBnbG9iYWxEZXZNb2RlQ2hlY2tzLmlkZW50aXR5RnVuY3Rpb25DaGVjaztcbiAgICAgICAgY29uc3QgaW5wdXRTdGFiaWxpdHlDaGVjayA9IGRldk1vZGVDaGVja3MgIT09IHZvaWQgMCAmJiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoXG4gICAgICAgICAgZGV2TW9kZUNoZWNrcyxcbiAgICAgICAgICBcImlucHV0U3RhYmlsaXR5Q2hlY2tcIlxuICAgICAgICApID8gZGV2TW9kZUNoZWNrcy5pbnB1dFN0YWJpbGl0eUNoZWNrIDogZ2xvYmFsRGV2TW9kZUNoZWNrcy5pbnB1dFN0YWJpbGl0eUNoZWNrO1xuICAgICAgICBpZiAoaWRlbnRpdHlGdW5jdGlvbkNoZWNrID09PSBcImFsd2F5c1wiIHx8IGlkZW50aXR5RnVuY3Rpb25DaGVjayA9PT0gXCJvbmNlXCIgJiYgZmlyc3RSdW4pIHtcbiAgICAgICAgICBydW5JZGVudGl0eUZ1bmN0aW9uQ2hlY2soXG4gICAgICAgICAgICByZXN1bHRGdW5jLFxuICAgICAgICAgICAgaW5wdXRTZWxlY3RvclJlc3VsdHMsXG4gICAgICAgICAgICBsYXN0UmVzdWx0XG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5wdXRTdGFiaWxpdHlDaGVjayA9PT0gXCJhbHdheXNcIiB8fCBpbnB1dFN0YWJpbGl0eUNoZWNrID09PSBcIm9uY2VcIiAmJiBmaXJzdFJ1bikge1xuICAgICAgICAgIGNvbnN0IGlucHV0U2VsZWN0b3JSZXN1bHRzQ29weSA9IGNvbGxlY3RJbnB1dFNlbGVjdG9yUmVzdWx0cyhcbiAgICAgICAgICAgIGRlcGVuZGVuY2llcyxcbiAgICAgICAgICAgIGFyZ3VtZW50c1xuICAgICAgICAgICk7XG4gICAgICAgICAgcnVuSW5wdXRTdGFiaWxpdHlDaGVjayhcbiAgICAgICAgICAgIHsgaW5wdXRTZWxlY3RvclJlc3VsdHMsIGlucHV0U2VsZWN0b3JSZXN1bHRzQ29weSB9LFxuICAgICAgICAgICAgeyBtZW1vaXplLCBtZW1vaXplT3B0aW9uczogZmluYWxNZW1vaXplT3B0aW9ucyB9LFxuICAgICAgICAgICAgYXJndW1lbnRzXG4gICAgICAgICAgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZmlyc3RSdW4pIGZpcnN0UnVuID0gZmFsc2U7XG4gICAgICB9XG4gICAgICByZXR1cm4gbGFzdFJlc3VsdDtcbiAgICB9LCAuLi5maW5hbEFyZ3NNZW1vaXplT3B0aW9ucyk7XG4gICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oc2VsZWN0b3IsIHtcbiAgICAgIHJlc3VsdEZ1bmMsXG4gICAgICBtZW1vaXplZFJlc3VsdEZ1bmMsXG4gICAgICBkZXBlbmRlbmNpZXMsXG4gICAgICBkZXBlbmRlbmN5UmVjb21wdXRhdGlvbnM6ICgpID0+IGRlcGVuZGVuY3lSZWNvbXB1dGF0aW9ucyxcbiAgICAgIHJlc2V0RGVwZW5kZW5jeVJlY29tcHV0YXRpb25zOiAoKSA9PiB7XG4gICAgICAgIGRlcGVuZGVuY3lSZWNvbXB1dGF0aW9ucyA9IDA7XG4gICAgICB9LFxuICAgICAgbGFzdFJlc3VsdDogKCkgPT4gbGFzdFJlc3VsdCxcbiAgICAgIHJlY29tcHV0YXRpb25zOiAoKSA9PiByZWNvbXB1dGF0aW9ucyxcbiAgICAgIHJlc2V0UmVjb21wdXRhdGlvbnM6ICgpID0+IHtcbiAgICAgICAgcmVjb21wdXRhdGlvbnMgPSAwO1xuICAgICAgfSxcbiAgICAgIG1lbW9pemUsXG4gICAgICBhcmdzTWVtb2l6ZVxuICAgIH0pO1xuICB9O1xuICBPYmplY3QuYXNzaWduKGNyZWF0ZVNlbGVjdG9yMiwge1xuICAgIHdpdGhUeXBlczogKCkgPT4gY3JlYXRlU2VsZWN0b3IyXG4gIH0pO1xuICByZXR1cm4gY3JlYXRlU2VsZWN0b3IyO1xufVxudmFyIGNyZWF0ZVNlbGVjdG9yID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZVNlbGVjdG9yQ3JlYXRvcih3ZWFrTWFwTWVtb2l6ZSk7XG5cbi8vIHNyYy9jcmVhdGVTdHJ1Y3R1cmVkU2VsZWN0b3IudHNcbnZhciBjcmVhdGVTdHJ1Y3R1cmVkU2VsZWN0b3IgPSAvKiBAX19QVVJFX18gKi8gT2JqZWN0LmFzc2lnbihcbiAgKGlucHV0U2VsZWN0b3JzT2JqZWN0LCBzZWxlY3RvckNyZWF0b3IgPSBjcmVhdGVTZWxlY3RvcikgPT4ge1xuICAgIGFzc2VydElzT2JqZWN0KFxuICAgICAgaW5wdXRTZWxlY3RvcnNPYmplY3QsXG4gICAgICBgY3JlYXRlU3RydWN0dXJlZFNlbGVjdG9yIGV4cGVjdHMgZmlyc3QgYXJndW1lbnQgdG8gYmUgYW4gb2JqZWN0IHdoZXJlIGVhY2ggcHJvcGVydHkgaXMgYSBzZWxlY3RvciwgaW5zdGVhZCByZWNlaXZlZCBhICR7dHlwZW9mIGlucHV0U2VsZWN0b3JzT2JqZWN0fWBcbiAgICApO1xuICAgIGNvbnN0IGlucHV0U2VsZWN0b3JLZXlzID0gT2JqZWN0LmtleXMoaW5wdXRTZWxlY3RvcnNPYmplY3QpO1xuICAgIGNvbnN0IGRlcGVuZGVuY2llcyA9IGlucHV0U2VsZWN0b3JLZXlzLm1hcChcbiAgICAgIChrZXkpID0+IGlucHV0U2VsZWN0b3JzT2JqZWN0W2tleV1cbiAgICApO1xuICAgIGNvbnN0IHN0cnVjdHVyZWRTZWxlY3RvciA9IHNlbGVjdG9yQ3JlYXRvcihcbiAgICAgIGRlcGVuZGVuY2llcyxcbiAgICAgICguLi5pbnB1dFNlbGVjdG9yUmVzdWx0cykgPT4ge1xuICAgICAgICByZXR1cm4gaW5wdXRTZWxlY3RvclJlc3VsdHMucmVkdWNlKChjb21wb3NpdGlvbiwgdmFsdWUsIGluZGV4KSA9PiB7XG4gICAgICAgICAgY29tcG9zaXRpb25baW5wdXRTZWxlY3RvcktleXNbaW5kZXhdXSA9IHZhbHVlO1xuICAgICAgICAgIHJldHVybiBjb21wb3NpdGlvbjtcbiAgICAgICAgfSwge30pO1xuICAgICAgfVxuICAgICk7XG4gICAgcmV0dXJuIHN0cnVjdHVyZWRTZWxlY3RvcjtcbiAgfSxcbiAgeyB3aXRoVHlwZXM6ICgpID0+IGNyZWF0ZVN0cnVjdHVyZWRTZWxlY3RvciB9XG4pO1xuXG4vLyBzcmMvbHJ1TWVtb2l6ZS50c1xuZnVuY3Rpb24gY3JlYXRlU2luZ2xldG9uQ2FjaGUoZXF1YWxzKSB7XG4gIGxldCBlbnRyeTtcbiAgcmV0dXJuIHtcbiAgICBnZXQoa2V5KSB7XG4gICAgICBpZiAoZW50cnkgJiYgZXF1YWxzKGVudHJ5LmtleSwga2V5KSkge1xuICAgICAgICByZXR1cm4gZW50cnkudmFsdWU7XG4gICAgICB9XG4gICAgICByZXR1cm4gTk9UX0ZPVU5EO1xuICAgIH0sXG4gICAgcHV0KGtleSwgdmFsdWUpIHtcbiAgICAgIGVudHJ5ID0geyBrZXksIHZhbHVlIH07XG4gICAgfSxcbiAgICBmaW5kTWF0Y2hpbmdFbnRyeSh2YWx1ZSwgcmVzdWx0RXF1YWxpdHlDaGVjaykge1xuICAgICAgY29uc3QgY3VycmVudCA9IGVudHJ5O1xuICAgICAgcmV0dXJuIGN1cnJlbnQgIT09IHZvaWQgMCAmJiByZXN1bHRFcXVhbGl0eUNoZWNrKGN1cnJlbnQudmFsdWUsIHZhbHVlKSA/IGN1cnJlbnQgOiB2b2lkIDA7XG4gICAgfSxcbiAgICBjbGVhcigpIHtcbiAgICAgIGVudHJ5ID0gdm9pZCAwO1xuICAgIH1cbiAgfTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZUxydUNhY2hlKG1heFNpemUsIGVxdWFscykge1xuICBsZXQgZW50cmllcyA9IFtdO1xuICBmdW5jdGlvbiBnZXQoa2V5KSB7XG4gICAgY29uc3QgY2FjaGVJbmRleCA9IGVudHJpZXMuZmluZEluZGV4KChlbnRyeSkgPT4gZXF1YWxzKGVudHJ5LmtleSwga2V5KSk7XG4gICAgaWYgKGNhY2hlSW5kZXggPiAtMSkge1xuICAgICAgY29uc3QgZW50cnkgPSBlbnRyaWVzW2NhY2hlSW5kZXhdO1xuICAgICAgaWYgKGNhY2hlSW5kZXggPiAwKSB7XG4gICAgICAgIGVudHJpZXMuc3BsaWNlKGNhY2hlSW5kZXgsIDEpO1xuICAgICAgICBlbnRyaWVzLnVuc2hpZnQoZW50cnkpO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGVudHJ5LnZhbHVlO1xuICAgIH1cbiAgICByZXR1cm4gTk9UX0ZPVU5EO1xuICB9XG4gIGZ1bmN0aW9uIHB1dChrZXksIHZhbHVlKSB7XG4gICAgZW50cmllcy51bnNoaWZ0KHsga2V5LCB2YWx1ZSB9KTtcbiAgICBpZiAoZW50cmllcy5sZW5ndGggPiBtYXhTaXplKSB7XG4gICAgICBlbnRyaWVzLnBvcCgpO1xuICAgIH1cbiAgfVxuICBmdW5jdGlvbiBmaW5kTWF0Y2hpbmdFbnRyeSh2YWx1ZSwgcmVzdWx0RXF1YWxpdHlDaGVjaykge1xuICAgIGNvbnN0IGN1cnJlbnRFbnRyaWVzID0gZW50cmllcztcbiAgICBjb25zdCB7IGxlbmd0aCB9ID0gY3VycmVudEVudHJpZXM7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW5ndGg7IGkrKykge1xuICAgICAgY29uc3QgZW50cnkgPSBjdXJyZW50RW50cmllc1tpXTtcbiAgICAgIGlmIChyZXN1bHRFcXVhbGl0eUNoZWNrKGVudHJ5LnZhbHVlLCB2YWx1ZSkpIHtcbiAgICAgICAgcmV0dXJuIGVudHJ5O1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdm9pZCAwO1xuICB9XG4gIGZ1bmN0aW9uIGNsZWFyKCkge1xuICAgIGVudHJpZXMgPSBbXTtcbiAgfVxuICByZXR1cm4geyBnZXQsIHB1dCwgZmluZE1hdGNoaW5nRW50cnksIGNsZWFyIH07XG59XG52YXIgcmVmZXJlbmNlRXF1YWxpdHlDaGVjayA9IChhLCBiKSA9PiBhID09PSBiO1xuZnVuY3Rpb24gY3JlYXRlQ2FjaGVLZXlDb21wYXJhdG9yKGVxdWFsaXR5Q2hlY2spIHtcbiAgcmV0dXJuIGZ1bmN0aW9uIGFyZUFyZ3VtZW50c1NoYWxsb3dseUVxdWFsKHByZXYsIG5leHQpIHtcbiAgICBpZiAocHJldiA9PT0gbnVsbCB8fCBuZXh0ID09PSBudWxsIHx8IHByZXYubGVuZ3RoICE9PSBuZXh0Lmxlbmd0aCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCB7IGxlbmd0aCB9ID0gcHJldjtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGxlbmd0aDsgaSsrKSB7XG4gICAgICBpZiAoIWVxdWFsaXR5Q2hlY2socHJldltpXSwgbmV4dFtpXSkpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfTtcbn1cbmZ1bmN0aW9uIGxydU1lbW9pemUoZnVuYywgZXF1YWxpdHlDaGVja09yT3B0aW9ucykge1xuICBjb25zdCBwcm92aWRlZE9wdGlvbnMgPSB0eXBlb2YgZXF1YWxpdHlDaGVja09yT3B0aW9ucyA9PT0gXCJvYmplY3RcIiA/IGVxdWFsaXR5Q2hlY2tPck9wdGlvbnMgOiB7IGVxdWFsaXR5Q2hlY2s6IGVxdWFsaXR5Q2hlY2tPck9wdGlvbnMgfTtcbiAgY29uc3Qge1xuICAgIGVxdWFsaXR5Q2hlY2sgPSByZWZlcmVuY2VFcXVhbGl0eUNoZWNrLFxuICAgIG1heFNpemUgPSAxLFxuICAgIHJlc3VsdEVxdWFsaXR5Q2hlY2tcbiAgfSA9IHByb3ZpZGVkT3B0aW9ucztcbiAgY29uc3QgY29tcGFyYXRvciA9IGNyZWF0ZUNhY2hlS2V5Q29tcGFyYXRvcihlcXVhbGl0eUNoZWNrKTtcbiAgbGV0IHJlc3VsdHNDb3VudCA9IDA7XG4gIGNvbnN0IGNhY2hlID0gbWF4U2l6ZSA8PSAxID8gY3JlYXRlU2luZ2xldG9uQ2FjaGUoY29tcGFyYXRvcikgOiBjcmVhdGVMcnVDYWNoZShtYXhTaXplLCBjb21wYXJhdG9yKTtcbiAgZnVuY3Rpb24gbWVtb2l6ZWQoKSB7XG4gICAgbGV0IHZhbHVlID0gY2FjaGUuZ2V0KGFyZ3VtZW50cyk7XG4gICAgaWYgKHZhbHVlID09PSBOT1RfRk9VTkQpIHtcbiAgICAgIHZhbHVlID0gZnVuYy5hcHBseShudWxsLCBhcmd1bWVudHMpO1xuICAgICAgcmVzdWx0c0NvdW50Kys7XG4gICAgICBpZiAocmVzdWx0RXF1YWxpdHlDaGVjaykge1xuICAgICAgICBjb25zdCBtYXRjaGluZ0VudHJ5ID0gY2FjaGUuZmluZE1hdGNoaW5nRW50cnkoXG4gICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgcmVzdWx0RXF1YWxpdHlDaGVja1xuICAgICAgICApO1xuICAgICAgICBpZiAobWF0Y2hpbmdFbnRyeSkge1xuICAgICAgICAgIHZhbHVlID0gbWF0Y2hpbmdFbnRyeS52YWx1ZTtcbiAgICAgICAgICByZXN1bHRzQ291bnQgIT09IDAgJiYgcmVzdWx0c0NvdW50LS07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGNhY2hlLnB1dChhcmd1bWVudHMsIHZhbHVlKTtcbiAgICB9XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIG1lbW9pemVkLmNsZWFyQ2FjaGUgPSAoKSA9PiB7XG4gICAgY2FjaGUuY2xlYXIoKTtcbiAgICBtZW1vaXplZC5yZXNldFJlc3VsdHNDb3VudCgpO1xuICB9O1xuICBtZW1vaXplZC5yZXN1bHRzQ291bnQgPSAoKSA9PiByZXN1bHRzQ291bnQ7XG4gIG1lbW9pemVkLnJlc2V0UmVzdWx0c0NvdW50ID0gKCkgPT4ge1xuICAgIHJlc3VsdHNDb3VudCA9IDA7XG4gIH07XG4gIHJldHVybiBtZW1vaXplZDtcbn1cbmV4cG9ydCB7XG4gIGNyZWF0ZVNlbGVjdG9yLFxuICBjcmVhdGVTZWxlY3RvckNyZWF0b3IsXG4gIGNyZWF0ZVN0cnVjdHVyZWRTZWxlY3RvcixcbiAgbHJ1TWVtb2l6ZSxcbiAgcmVmZXJlbmNlRXF1YWxpdHlDaGVjayxcbiAgc2V0R2xvYmFsRGV2TW9kZUNoZWNrcyxcbiAgd2Vha01hcE1lbW9pemVcbn07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1yZXNlbGVjdC5tanMubWFwIiwiLy8gc3JjL2luZGV4LnRzXG5mdW5jdGlvbiBjcmVhdGVUaHVua01pZGRsZXdhcmUoZXh0cmFBcmd1bWVudCkge1xuICBjb25zdCBtaWRkbGV3YXJlID0gKHsgZGlzcGF0Y2gsIGdldFN0YXRlIH0pID0+IChuZXh0KSA9PiAoYWN0aW9uKSA9PiB7XG4gICAgaWYgKHR5cGVvZiBhY3Rpb24gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgcmV0dXJuIGFjdGlvbihkaXNwYXRjaCwgZ2V0U3RhdGUsIGV4dHJhQXJndW1lbnQpO1xuICAgIH1cbiAgICByZXR1cm4gbmV4dChhY3Rpb24pO1xuICB9O1xuICByZXR1cm4gbWlkZGxld2FyZTtcbn1cbnZhciB0aHVuayA9IGNyZWF0ZVRodW5rTWlkZGxld2FyZSgpO1xudmFyIHdpdGhFeHRyYUFyZ3VtZW50ID0gY3JlYXRlVGh1bmtNaWRkbGV3YXJlO1xuZXhwb3J0IHtcbiAgdGh1bmssXG4gIHdpdGhFeHRyYUFyZ3VtZW50XG59O1xuIiwiaW1wb3J0IHsgYXBwbHlNaWRkbGV3YXJlLCBjb21iaW5lUmVkdWNlcnMsIGNvbWJpbmVSZWR1Y2VycyBhcyBjb21iaW5lUmVkdWNlcnMkMSwgY29tcG9zZSwgY3JlYXRlU3RvcmUsIGlzQWN0aW9uLCBpc1BsYWluT2JqZWN0IH0gZnJvbSBcInJlZHV4XCI7XG5pbXBvcnQgeyBjdXJyZW50LCBmcmVlemUsIGlzRHJhZnQsIGlzRHJhZnRhYmxlLCBvcmlnaW5hbCwgcHJvZHVjZSBhcyBjcmVhdGVOZXh0U3RhdGUgfSBmcm9tIFwiaW1tZXJcIjtcbmltcG9ydCB7IGNyZWF0ZVNlbGVjdG9yLCBjcmVhdGVTZWxlY3RvckNyZWF0b3IsIGxydU1lbW9pemUsIHdlYWtNYXBNZW1vaXplIH0gZnJvbSBcInJlc2VsZWN0XCI7XG5pbXBvcnQgeyB0aHVuaywgd2l0aEV4dHJhQXJndW1lbnQgfSBmcm9tIFwicmVkdXgtdGh1bmtcIjtcbmV4cG9ydCAqIGZyb20gXCJyZWR1eFwiO1xuLy8jcmVnaW9uIHNyYy9jcmVhdGVEcmFmdFNhZmVTZWxlY3Rvci50c1xuY29uc3QgY3JlYXRlRHJhZnRTYWZlU2VsZWN0b3JDcmVhdG9yID0gKC4uLmFyZ3MpID0+IHtcblx0Y29uc3QgY3JlYXRlU2VsZWN0b3IgPSBjcmVhdGVTZWxlY3RvckNyZWF0b3IoLi4uYXJncyk7XG5cdGNvbnN0IGNyZWF0ZURyYWZ0U2FmZVNlbGVjdG9yID0gT2JqZWN0LmFzc2lnbigoLi4uYXJncykgPT4ge1xuXHRcdGNvbnN0IHNlbGVjdG9yID0gY3JlYXRlU2VsZWN0b3IoLi4uYXJncyk7XG5cdFx0Y29uc3Qgd3JhcHBlZFNlbGVjdG9yID0gKHZhbHVlLCAuLi5yZXN0KSA9PiBzZWxlY3Rvcihpc0RyYWZ0KHZhbHVlKSA/IGN1cnJlbnQodmFsdWUpIDogdmFsdWUsIC4uLnJlc3QpO1xuXHRcdE9iamVjdC5hc3NpZ24od3JhcHBlZFNlbGVjdG9yLCBzZWxlY3Rvcik7XG5cdFx0cmV0dXJuIHdyYXBwZWRTZWxlY3Rvcjtcblx0fSwgeyB3aXRoVHlwZXM6ICgpID0+IGNyZWF0ZURyYWZ0U2FmZVNlbGVjdG9yIH0pO1xuXHRyZXR1cm4gY3JlYXRlRHJhZnRTYWZlU2VsZWN0b3I7XG59O1xuY29uc3QgY3JlYXRlRHJhZnRTYWZlU2VsZWN0b3IgPSAvKiBAX19QVVJFX18gKi8gY3JlYXRlRHJhZnRTYWZlU2VsZWN0b3JDcmVhdG9yKHdlYWtNYXBNZW1vaXplKTtcbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9kZXZ0b29sc0V4dGVuc2lvbi50c1xuY29uc3QgY29tcG9zZVdpdGhEZXZUb29scyA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgJiYgd2luZG93Ll9fUkVEVVhfREVWVE9PTFNfRVhURU5TSU9OX0NPTVBPU0VfXyA/IHdpbmRvdy5fX1JFRFVYX0RFVlRPT0xTX0VYVEVOU0lPTl9DT01QT1NFX18gOiBmdW5jdGlvbigpIHtcblx0aWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDApIHJldHVybiB2b2lkIDA7XG5cdGlmICh0eXBlb2YgYXJndW1lbnRzWzBdID09PSBcIm9iamVjdFwiKSByZXR1cm4gY29tcG9zZTtcblx0cmV0dXJuIGNvbXBvc2UuYXBwbHkobnVsbCwgYXJndW1lbnRzKTtcbn07XG50eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5fX1JFRFVYX0RFVlRPT0xTX0VYVEVOU0lPTl9fICYmIHdpbmRvdy5fX1JFRFVYX0RFVlRPT0xTX0VYVEVOU0lPTl9fO1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL3RzSGVscGVycy50c1xuY29uc3QgaGFzTWF0Y2hGdW5jdGlvbiA9ICh2KSA9PiB7XG5cdHJldHVybiB2ICYmIHR5cGVvZiB2Lm1hdGNoID09PSBcImZ1bmN0aW9uXCI7XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NyZWF0ZUFjdGlvbi50c1xuZnVuY3Rpb24gY3JlYXRlQWN0aW9uKHR5cGUsIHByZXBhcmVBY3Rpb24pIHtcblx0ZnVuY3Rpb24gYWN0aW9uQ3JlYXRvciguLi5hcmdzKSB7XG5cdFx0aWYgKHByZXBhcmVBY3Rpb24pIHtcblx0XHRcdGxldCBwcmVwYXJlZCA9IHByZXBhcmVBY3Rpb24oLi4uYXJncyk7XG5cdFx0XHRpZiAoIXByZXBhcmVkKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgwKSA6IFwicHJlcGFyZUFjdGlvbiBkaWQgbm90IHJldHVybiBhbiBvYmplY3RcIik7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHR0eXBlLFxuXHRcdFx0XHRwYXlsb2FkOiBwcmVwYXJlZC5wYXlsb2FkLFxuXHRcdFx0XHQuLi5cIm1ldGFcIiBpbiBwcmVwYXJlZCAmJiB7IG1ldGE6IHByZXBhcmVkLm1ldGEgfSxcblx0XHRcdFx0Li4uXCJlcnJvclwiIGluIHByZXBhcmVkICYmIHsgZXJyb3I6IHByZXBhcmVkLmVycm9yIH1cblx0XHRcdH07XG5cdFx0fVxuXHRcdHJldHVybiB7XG5cdFx0XHR0eXBlLFxuXHRcdFx0cGF5bG9hZDogYXJnc1swXVxuXHRcdH07XG5cdH1cblx0YWN0aW9uQ3JlYXRvci50b1N0cmluZyA9ICgpID0+IGAke3R5cGV9YDtcblx0YWN0aW9uQ3JlYXRvci50eXBlID0gdHlwZTtcblx0YWN0aW9uQ3JlYXRvci5tYXRjaCA9IChhY3Rpb24pID0+IGlzQWN0aW9uKGFjdGlvbikgJiYgYWN0aW9uLnR5cGUgPT09IHR5cGU7XG5cdHJldHVybiBhY3Rpb25DcmVhdG9yO1xufVxuZnVuY3Rpb24gaXNBY3Rpb25DcmVhdG9yKGFjdGlvbikge1xuXHRyZXR1cm4gdHlwZW9mIGFjdGlvbiA9PT0gXCJmdW5jdGlvblwiICYmIFwidHlwZVwiIGluIGFjdGlvbiAmJiBoYXNNYXRjaEZ1bmN0aW9uKGFjdGlvbik7XG59XG5mdW5jdGlvbiBpc0ZTQShhY3Rpb24pIHtcblx0cmV0dXJuIGlzQWN0aW9uKGFjdGlvbikgJiYgT2JqZWN0LmtleXMoYWN0aW9uKS5ldmVyeShpc1ZhbGlkS2V5KTtcbn1cbmZ1bmN0aW9uIGlzVmFsaWRLZXkoa2V5KSB7XG5cdHJldHVybiBbXG5cdFx0XCJ0eXBlXCIsXG5cdFx0XCJwYXlsb2FkXCIsXG5cdFx0XCJlcnJvclwiLFxuXHRcdFwibWV0YVwiXG5cdF0uaW5kZXhPZihrZXkpID4gLTE7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvYWN0aW9uQ3JlYXRvckludmFyaWFudE1pZGRsZXdhcmUudHNcbmZ1bmN0aW9uIGdldE1lc3NhZ2UodHlwZSkge1xuXHRjb25zdCBzcGxpdFR5cGUgPSB0eXBlID8gYCR7dHlwZX1gLnNwbGl0KFwiL1wiKSA6IFtdO1xuXHRjb25zdCBhY3Rpb25OYW1lID0gc3BsaXRUeXBlW3NwbGl0VHlwZS5sZW5ndGggLSAxXSB8fCBcImFjdGlvbkNyZWF0b3JcIjtcblx0cmV0dXJuIGBEZXRlY3RlZCBhbiBhY3Rpb24gY3JlYXRvciB3aXRoIHR5cGUgXCIke3R5cGUgfHwgXCJ1bmtub3duXCJ9XCIgYmVpbmcgZGlzcGF0Y2hlZC5cbk1ha2Ugc3VyZSB5b3UncmUgY2FsbGluZyB0aGUgYWN0aW9uIGNyZWF0b3IgYmVmb3JlIGRpc3BhdGNoaW5nLCBpLmUuIFxcYGRpc3BhdGNoKCR7YWN0aW9uTmFtZX0oKSlcXGAgaW5zdGVhZCBvZiBcXGBkaXNwYXRjaCgke2FjdGlvbk5hbWV9KVxcYC4gVGhpcyBpcyBuZWNlc3NhcnkgZXZlbiBpZiB0aGUgYWN0aW9uIGhhcyBubyBwYXlsb2FkLmA7XG59XG5mdW5jdGlvbiBjcmVhdGVBY3Rpb25DcmVhdG9ySW52YXJpYW50TWlkZGxld2FyZShvcHRpb25zID0ge30pIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIikgcmV0dXJuICgpID0+IChuZXh0KSA9PiAoYWN0aW9uKSA9PiBuZXh0KGFjdGlvbik7XG5cdGNvbnN0IHsgaXNBY3Rpb25DcmVhdG9yOiBpc0FjdGlvbkNyZWF0b3IkMSA9IGlzQWN0aW9uQ3JlYXRvciB9ID0gb3B0aW9ucztcblx0cmV0dXJuICgpID0+IChuZXh0KSA9PiAoYWN0aW9uKSA9PiB7XG5cdFx0aWYgKGlzQWN0aW9uQ3JlYXRvciQxKGFjdGlvbikpIGNvbnNvbGUud2FybihnZXRNZXNzYWdlKGFjdGlvbi50eXBlKSk7XG5cdFx0cmV0dXJuIG5leHQoYWN0aW9uKTtcblx0fTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy91dGlscy50c1xuZnVuY3Rpb24gZ2V0VGltZU1lYXN1cmVVdGlscyhtYXhEZWxheSwgZm5OYW1lKSB7XG5cdGxldCBlbGFwc2VkID0gMDtcblx0cmV0dXJuIHtcblx0XHRtZWFzdXJlVGltZShmbikge1xuXHRcdFx0Y29uc3Qgc3RhcnRlZCA9IERhdGUubm93KCk7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRyZXR1cm4gZm4oKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdGVsYXBzZWQgKz0gRGF0ZS5ub3coKSAtIHN0YXJ0ZWQ7XG5cdFx0XHR9XG5cdFx0fSxcblx0XHR3YXJuSWZFeGNlZWRlZCgpIHtcblx0XHRcdGlmIChlbGFwc2VkID4gbWF4RGVsYXkpIGNvbnNvbGUud2FybihgJHtmbk5hbWV9IHRvb2sgJHtlbGFwc2VkfW1zLCB3aGljaCBpcyBtb3JlIHRoYW4gdGhlIHdhcm5pbmcgdGhyZXNob2xkIG9mICR7bWF4RGVsYXl9bXMuIFxuSWYgeW91ciBzdGF0ZSBvciBhY3Rpb25zIGFyZSB2ZXJ5IGxhcmdlLCB5b3UgbWF5IHdhbnQgdG8gZGlzYWJsZSB0aGUgbWlkZGxld2FyZSBhcyBpdCBtaWdodCBjYXVzZSB0b28gbXVjaCBvZiBhIHNsb3dkb3duIGluIGRldmVsb3BtZW50IG1vZGUuIFNlZSBodHRwczovL3JlZHV4LXRvb2xraXQuanMub3JnL2FwaS9nZXREZWZhdWx0TWlkZGxld2FyZSBmb3IgaW5zdHJ1Y3Rpb25zLlxuSXQgaXMgZGlzYWJsZWQgaW4gcHJvZHVjdGlvbiBidWlsZHMsIHNvIHlvdSBkb24ndCBuZWVkIHRvIHdvcnJ5IGFib3V0IHRoYXQuYCk7XG5cdFx0fVxuXHR9O1xufVxudmFyIFR1cGxlID0gY2xhc3MgVHVwbGUgZXh0ZW5kcyBBcnJheSB7XG5cdGNvbnN0cnVjdG9yKC4uLml0ZW1zKSB7XG5cdFx0c3VwZXIoLi4uaXRlbXMpO1xuXHRcdE9iamVjdC5zZXRQcm90b3R5cGVPZih0aGlzLCBUdXBsZS5wcm90b3R5cGUpO1xuXHR9XG5cdHN0YXRpYyBnZXQgW1N5bWJvbC5zcGVjaWVzXSgpIHtcblx0XHRyZXR1cm4gVHVwbGU7XG5cdH1cblx0Y29uY2F0KC4uLmFycikge1xuXHRcdHJldHVybiBzdXBlci5jb25jYXQuYXBwbHkodGhpcywgYXJyKTtcblx0fVxuXHRwcmVwZW5kKC4uLmFycikge1xuXHRcdGlmIChhcnIubGVuZ3RoID09PSAxICYmIEFycmF5LmlzQXJyYXkoYXJyWzBdKSkgcmV0dXJuIG5ldyBUdXBsZSguLi5hcnJbMF0uY29uY2F0KHRoaXMpKTtcblx0XHRyZXR1cm4gbmV3IFR1cGxlKC4uLmFyci5jb25jYXQodGhpcykpO1xuXHR9XG59O1xuZnVuY3Rpb24gZnJlZXplRHJhZnRhYmxlKHZhbCkge1xuXHRyZXR1cm4gaXNEcmFmdGFibGUodmFsKSA/IGNyZWF0ZU5leHRTdGF0ZSh2YWwsICgpID0+IHt9KSA6IHZhbDtcbn1cbmZ1bmN0aW9uIGdldE9ySW5zZXJ0Q29tcHV0ZWQobWFwLCBrZXksIGNvbXB1dGUpIHtcblx0aWYgKG1hcC5oYXMoa2V5KSkgcmV0dXJuIG1hcC5nZXQoa2V5KTtcblx0cmV0dXJuIG1hcC5zZXQoa2V5LCBjb21wdXRlKGtleSkpLmdldChrZXkpO1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2ltbXV0YWJsZVN0YXRlSW52YXJpYW50TWlkZGxld2FyZS50c1xuZnVuY3Rpb24gaXNJbW11dGFibGVEZWZhdWx0KHZhbHVlKSB7XG5cdHJldHVybiB0eXBlb2YgdmFsdWUgIT09IFwib2JqZWN0XCIgfHwgdmFsdWUgPT0gbnVsbCB8fCBPYmplY3QuaXNGcm96ZW4odmFsdWUpO1xufVxuZnVuY3Rpb24gdHJhY2tGb3JNdXRhdGlvbnMoaXNJbW11dGFibGUsIGlnbm9yZWRQYXRocywgb2JqKSB7XG5cdGNvbnN0IHRyYWNrZWRQcm9wZXJ0aWVzID0gdHJhY2tQcm9wZXJ0aWVzKGlzSW1tdXRhYmxlLCBpZ25vcmVkUGF0aHMsIG9iaik7XG5cdHJldHVybiB7IGRldGVjdE11dGF0aW9ucygpIHtcblx0XHRyZXR1cm4gZGV0ZWN0TXV0YXRpb25zKGlzSW1tdXRhYmxlLCBpZ25vcmVkUGF0aHMsIHRyYWNrZWRQcm9wZXJ0aWVzLCBvYmopO1xuXHR9IH07XG59XG5mdW5jdGlvbiB0cmFja1Byb3BlcnRpZXMoaXNJbW11dGFibGUsIGlnbm9yZWRQYXRocyA9IFtdLCBvYmosIHBhdGggPSBcIlwiLCBpblByb2dyZXNzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSkge1xuXHRjb25zdCB0cmFja2VkID0geyB2YWx1ZTogb2JqIH07XG5cdGlmICghaXNJbW11dGFibGUob2JqKSkge1xuXHRcdGNvbnN0IGFscmVhZHlJblByb2dyZXNzID0gaW5Qcm9ncmVzcy5nZXQob2JqKTtcblx0XHRpZiAoYWxyZWFkeUluUHJvZ3Jlc3MpIHJldHVybiBhbHJlYWR5SW5Qcm9ncmVzcztcblx0XHR0cmFja2VkLmNoaWxkcmVuID0ge307XG5cdFx0aW5Qcm9ncmVzcy5zZXQob2JqLCB0cmFja2VkKTtcblx0XHRjb25zdCBoYXNJZ25vcmVkUGF0aHMgPSBpZ25vcmVkUGF0aHMubGVuZ3RoID4gMDtcblx0XHRmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcblx0XHRcdGNvbnN0IG5lc3RlZFBhdGggPSBwYXRoID8gcGF0aCArIFwiLlwiICsga2V5IDoga2V5O1xuXHRcdFx0aWYgKGhhc0lnbm9yZWRQYXRocykge1xuXHRcdFx0XHRpZiAoaWdub3JlZFBhdGhzLnNvbWUoKGlnbm9yZWQpID0+IHtcblx0XHRcdFx0XHRpZiAoaWdub3JlZCBpbnN0YW5jZW9mIFJlZ0V4cCkgcmV0dXJuIGlnbm9yZWQudGVzdChuZXN0ZWRQYXRoKTtcblx0XHRcdFx0XHRyZXR1cm4gbmVzdGVkUGF0aCA9PT0gaWdub3JlZDtcblx0XHRcdFx0fSkpIGNvbnRpbnVlO1xuXHRcdFx0fVxuXHRcdFx0dHJhY2tlZC5jaGlsZHJlbltrZXldID0gdHJhY2tQcm9wZXJ0aWVzKGlzSW1tdXRhYmxlLCBpZ25vcmVkUGF0aHMsIG9ialtrZXldLCBuZXN0ZWRQYXRoLCBpblByb2dyZXNzKTtcblx0XHR9XG5cdFx0aW5Qcm9ncmVzcy5kZWxldGUob2JqKTtcblx0fVxuXHRyZXR1cm4gdHJhY2tlZDtcbn1cbmZ1bmN0aW9uIGRldGVjdE11dGF0aW9ucyhpc0ltbXV0YWJsZSwgaWdub3JlZFBhdGhzID0gW10sIHRyYWNrZWRQcm9wZXJ0eSwgb2JqLCBzYW1lUGFyZW50UmVmID0gZmFsc2UsIHBhdGggPSBcIlwiLCBzZWVuID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKSkge1xuXHRjb25zdCBwcmV2T2JqID0gdHJhY2tlZFByb3BlcnR5ID8gdHJhY2tlZFByb3BlcnR5LnZhbHVlIDogdm9pZCAwO1xuXHRjb25zdCBzYW1lUmVmID0gcHJldk9iaiA9PT0gb2JqO1xuXHRpZiAoc2FtZVBhcmVudFJlZiAmJiAhc2FtZVJlZiAmJiAhTnVtYmVyLmlzTmFOKG9iaikpIHJldHVybiB7XG5cdFx0d2FzTXV0YXRlZDogdHJ1ZSxcblx0XHRwYXRoXG5cdH07XG5cdGlmIChpc0ltbXV0YWJsZShwcmV2T2JqKSB8fCBpc0ltbXV0YWJsZShvYmopKSByZXR1cm4geyB3YXNNdXRhdGVkOiBmYWxzZSB9O1xuXHRsZXQgc2VlblZhbHVlcyA9IHNlZW4uZ2V0KHRyYWNrZWRQcm9wZXJ0eSk7XG5cdGlmICghc2VlblZhbHVlcykge1xuXHRcdHNlZW5WYWx1ZXMgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuXHRcdHNlZW4uc2V0KHRyYWNrZWRQcm9wZXJ0eSwgc2VlblZhbHVlcyk7XG5cdH0gZWxzZSBpZiAoc2VlblZhbHVlcy5oYXMob2JqKSkgcmV0dXJuIHsgd2FzTXV0YXRlZDogZmFsc2UgfTtcblx0c2VlblZhbHVlcy5hZGQob2JqKTtcblx0Y29uc3Qga2V5c1RvRGV0ZWN0ID0ge307XG5cdGZvciAobGV0IGtleSBpbiB0cmFja2VkUHJvcGVydHkuY2hpbGRyZW4pIGtleXNUb0RldGVjdFtrZXldID0gdHJ1ZTtcblx0Zm9yIChsZXQga2V5IGluIG9iaikga2V5c1RvRGV0ZWN0W2tleV0gPSB0cnVlO1xuXHRjb25zdCBoYXNJZ25vcmVkUGF0aHMgPSBpZ25vcmVkUGF0aHMubGVuZ3RoID4gMDtcblx0Zm9yIChsZXQga2V5IGluIGtleXNUb0RldGVjdCkge1xuXHRcdGNvbnN0IG5lc3RlZFBhdGggPSBwYXRoID8gcGF0aCArIFwiLlwiICsga2V5IDoga2V5O1xuXHRcdGlmIChoYXNJZ25vcmVkUGF0aHMpIHtcblx0XHRcdGlmIChpZ25vcmVkUGF0aHMuc29tZSgoaWdub3JlZCkgPT4ge1xuXHRcdFx0XHRpZiAoaWdub3JlZCBpbnN0YW5jZW9mIFJlZ0V4cCkgcmV0dXJuIGlnbm9yZWQudGVzdChuZXN0ZWRQYXRoKTtcblx0XHRcdFx0cmV0dXJuIG5lc3RlZFBhdGggPT09IGlnbm9yZWQ7XG5cdFx0XHR9KSkgY29udGludWU7XG5cdFx0fVxuXHRcdGNvbnN0IHJlc3VsdCA9IGRldGVjdE11dGF0aW9ucyhpc0ltbXV0YWJsZSwgaWdub3JlZFBhdGhzLCB0cmFja2VkUHJvcGVydHkuY2hpbGRyZW5ba2V5XSwgb2JqW2tleV0sIHNhbWVSZWYsIG5lc3RlZFBhdGgsIHNlZW4pO1xuXHRcdGlmIChyZXN1bHQud2FzTXV0YXRlZCkgcmV0dXJuIHJlc3VsdDtcblx0fVxuXHRyZXR1cm4geyB3YXNNdXRhdGVkOiBmYWxzZSB9O1xufVxuZnVuY3Rpb24gY3JlYXRlSW1tdXRhYmxlU3RhdGVJbnZhcmlhbnRNaWRkbGV3YXJlKG9wdGlvbnMgPSB7fSkge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiKSByZXR1cm4gKCkgPT4gKG5leHQpID0+IChhY3Rpb24pID0+IG5leHQoYWN0aW9uKTtcblx0ZWxzZSB7XG5cdFx0ZnVuY3Rpb24gc3RyaW5naWZ5KG9iaiwgc2VyaWFsaXplciwgaW5kZW50LCBkZWN5Y2xlcikge1xuXHRcdFx0cmV0dXJuIEpTT04uc3RyaW5naWZ5KG9iaiwgZ2V0U2VyaWFsaXplKHNlcmlhbGl6ZXIsIGRlY3ljbGVyKSwgaW5kZW50KTtcblx0XHR9XG5cdFx0ZnVuY3Rpb24gZ2V0U2VyaWFsaXplKHNlcmlhbGl6ZXIsIGRlY3ljbGVyKSB7XG5cdFx0XHRsZXQgc3RhY2sgPSBbXSwga2V5cyA9IFtdO1xuXHRcdFx0aWYgKCFkZWN5Y2xlcikgZGVjeWNsZXIgPSBmdW5jdGlvbihfLCB2YWx1ZSkge1xuXHRcdFx0XHRpZiAoc3RhY2tbMF0gPT09IHZhbHVlKSByZXR1cm4gXCJbQ2lyY3VsYXIgfl1cIjtcblx0XHRcdFx0cmV0dXJuIFwiW0NpcmN1bGFyIH4uXCIgKyBrZXlzLnNsaWNlKDAsIHN0YWNrLmluZGV4T2YodmFsdWUpKS5qb2luKFwiLlwiKSArIFwiXVwiO1xuXHRcdFx0fTtcblx0XHRcdHJldHVybiBmdW5jdGlvbihrZXksIHZhbHVlKSB7XG5cdFx0XHRcdGlmIChzdGFjay5sZW5ndGggPiAwKSB7XG5cdFx0XHRcdFx0dmFyIHRoaXNQb3MgPSBzdGFjay5pbmRleE9mKHRoaXMpO1xuXHRcdFx0XHRcdGlmICh+dGhpc1Bvcykge1xuXHRcdFx0XHRcdFx0c3RhY2suc3BsaWNlKHRoaXNQb3MgKyAxKTtcblx0XHRcdFx0XHRcdGtleXMuc3BsaWNlKHRoaXNQb3MsIEluZmluaXR5LCBrZXkpO1xuXHRcdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0XHRzdGFjay5wdXNoKHRoaXMpO1xuXHRcdFx0XHRcdFx0a2V5cy5wdXNoKGtleSk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmICh+c3RhY2suaW5kZXhPZih2YWx1ZSkpIHZhbHVlID0gZGVjeWNsZXIuY2FsbCh0aGlzLCBrZXksIHZhbHVlKTtcblx0XHRcdFx0fSBlbHNlIHN0YWNrLnB1c2godmFsdWUpO1xuXHRcdFx0XHRyZXR1cm4gc2VyaWFsaXplciA9PSBudWxsID8gdmFsdWUgOiBzZXJpYWxpemVyLmNhbGwodGhpcywga2V5LCB2YWx1ZSk7XG5cdFx0XHR9O1xuXHRcdH1cblx0XHRsZXQgeyBpc0ltbXV0YWJsZSA9IGlzSW1tdXRhYmxlRGVmYXVsdCwgaWdub3JlZFBhdGhzLCB3YXJuQWZ0ZXIgPSAzMiB9ID0gb3B0aW9ucztcblx0XHRjb25zdCB0cmFjayA9IHRyYWNrRm9yTXV0YXRpb25zLmJpbmQobnVsbCwgaXNJbW11dGFibGUsIGlnbm9yZWRQYXRocyk7XG5cdFx0cmV0dXJuICh7IGdldFN0YXRlIH0pID0+IHtcblx0XHRcdGxldCBzdGF0ZSA9IGdldFN0YXRlKCk7XG5cdFx0XHRsZXQgdHJhY2tlciA9IHRyYWNrKHN0YXRlKTtcblx0XHRcdGxldCByZXN1bHQ7XG5cdFx0XHRyZXR1cm4gKG5leHQpID0+IChhY3Rpb24pID0+IHtcblx0XHRcdFx0Y29uc3QgbWVhc3VyZVV0aWxzID0gZ2V0VGltZU1lYXN1cmVVdGlscyh3YXJuQWZ0ZXIsIFwiSW1tdXRhYmxlU3RhdGVJbnZhcmlhbnRNaWRkbGV3YXJlXCIpO1xuXHRcdFx0XHRtZWFzdXJlVXRpbHMubWVhc3VyZVRpbWUoKCkgPT4ge1xuXHRcdFx0XHRcdHN0YXRlID0gZ2V0U3RhdGUoKTtcblx0XHRcdFx0XHRyZXN1bHQgPSB0cmFja2VyLmRldGVjdE11dGF0aW9ucygpO1xuXHRcdFx0XHRcdHRyYWNrZXIgPSB0cmFjayhzdGF0ZSk7XG5cdFx0XHRcdFx0aWYgKHJlc3VsdC53YXNNdXRhdGVkKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxOSkgOiBgQSBzdGF0ZSBtdXRhdGlvbiB3YXMgZGV0ZWN0ZWQgYmV0d2VlbiBkaXNwYXRjaGVzLCBpbiB0aGUgcGF0aCAnJHtyZXN1bHQucGF0aCB8fCBcIlwifScuICBUaGlzIG1heSBjYXVzZSBpbmNvcnJlY3QgYmVoYXZpb3IuIChodHRwczovL3JlZHV4LmpzLm9yZy9zdHlsZS1ndWlkZS9zdHlsZS1ndWlkZSNkby1ub3QtbXV0YXRlLXN0YXRlKWApO1xuXHRcdFx0XHR9KTtcblx0XHRcdFx0Y29uc3QgZGlzcGF0Y2hlZEFjdGlvbiA9IG5leHQoYWN0aW9uKTtcblx0XHRcdFx0bWVhc3VyZVV0aWxzLm1lYXN1cmVUaW1lKCgpID0+IHtcblx0XHRcdFx0XHRzdGF0ZSA9IGdldFN0YXRlKCk7XG5cdFx0XHRcdFx0cmVzdWx0ID0gdHJhY2tlci5kZXRlY3RNdXRhdGlvbnMoKTtcblx0XHRcdFx0XHR0cmFja2VyID0gdHJhY2soc3RhdGUpO1xuXHRcdFx0XHRcdGlmIChyZXN1bHQud2FzTXV0YXRlZCkgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMjApIDogYEEgc3RhdGUgbXV0YXRpb24gd2FzIGRldGVjdGVkIGluc2lkZSBhIGRpc3BhdGNoLCBpbiB0aGUgcGF0aDogJHtyZXN1bHQucGF0aCB8fCBcIlwifS4gVGFrZSBhIGxvb2sgYXQgdGhlIHJlZHVjZXIocykgaGFuZGxpbmcgdGhlIGFjdGlvbiAke3N0cmluZ2lmeShhY3Rpb24pfS4gKGh0dHBzOi8vcmVkdXguanMub3JnL3N0eWxlLWd1aWRlL3N0eWxlLWd1aWRlI2RvLW5vdC1tdXRhdGUtc3RhdGUpYCk7XG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRtZWFzdXJlVXRpbHMud2FybklmRXhjZWVkZWQoKTtcblx0XHRcdFx0cmV0dXJuIGRpc3BhdGNoZWRBY3Rpb247XG5cdFx0XHR9O1xuXHRcdH07XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9zZXJpYWxpemFibGVTdGF0ZUludmFyaWFudE1pZGRsZXdhcmUudHNcbmZ1bmN0aW9uIGlzUGxhaW4odmFsKSB7XG5cdGNvbnN0IHR5cGUgPSB0eXBlb2YgdmFsO1xuXHRyZXR1cm4gdmFsID09IG51bGwgfHwgdHlwZSA9PT0gXCJzdHJpbmdcIiB8fCB0eXBlID09PSBcImJvb2xlYW5cIiB8fCB0eXBlID09PSBcIm51bWJlclwiIHx8IEFycmF5LmlzQXJyYXkodmFsKSB8fCBpc1BsYWluT2JqZWN0KHZhbCk7XG59XG5mdW5jdGlvbiBmaW5kTm9uU2VyaWFsaXphYmxlVmFsdWUodmFsdWUsIHBhdGggPSBcIlwiLCBpc1NlcmlhbGl6YWJsZSA9IGlzUGxhaW4sIGdldEVudHJpZXMsIGlnbm9yZWRQYXRocyA9IFtdLCBjYWNoZSkge1xuXHRsZXQgZm91bmROZXN0ZWRTZXJpYWxpemFibGU7XG5cdGlmICghaXNTZXJpYWxpemFibGUodmFsdWUpKSByZXR1cm4ge1xuXHRcdGtleVBhdGg6IHBhdGggfHwgXCI8cm9vdD5cIixcblx0XHR2YWx1ZVxuXHR9O1xuXHRpZiAodHlwZW9mIHZhbHVlICE9PSBcIm9iamVjdFwiIHx8IHZhbHVlID09PSBudWxsKSByZXR1cm4gZmFsc2U7XG5cdGlmIChjYWNoZT8uaGFzKHZhbHVlKSkgcmV0dXJuIGZhbHNlO1xuXHRjb25zdCBlbnRyaWVzID0gZ2V0RW50cmllcyAhPSBudWxsID8gZ2V0RW50cmllcyh2YWx1ZSkgOiBPYmplY3QuZW50cmllcyh2YWx1ZSk7XG5cdGNvbnN0IGhhc0lnbm9yZWRQYXRocyA9IGlnbm9yZWRQYXRocy5sZW5ndGggPiAwO1xuXHRmb3IgKGNvbnN0IFtrZXksIG5lc3RlZFZhbHVlXSBvZiBlbnRyaWVzKSB7XG5cdFx0Y29uc3QgbmVzdGVkUGF0aCA9IHBhdGggPyBwYXRoICsgXCIuXCIgKyBrZXkgOiBrZXk7XG5cdFx0aWYgKGhhc0lnbm9yZWRQYXRocykge1xuXHRcdFx0aWYgKGlnbm9yZWRQYXRocy5zb21lKChpZ25vcmVkKSA9PiB7XG5cdFx0XHRcdGlmIChpZ25vcmVkIGluc3RhbmNlb2YgUmVnRXhwKSByZXR1cm4gaWdub3JlZC50ZXN0KG5lc3RlZFBhdGgpO1xuXHRcdFx0XHRyZXR1cm4gbmVzdGVkUGF0aCA9PT0gaWdub3JlZDtcblx0XHRcdH0pKSBjb250aW51ZTtcblx0XHR9XG5cdFx0aWYgKCFpc1NlcmlhbGl6YWJsZShuZXN0ZWRWYWx1ZSkpIHJldHVybiB7XG5cdFx0XHRrZXlQYXRoOiBuZXN0ZWRQYXRoLFxuXHRcdFx0dmFsdWU6IG5lc3RlZFZhbHVlXG5cdFx0fTtcblx0XHRpZiAodHlwZW9mIG5lc3RlZFZhbHVlID09PSBcIm9iamVjdFwiKSB7XG5cdFx0XHRmb3VuZE5lc3RlZFNlcmlhbGl6YWJsZSA9IGZpbmROb25TZXJpYWxpemFibGVWYWx1ZShuZXN0ZWRWYWx1ZSwgbmVzdGVkUGF0aCwgaXNTZXJpYWxpemFibGUsIGdldEVudHJpZXMsIGlnbm9yZWRQYXRocywgY2FjaGUpO1xuXHRcdFx0aWYgKGZvdW5kTmVzdGVkU2VyaWFsaXphYmxlKSByZXR1cm4gZm91bmROZXN0ZWRTZXJpYWxpemFibGU7XG5cdFx0fVxuXHR9XG5cdGlmIChjYWNoZSAmJiBpc05lc3RlZEZyb3plbih2YWx1ZSkpIGNhY2hlLmFkZCh2YWx1ZSk7XG5cdHJldHVybiBmYWxzZTtcbn1cbmZ1bmN0aW9uIGlzTmVzdGVkRnJvemVuKHZhbHVlKSB7XG5cdGlmICghT2JqZWN0LmlzRnJvemVuKHZhbHVlKSkgcmV0dXJuIGZhbHNlO1xuXHRmb3IgKGNvbnN0IG5lc3RlZFZhbHVlIG9mIE9iamVjdC52YWx1ZXModmFsdWUpKSB7XG5cdFx0aWYgKHR5cGVvZiBuZXN0ZWRWYWx1ZSAhPT0gXCJvYmplY3RcIiB8fCBuZXN0ZWRWYWx1ZSA9PT0gbnVsbCkgY29udGludWU7XG5cdFx0aWYgKCFpc05lc3RlZEZyb3plbihuZXN0ZWRWYWx1ZSkpIHJldHVybiBmYWxzZTtcblx0fVxuXHRyZXR1cm4gdHJ1ZTtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVNlcmlhbGl6YWJsZVN0YXRlSW52YXJpYW50TWlkZGxld2FyZShvcHRpb25zID0ge30pIHtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIikgcmV0dXJuICgpID0+IChuZXh0KSA9PiAoYWN0aW9uKSA9PiBuZXh0KGFjdGlvbik7XG5cdGVsc2Uge1xuXHRcdGNvbnN0IHsgaXNTZXJpYWxpemFibGUgPSBpc1BsYWluLCBnZXRFbnRyaWVzLCBpZ25vcmVkQWN0aW9ucyA9IFtdLCBpZ25vcmVkQWN0aW9uUGF0aHMgPSBbXCJtZXRhLmFyZ1wiLCBcIm1ldGEuYmFzZVF1ZXJ5TWV0YVwiXSwgaWdub3JlZFBhdGhzID0gW10sIHdhcm5BZnRlciA9IDMyLCBpZ25vcmVTdGF0ZSA9IGZhbHNlLCBpZ25vcmVBY3Rpb25zID0gZmFsc2UsIGRpc2FibGVDYWNoZSA9IGZhbHNlIH0gPSBvcHRpb25zO1xuXHRcdGNvbnN0IGNhY2hlID0gIWRpc2FibGVDYWNoZSAmJiBXZWFrU2V0ID8gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrU2V0KCkgOiB2b2lkIDA7XG5cdFx0cmV0dXJuIChzdG9yZUFQSSkgPT4gKG5leHQpID0+IChhY3Rpb24pID0+IHtcblx0XHRcdGlmICghaXNBY3Rpb24oYWN0aW9uKSkgcmV0dXJuIG5leHQoYWN0aW9uKTtcblx0XHRcdGNvbnN0IHJlc3VsdCA9IG5leHQoYWN0aW9uKTtcblx0XHRcdGNvbnN0IG1lYXN1cmVVdGlscyA9IGdldFRpbWVNZWFzdXJlVXRpbHMod2FybkFmdGVyLCBcIlNlcmlhbGl6YWJsZVN0YXRlSW52YXJpYW50TWlkZGxld2FyZVwiKTtcblx0XHRcdGlmICghaWdub3JlQWN0aW9ucyAmJiAhKGlnbm9yZWRBY3Rpb25zLmxlbmd0aCAmJiBpZ25vcmVkQWN0aW9ucy5pbmRleE9mKGFjdGlvbi50eXBlKSAhPT0gLTEpKSBtZWFzdXJlVXRpbHMubWVhc3VyZVRpbWUoKCkgPT4ge1xuXHRcdFx0XHRjb25zdCBmb3VuZEFjdGlvbk5vblNlcmlhbGl6YWJsZVZhbHVlID0gZmluZE5vblNlcmlhbGl6YWJsZVZhbHVlKGFjdGlvbiwgXCJcIiwgaXNTZXJpYWxpemFibGUsIGdldEVudHJpZXMsIGlnbm9yZWRBY3Rpb25QYXRocywgY2FjaGUpO1xuXHRcdFx0XHRpZiAoZm91bmRBY3Rpb25Ob25TZXJpYWxpemFibGVWYWx1ZSkge1xuXHRcdFx0XHRcdGNvbnN0IHsga2V5UGF0aCwgdmFsdWUgfSA9IGZvdW5kQWN0aW9uTm9uU2VyaWFsaXphYmxlVmFsdWU7XG5cdFx0XHRcdFx0Y29uc29sZS5lcnJvcihgQSBub24tc2VyaWFsaXphYmxlIHZhbHVlIHdhcyBkZXRlY3RlZCBpbiBhbiBhY3Rpb24sIGluIHRoZSBwYXRoOiBcXGAke2tleVBhdGh9XFxgLiBWYWx1ZTpgLCB2YWx1ZSwgXCJcXG5UYWtlIGEgbG9vayBhdCB0aGUgbG9naWMgdGhhdCBkaXNwYXRjaGVkIHRoaXMgYWN0aW9uOiBcIiwgYWN0aW9uLCBcIlxcbihTZWUgaHR0cHM6Ly9yZWR1eC5qcy5vcmcvZmFxL2FjdGlvbnMjd2h5LXNob3VsZC10eXBlLWJlLWEtc3RyaW5nLXdoeS1zaG91bGQtbXktYWN0aW9uLXR5cGVzLWJlLWNvbnN0YW50cylcIiwgXCJcXG4oVG8gYWxsb3cgbm9uLXNlcmlhbGl6YWJsZSB2YWx1ZXMgc2VlOiBodHRwczovL3JlZHV4LXRvb2xraXQuanMub3JnL3VzYWdlL3VzYWdlLWd1aWRlI3dvcmtpbmctd2l0aC1ub24tc2VyaWFsaXphYmxlLWRhdGEpXCIpO1xuXHRcdFx0XHR9XG5cdFx0XHR9KTtcblx0XHRcdGlmICghaWdub3JlU3RhdGUpIHtcblx0XHRcdFx0bWVhc3VyZVV0aWxzLm1lYXN1cmVUaW1lKCgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBmb3VuZFN0YXRlTm9uU2VyaWFsaXphYmxlVmFsdWUgPSBmaW5kTm9uU2VyaWFsaXphYmxlVmFsdWUoc3RvcmVBUEkuZ2V0U3RhdGUoKSwgXCJcIiwgaXNTZXJpYWxpemFibGUsIGdldEVudHJpZXMsIGlnbm9yZWRQYXRocywgY2FjaGUpO1xuXHRcdFx0XHRcdGlmIChmb3VuZFN0YXRlTm9uU2VyaWFsaXphYmxlVmFsdWUpIHtcblx0XHRcdFx0XHRcdGNvbnN0IHsga2V5UGF0aCwgdmFsdWUgfSA9IGZvdW5kU3RhdGVOb25TZXJpYWxpemFibGVWYWx1ZTtcblx0XHRcdFx0XHRcdGNvbnNvbGUuZXJyb3IoYEEgbm9uLXNlcmlhbGl6YWJsZSB2YWx1ZSB3YXMgZGV0ZWN0ZWQgaW4gdGhlIHN0YXRlLCBpbiB0aGUgcGF0aDogXFxgJHtrZXlQYXRofVxcYC4gVmFsdWU6YCwgdmFsdWUsIGBcblRha2UgYSBsb29rIGF0IHRoZSByZWR1Y2VyKHMpIGhhbmRsaW5nIHRoaXMgYWN0aW9uIHR5cGU6ICR7YWN0aW9uLnR5cGV9LlxuKFNlZSBodHRwczovL3JlZHV4LmpzLm9yZy9mYXEvb3JnYW5pemluZy1zdGF0ZSNjYW4taS1wdXQtZnVuY3Rpb25zLXByb21pc2VzLW9yLW90aGVyLW5vbi1zZXJpYWxpemFibGUtaXRlbXMtaW4tbXktc3RvcmUtc3RhdGUpYCk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9KTtcblx0XHRcdFx0bWVhc3VyZVV0aWxzLndhcm5JZkV4Y2VlZGVkKCk7XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gcmVzdWx0O1xuXHRcdH07XG5cdH1cbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9nZXREZWZhdWx0TWlkZGxld2FyZS50c1xuZnVuY3Rpb24gaXNCb29sZWFuKHgpIHtcblx0cmV0dXJuIHR5cGVvZiB4ID09PSBcImJvb2xlYW5cIjtcbn1cbmNvbnN0IGJ1aWxkR2V0RGVmYXVsdE1pZGRsZXdhcmUgPSAoKSA9PiBmdW5jdGlvbiBnZXREZWZhdWx0TWlkZGxld2FyZShvcHRpb25zKSB7XG5cdGNvbnN0IHsgdGh1bms6IHRodW5rJDEgPSB0cnVlLCBpbW11dGFibGVDaGVjayA9IHRydWUsIHNlcmlhbGl6YWJsZUNoZWNrID0gdHJ1ZSwgYWN0aW9uQ3JlYXRvckNoZWNrID0gdHJ1ZSB9ID0gb3B0aW9ucyA/PyB7fTtcblx0bGV0IG1pZGRsZXdhcmVBcnJheSA9IG5ldyBUdXBsZSgpO1xuXHRpZiAodGh1bmskMSkge1xuXHRcdGlmIChpc0Jvb2xlYW4odGh1bmskMSkpIG1pZGRsZXdhcmVBcnJheS5wdXNoKHRodW5rKTtcblx0XHRlbHNlIG1pZGRsZXdhcmVBcnJheS5wdXNoKHdpdGhFeHRyYUFyZ3VtZW50KHRodW5rJDEuZXh0cmFBcmd1bWVudCkpO1xuXHR9XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRpZiAoaW1tdXRhYmxlQ2hlY2spIHtcblx0XHRcdGxldCBpbW11dGFibGVPcHRpb25zID0ge307XG5cdFx0XHRpZiAoIWlzQm9vbGVhbihpbW11dGFibGVDaGVjaykpIGltbXV0YWJsZU9wdGlvbnMgPSBpbW11dGFibGVDaGVjaztcblx0XHRcdG1pZGRsZXdhcmVBcnJheS51bnNoaWZ0KGNyZWF0ZUltbXV0YWJsZVN0YXRlSW52YXJpYW50TWlkZGxld2FyZShpbW11dGFibGVPcHRpb25zKSk7XG5cdFx0fVxuXHRcdGlmIChzZXJpYWxpemFibGVDaGVjaykge1xuXHRcdFx0bGV0IHNlcmlhbGl6YWJsZU9wdGlvbnMgPSB7fTtcblx0XHRcdGlmICghaXNCb29sZWFuKHNlcmlhbGl6YWJsZUNoZWNrKSkgc2VyaWFsaXphYmxlT3B0aW9ucyA9IHNlcmlhbGl6YWJsZUNoZWNrO1xuXHRcdFx0bWlkZGxld2FyZUFycmF5LnB1c2goY3JlYXRlU2VyaWFsaXphYmxlU3RhdGVJbnZhcmlhbnRNaWRkbGV3YXJlKHNlcmlhbGl6YWJsZU9wdGlvbnMpKTtcblx0XHR9XG5cdFx0aWYgKGFjdGlvbkNyZWF0b3JDaGVjaykge1xuXHRcdFx0bGV0IGFjdGlvbkNyZWF0b3JPcHRpb25zID0ge307XG5cdFx0XHRpZiAoIWlzQm9vbGVhbihhY3Rpb25DcmVhdG9yQ2hlY2spKSBhY3Rpb25DcmVhdG9yT3B0aW9ucyA9IGFjdGlvbkNyZWF0b3JDaGVjaztcblx0XHRcdG1pZGRsZXdhcmVBcnJheS51bnNoaWZ0KGNyZWF0ZUFjdGlvbkNyZWF0b3JJbnZhcmlhbnRNaWRkbGV3YXJlKGFjdGlvbkNyZWF0b3JPcHRpb25zKSk7XG5cdFx0fVxuXHR9XG5cdHJldHVybiBtaWRkbGV3YXJlQXJyYXk7XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2F1dG9CYXRjaEVuaGFuY2VyLnRzXG5jb25zdCBTSE9VTERfQVVUT0JBVENIID0gXCJSVEtfYXV0b0JhdGNoXCI7XG5jb25zdCBwcmVwYXJlQXV0b0JhdGNoZWQgPSAoKSA9PiAocGF5bG9hZCkgPT4gKHtcblx0cGF5bG9hZCxcblx0bWV0YTogeyBbU0hPVUxEX0FVVE9CQVRDSF06IHRydWUgfVxufSk7XG5jb25zdCBjcmVhdGVRdWV1ZVdpdGhUaW1lciA9ICh0aW1lb3V0KSA9PiB7XG5cdHJldHVybiAobm90aWZ5KSA9PiB7XG5cdFx0c2V0VGltZW91dChub3RpZnksIHRpbWVvdXQpO1xuXHR9O1xufTtcbmNvbnN0IGNyZWF0ZVJhZldpdGhGYWxsYmFja1RpbWVyID0gKHJhZiwgdGltZW91dCkgPT4ge1xuXHRyZXR1cm4gKG5vdGlmeSkgPT4ge1xuXHRcdGxldCBjYWxsZWQgPSBmYWxzZTtcblx0XHRsZXQgcmFmSWQ7XG5cdFx0bGV0IHRpbWVySWQ7XG5cdFx0Y29uc3QgY2FsbGJhY2sgPSAoKSA9PiB7XG5cdFx0XHRpZiAoY2FsbGVkKSByZXR1cm47XG5cdFx0XHRjYWxsZWQgPSB0cnVlO1xuXHRcdFx0Y2FuY2VsQW5pbWF0aW9uRnJhbWUocmFmSWQpO1xuXHRcdFx0Y2xlYXJUaW1lb3V0KHRpbWVySWQpO1xuXHRcdFx0bm90aWZ5KCk7XG5cdFx0fTtcblx0XHRyYWZJZCA9IHJhZihjYWxsYmFjayk7XG5cdFx0dGltZXJJZCA9IHNldFRpbWVvdXQoY2FsbGJhY2ssIHRpbWVvdXQpO1xuXHR9O1xufTtcbmNvbnN0IGF1dG9CYXRjaEVuaGFuY2VyID0gKG9wdGlvbnMgPSB7IHR5cGU6IFwicmFmXCIgfSkgPT4gKG5leHQpID0+ICguLi5hcmdzKSA9PiB7XG5cdGNvbnN0IHN0b3JlID0gbmV4dCguLi5hcmdzKTtcblx0bGV0IG5vdGlmeWluZyA9IHRydWU7XG5cdGxldCBzaG91bGROb3RpZnlBdEVuZE9mVGljayA9IGZhbHNlO1xuXHRsZXQgbm90aWZpY2F0aW9uUXVldWVkID0gZmFsc2U7XG5cdGNvbnN0IGxpc3RlbmVycyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdGNvbnN0IHF1ZXVlQ2FsbGJhY2sgPSBvcHRpb25zLnR5cGUgPT09IFwidGlja1wiID8gcXVldWVNaWNyb3Rhc2sgOiBvcHRpb25zLnR5cGUgPT09IFwicmFmXCIgPyB0eXBlb2Ygd2luZG93ICE9PSBcInVuZGVmaW5lZFwiICYmIHdpbmRvdy5yZXF1ZXN0QW5pbWF0aW9uRnJhbWUgPyBjcmVhdGVSYWZXaXRoRmFsbGJhY2tUaW1lcih3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lLCAxMDApIDogY3JlYXRlUXVldWVXaXRoVGltZXIoMTApIDogb3B0aW9ucy50eXBlID09PSBcImNhbGxiYWNrXCIgPyBvcHRpb25zLnF1ZXVlTm90aWZpY2F0aW9uIDogY3JlYXRlUXVldWVXaXRoVGltZXIob3B0aW9ucy50aW1lb3V0KTtcblx0Y29uc3Qgbm90aWZ5TGlzdGVuZXJzID0gKCkgPT4ge1xuXHRcdG5vdGlmaWNhdGlvblF1ZXVlZCA9IGZhbHNlO1xuXHRcdGlmIChzaG91bGROb3RpZnlBdEVuZE9mVGljaykge1xuXHRcdFx0c2hvdWxkTm90aWZ5QXRFbmRPZlRpY2sgPSBmYWxzZTtcblx0XHRcdGxpc3RlbmVycy5mb3JFYWNoKChsKSA9PiBsKCkpO1xuXHRcdH1cblx0fTtcblx0cmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIHN0b3JlLCB7XG5cdFx0c3Vic2NyaWJlKGxpc3RlbmVyKSB7XG5cdFx0XHRjb25zdCB3cmFwcGVkTGlzdGVuZXIgPSAoKSA9PiBub3RpZnlpbmcgJiYgbGlzdGVuZXIoKTtcblx0XHRcdGNvbnN0IHVuc3Vic2NyaWJlID0gc3RvcmUuc3Vic2NyaWJlKHdyYXBwZWRMaXN0ZW5lcik7XG5cdFx0XHRsaXN0ZW5lcnMuYWRkKGxpc3RlbmVyKTtcblx0XHRcdHJldHVybiAoKSA9PiB7XG5cdFx0XHRcdHVuc3Vic2NyaWJlKCk7XG5cdFx0XHRcdGxpc3RlbmVycy5kZWxldGUobGlzdGVuZXIpO1xuXHRcdFx0fTtcblx0XHR9LFxuXHRcdGRpc3BhdGNoKGFjdGlvbikge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0bm90aWZ5aW5nID0gIWFjdGlvbj8ubWV0YT8uW1NIT1VMRF9BVVRPQkFUQ0hdO1xuXHRcdFx0XHRzaG91bGROb3RpZnlBdEVuZE9mVGljayA9ICFub3RpZnlpbmc7XG5cdFx0XHRcdGlmIChzaG91bGROb3RpZnlBdEVuZE9mVGljaykge1xuXHRcdFx0XHRcdGlmICghbm90aWZpY2F0aW9uUXVldWVkKSB7XG5cdFx0XHRcdFx0XHRub3RpZmljYXRpb25RdWV1ZWQgPSB0cnVlO1xuXHRcdFx0XHRcdFx0cXVldWVDYWxsYmFjayhub3RpZnlMaXN0ZW5lcnMpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZXR1cm4gc3RvcmUuZGlzcGF0Y2goYWN0aW9uKTtcblx0XHRcdH0gZmluYWxseSB7XG5cdFx0XHRcdG5vdGlmeWluZyA9IHRydWU7XG5cdFx0XHR9XG5cdFx0fVxuXHR9KTtcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvZ2V0RGVmYXVsdEVuaGFuY2Vycy50c1xuY29uc3QgYnVpbGRHZXREZWZhdWx0RW5oYW5jZXJzID0gKG1pZGRsZXdhcmVFbmhhbmNlcikgPT4gZnVuY3Rpb24gZ2V0RGVmYXVsdEVuaGFuY2VycyhvcHRpb25zKSB7XG5cdGNvbnN0IHsgYXV0b0JhdGNoID0gdHJ1ZSB9ID0gb3B0aW9ucyA/PyB7fTtcblx0bGV0IGVuaGFuY2VyQXJyYXkgPSBuZXcgVHVwbGUobWlkZGxld2FyZUVuaGFuY2VyKTtcblx0aWYgKGF1dG9CYXRjaCkgZW5oYW5jZXJBcnJheS5wdXNoKGF1dG9CYXRjaEVuaGFuY2VyKHR5cGVvZiBhdXRvQmF0Y2ggPT09IFwib2JqZWN0XCIgPyBhdXRvQmF0Y2ggOiB2b2lkIDApKTtcblx0cmV0dXJuIGVuaGFuY2VyQXJyYXk7XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvbmZpZ3VyZVN0b3JlLnRzXG5mdW5jdGlvbiBjb25maWd1cmVTdG9yZShvcHRpb25zKSB7XG5cdGNvbnN0IGdldERlZmF1bHRNaWRkbGV3YXJlID0gYnVpbGRHZXREZWZhdWx0TWlkZGxld2FyZSgpO1xuXHRjb25zdCB7IHJlZHVjZXIgPSB2b2lkIDAsIG1pZGRsZXdhcmUsIGRldlRvb2xzID0gdHJ1ZSwgZHVwbGljYXRlTWlkZGxld2FyZUNoZWNrID0gdHJ1ZSwgcHJlbG9hZGVkU3RhdGUgPSB2b2lkIDAsIGVuaGFuY2VycyA9IHZvaWQgMCB9ID0gb3B0aW9ucyB8fCB7fTtcblx0bGV0IHJvb3RSZWR1Y2VyO1xuXHRpZiAodHlwZW9mIHJlZHVjZXIgPT09IFwiZnVuY3Rpb25cIikgcm9vdFJlZHVjZXIgPSByZWR1Y2VyO1xuXHRlbHNlIGlmIChpc1BsYWluT2JqZWN0KHJlZHVjZXIpKSByb290UmVkdWNlciA9IGNvbWJpbmVSZWR1Y2VycyQxKHJlZHVjZXIpO1xuXHRlbHNlIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDEpIDogXCJgcmVkdWNlcmAgaXMgYSByZXF1aXJlZCBhcmd1bWVudCwgYW5kIG11c3QgYmUgYSBmdW5jdGlvbiBvciBhbiBvYmplY3Qgb2YgZnVuY3Rpb25zIHRoYXQgY2FuIGJlIHBhc3NlZCB0byBjb21iaW5lUmVkdWNlcnNcIik7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgbWlkZGxld2FyZSAmJiB0eXBlb2YgbWlkZGxld2FyZSAhPT0gXCJmdW5jdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgyKSA6IFwiYG1pZGRsZXdhcmVgIGZpZWxkIG11c3QgYmUgYSBjYWxsYmFja1wiKTtcblx0bGV0IGZpbmFsTWlkZGxld2FyZTtcblx0aWYgKHR5cGVvZiBtaWRkbGV3YXJlID09PSBcImZ1bmN0aW9uXCIpIHtcblx0XHRmaW5hbE1pZGRsZXdhcmUgPSBtaWRkbGV3YXJlKGdldERlZmF1bHRNaWRkbGV3YXJlKTtcblx0XHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmICFBcnJheS5pc0FycmF5KGZpbmFsTWlkZGxld2FyZSkpIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDMpIDogXCJ3aGVuIHVzaW5nIGEgbWlkZGxld2FyZSBidWlsZGVyIGZ1bmN0aW9uLCBhbiBhcnJheSBvZiBtaWRkbGV3YXJlIG11c3QgYmUgcmV0dXJuZWRcIik7XG5cdH0gZWxzZSBmaW5hbE1pZGRsZXdhcmUgPSBnZXREZWZhdWx0TWlkZGxld2FyZSgpO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGZpbmFsTWlkZGxld2FyZS5zb21lKChpdGVtKSA9PiB0eXBlb2YgaXRlbSAhPT0gXCJmdW5jdGlvblwiKSkgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoNCkgOiBcImVhY2ggbWlkZGxld2FyZSBwcm92aWRlZCB0byBjb25maWd1cmVTdG9yZSBtdXN0IGJlIGEgZnVuY3Rpb25cIik7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgZHVwbGljYXRlTWlkZGxld2FyZUNoZWNrKSB7XG5cdFx0bGV0IG1pZGRsZXdhcmVSZWZlcmVuY2VzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoKTtcblx0XHRmaW5hbE1pZGRsZXdhcmUuZm9yRWFjaCgobWlkZGxld2FyZSkgPT4ge1xuXHRcdFx0aWYgKG1pZGRsZXdhcmVSZWZlcmVuY2VzLmhhcyhtaWRkbGV3YXJlKSkgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoNDIpIDogXCJEdXBsaWNhdGUgbWlkZGxld2FyZSByZWZlcmVuY2VzIGZvdW5kIHdoZW4gY3JlYXRpbmcgdGhlIHN0b3JlLiBFbnN1cmUgdGhhdCBlYWNoIG1pZGRsZXdhcmUgaXMgb25seSBpbmNsdWRlZCBvbmNlLlwiKTtcblx0XHRcdG1pZGRsZXdhcmVSZWZlcmVuY2VzLmFkZChtaWRkbGV3YXJlKTtcblx0XHR9KTtcblx0fVxuXHRsZXQgZmluYWxDb21wb3NlID0gY29tcG9zZTtcblx0aWYgKGRldlRvb2xzKSBmaW5hbENvbXBvc2UgPSBjb21wb3NlV2l0aERldlRvb2xzKHtcblx0XHR0cmFjZTogcHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiLFxuXHRcdC4uLnR5cGVvZiBkZXZUb29scyA9PT0gXCJvYmplY3RcIiAmJiBkZXZUb29sc1xuXHR9KTtcblx0Y29uc3QgbWlkZGxld2FyZUVuaGFuY2VyID0gYXBwbHlNaWRkbGV3YXJlKC4uLmZpbmFsTWlkZGxld2FyZSk7XG5cdGNvbnN0IGdldERlZmF1bHRFbmhhbmNlcnMgPSBidWlsZEdldERlZmF1bHRFbmhhbmNlcnMobWlkZGxld2FyZUVuaGFuY2VyKTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBlbmhhbmNlcnMgJiYgdHlwZW9mIGVuaGFuY2VycyAhPT0gXCJmdW5jdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSg1KSA6IFwiYGVuaGFuY2Vyc2AgZmllbGQgbXVzdCBiZSBhIGNhbGxiYWNrXCIpO1xuXHRsZXQgc3RvcmVFbmhhbmNlcnMgPSB0eXBlb2YgZW5oYW5jZXJzID09PSBcImZ1bmN0aW9uXCIgPyBlbmhhbmNlcnMoZ2V0RGVmYXVsdEVuaGFuY2VycykgOiBnZXREZWZhdWx0RW5oYW5jZXJzKCk7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgIUFycmF5LmlzQXJyYXkoc3RvcmVFbmhhbmNlcnMpKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSg2KSA6IFwiYGVuaGFuY2Vyc2AgY2FsbGJhY2sgbXVzdCByZXR1cm4gYW4gYXJyYXlcIik7XG5cdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIgJiYgc3RvcmVFbmhhbmNlcnMuc29tZSgoaXRlbSkgPT4gdHlwZW9mIGl0ZW0gIT09IFwiZnVuY3Rpb25cIikpIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDcpIDogXCJlYWNoIGVuaGFuY2VyIHByb3ZpZGVkIHRvIGNvbmZpZ3VyZVN0b3JlIG11c3QgYmUgYSBmdW5jdGlvblwiKTtcblx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIiAmJiBmaW5hbE1pZGRsZXdhcmUubGVuZ3RoICYmICFzdG9yZUVuaGFuY2Vycy5pbmNsdWRlcyhtaWRkbGV3YXJlRW5oYW5jZXIpKSBjb25zb2xlLmVycm9yKFwibWlkZGxld2FyZXMgd2VyZSBwcm92aWRlZCwgYnV0IG1pZGRsZXdhcmUgZW5oYW5jZXIgd2FzIG5vdCBpbmNsdWRlZCBpbiBmaW5hbCBlbmhhbmNlcnMgLSBtYWtlIHN1cmUgdG8gY2FsbCBgZ2V0RGVmYXVsdEVuaGFuY2Vyc2BcIik7XG5cdGNvbnN0IGNvbXBvc2VkRW5oYW5jZXIgPSBmaW5hbENvbXBvc2UoLi4uc3RvcmVFbmhhbmNlcnMpO1xuXHRyZXR1cm4gY3JlYXRlU3RvcmUocm9vdFJlZHVjZXIsIHByZWxvYWRlZFN0YXRlLCBjb21wb3NlZEVuaGFuY2VyKTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9tYXBCdWlsZGVycy50c1xuZnVuY3Rpb24gZXhlY3V0ZVJlZHVjZXJCdWlsZGVyQ2FsbGJhY2soYnVpbGRlckNhbGxiYWNrKSB7XG5cdGNvbnN0IGFjdGlvbnNNYXAgPSB7fTtcblx0Y29uc3QgYWN0aW9uTWF0Y2hlcnMgPSBbXTtcblx0bGV0IGRlZmF1bHRDYXNlUmVkdWNlcjtcblx0Y29uc3QgYnVpbGRlciA9IHtcblx0XHRhZGRDYXNlKHR5cGVPckFjdGlvbkNyZWF0b3IsIHJlZHVjZXIpIHtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdFx0aWYgKGFjdGlvbk1hdGNoZXJzLmxlbmd0aCA+IDApIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDI2KSA6IFwiYGJ1aWxkZXIuYWRkQ2FzZWAgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIGJlZm9yZSBjYWxsaW5nIGBidWlsZGVyLmFkZE1hdGNoZXJgXCIpO1xuXHRcdFx0XHRpZiAoZGVmYXVsdENhc2VSZWR1Y2VyKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgyNykgOiBcImBidWlsZGVyLmFkZENhc2VgIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBiZWZvcmUgY2FsbGluZyBgYnVpbGRlci5hZGREZWZhdWx0Q2FzZWBcIik7XG5cdFx0XHR9XG5cdFx0XHRjb25zdCB0eXBlID0gdHlwZW9mIHR5cGVPckFjdGlvbkNyZWF0b3IgPT09IFwic3RyaW5nXCIgPyB0eXBlT3JBY3Rpb25DcmVhdG9yIDogdHlwZU9yQWN0aW9uQ3JlYXRvci50eXBlO1xuXHRcdFx0aWYgKCF0eXBlKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgyOCkgOiBcImBidWlsZGVyLmFkZENhc2VgIGNhbm5vdCBiZSBjYWxsZWQgd2l0aCBhbiBlbXB0eSBhY3Rpb24gdHlwZVwiKTtcblx0XHRcdGlmICh0eXBlIGluIGFjdGlvbnNNYXApIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDI5KSA6IGBcXGBidWlsZGVyLmFkZENhc2VcXGAgY2Fubm90IGJlIGNhbGxlZCB3aXRoIHR3byByZWR1Y2VycyBmb3IgdGhlIHNhbWUgYWN0aW9uIHR5cGUgJyR7dHlwZX0nYCk7XG5cdFx0XHRhY3Rpb25zTWFwW3R5cGVdID0gcmVkdWNlcjtcblx0XHRcdHJldHVybiBidWlsZGVyO1xuXHRcdH0sXG5cdFx0YWRkQXN5bmNUaHVuayhhc3luY1RodW5rLCByZWR1Y2Vycykge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAoZGVmYXVsdENhc2VSZWR1Y2VyKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSg0MykgOiBcImBidWlsZGVyLmFkZEFzeW5jVGh1bmtgIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBiZWZvcmUgY2FsbGluZyBgYnVpbGRlci5hZGREZWZhdWx0Q2FzZWBcIik7XG5cdFx0XHR9XG5cdFx0XHRpZiAocmVkdWNlcnMucGVuZGluZykgYWN0aW9uc01hcFthc3luY1RodW5rLnBlbmRpbmcudHlwZV0gPSByZWR1Y2Vycy5wZW5kaW5nO1xuXHRcdFx0aWYgKHJlZHVjZXJzLnJlamVjdGVkKSBhY3Rpb25zTWFwW2FzeW5jVGh1bmsucmVqZWN0ZWQudHlwZV0gPSByZWR1Y2Vycy5yZWplY3RlZDtcblx0XHRcdGlmIChyZWR1Y2Vycy5mdWxmaWxsZWQpIGFjdGlvbnNNYXBbYXN5bmNUaHVuay5mdWxmaWxsZWQudHlwZV0gPSByZWR1Y2Vycy5mdWxmaWxsZWQ7XG5cdFx0XHRpZiAocmVkdWNlcnMuc2V0dGxlZCkgYWN0aW9uTWF0Y2hlcnMucHVzaCh7XG5cdFx0XHRcdG1hdGNoZXI6IGFzeW5jVGh1bmsuc2V0dGxlZCxcblx0XHRcdFx0cmVkdWNlcjogcmVkdWNlcnMuc2V0dGxlZFxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gYnVpbGRlcjtcblx0XHR9LFxuXHRcdGFkZE1hdGNoZXIobWF0Y2hlciwgcmVkdWNlcikge1xuXHRcdFx0aWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSBcInByb2R1Y3Rpb25cIikge1xuXHRcdFx0XHRpZiAoZGVmYXVsdENhc2VSZWR1Y2VyKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgzMCkgOiBcImBidWlsZGVyLmFkZE1hdGNoZXJgIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBiZWZvcmUgY2FsbGluZyBgYnVpbGRlci5hZGREZWZhdWx0Q2FzZWBcIik7XG5cdFx0XHR9XG5cdFx0XHRhY3Rpb25NYXRjaGVycy5wdXNoKHtcblx0XHRcdFx0bWF0Y2hlcixcblx0XHRcdFx0cmVkdWNlclxuXHRcdFx0fSk7XG5cdFx0XHRyZXR1cm4gYnVpbGRlcjtcblx0XHR9LFxuXHRcdGFkZERlZmF1bHRDYXNlKHJlZHVjZXIpIHtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdFx0aWYgKGRlZmF1bHRDYXNlUmVkdWNlcikgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMzEpIDogXCJgYnVpbGRlci5hZGREZWZhdWx0Q2FzZWAgY2FuIG9ubHkgYmUgY2FsbGVkIG9uY2VcIik7XG5cdFx0XHR9XG5cdFx0XHRkZWZhdWx0Q2FzZVJlZHVjZXIgPSByZWR1Y2VyO1xuXHRcdFx0cmV0dXJuIGJ1aWxkZXI7XG5cdFx0fVxuXHR9O1xuXHRidWlsZGVyQ2FsbGJhY2soYnVpbGRlcik7XG5cdHJldHVybiBbXG5cdFx0YWN0aW9uc01hcCxcblx0XHRhY3Rpb25NYXRjaGVycyxcblx0XHRkZWZhdWx0Q2FzZVJlZHVjZXJcblx0XTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jcmVhdGVSZWR1Y2VyLnRzXG5mdW5jdGlvbiBpc1N0YXRlRnVuY3Rpb24oeCkge1xuXHRyZXR1cm4gdHlwZW9mIHggPT09IFwiZnVuY3Rpb25cIjtcbn1cbmZ1bmN0aW9uIGNyZWF0ZVJlZHVjZXIoaW5pdGlhbFN0YXRlLCBtYXBPckJ1aWxkZXJDYWxsYmFjaykge1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB7XG5cdFx0aWYgKHR5cGVvZiBtYXBPckJ1aWxkZXJDYWxsYmFjayA9PT0gXCJvYmplY3RcIikgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoOCkgOiBcIlRoZSBvYmplY3Qgbm90YXRpb24gZm9yIGBjcmVhdGVSZWR1Y2VyYCBoYXMgYmVlbiByZW1vdmVkLiBQbGVhc2UgdXNlIHRoZSAnYnVpbGRlciBjYWxsYmFjaycgbm90YXRpb24gaW5zdGVhZDogaHR0cHM6Ly9yZWR1eC10b29sa2l0LmpzLm9yZy9hcGkvY3JlYXRlUmVkdWNlclwiKTtcblx0fVxuXHRsZXQgW2FjdGlvbnNNYXAsIGZpbmFsQWN0aW9uTWF0Y2hlcnMsIGZpbmFsRGVmYXVsdENhc2VSZWR1Y2VyXSA9IGV4ZWN1dGVSZWR1Y2VyQnVpbGRlckNhbGxiYWNrKG1hcE9yQnVpbGRlckNhbGxiYWNrKTtcblx0bGV0IGdldEluaXRpYWxTdGF0ZTtcblx0aWYgKGlzU3RhdGVGdW5jdGlvbihpbml0aWFsU3RhdGUpKSBnZXRJbml0aWFsU3RhdGUgPSAoKSA9PiBmcmVlemVEcmFmdGFibGUoaW5pdGlhbFN0YXRlKCkpO1xuXHRlbHNlIHtcblx0XHRjb25zdCBmcm96ZW5Jbml0aWFsU3RhdGUgPSBmcmVlemVEcmFmdGFibGUoaW5pdGlhbFN0YXRlKTtcblx0XHRnZXRJbml0aWFsU3RhdGUgPSAoKSA9PiBmcm96ZW5Jbml0aWFsU3RhdGU7XG5cdH1cblx0ZnVuY3Rpb24gcmVkdWNlcihzdGF0ZSA9IGdldEluaXRpYWxTdGF0ZSgpLCBhY3Rpb24pIHtcblx0XHRsZXQgY2FzZVJlZHVjZXJzID0gW2FjdGlvbnNNYXBbYWN0aW9uLnR5cGVdLCAuLi5maW5hbEFjdGlvbk1hdGNoZXJzLmZpbHRlcigoeyBtYXRjaGVyIH0pID0+IG1hdGNoZXIoYWN0aW9uKSkubWFwKCh7IHJlZHVjZXIgfSkgPT4gcmVkdWNlcildO1xuXHRcdGlmIChjYXNlUmVkdWNlcnMuZmlsdGVyKChjcikgPT4gISFjcikubGVuZ3RoID09PSAwKSBjYXNlUmVkdWNlcnMgPSBbZmluYWxEZWZhdWx0Q2FzZVJlZHVjZXJdO1xuXHRcdHJldHVybiBjYXNlUmVkdWNlcnMucmVkdWNlKChwcmV2aW91c1N0YXRlLCBjYXNlUmVkdWNlcikgPT4ge1xuXHRcdFx0aWYgKGNhc2VSZWR1Y2VyKSB7XG5cdFx0XHRcdGlmIChpc0RyYWZ0KHByZXZpb3VzU3RhdGUpKSB7XG5cdFx0XHRcdFx0Y29uc3QgcmVzdWx0ID0gY2FzZVJlZHVjZXIocHJldmlvdXNTdGF0ZSwgYWN0aW9uKTtcblx0XHRcdFx0XHRpZiAocmVzdWx0ID09PSB2b2lkIDApIHJldHVybiBwcmV2aW91c1N0YXRlO1xuXHRcdFx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0XHRcdH0gZWxzZSBpZiAoIWlzRHJhZnRhYmxlKHByZXZpb3VzU3RhdGUpKSB7XG5cdFx0XHRcdFx0Y29uc3QgcmVzdWx0ID0gY2FzZVJlZHVjZXIocHJldmlvdXNTdGF0ZSwgYWN0aW9uKTtcblx0XHRcdFx0XHRpZiAocmVzdWx0ID09PSB2b2lkIDApIHtcblx0XHRcdFx0XHRcdGlmIChwcmV2aW91c1N0YXRlID09PSBudWxsKSByZXR1cm4gcHJldmlvdXNTdGF0ZTtcblx0XHRcdFx0XHRcdHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDkpIDogXCJBIGNhc2UgcmVkdWNlciBvbiBhIG5vbi1kcmFmdGFibGUgdmFsdWUgbXVzdCBub3QgcmV0dXJuIHVuZGVmaW5lZFwiKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0cmV0dXJuIHJlc3VsdDtcblx0XHRcdFx0fSBlbHNlIHJldHVybiBjcmVhdGVOZXh0U3RhdGUocHJldmlvdXNTdGF0ZSwgKGRyYWZ0KSA9PiB7XG5cdFx0XHRcdFx0cmV0dXJuIGNhc2VSZWR1Y2VyKGRyYWZ0LCBhY3Rpb24pO1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiBwcmV2aW91c1N0YXRlO1xuXHRcdH0sIHN0YXRlKTtcblx0fVxuXHRyZWR1Y2VyLmdldEluaXRpYWxTdGF0ZSA9IGdldEluaXRpYWxTdGF0ZTtcblx0cmV0dXJuIHJlZHVjZXI7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbWF0Y2hlcnMudHNcbmNvbnN0IG1hdGNoZXMgPSAobWF0Y2hlciwgYWN0aW9uKSA9PiB7XG5cdGlmIChoYXNNYXRjaEZ1bmN0aW9uKG1hdGNoZXIpKSByZXR1cm4gbWF0Y2hlci5tYXRjaChhY3Rpb24pO1xuXHRlbHNlIHJldHVybiBtYXRjaGVyKGFjdGlvbik7XG59O1xuZnVuY3Rpb24gaXNBbnlPZiguLi5tYXRjaGVycykge1xuXHRyZXR1cm4gKGFjdGlvbikgPT4ge1xuXHRcdHJldHVybiBtYXRjaGVycy5zb21lKChtYXRjaGVyKSA9PiBtYXRjaGVzKG1hdGNoZXIsIGFjdGlvbikpO1xuXHR9O1xufVxuZnVuY3Rpb24gaXNBbGxPZiguLi5tYXRjaGVycykge1xuXHRyZXR1cm4gKGFjdGlvbikgPT4ge1xuXHRcdHJldHVybiBtYXRjaGVycy5ldmVyeSgobWF0Y2hlcikgPT4gbWF0Y2hlcyhtYXRjaGVyLCBhY3Rpb24pKTtcblx0fTtcbn1cbmZ1bmN0aW9uIGhhc0V4cGVjdGVkUmVxdWVzdE1ldGFkYXRhKGFjdGlvbiwgdmFsaWRTdGF0dXMpIHtcblx0aWYgKCFhY3Rpb24gfHwgIWFjdGlvbi5tZXRhKSByZXR1cm4gZmFsc2U7XG5cdGNvbnN0IGhhc1ZhbGlkUmVxdWVzdElkID0gdHlwZW9mIGFjdGlvbi5tZXRhLnJlcXVlc3RJZCA9PT0gXCJzdHJpbmdcIjtcblx0Y29uc3QgaGFzVmFsaWRSZXF1ZXN0U3RhdHVzID0gdmFsaWRTdGF0dXMuaW5kZXhPZihhY3Rpb24ubWV0YS5yZXF1ZXN0U3RhdHVzKSA+IC0xO1xuXHRyZXR1cm4gaGFzVmFsaWRSZXF1ZXN0SWQgJiYgaGFzVmFsaWRSZXF1ZXN0U3RhdHVzO1xufVxuZnVuY3Rpb24gaXNBc3luY1RodW5rQXJyYXkoYSkge1xuXHRyZXR1cm4gdHlwZW9mIGFbMF0gPT09IFwiZnVuY3Rpb25cIiAmJiBcInBlbmRpbmdcIiBpbiBhWzBdICYmIFwiZnVsZmlsbGVkXCIgaW4gYVswXSAmJiBcInJlamVjdGVkXCIgaW4gYVswXTtcbn1cbmZ1bmN0aW9uIGlzUGVuZGluZyguLi5hc3luY1RodW5rcykge1xuXHRpZiAoYXN5bmNUaHVua3MubGVuZ3RoID09PSAwKSByZXR1cm4gKGFjdGlvbikgPT4gaGFzRXhwZWN0ZWRSZXF1ZXN0TWV0YWRhdGEoYWN0aW9uLCBbXCJwZW5kaW5nXCJdKTtcblx0aWYgKCFpc0FzeW5jVGh1bmtBcnJheShhc3luY1RodW5rcykpIHJldHVybiBpc1BlbmRpbmcoKShhc3luY1RodW5rc1swXSk7XG5cdHJldHVybiBpc0FueU9mKC4uLmFzeW5jVGh1bmtzLm1hcCgoYXN5bmNUaHVuaykgPT4gYXN5bmNUaHVuay5wZW5kaW5nKSk7XG59XG5mdW5jdGlvbiBpc1JlamVjdGVkKC4uLmFzeW5jVGh1bmtzKSB7XG5cdGlmIChhc3luY1RodW5rcy5sZW5ndGggPT09IDApIHJldHVybiAoYWN0aW9uKSA9PiBoYXNFeHBlY3RlZFJlcXVlc3RNZXRhZGF0YShhY3Rpb24sIFtcInJlamVjdGVkXCJdKTtcblx0aWYgKCFpc0FzeW5jVGh1bmtBcnJheShhc3luY1RodW5rcykpIHJldHVybiBpc1JlamVjdGVkKCkoYXN5bmNUaHVua3NbMF0pO1xuXHRyZXR1cm4gaXNBbnlPZiguLi5hc3luY1RodW5rcy5tYXAoKGFzeW5jVGh1bmspID0+IGFzeW5jVGh1bmsucmVqZWN0ZWQpKTtcbn1cbmZ1bmN0aW9uIGlzUmVqZWN0ZWRXaXRoVmFsdWUoLi4uYXN5bmNUaHVua3MpIHtcblx0Y29uc3QgaGFzRmxhZyA9IChhY3Rpb24pID0+IHtcblx0XHRyZXR1cm4gYWN0aW9uICYmIGFjdGlvbi5tZXRhICYmIGFjdGlvbi5tZXRhLnJlamVjdGVkV2l0aFZhbHVlO1xuXHR9O1xuXHRpZiAoYXN5bmNUaHVua3MubGVuZ3RoID09PSAwKSByZXR1cm4gaXNBbGxPZihpc1JlamVjdGVkKC4uLmFzeW5jVGh1bmtzKSwgaGFzRmxhZyk7XG5cdGlmICghaXNBc3luY1RodW5rQXJyYXkoYXN5bmNUaHVua3MpKSByZXR1cm4gaXNSZWplY3RlZFdpdGhWYWx1ZSgpKGFzeW5jVGh1bmtzWzBdKTtcblx0cmV0dXJuIGlzQWxsT2YoaXNSZWplY3RlZCguLi5hc3luY1RodW5rcyksIGhhc0ZsYWcpO1xufVxuZnVuY3Rpb24gaXNGdWxmaWxsZWQoLi4uYXN5bmNUaHVua3MpIHtcblx0aWYgKGFzeW5jVGh1bmtzLmxlbmd0aCA9PT0gMCkgcmV0dXJuIChhY3Rpb24pID0+IGhhc0V4cGVjdGVkUmVxdWVzdE1ldGFkYXRhKGFjdGlvbiwgW1wiZnVsZmlsbGVkXCJdKTtcblx0aWYgKCFpc0FzeW5jVGh1bmtBcnJheShhc3luY1RodW5rcykpIHJldHVybiBpc0Z1bGZpbGxlZCgpKGFzeW5jVGh1bmtzWzBdKTtcblx0cmV0dXJuIGlzQW55T2YoLi4uYXN5bmNUaHVua3MubWFwKChhc3luY1RodW5rKSA9PiBhc3luY1RodW5rLmZ1bGZpbGxlZCkpO1xufVxuZnVuY3Rpb24gaXNBc3luY1RodW5rQWN0aW9uKC4uLmFzeW5jVGh1bmtzKSB7XG5cdGlmIChhc3luY1RodW5rcy5sZW5ndGggPT09IDApIHJldHVybiAoYWN0aW9uKSA9PiBoYXNFeHBlY3RlZFJlcXVlc3RNZXRhZGF0YShhY3Rpb24sIFtcblx0XHRcInBlbmRpbmdcIixcblx0XHRcImZ1bGZpbGxlZFwiLFxuXHRcdFwicmVqZWN0ZWRcIlxuXHRdKTtcblx0aWYgKCFpc0FzeW5jVGh1bmtBcnJheShhc3luY1RodW5rcykpIHJldHVybiBpc0FzeW5jVGh1bmtBY3Rpb24oKShhc3luY1RodW5rc1swXSk7XG5cdHJldHVybiBpc0FueU9mKC4uLmFzeW5jVGh1bmtzLmZsYXRNYXAoKGFzeW5jVGh1bmspID0+IFtcblx0XHRhc3luY1RodW5rLnBlbmRpbmcsXG5cdFx0YXN5bmNUaHVuay5yZWplY3RlZCxcblx0XHRhc3luY1RodW5rLmZ1bGZpbGxlZFxuXHRdKSk7XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvbmFub2lkLnRzXG5sZXQgdXJsQWxwaGFiZXQgPSBcIk1vZHVsZVN5bWJoYXNPd25Qci0wMTIzNDU2Nzg5QUJDREVGR0hOUlZmZ2N0aVV2el9LcVlUSmtMeHBaWElqUVdcIjtcbmxldCBuYW5vaWQgPSAoc2l6ZSA9IDIxKSA9PiB7XG5cdGxldCBpZCA9IFwiXCI7XG5cdGxldCBpID0gc2l6ZTtcblx0d2hpbGUgKGktLSkgaWQgKz0gdXJsQWxwaGFiZXRbTWF0aC5yYW5kb20oKSAqIDY0IHwgMF07XG5cdHJldHVybiBpZDtcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvY3JlYXRlQXN5bmNUaHVuay50c1xuY29uc3QgY29tbW9uUHJvcGVydGllcyA9IFtcblx0XCJuYW1lXCIsXG5cdFwibWVzc2FnZVwiLFxuXHRcInN0YWNrXCIsXG5cdFwiY29kZVwiXG5dO1xudmFyIFJlamVjdFdpdGhWYWx1ZSA9IGNsYXNzIHtcblx0cGF5bG9hZDtcblx0bWV0YTtcblx0X3R5cGU7XG5cdGNvbnN0cnVjdG9yKHBheWxvYWQsIG1ldGEpIHtcblx0XHR0aGlzLnBheWxvYWQgPSBwYXlsb2FkO1xuXHRcdHRoaXMubWV0YSA9IG1ldGE7XG5cdH1cbn07XG52YXIgRnVsZmlsbFdpdGhNZXRhID0gY2xhc3Mge1xuXHRwYXlsb2FkO1xuXHRtZXRhO1xuXHRfdHlwZTtcblx0Y29uc3RydWN0b3IocGF5bG9hZCwgbWV0YSkge1xuXHRcdHRoaXMucGF5bG9hZCA9IHBheWxvYWQ7XG5cdFx0dGhpcy5tZXRhID0gbWV0YTtcblx0fVxufTtcbmNvbnN0IG1pbmlTZXJpYWxpemVFcnJvciA9ICh2YWx1ZSkgPT4ge1xuXHRpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsKSB7XG5cdFx0Y29uc3Qgc2ltcGxlRXJyb3IgPSB7fTtcblx0XHRmb3IgKGNvbnN0IHByb3BlcnR5IG9mIGNvbW1vblByb3BlcnRpZXMpIGlmICh0eXBlb2YgdmFsdWVbcHJvcGVydHldID09PSBcInN0cmluZ1wiKSBzaW1wbGVFcnJvcltwcm9wZXJ0eV0gPSB2YWx1ZVtwcm9wZXJ0eV07XG5cdFx0cmV0dXJuIHNpbXBsZUVycm9yO1xuXHR9XG5cdHJldHVybiB7IG1lc3NhZ2U6IFN0cmluZyh2YWx1ZSkgfTtcbn07XG5jb25zdCBleHRlcm5hbEFib3J0TWVzc2FnZSA9IFwiRXh0ZXJuYWwgc2lnbmFsIHdhcyBhYm9ydGVkXCI7XG5jb25zdCBjcmVhdGVBc3luY1RodW5rID0gLyogQF9fUFVSRV9fICovICgoKSA9PiB7XG5cdGZ1bmN0aW9uIGNyZWF0ZUFzeW5jVGh1bmsodHlwZVByZWZpeCwgcGF5bG9hZENyZWF0b3IsIG9wdGlvbnMpIHtcblx0XHRjb25zdCBmdWxmaWxsZWQgPSBjcmVhdGVBY3Rpb24odHlwZVByZWZpeCArIFwiL2Z1bGZpbGxlZFwiLCAocGF5bG9hZCwgcmVxdWVzdElkLCBhcmcsIG1ldGEpID0+ICh7XG5cdFx0XHRwYXlsb2FkLFxuXHRcdFx0bWV0YToge1xuXHRcdFx0XHQuLi5tZXRhIHx8IHt9LFxuXHRcdFx0XHRhcmcsXG5cdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0cmVxdWVzdFN0YXR1czogXCJmdWxmaWxsZWRcIlxuXHRcdFx0fVxuXHRcdH0pKTtcblx0XHRjb25zdCBwZW5kaW5nID0gY3JlYXRlQWN0aW9uKHR5cGVQcmVmaXggKyBcIi9wZW5kaW5nXCIsIChyZXF1ZXN0SWQsIGFyZywgbWV0YSkgPT4gKHtcblx0XHRcdHBheWxvYWQ6IHZvaWQgMCxcblx0XHRcdG1ldGE6IHtcblx0XHRcdFx0Li4ubWV0YSB8fCB7fSxcblx0XHRcdFx0YXJnLFxuXHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdHJlcXVlc3RTdGF0dXM6IFwicGVuZGluZ1wiXG5cdFx0XHR9XG5cdFx0fSkpO1xuXHRcdGNvbnN0IHJlamVjdGVkID0gY3JlYXRlQWN0aW9uKHR5cGVQcmVmaXggKyBcIi9yZWplY3RlZFwiLCAoZXJyb3IsIHJlcXVlc3RJZCwgYXJnLCBwYXlsb2FkLCBtZXRhKSA9PiAoe1xuXHRcdFx0cGF5bG9hZCxcblx0XHRcdGVycm9yOiAob3B0aW9ucyAmJiBvcHRpb25zLnNlcmlhbGl6ZUVycm9yIHx8IG1pbmlTZXJpYWxpemVFcnJvcikoZXJyb3IgfHwgXCJSZWplY3RlZFwiKSxcblx0XHRcdG1ldGE6IHtcblx0XHRcdFx0Li4ubWV0YSB8fCB7fSxcblx0XHRcdFx0YXJnLFxuXHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdHJlamVjdGVkV2l0aFZhbHVlOiBwYXlsb2FkICE9PSB2b2lkIDAsXG5cdFx0XHRcdHJlcXVlc3RTdGF0dXM6IFwicmVqZWN0ZWRcIixcblx0XHRcdFx0YWJvcnRlZDogZXJyb3I/Lm5hbWUgPT09IFwiQWJvcnRFcnJvclwiLFxuXHRcdFx0XHRjb25kaXRpb246IGVycm9yPy5uYW1lID09PSBcIkNvbmRpdGlvbkVycm9yXCJcblx0XHRcdH1cblx0XHR9KSk7XG5cdFx0ZnVuY3Rpb24gYWN0aW9uQ3JlYXRvcihhcmcsIHsgc2lnbmFsIH0gPSB7fSkge1xuXHRcdFx0cmV0dXJuIChkaXNwYXRjaCwgZ2V0U3RhdGUsIGV4dHJhKSA9PiB7XG5cdFx0XHRcdGNvbnN0IHJlcXVlc3RJZCA9IG9wdGlvbnM/LmlkR2VuZXJhdG9yID8gb3B0aW9ucy5pZEdlbmVyYXRvcihhcmcpIDogbmFub2lkKCk7XG5cdFx0XHRcdGNvbnN0IGFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRcdFx0bGV0IGFib3J0SGFuZGxlcjtcblx0XHRcdFx0bGV0IGFib3J0UmVhc29uO1xuXHRcdFx0XHRmdW5jdGlvbiBhYm9ydChyZWFzb24pIHtcblx0XHRcdFx0XHRhYm9ydFJlYXNvbiA9IHJlYXNvbjtcblx0XHRcdFx0XHRhYm9ydENvbnRyb2xsZXIuYWJvcnQoKTtcblx0XHRcdFx0fVxuXHRcdFx0XHRpZiAoc2lnbmFsKSB7XG5cdFx0XHRcdFx0aWYgKHNpZ25hbC5hYm9ydGVkKSBhYm9ydChleHRlcm5hbEFib3J0TWVzc2FnZSk7XG5cdFx0XHRcdFx0ZWxzZSBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsICgpID0+IGFib3J0KGV4dGVybmFsQWJvcnRNZXNzYWdlKSwgeyBvbmNlOiB0cnVlIH0pO1xuXHRcdFx0XHR9XG5cdFx0XHRcdGNvbnN0IHByb21pc2UgPSBhc3luYyBmdW5jdGlvbigpIHtcblx0XHRcdFx0XHRsZXQgZmluYWxBY3Rpb247XG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdGxldCBjb25kaXRpb25SZXN1bHQgPSBvcHRpb25zPy5jb25kaXRpb24/LihhcmcsIHtcblx0XHRcdFx0XHRcdFx0Z2V0U3RhdGUsXG5cdFx0XHRcdFx0XHRcdGV4dHJhXG5cdFx0XHRcdFx0XHR9KTtcblx0XHRcdFx0XHRcdGlmIChpc1RoZW5hYmxlKGNvbmRpdGlvblJlc3VsdCkpIGNvbmRpdGlvblJlc3VsdCA9IGF3YWl0IGNvbmRpdGlvblJlc3VsdDtcblx0XHRcdFx0XHRcdGlmIChjb25kaXRpb25SZXN1bHQgPT09IGZhbHNlKSB0aHJvdyB7XG5cdFx0XHRcdFx0XHRcdG5hbWU6IFwiQ29uZGl0aW9uRXJyb3JcIixcblx0XHRcdFx0XHRcdFx0bWVzc2FnZTogXCJBYm9ydGVkIGR1ZSB0byBjb25kaXRpb24gY2FsbGJhY2sgcmV0dXJuaW5nIGZhbHNlLlwiXG5cdFx0XHRcdFx0XHR9O1xuXHRcdFx0XHRcdFx0aWYgKGFib3J0Q29udHJvbGxlci5zaWduYWwuYWJvcnRlZCkgdGhyb3cge1xuXHRcdFx0XHRcdFx0XHRuYW1lOiBcIkFib3J0RXJyb3JcIixcblx0XHRcdFx0XHRcdFx0bWVzc2FnZTogYWJvcnRSZWFzb24gfHwgXCJBYm9ydGVkXCJcblx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRjb25zdCBhYm9ydGVkUHJvbWlzZSA9IG5ldyBQcm9taXNlKChfLCByZWplY3QpID0+IHtcblx0XHRcdFx0XHRcdFx0YWJvcnRIYW5kbGVyID0gKCkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdHJlamVjdCh7XG5cdFx0XHRcdFx0XHRcdFx0XHRuYW1lOiBcIkFib3J0RXJyb3JcIixcblx0XHRcdFx0XHRcdFx0XHRcdG1lc3NhZ2U6IGFib3J0UmVhc29uIHx8IFwiQWJvcnRlZFwiXG5cdFx0XHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHRcdH07XG5cdFx0XHRcdFx0XHRcdGFib3J0Q29udHJvbGxlci5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcihcImFib3J0XCIsIGFib3J0SGFuZGxlciwgeyBvbmNlOiB0cnVlIH0pO1xuXHRcdFx0XHRcdFx0fSk7XG5cdFx0XHRcdFx0XHRkaXNwYXRjaChwZW5kaW5nKHJlcXVlc3RJZCwgYXJnLCBvcHRpb25zPy5nZXRQZW5kaW5nTWV0YT8uKHtcblx0XHRcdFx0XHRcdFx0cmVxdWVzdElkLFxuXHRcdFx0XHRcdFx0XHRhcmdcblx0XHRcdFx0XHRcdH0sIHtcblx0XHRcdFx0XHRcdFx0Z2V0U3RhdGUsXG5cdFx0XHRcdFx0XHRcdGV4dHJhXG5cdFx0XHRcdFx0XHR9KSkpO1xuXHRcdFx0XHRcdFx0ZmluYWxBY3Rpb24gPSBhd2FpdCBQcm9taXNlLnJhY2UoW2Fib3J0ZWRQcm9taXNlLCBQcm9taXNlLnJlc29sdmUocGF5bG9hZENyZWF0b3IoYXJnLCB7XG5cdFx0XHRcdFx0XHRcdGRpc3BhdGNoLFxuXHRcdFx0XHRcdFx0XHRnZXRTdGF0ZSxcblx0XHRcdFx0XHRcdFx0ZXh0cmEsXG5cdFx0XHRcdFx0XHRcdHJlcXVlc3RJZCxcblx0XHRcdFx0XHRcdFx0c2lnbmFsOiBhYm9ydENvbnRyb2xsZXIuc2lnbmFsLFxuXHRcdFx0XHRcdFx0XHRhYm9ydCxcblx0XHRcdFx0XHRcdFx0cmVqZWN0V2l0aFZhbHVlOiAoKHZhbHVlLCBtZXRhKSA9PiB7XG5cdFx0XHRcdFx0XHRcdFx0cmV0dXJuIG5ldyBSZWplY3RXaXRoVmFsdWUodmFsdWUsIG1ldGEpO1xuXHRcdFx0XHRcdFx0XHR9KSxcblx0XHRcdFx0XHRcdFx0ZnVsZmlsbFdpdGhWYWx1ZTogKCh2YWx1ZSwgbWV0YSkgPT4ge1xuXHRcdFx0XHRcdFx0XHRcdHJldHVybiBuZXcgRnVsZmlsbFdpdGhNZXRhKHZhbHVlLCBtZXRhKTtcblx0XHRcdFx0XHRcdFx0fSlcblx0XHRcdFx0XHRcdH0pKS50aGVuKChyZXN1bHQpID0+IHtcblx0XHRcdFx0XHRcdFx0aWYgKHJlc3VsdCBpbnN0YW5jZW9mIFJlamVjdFdpdGhWYWx1ZSkgdGhyb3cgcmVzdWx0O1xuXHRcdFx0XHRcdFx0XHRpZiAocmVzdWx0IGluc3RhbmNlb2YgRnVsZmlsbFdpdGhNZXRhKSByZXR1cm4gZnVsZmlsbGVkKHJlc3VsdC5wYXlsb2FkLCByZXF1ZXN0SWQsIGFyZywgcmVzdWx0Lm1ldGEpO1xuXHRcdFx0XHRcdFx0XHRyZXR1cm4gZnVsZmlsbGVkKHJlc3VsdCwgcmVxdWVzdElkLCBhcmcpO1xuXHRcdFx0XHRcdFx0fSldKTtcblx0XHRcdFx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdFx0XHRcdGZpbmFsQWN0aW9uID0gZXJyIGluc3RhbmNlb2YgUmVqZWN0V2l0aFZhbHVlID8gcmVqZWN0ZWQobnVsbCwgcmVxdWVzdElkLCBhcmcsIGVyci5wYXlsb2FkLCBlcnIubWV0YSkgOiByZWplY3RlZChlcnIsIHJlcXVlc3RJZCwgYXJnKTtcblx0XHRcdFx0XHR9IGZpbmFsbHkge1xuXHRcdFx0XHRcdFx0aWYgKGFib3J0SGFuZGxlcikgYWJvcnRDb250cm9sbGVyLnNpZ25hbC5yZW1vdmVFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgYWJvcnRIYW5kbGVyKTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCEob3B0aW9ucyAmJiAhb3B0aW9ucy5kaXNwYXRjaENvbmRpdGlvblJlamVjdGlvbiAmJiByZWplY3RlZC5tYXRjaChmaW5hbEFjdGlvbikgJiYgZmluYWxBY3Rpb24ubWV0YS5jb25kaXRpb24pKSBkaXNwYXRjaChmaW5hbEFjdGlvbik7XG5cdFx0XHRcdFx0cmV0dXJuIGZpbmFsQWN0aW9uO1xuXHRcdFx0XHR9KCk7XG5cdFx0XHRcdHJldHVybiBPYmplY3QuYXNzaWduKHByb21pc2UsIHtcblx0XHRcdFx0XHRhYm9ydCxcblx0XHRcdFx0XHRyZXF1ZXN0SWQsXG5cdFx0XHRcdFx0YXJnLFxuXHRcdFx0XHRcdHVud3JhcCgpIHtcblx0XHRcdFx0XHRcdHJldHVybiBwcm9taXNlLnRoZW4odW53cmFwUmVzdWx0KTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pO1xuXHRcdFx0fTtcblx0XHR9XG5cdFx0cmV0dXJuIE9iamVjdC5hc3NpZ24oYWN0aW9uQ3JlYXRvciwge1xuXHRcdFx0cGVuZGluZyxcblx0XHRcdHJlamVjdGVkLFxuXHRcdFx0ZnVsZmlsbGVkLFxuXHRcdFx0c2V0dGxlZDogaXNBbnlPZihyZWplY3RlZCwgZnVsZmlsbGVkKSxcblx0XHRcdHR5cGVQcmVmaXhcblx0XHR9KTtcblx0fVxuXHRjcmVhdGVBc3luY1RodW5rLndpdGhUeXBlcyA9ICgpID0+IGNyZWF0ZUFzeW5jVGh1bms7XG5cdHJldHVybiBjcmVhdGVBc3luY1RodW5rO1xufSkoKTtcbmZ1bmN0aW9uIHVud3JhcFJlc3VsdChhY3Rpb24pIHtcblx0aWYgKGFjdGlvbi5tZXRhICYmIGFjdGlvbi5tZXRhLnJlamVjdGVkV2l0aFZhbHVlKSB0aHJvdyBhY3Rpb24ucGF5bG9hZDtcblx0aWYgKGFjdGlvbi5lcnJvcikgdGhyb3cgYWN0aW9uLmVycm9yO1xuXHRyZXR1cm4gYWN0aW9uLnBheWxvYWQ7XG59XG5mdW5jdGlvbiBpc1RoZW5hYmxlKHZhbHVlKSB7XG5cdHJldHVybiB2YWx1ZSAhPT0gbnVsbCAmJiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIHZhbHVlLnRoZW4gPT09IFwiZnVuY3Rpb25cIjtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9jcmVhdGVTbGljZS50c1xuY29uc3QgYXN5bmNUaHVua1N5bWJvbCA9IC8qIEBfX1BVUkVfXyAqLyBTeW1ib2wuZm9yKFwicnRrLXNsaWNlLWNyZWF0ZWFzeW5jdGh1bmtcIik7XG5jb25zdCBhc3luY1RodW5rQ3JlYXRvciA9IHsgW2FzeW5jVGh1bmtTeW1ib2xdOiBjcmVhdGVBc3luY1RodW5rIH07XG5sZXQgUmVkdWNlclR5cGUgPSAvKiBAX19QVVJFX18gKi8gZnVuY3Rpb24oUmVkdWNlclR5cGUpIHtcblx0UmVkdWNlclR5cGVbXCJyZWR1Y2VyXCJdID0gXCJyZWR1Y2VyXCI7XG5cdFJlZHVjZXJUeXBlW1wicmVkdWNlcldpdGhQcmVwYXJlXCJdID0gXCJyZWR1Y2VyV2l0aFByZXBhcmVcIjtcblx0UmVkdWNlclR5cGVbXCJhc3luY1RodW5rXCJdID0gXCJhc3luY1RodW5rXCI7XG5cdHJldHVybiBSZWR1Y2VyVHlwZTtcbn0oe30pO1xuZnVuY3Rpb24gZ2V0VHlwZShzbGljZSwgYWN0aW9uS2V5KSB7XG5cdHJldHVybiBgJHtzbGljZX0vJHthY3Rpb25LZXl9YDtcbn1cbmZ1bmN0aW9uIGJ1aWxkQ3JlYXRlU2xpY2UoeyBjcmVhdG9ycyB9ID0ge30pIHtcblx0Y29uc3QgY0FUID0gY3JlYXRvcnM/LmFzeW5jVGh1bms/Llthc3luY1RodW5rU3ltYm9sXTtcblx0cmV0dXJuIGZ1bmN0aW9uIGNyZWF0ZVNsaWNlKG9wdGlvbnMpIHtcblx0XHRjb25zdCB7IG5hbWUsIHJlZHVjZXJQYXRoID0gbmFtZSB9ID0gb3B0aW9ucztcblx0XHRpZiAoIW5hbWUpIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDExKSA6IFwiYG5hbWVgIGlzIGEgcmVxdWlyZWQgb3B0aW9uIGZvciBjcmVhdGVTbGljZVwiKTtcblx0XHRpZiAodHlwZW9mIHByb2Nlc3MgIT09IFwidW5kZWZpbmVkXCIgJiYgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwiZGV2ZWxvcG1lbnRcIikge1xuXHRcdFx0aWYgKG9wdGlvbnMuaW5pdGlhbFN0YXRlID09PSB2b2lkIDApIGNvbnNvbGUuZXJyb3IoXCJZb3UgbXVzdCBwcm92aWRlIGFuIGBpbml0aWFsU3RhdGVgIHZhbHVlIHRoYXQgaXMgbm90IGB1bmRlZmluZWRgLiBZb3UgbWF5IGhhdmUgbWlzc3BlbGxlZCBgaW5pdGlhbFN0YXRlYFwiKTtcblx0XHR9XG5cdFx0Y29uc3QgcmVkdWNlcnMgPSAodHlwZW9mIG9wdGlvbnMucmVkdWNlcnMgPT09IFwiZnVuY3Rpb25cIiA/IG9wdGlvbnMucmVkdWNlcnMoYnVpbGRSZWR1Y2VyQ3JlYXRvcnMoKSkgOiBvcHRpb25zLnJlZHVjZXJzKSB8fCB7fTtcblx0XHRjb25zdCByZWR1Y2VyTmFtZXMgPSBPYmplY3Qua2V5cyhyZWR1Y2Vycyk7XG5cdFx0Y29uc3QgY29udGV4dCA9IHtcblx0XHRcdHNsaWNlQ2FzZVJlZHVjZXJzQnlOYW1lOiB7fSxcblx0XHRcdHNsaWNlQ2FzZVJlZHVjZXJzQnlUeXBlOiB7fSxcblx0XHRcdGFjdGlvbkNyZWF0b3JzOiB7fSxcblx0XHRcdHNsaWNlTWF0Y2hlcnM6IFtdXG5cdFx0fTtcblx0XHRjb25zdCBjb250ZXh0TWV0aG9kcyA9IHtcblx0XHRcdGFkZENhc2UodHlwZU9yQWN0aW9uQ3JlYXRvciwgcmVkdWNlcikge1xuXHRcdFx0XHRjb25zdCB0eXBlID0gdHlwZW9mIHR5cGVPckFjdGlvbkNyZWF0b3IgPT09IFwic3RyaW5nXCIgPyB0eXBlT3JBY3Rpb25DcmVhdG9yIDogdHlwZU9yQWN0aW9uQ3JlYXRvci50eXBlO1xuXHRcdFx0XHRpZiAoIXR5cGUpIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDEyKSA6IFwiYGNvbnRleHQuYWRkQ2FzZWAgY2Fubm90IGJlIGNhbGxlZCB3aXRoIGFuIGVtcHR5IGFjdGlvbiB0eXBlXCIpO1xuXHRcdFx0XHRpZiAodHlwZSBpbiBjb250ZXh0LnNsaWNlQ2FzZVJlZHVjZXJzQnlUeXBlKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxMykgOiBcImBjb250ZXh0LmFkZENhc2VgIGNhbm5vdCBiZSBjYWxsZWQgd2l0aCB0d28gcmVkdWNlcnMgZm9yIHRoZSBzYW1lIGFjdGlvbiB0eXBlOiBcIiArIHR5cGUpO1xuXHRcdFx0XHRjb250ZXh0LnNsaWNlQ2FzZVJlZHVjZXJzQnlUeXBlW3R5cGVdID0gcmVkdWNlcjtcblx0XHRcdFx0cmV0dXJuIGNvbnRleHRNZXRob2RzO1xuXHRcdFx0fSxcblx0XHRcdGFkZE1hdGNoZXIobWF0Y2hlciwgcmVkdWNlcikge1xuXHRcdFx0XHRjb250ZXh0LnNsaWNlTWF0Y2hlcnMucHVzaCh7XG5cdFx0XHRcdFx0bWF0Y2hlcixcblx0XHRcdFx0XHRyZWR1Y2VyXG5cdFx0XHRcdH0pO1xuXHRcdFx0XHRyZXR1cm4gY29udGV4dE1ldGhvZHM7XG5cdFx0XHR9LFxuXHRcdFx0ZXhwb3NlQWN0aW9uKG5hbWUsIGFjdGlvbkNyZWF0b3IpIHtcblx0XHRcdFx0Y29udGV4dC5hY3Rpb25DcmVhdG9yc1tuYW1lXSA9IGFjdGlvbkNyZWF0b3I7XG5cdFx0XHRcdHJldHVybiBjb250ZXh0TWV0aG9kcztcblx0XHRcdH0sXG5cdFx0XHRleHBvc2VDYXNlUmVkdWNlcihuYW1lLCByZWR1Y2VyKSB7XG5cdFx0XHRcdGNvbnRleHQuc2xpY2VDYXNlUmVkdWNlcnNCeU5hbWVbbmFtZV0gPSByZWR1Y2VyO1xuXHRcdFx0XHRyZXR1cm4gY29udGV4dE1ldGhvZHM7XG5cdFx0XHR9XG5cdFx0fTtcblx0XHRyZWR1Y2VyTmFtZXMuZm9yRWFjaCgocmVkdWNlck5hbWUpID0+IHtcblx0XHRcdGNvbnN0IHJlZHVjZXJEZWZpbml0aW9uID0gcmVkdWNlcnNbcmVkdWNlck5hbWVdO1xuXHRcdFx0Y29uc3QgcmVkdWNlckRldGFpbHMgPSB7XG5cdFx0XHRcdHJlZHVjZXJOYW1lLFxuXHRcdFx0XHR0eXBlOiBnZXRUeXBlKG5hbWUsIHJlZHVjZXJOYW1lKSxcblx0XHRcdFx0Y3JlYXRlTm90YXRpb246IHR5cGVvZiBvcHRpb25zLnJlZHVjZXJzID09PSBcImZ1bmN0aW9uXCJcblx0XHRcdH07XG5cdFx0XHRpZiAoaXNBc3luY1RodW5rU2xpY2VSZWR1Y2VyRGVmaW5pdGlvbihyZWR1Y2VyRGVmaW5pdGlvbikpIGhhbmRsZVRodW5rQ2FzZVJlZHVjZXJEZWZpbml0aW9uKHJlZHVjZXJEZXRhaWxzLCByZWR1Y2VyRGVmaW5pdGlvbiwgY29udGV4dE1ldGhvZHMsIGNBVCk7XG5cdFx0XHRlbHNlIGhhbmRsZU5vcm1hbFJlZHVjZXJEZWZpbml0aW9uKHJlZHVjZXJEZXRhaWxzLCByZWR1Y2VyRGVmaW5pdGlvbiwgY29udGV4dE1ldGhvZHMpO1xuXHRcdH0pO1xuXHRcdGZ1bmN0aW9uIGJ1aWxkUmVkdWNlcigpIHtcblx0XHRcdGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJwcm9kdWN0aW9uXCIpIHtcblx0XHRcdFx0aWYgKHR5cGVvZiBvcHRpb25zLmV4dHJhUmVkdWNlcnMgPT09IFwib2JqZWN0XCIpIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDE0KSA6IFwiVGhlIG9iamVjdCBub3RhdGlvbiBmb3IgYGNyZWF0ZVNsaWNlLmV4dHJhUmVkdWNlcnNgIGhhcyBiZWVuIHJlbW92ZWQuIFBsZWFzZSB1c2UgdGhlICdidWlsZGVyIGNhbGxiYWNrJyBub3RhdGlvbiBpbnN0ZWFkOiBodHRwczovL3JlZHV4LXRvb2xraXQuanMub3JnL2FwaS9jcmVhdGVTbGljZVwiKTtcblx0XHRcdH1cblx0XHRcdGNvbnN0IFtleHRyYVJlZHVjZXJzID0ge30sIGFjdGlvbk1hdGNoZXJzID0gW10sIGRlZmF1bHRDYXNlUmVkdWNlciA9IHZvaWQgMF0gPSB0eXBlb2Ygb3B0aW9ucy5leHRyYVJlZHVjZXJzID09PSBcImZ1bmN0aW9uXCIgPyBleGVjdXRlUmVkdWNlckJ1aWxkZXJDYWxsYmFjayhvcHRpb25zLmV4dHJhUmVkdWNlcnMpIDogW29wdGlvbnMuZXh0cmFSZWR1Y2Vyc107XG5cdFx0XHRjb25zdCBmaW5hbENhc2VSZWR1Y2VycyA9IHtcblx0XHRcdFx0Li4uZXh0cmFSZWR1Y2Vycyxcblx0XHRcdFx0Li4uY29udGV4dC5zbGljZUNhc2VSZWR1Y2Vyc0J5VHlwZVxuXHRcdFx0fTtcblx0XHRcdHJldHVybiBjcmVhdGVSZWR1Y2VyKG9wdGlvbnMuaW5pdGlhbFN0YXRlLCAoYnVpbGRlcikgPT4ge1xuXHRcdFx0XHRmb3IgKGxldCBrZXkgaW4gZmluYWxDYXNlUmVkdWNlcnMpIGJ1aWxkZXIuYWRkQ2FzZShrZXksIGZpbmFsQ2FzZVJlZHVjZXJzW2tleV0pO1xuXHRcdFx0XHRmb3IgKGxldCBzTSBvZiBjb250ZXh0LnNsaWNlTWF0Y2hlcnMpIGJ1aWxkZXIuYWRkTWF0Y2hlcihzTS5tYXRjaGVyLCBzTS5yZWR1Y2VyKTtcblx0XHRcdFx0Zm9yIChsZXQgbSBvZiBhY3Rpb25NYXRjaGVycykgYnVpbGRlci5hZGRNYXRjaGVyKG0ubWF0Y2hlciwgbS5yZWR1Y2VyKTtcblx0XHRcdFx0aWYgKGRlZmF1bHRDYXNlUmVkdWNlcikgYnVpbGRlci5hZGREZWZhdWx0Q2FzZShkZWZhdWx0Q2FzZVJlZHVjZXIpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdGNvbnN0IHNlbGVjdFNlbGYgPSAoc3RhdGUpID0+IHN0YXRlO1xuXHRcdGNvbnN0IGluamVjdGVkU2VsZWN0b3JDYWNoZSA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdFx0Y29uc3QgaW5qZWN0ZWRTdGF0ZUNhY2hlID0gLyogQF9fUFVSRV9fICovIG5ldyBXZWFrTWFwKCk7XG5cdFx0bGV0IF9yZWR1Y2VyO1xuXHRcdGZ1bmN0aW9uIHJlZHVjZXIoc3RhdGUsIGFjdGlvbikge1xuXHRcdFx0aWYgKCFfcmVkdWNlcikgX3JlZHVjZXIgPSBidWlsZFJlZHVjZXIoKTtcblx0XHRcdHJldHVybiBfcmVkdWNlcihzdGF0ZSwgYWN0aW9uKTtcblx0XHR9XG5cdFx0ZnVuY3Rpb24gZ2V0SW5pdGlhbFN0YXRlKCkge1xuXHRcdFx0aWYgKCFfcmVkdWNlcikgX3JlZHVjZXIgPSBidWlsZFJlZHVjZXIoKTtcblx0XHRcdHJldHVybiBfcmVkdWNlci5nZXRJbml0aWFsU3RhdGUoKTtcblx0XHR9XG5cdFx0ZnVuY3Rpb24gbWFrZVNlbGVjdG9yUHJvcHMocmVkdWNlclBhdGgsIGluamVjdGVkID0gZmFsc2UpIHtcblx0XHRcdGZ1bmN0aW9uIHNlbGVjdFNsaWNlKHN0YXRlKSB7XG5cdFx0XHRcdGxldCBzbGljZVN0YXRlID0gc3RhdGVbcmVkdWNlclBhdGhdO1xuXHRcdFx0XHRpZiAodHlwZW9mIHNsaWNlU3RhdGUgPT09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdFx0XHRpZiAoaW5qZWN0ZWQpIHNsaWNlU3RhdGUgPSBnZXRPckluc2VydENvbXB1dGVkKGluamVjdGVkU3RhdGVDYWNoZSwgc2VsZWN0U2xpY2UsIGdldEluaXRpYWxTdGF0ZSk7XG5cdFx0XHRcdFx0ZWxzZSBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxNSkgOiBcInNlbGVjdFNsaWNlIHJldHVybmVkIHVuZGVmaW5lZCBmb3IgYW4gdW5pbmplY3RlZCBzbGljZSByZWR1Y2VyXCIpO1xuXHRcdFx0XHR9XG5cdFx0XHRcdHJldHVybiBzbGljZVN0YXRlO1xuXHRcdFx0fVxuXHRcdFx0ZnVuY3Rpb24gZ2V0U2VsZWN0b3JzKHNlbGVjdFN0YXRlID0gc2VsZWN0U2VsZikge1xuXHRcdFx0XHRyZXR1cm4gZ2V0T3JJbnNlcnRDb21wdXRlZChnZXRPckluc2VydENvbXB1dGVkKGluamVjdGVkU2VsZWN0b3JDYWNoZSwgaW5qZWN0ZWQsICgpID0+IC8qIEBfX1BVUkVfXyAqLyBuZXcgV2Vha01hcCgpKSwgc2VsZWN0U3RhdGUsICgpID0+IHtcblx0XHRcdFx0XHRjb25zdCBtYXAgPSB7fTtcblx0XHRcdFx0XHRmb3IgKGNvbnN0IFtuYW1lLCBzZWxlY3Rvcl0gb2YgT2JqZWN0LmVudHJpZXMob3B0aW9ucy5zZWxlY3RvcnMgPz8ge30pKSBtYXBbbmFtZV0gPSB3cmFwU2VsZWN0b3Ioc2VsZWN0b3IsIHNlbGVjdFN0YXRlLCAoKSA9PiBnZXRPckluc2VydENvbXB1dGVkKGluamVjdGVkU3RhdGVDYWNoZSwgc2VsZWN0U3RhdGUsIGdldEluaXRpYWxTdGF0ZSksIGluamVjdGVkKTtcblx0XHRcdFx0XHRyZXR1cm4gbWFwO1xuXHRcdFx0XHR9KTtcblx0XHRcdH1cblx0XHRcdHJldHVybiB7XG5cdFx0XHRcdHJlZHVjZXJQYXRoLFxuXHRcdFx0XHRnZXRTZWxlY3RvcnMsXG5cdFx0XHRcdGdldCBzZWxlY3RvcnMoKSB7XG5cdFx0XHRcdFx0cmV0dXJuIGdldFNlbGVjdG9ycyhzZWxlY3RTbGljZSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdHNlbGVjdFNsaWNlXG5cdFx0XHR9O1xuXHRcdH1cblx0XHRjb25zdCBzbGljZSA9IHtcblx0XHRcdG5hbWUsXG5cdFx0XHRyZWR1Y2VyLFxuXHRcdFx0YWN0aW9uczogY29udGV4dC5hY3Rpb25DcmVhdG9ycyxcblx0XHRcdGNhc2VSZWR1Y2VyczogY29udGV4dC5zbGljZUNhc2VSZWR1Y2Vyc0J5TmFtZSxcblx0XHRcdGdldEluaXRpYWxTdGF0ZSxcblx0XHRcdC4uLm1ha2VTZWxlY3RvclByb3BzKHJlZHVjZXJQYXRoKSxcblx0XHRcdGluamVjdEludG8oaW5qZWN0YWJsZSwgeyByZWR1Y2VyUGF0aDogcGF0aE9wdCwgLi4uY29uZmlnIH0gPSB7fSkge1xuXHRcdFx0XHRjb25zdCBuZXdSZWR1Y2VyUGF0aCA9IHBhdGhPcHQgPz8gcmVkdWNlclBhdGg7XG5cdFx0XHRcdGluamVjdGFibGUuaW5qZWN0KHtcblx0XHRcdFx0XHRyZWR1Y2VyUGF0aDogbmV3UmVkdWNlclBhdGgsXG5cdFx0XHRcdFx0cmVkdWNlclxuXHRcdFx0XHR9LCBjb25maWcpO1xuXHRcdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRcdC4uLnNsaWNlLFxuXHRcdFx0XHRcdC4uLm1ha2VTZWxlY3RvclByb3BzKG5ld1JlZHVjZXJQYXRoLCB0cnVlKVxuXHRcdFx0XHR9O1xuXHRcdFx0fVxuXHRcdH07XG5cdFx0cmV0dXJuIHNsaWNlO1xuXHR9O1xufVxuZnVuY3Rpb24gd3JhcFNlbGVjdG9yKHNlbGVjdG9yLCBzZWxlY3RTdGF0ZSwgZ2V0SW5pdGlhbFN0YXRlLCBpbmplY3RlZCkge1xuXHRmdW5jdGlvbiB3cmFwcGVyKHJvb3RTdGF0ZSwgLi4uYXJncykge1xuXHRcdGxldCBzbGljZVN0YXRlID0gc2VsZWN0U3RhdGUocm9vdFN0YXRlKTtcblx0XHRpZiAodHlwZW9mIHNsaWNlU3RhdGUgPT09IFwidW5kZWZpbmVkXCIpIHtcblx0XHRcdGlmIChpbmplY3RlZCkgc2xpY2VTdGF0ZSA9IGdldEluaXRpYWxTdGF0ZSgpO1xuXHRcdFx0ZWxzZSBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxNikgOiBcInNlbGVjdFN0YXRlIHJldHVybmVkIHVuZGVmaW5lZCBmb3IgYW4gdW5pbmplY3RlZCBzbGljZSByZWR1Y2VyXCIpO1xuXHRcdH1cblx0XHRyZXR1cm4gc2VsZWN0b3Ioc2xpY2VTdGF0ZSwgLi4uYXJncyk7XG5cdH1cblx0d3JhcHBlci51bndyYXBwZWQgPSBzZWxlY3Rvcjtcblx0cmV0dXJuIHdyYXBwZXI7XG59XG5jb25zdCBjcmVhdGVTbGljZSA9IC8qIEBfX1BVUkVfXyAqLyBidWlsZENyZWF0ZVNsaWNlKCk7XG5mdW5jdGlvbiBidWlsZFJlZHVjZXJDcmVhdG9ycygpIHtcblx0ZnVuY3Rpb24gYXN5bmNUaHVuayhwYXlsb2FkQ3JlYXRvciwgY29uZmlnKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdF9yZWR1Y2VyRGVmaW5pdGlvblR5cGU6IFwiYXN5bmNUaHVua1wiLFxuXHRcdFx0cGF5bG9hZENyZWF0b3IsXG5cdFx0XHQuLi5jb25maWdcblx0XHR9O1xuXHR9XG5cdGFzeW5jVGh1bmsud2l0aFR5cGVzID0gKCkgPT4gYXN5bmNUaHVuaztcblx0cmV0dXJuIHtcblx0XHRyZWR1Y2VyKGNhc2VSZWR1Y2VyKSB7XG5cdFx0XHRyZXR1cm4gT2JqZWN0LmFzc2lnbih7IFtjYXNlUmVkdWNlci5uYW1lXSguLi5hcmdzKSB7XG5cdFx0XHRcdHJldHVybiBjYXNlUmVkdWNlciguLi5hcmdzKTtcblx0XHRcdH0gfVtjYXNlUmVkdWNlci5uYW1lXSwgeyBfcmVkdWNlckRlZmluaXRpb25UeXBlOiBcInJlZHVjZXJcIiB9KTtcblx0XHR9LFxuXHRcdHByZXBhcmVkUmVkdWNlcihwcmVwYXJlLCByZWR1Y2VyKSB7XG5cdFx0XHRyZXR1cm4ge1xuXHRcdFx0XHRfcmVkdWNlckRlZmluaXRpb25UeXBlOiBcInJlZHVjZXJXaXRoUHJlcGFyZVwiLFxuXHRcdFx0XHRwcmVwYXJlLFxuXHRcdFx0XHRyZWR1Y2VyXG5cdFx0XHR9O1xuXHRcdH0sXG5cdFx0YXN5bmNUaHVua1xuXHR9O1xufVxuZnVuY3Rpb24gaGFuZGxlTm9ybWFsUmVkdWNlckRlZmluaXRpb24oeyB0eXBlLCByZWR1Y2VyTmFtZSwgY3JlYXRlTm90YXRpb24gfSwgbWF5YmVSZWR1Y2VyV2l0aFByZXBhcmUsIGNvbnRleHQpIHtcblx0bGV0IGNhc2VSZWR1Y2VyO1xuXHRsZXQgcHJlcGFyZUNhbGxiYWNrO1xuXHRpZiAoXCJyZWR1Y2VyXCIgaW4gbWF5YmVSZWR1Y2VyV2l0aFByZXBhcmUpIHtcblx0XHRpZiAoY3JlYXRlTm90YXRpb24gJiYgIWlzQ2FzZVJlZHVjZXJXaXRoUHJlcGFyZURlZmluaXRpb24obWF5YmVSZWR1Y2VyV2l0aFByZXBhcmUpKSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgxNykgOiBcIlBsZWFzZSB1c2UgdGhlIGBjcmVhdGUucHJlcGFyZWRSZWR1Y2VyYCBub3RhdGlvbiBmb3IgcHJlcGFyZWQgYWN0aW9uIGNyZWF0b3JzIHdpdGggdGhlIGBjcmVhdGVgIG5vdGF0aW9uLlwiKTtcblx0XHRjYXNlUmVkdWNlciA9IG1heWJlUmVkdWNlcldpdGhQcmVwYXJlLnJlZHVjZXI7XG5cdFx0cHJlcGFyZUNhbGxiYWNrID0gbWF5YmVSZWR1Y2VyV2l0aFByZXBhcmUucHJlcGFyZTtcblx0fSBlbHNlIGNhc2VSZWR1Y2VyID0gbWF5YmVSZWR1Y2VyV2l0aFByZXBhcmU7XG5cdGNvbnRleHQuYWRkQ2FzZSh0eXBlLCBjYXNlUmVkdWNlcikuZXhwb3NlQ2FzZVJlZHVjZXIocmVkdWNlck5hbWUsIGNhc2VSZWR1Y2VyKS5leHBvc2VBY3Rpb24ocmVkdWNlck5hbWUsIHByZXBhcmVDYWxsYmFjayA/IGNyZWF0ZUFjdGlvbih0eXBlLCBwcmVwYXJlQ2FsbGJhY2spIDogY3JlYXRlQWN0aW9uKHR5cGUpKTtcbn1cbmZ1bmN0aW9uIGlzQXN5bmNUaHVua1NsaWNlUmVkdWNlckRlZmluaXRpb24ocmVkdWNlckRlZmluaXRpb24pIHtcblx0cmV0dXJuIHJlZHVjZXJEZWZpbml0aW9uLl9yZWR1Y2VyRGVmaW5pdGlvblR5cGUgPT09IFwiYXN5bmNUaHVua1wiO1xufVxuZnVuY3Rpb24gaXNDYXNlUmVkdWNlcldpdGhQcmVwYXJlRGVmaW5pdGlvbihyZWR1Y2VyRGVmaW5pdGlvbikge1xuXHRyZXR1cm4gcmVkdWNlckRlZmluaXRpb24uX3JlZHVjZXJEZWZpbml0aW9uVHlwZSA9PT0gXCJyZWR1Y2VyV2l0aFByZXBhcmVcIjtcbn1cbmZ1bmN0aW9uIGhhbmRsZVRodW5rQ2FzZVJlZHVjZXJEZWZpbml0aW9uKHsgdHlwZSwgcmVkdWNlck5hbWUgfSwgcmVkdWNlckRlZmluaXRpb24sIGNvbnRleHQsIGNBVCkge1xuXHRpZiAoIWNBVCkgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMTgpIDogXCJDYW5ub3QgdXNlIGBjcmVhdGUuYXN5bmNUaHVua2AgaW4gdGhlIGJ1aWx0LWluIGBjcmVhdGVTbGljZWAuIFVzZSBgYnVpbGRDcmVhdGVTbGljZSh7IGNyZWF0b3JzOiB7IGFzeW5jVGh1bms6IGFzeW5jVGh1bmtDcmVhdG9yIH0gfSlgIHRvIGNyZWF0ZSBhIGN1c3RvbWlzZWQgdmVyc2lvbiBvZiBgY3JlYXRlU2xpY2VgLlwiKTtcblx0Y29uc3QgeyBwYXlsb2FkQ3JlYXRvciwgZnVsZmlsbGVkLCBwZW5kaW5nLCByZWplY3RlZCwgc2V0dGxlZCwgb3B0aW9ucyB9ID0gcmVkdWNlckRlZmluaXRpb247XG5cdGNvbnN0IHRodW5rID0gY0FUKHR5cGUsIHBheWxvYWRDcmVhdG9yLCBvcHRpb25zKTtcblx0Y29udGV4dC5leHBvc2VBY3Rpb24ocmVkdWNlck5hbWUsIHRodW5rKTtcblx0aWYgKGZ1bGZpbGxlZCkgY29udGV4dC5hZGRDYXNlKHRodW5rLmZ1bGZpbGxlZCwgZnVsZmlsbGVkKTtcblx0aWYgKHBlbmRpbmcpIGNvbnRleHQuYWRkQ2FzZSh0aHVuay5wZW5kaW5nLCBwZW5kaW5nKTtcblx0aWYgKHJlamVjdGVkKSBjb250ZXh0LmFkZENhc2UodGh1bmsucmVqZWN0ZWQsIHJlamVjdGVkKTtcblx0aWYgKHNldHRsZWQpIGNvbnRleHQuYWRkTWF0Y2hlcih0aHVuay5zZXR0bGVkLCBzZXR0bGVkKTtcblx0Y29udGV4dC5leHBvc2VDYXNlUmVkdWNlcihyZWR1Y2VyTmFtZSwge1xuXHRcdGZ1bGZpbGxlZDogZnVsZmlsbGVkIHx8IG5vb3AkMSxcblx0XHRwZW5kaW5nOiBwZW5kaW5nIHx8IG5vb3AkMSxcblx0XHRyZWplY3RlZDogcmVqZWN0ZWQgfHwgbm9vcCQxLFxuXHRcdHNldHRsZWQ6IHNldHRsZWQgfHwgbm9vcCQxXG5cdH0pO1xufVxuZnVuY3Rpb24gbm9vcCQxKCkge31cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9lbnRpdGllcy9lbnRpdHlfc3RhdGUudHNcbmZ1bmN0aW9uIGdldEluaXRpYWxFbnRpdHlTdGF0ZSgpIHtcblx0cmV0dXJuIHtcblx0XHRpZHM6IFtdLFxuXHRcdGVudGl0aWVzOiB7fVxuXHR9O1xufVxuZnVuY3Rpb24gY3JlYXRlSW5pdGlhbFN0YXRlRmFjdG9yeShzdGF0ZUFkYXB0ZXIpIHtcblx0ZnVuY3Rpb24gZ2V0SW5pdGlhbFN0YXRlKGFkZGl0aW9uYWxTdGF0ZSA9IHt9LCBlbnRpdGllcykge1xuXHRcdGNvbnN0IHN0YXRlID0gT2JqZWN0LmFzc2lnbihnZXRJbml0aWFsRW50aXR5U3RhdGUoKSwgYWRkaXRpb25hbFN0YXRlKTtcblx0XHRyZXR1cm4gZW50aXRpZXMgPyBzdGF0ZUFkYXB0ZXIuc2V0QWxsKHN0YXRlLCBlbnRpdGllcykgOiBzdGF0ZTtcblx0fVxuXHRyZXR1cm4geyBnZXRJbml0aWFsU3RhdGUgfTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9lbnRpdGllcy9zdGF0ZV9zZWxlY3RvcnMudHNcbmZ1bmN0aW9uIGNyZWF0ZVNlbGVjdG9yc0ZhY3RvcnkoKSB7XG5cdGZ1bmN0aW9uIGdldFNlbGVjdG9ycyhzZWxlY3RTdGF0ZSwgb3B0aW9ucyA9IHt9KSB7XG5cdFx0Y29uc3QgeyBjcmVhdGVTZWxlY3RvciA9IGNyZWF0ZURyYWZ0U2FmZVNlbGVjdG9yIH0gPSBvcHRpb25zO1xuXHRcdGNvbnN0IHNlbGVjdElkcyA9IChzdGF0ZSkgPT4gc3RhdGUuaWRzO1xuXHRcdGNvbnN0IHNlbGVjdEVudGl0aWVzID0gKHN0YXRlKSA9PiBzdGF0ZS5lbnRpdGllcztcblx0XHRjb25zdCBzZWxlY3RBbGwgPSBjcmVhdGVTZWxlY3RvcihzZWxlY3RJZHMsIHNlbGVjdEVudGl0aWVzLCAoaWRzLCBlbnRpdGllcykgPT4gaWRzLm1hcCgoaWQpID0+IGVudGl0aWVzW2lkXSkpO1xuXHRcdGNvbnN0IHNlbGVjdElkID0gKF8sIGlkKSA9PiBpZDtcblx0XHRjb25zdCBzZWxlY3RCeUlkID0gKGVudGl0aWVzLCBpZCkgPT4gZW50aXRpZXNbaWRdO1xuXHRcdGNvbnN0IHNlbGVjdFRvdGFsID0gY3JlYXRlU2VsZWN0b3Ioc2VsZWN0SWRzLCAoaWRzKSA9PiBpZHMubGVuZ3RoKTtcblx0XHRpZiAoIXNlbGVjdFN0YXRlKSByZXR1cm4ge1xuXHRcdFx0c2VsZWN0SWRzLFxuXHRcdFx0c2VsZWN0RW50aXRpZXMsXG5cdFx0XHRzZWxlY3RBbGwsXG5cdFx0XHRzZWxlY3RUb3RhbCxcblx0XHRcdHNlbGVjdEJ5SWQ6IGNyZWF0ZVNlbGVjdG9yKHNlbGVjdEVudGl0aWVzLCBzZWxlY3RJZCwgc2VsZWN0QnlJZClcblx0XHR9O1xuXHRcdGNvbnN0IHNlbGVjdEdsb2JhbGl6ZWRFbnRpdGllcyA9IGNyZWF0ZVNlbGVjdG9yKHNlbGVjdFN0YXRlLCBzZWxlY3RFbnRpdGllcyk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHNlbGVjdElkczogY3JlYXRlU2VsZWN0b3Ioc2VsZWN0U3RhdGUsIHNlbGVjdElkcyksXG5cdFx0XHRzZWxlY3RFbnRpdGllczogc2VsZWN0R2xvYmFsaXplZEVudGl0aWVzLFxuXHRcdFx0c2VsZWN0QWxsOiBjcmVhdGVTZWxlY3RvcihzZWxlY3RTdGF0ZSwgc2VsZWN0QWxsKSxcblx0XHRcdHNlbGVjdFRvdGFsOiBjcmVhdGVTZWxlY3RvcihzZWxlY3RTdGF0ZSwgc2VsZWN0VG90YWwpLFxuXHRcdFx0c2VsZWN0QnlJZDogY3JlYXRlU2VsZWN0b3Ioc2VsZWN0R2xvYmFsaXplZEVudGl0aWVzLCBzZWxlY3RJZCwgc2VsZWN0QnlJZClcblx0XHR9O1xuXHR9XG5cdHJldHVybiB7IGdldFNlbGVjdG9ycyB9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2VudGl0aWVzL3N0YXRlX2FkYXB0ZXIudHNcbmNvbnN0IGlzRHJhZnRUeXBlZCA9IGlzRHJhZnQ7XG5mdW5jdGlvbiBjcmVhdGVTaW5nbGVBcmd1bWVudFN0YXRlT3BlcmF0b3IobXV0YXRvcikge1xuXHRjb25zdCBvcGVyYXRvciA9IGNyZWF0ZVN0YXRlT3BlcmF0b3IoKF8sIHN0YXRlKSA9PiBtdXRhdG9yKHN0YXRlKSk7XG5cdHJldHVybiBmdW5jdGlvbiBvcGVyYXRpb24oc3RhdGUpIHtcblx0XHRyZXR1cm4gb3BlcmF0b3Ioc3RhdGUsIHZvaWQgMCk7XG5cdH07XG59XG5mdW5jdGlvbiBjcmVhdGVTdGF0ZU9wZXJhdG9yKG11dGF0b3IpIHtcblx0cmV0dXJuIGZ1bmN0aW9uIG9wZXJhdGlvbihzdGF0ZSwgYXJnKSB7XG5cdFx0ZnVuY3Rpb24gaXNQYXlsb2FkQWN0aW9uQXJndW1lbnQoYXJnKSB7XG5cdFx0XHRyZXR1cm4gaXNGU0EoYXJnKTtcblx0XHR9XG5cdFx0Y29uc3QgcnVuTXV0YXRvciA9IChkcmFmdCkgPT4ge1xuXHRcdFx0aWYgKGlzUGF5bG9hZEFjdGlvbkFyZ3VtZW50KGFyZykpIG11dGF0b3IoYXJnLnBheWxvYWQsIGRyYWZ0KTtcblx0XHRcdGVsc2UgbXV0YXRvcihhcmcsIGRyYWZ0KTtcblx0XHR9O1xuXHRcdGlmIChpc0RyYWZ0VHlwZWQoc3RhdGUpKSB7XG5cdFx0XHRydW5NdXRhdG9yKHN0YXRlKTtcblx0XHRcdHJldHVybiBzdGF0ZTtcblx0XHR9XG5cdFx0cmV0dXJuIGNyZWF0ZU5leHRTdGF0ZShzdGF0ZSwgcnVuTXV0YXRvcik7XG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvZW50aXRpZXMvdXRpbHMudHNcbmZ1bmN0aW9uIHNlbGVjdElkVmFsdWUoZW50aXR5LCBzZWxlY3RJZCkge1xuXHRjb25zdCBrZXkgPSBzZWxlY3RJZChlbnRpdHkpO1xuXHRpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09IFwicHJvZHVjdGlvblwiICYmIGtleSA9PT0gdm9pZCAwKSBjb25zb2xlLndhcm4oXCJUaGUgZW50aXR5IHBhc3NlZCB0byB0aGUgYHNlbGVjdElkYCBpbXBsZW1lbnRhdGlvbiByZXR1cm5lZCB1bmRlZmluZWQuXCIsIFwiWW91IHNob3VsZCBwcm9iYWJseSBwcm92aWRlIHlvdXIgb3duIGBzZWxlY3RJZGAgaW1wbGVtZW50YXRpb24uXCIsIFwiVGhlIGVudGl0eSB0aGF0IHdhcyBwYXNzZWQ6XCIsIGVudGl0eSwgXCJUaGUgYHNlbGVjdElkYCBpbXBsZW1lbnRhdGlvbjpcIiwgc2VsZWN0SWQudG9TdHJpbmcoKSk7XG5cdHJldHVybiBrZXk7XG59XG5mdW5jdGlvbiBlbnN1cmVFbnRpdGllc0FycmF5KGVudGl0aWVzKSB7XG5cdGlmICghQXJyYXkuaXNBcnJheShlbnRpdGllcykpIGVudGl0aWVzID0gT2JqZWN0LnZhbHVlcyhlbnRpdGllcyk7XG5cdHJldHVybiBlbnRpdGllcztcbn1cbmZ1bmN0aW9uIGdldEN1cnJlbnQodmFsdWUpIHtcblx0cmV0dXJuIGlzRHJhZnQodmFsdWUpID8gY3VycmVudCh2YWx1ZSkgOiB2YWx1ZTtcbn1cbmZ1bmN0aW9uIHNwbGl0QWRkZWRVcGRhdGVkRW50aXRpZXMobmV3RW50aXRpZXMsIHNlbGVjdElkLCBzdGF0ZSkge1xuXHRuZXdFbnRpdGllcyA9IGVuc3VyZUVudGl0aWVzQXJyYXkobmV3RW50aXRpZXMpO1xuXHRjb25zdCBleGlzdGluZ0lkc0FycmF5ID0gZ2V0Q3VycmVudChzdGF0ZS5pZHMpO1xuXHRjb25zdCBleGlzdGluZ0lkcyA9IG5ldyBTZXQoZXhpc3RpbmdJZHNBcnJheSk7XG5cdGNvbnN0IGFkZGVkID0gW107XG5cdGNvbnN0IGFkZGVkSWRzID0gLyogQF9fUFVSRV9fICovIG5ldyBTZXQoW10pO1xuXHRjb25zdCB1cGRhdGVkID0gW107XG5cdGZvciAoY29uc3QgZW50aXR5IG9mIG5ld0VudGl0aWVzKSB7XG5cdFx0Y29uc3QgaWQgPSBzZWxlY3RJZFZhbHVlKGVudGl0eSwgc2VsZWN0SWQpO1xuXHRcdGlmIChleGlzdGluZ0lkcy5oYXMoaWQpIHx8IGFkZGVkSWRzLmhhcyhpZCkpIHVwZGF0ZWQucHVzaCh7XG5cdFx0XHRpZCxcblx0XHRcdGNoYW5nZXM6IGVudGl0eVxuXHRcdH0pO1xuXHRcdGVsc2Uge1xuXHRcdFx0YWRkZWRJZHMuYWRkKGlkKTtcblx0XHRcdGFkZGVkLnB1c2goZW50aXR5KTtcblx0XHR9XG5cdH1cblx0cmV0dXJuIFtcblx0XHRhZGRlZCxcblx0XHR1cGRhdGVkLFxuXHRcdGV4aXN0aW5nSWRzQXJyYXlcblx0XTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9lbnRpdGllcy91bnNvcnRlZF9zdGF0ZV9hZGFwdGVyLnRzXG5mdW5jdGlvbiBjcmVhdGVVbnNvcnRlZFN0YXRlQWRhcHRlcihzZWxlY3RJZCkge1xuXHRmdW5jdGlvbiBhZGRPbmVNdXRhYmx5KGVudGl0eSwgc3RhdGUpIHtcblx0XHRjb25zdCBrZXkgPSBzZWxlY3RJZFZhbHVlKGVudGl0eSwgc2VsZWN0SWQpO1xuXHRcdGlmIChrZXkgaW4gc3RhdGUuZW50aXRpZXMpIHJldHVybjtcblx0XHRzdGF0ZS5pZHMucHVzaChrZXkpO1xuXHRcdHN0YXRlLmVudGl0aWVzW2tleV0gPSBlbnRpdHk7XG5cdH1cblx0ZnVuY3Rpb24gYWRkTWFueU11dGFibHkobmV3RW50aXRpZXMsIHN0YXRlKSB7XG5cdFx0bmV3RW50aXRpZXMgPSBlbnN1cmVFbnRpdGllc0FycmF5KG5ld0VudGl0aWVzKTtcblx0XHRmb3IgKGNvbnN0IGVudGl0eSBvZiBuZXdFbnRpdGllcykgYWRkT25lTXV0YWJseShlbnRpdHksIHN0YXRlKTtcblx0fVxuXHRmdW5jdGlvbiBzZXRPbmVNdXRhYmx5KGVudGl0eSwgc3RhdGUpIHtcblx0XHRjb25zdCBrZXkgPSBzZWxlY3RJZFZhbHVlKGVudGl0eSwgc2VsZWN0SWQpO1xuXHRcdGlmICghKGtleSBpbiBzdGF0ZS5lbnRpdGllcykpIHN0YXRlLmlkcy5wdXNoKGtleSk7XG5cdFx0c3RhdGUuZW50aXRpZXNba2V5XSA9IGVudGl0eTtcblx0fVxuXHRmdW5jdGlvbiBzZXRNYW55TXV0YWJseShuZXdFbnRpdGllcywgc3RhdGUpIHtcblx0XHRuZXdFbnRpdGllcyA9IGVuc3VyZUVudGl0aWVzQXJyYXkobmV3RW50aXRpZXMpO1xuXHRcdGZvciAoY29uc3QgZW50aXR5IG9mIG5ld0VudGl0aWVzKSBzZXRPbmVNdXRhYmx5KGVudGl0eSwgc3RhdGUpO1xuXHR9XG5cdGZ1bmN0aW9uIHNldEFsbE11dGFibHkobmV3RW50aXRpZXMsIHN0YXRlKSB7XG5cdFx0bmV3RW50aXRpZXMgPSBlbnN1cmVFbnRpdGllc0FycmF5KG5ld0VudGl0aWVzKTtcblx0XHRzdGF0ZS5pZHMgPSBbXTtcblx0XHRzdGF0ZS5lbnRpdGllcyA9IHt9O1xuXHRcdHNldE1hbnlNdXRhYmx5KG5ld0VudGl0aWVzLCBzdGF0ZSk7XG5cdH1cblx0ZnVuY3Rpb24gcmVtb3ZlT25lTXV0YWJseShrZXksIHN0YXRlKSB7XG5cdFx0cmV0dXJuIHJlbW92ZU1hbnlNdXRhYmx5KFtrZXldLCBzdGF0ZSk7XG5cdH1cblx0ZnVuY3Rpb24gcmVtb3ZlTWFueU11dGFibHkoa2V5cywgc3RhdGUpIHtcblx0XHRsZXQgZGlkTXV0YXRlID0gZmFsc2U7XG5cdFx0a2V5cy5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRcdGlmIChrZXkgaW4gc3RhdGUuZW50aXRpZXMpIHtcblx0XHRcdFx0ZGVsZXRlIHN0YXRlLmVudGl0aWVzW2tleV07XG5cdFx0XHRcdGRpZE11dGF0ZSA9IHRydWU7XG5cdFx0XHR9XG5cdFx0fSk7XG5cdFx0aWYgKGRpZE11dGF0ZSkgc3RhdGUuaWRzID0gc3RhdGUuaWRzLmZpbHRlcigoaWQpID0+IGlkIGluIHN0YXRlLmVudGl0aWVzKTtcblx0fVxuXHRmdW5jdGlvbiByZW1vdmVBbGxNdXRhYmx5KHN0YXRlKSB7XG5cdFx0T2JqZWN0LmFzc2lnbihzdGF0ZSwge1xuXHRcdFx0aWRzOiBbXSxcblx0XHRcdGVudGl0aWVzOiB7fVxuXHRcdH0pO1xuXHR9XG5cdGZ1bmN0aW9uIHRha2VOZXdLZXkoa2V5cywgdXBkYXRlLCBzdGF0ZSkge1xuXHRcdGNvbnN0IG9yaWdpbmFsID0gc3RhdGUuZW50aXRpZXNbdXBkYXRlLmlkXTtcblx0XHRpZiAob3JpZ2luYWwgPT09IHZvaWQgMCkgcmV0dXJuIGZhbHNlO1xuXHRcdGNvbnN0IHVwZGF0ZWQgPSBPYmplY3QuYXNzaWduKHt9LCBvcmlnaW5hbCwgdXBkYXRlLmNoYW5nZXMpO1xuXHRcdGNvbnN0IG5ld0tleSA9IHNlbGVjdElkVmFsdWUodXBkYXRlZCwgc2VsZWN0SWQpO1xuXHRcdGNvbnN0IGhhc05ld0tleSA9IG5ld0tleSAhPT0gdXBkYXRlLmlkO1xuXHRcdGlmIChoYXNOZXdLZXkpIHtcblx0XHRcdGtleXNbdXBkYXRlLmlkXSA9IG5ld0tleTtcblx0XHRcdGRlbGV0ZSBzdGF0ZS5lbnRpdGllc1t1cGRhdGUuaWRdO1xuXHRcdH1cblx0XHRzdGF0ZS5lbnRpdGllc1tuZXdLZXldID0gdXBkYXRlZDtcblx0XHRyZXR1cm4gaGFzTmV3S2V5O1xuXHR9XG5cdGZ1bmN0aW9uIHVwZGF0ZU9uZU11dGFibHkodXBkYXRlLCBzdGF0ZSkge1xuXHRcdHJldHVybiB1cGRhdGVNYW55TXV0YWJseShbdXBkYXRlXSwgc3RhdGUpO1xuXHR9XG5cdGZ1bmN0aW9uIHVwZGF0ZU1hbnlNdXRhYmx5KHVwZGF0ZXMsIHN0YXRlKSB7XG5cdFx0Y29uc3QgbmV3S2V5cyA9IHt9O1xuXHRcdGNvbnN0IHVwZGF0ZXNQZXJFbnRpdHkgPSB7fTtcblx0XHR1cGRhdGVzLmZvckVhY2goKHVwZGF0ZSkgPT4ge1xuXHRcdFx0aWYgKHVwZGF0ZS5pZCBpbiBzdGF0ZS5lbnRpdGllcykgdXBkYXRlc1BlckVudGl0eVt1cGRhdGUuaWRdID0ge1xuXHRcdFx0XHRpZDogdXBkYXRlLmlkLFxuXHRcdFx0XHRjaGFuZ2VzOiB7XG5cdFx0XHRcdFx0Li4udXBkYXRlc1BlckVudGl0eVt1cGRhdGUuaWRdPy5jaGFuZ2VzLFxuXHRcdFx0XHRcdC4uLnVwZGF0ZS5jaGFuZ2VzXG5cdFx0XHRcdH1cblx0XHRcdH07XG5cdFx0fSk7XG5cdFx0dXBkYXRlcyA9IE9iamVjdC52YWx1ZXModXBkYXRlc1BlckVudGl0eSk7XG5cdFx0aWYgKHVwZGF0ZXMubGVuZ3RoID4gMCkge1xuXHRcdFx0aWYgKHVwZGF0ZXMuZmlsdGVyKCh1cGRhdGUpID0+IHRha2VOZXdLZXkobmV3S2V5cywgdXBkYXRlLCBzdGF0ZSkpLmxlbmd0aCA+IDApIHN0YXRlLmlkcyA9IE9iamVjdC52YWx1ZXMoc3RhdGUuZW50aXRpZXMpLm1hcCgoZSkgPT4gc2VsZWN0SWRWYWx1ZShlLCBzZWxlY3RJZCkpO1xuXHRcdH1cblx0fVxuXHRmdW5jdGlvbiB1cHNlcnRPbmVNdXRhYmx5KGVudGl0eSwgc3RhdGUpIHtcblx0XHRyZXR1cm4gdXBzZXJ0TWFueU11dGFibHkoW2VudGl0eV0sIHN0YXRlKTtcblx0fVxuXHRmdW5jdGlvbiB1cHNlcnRNYW55TXV0YWJseShuZXdFbnRpdGllcywgc3RhdGUpIHtcblx0XHRjb25zdCBbYWRkZWQsIHVwZGF0ZWRdID0gc3BsaXRBZGRlZFVwZGF0ZWRFbnRpdGllcyhuZXdFbnRpdGllcywgc2VsZWN0SWQsIHN0YXRlKTtcblx0XHRhZGRNYW55TXV0YWJseShhZGRlZCwgc3RhdGUpO1xuXHRcdHVwZGF0ZU1hbnlNdXRhYmx5KHVwZGF0ZWQsIHN0YXRlKTtcblx0fVxuXHRyZXR1cm4ge1xuXHRcdHJlbW92ZUFsbDogY3JlYXRlU2luZ2xlQXJndW1lbnRTdGF0ZU9wZXJhdG9yKHJlbW92ZUFsbE11dGFibHkpLFxuXHRcdGFkZE9uZTogY3JlYXRlU3RhdGVPcGVyYXRvcihhZGRPbmVNdXRhYmx5KSxcblx0XHRhZGRNYW55OiBjcmVhdGVTdGF0ZU9wZXJhdG9yKGFkZE1hbnlNdXRhYmx5KSxcblx0XHRzZXRPbmU6IGNyZWF0ZVN0YXRlT3BlcmF0b3Ioc2V0T25lTXV0YWJseSksXG5cdFx0c2V0TWFueTogY3JlYXRlU3RhdGVPcGVyYXRvcihzZXRNYW55TXV0YWJseSksXG5cdFx0c2V0QWxsOiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHNldEFsbE11dGFibHkpLFxuXHRcdHVwZGF0ZU9uZTogY3JlYXRlU3RhdGVPcGVyYXRvcih1cGRhdGVPbmVNdXRhYmx5KSxcblx0XHR1cGRhdGVNYW55OiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHVwZGF0ZU1hbnlNdXRhYmx5KSxcblx0XHR1cHNlcnRPbmU6IGNyZWF0ZVN0YXRlT3BlcmF0b3IodXBzZXJ0T25lTXV0YWJseSksXG5cdFx0dXBzZXJ0TWFueTogY3JlYXRlU3RhdGVPcGVyYXRvcih1cHNlcnRNYW55TXV0YWJseSksXG5cdFx0cmVtb3ZlT25lOiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHJlbW92ZU9uZU11dGFibHkpLFxuXHRcdHJlbW92ZU1hbnk6IGNyZWF0ZVN0YXRlT3BlcmF0b3IocmVtb3ZlTWFueU11dGFibHkpXG5cdH07XG59XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvZW50aXRpZXMvc29ydGVkX3N0YXRlX2FkYXB0ZXIudHNcbmZ1bmN0aW9uIGZpbmRJbnNlcnRJbmRleChzb3J0ZWRJdGVtcywgaXRlbSwgY29tcGFyaXNvbkZ1bmN0aW9uKSB7XG5cdGxldCBsb3dJbmRleCA9IDA7XG5cdGxldCBoaWdoSW5kZXggPSBzb3J0ZWRJdGVtcy5sZW5ndGg7XG5cdHdoaWxlIChsb3dJbmRleCA8IGhpZ2hJbmRleCkge1xuXHRcdGxldCBtaWRkbGVJbmRleCA9IGxvd0luZGV4ICsgaGlnaEluZGV4ID4+PiAxO1xuXHRcdGNvbnN0IGN1cnJlbnRJdGVtID0gc29ydGVkSXRlbXNbbWlkZGxlSW5kZXhdO1xuXHRcdGlmIChjb21wYXJpc29uRnVuY3Rpb24oaXRlbSwgY3VycmVudEl0ZW0pID49IDApIGxvd0luZGV4ID0gbWlkZGxlSW5kZXggKyAxO1xuXHRcdGVsc2UgaGlnaEluZGV4ID0gbWlkZGxlSW5kZXg7XG5cdH1cblx0cmV0dXJuIGxvd0luZGV4O1xufVxuZnVuY3Rpb24gaW5zZXJ0KHNvcnRlZEl0ZW1zLCBpdGVtLCBjb21wYXJpc29uRnVuY3Rpb24pIHtcblx0Y29uc3QgaW5zZXJ0QXRJbmRleCA9IGZpbmRJbnNlcnRJbmRleChzb3J0ZWRJdGVtcywgaXRlbSwgY29tcGFyaXNvbkZ1bmN0aW9uKTtcblx0c29ydGVkSXRlbXMuc3BsaWNlKGluc2VydEF0SW5kZXgsIDAsIGl0ZW0pO1xuXHRyZXR1cm4gc29ydGVkSXRlbXM7XG59XG5mdW5jdGlvbiBjcmVhdGVTb3J0ZWRTdGF0ZUFkYXB0ZXIoc2VsZWN0SWQsIGNvbXBhcmVyKSB7XG5cdGNvbnN0IHsgcmVtb3ZlT25lLCByZW1vdmVNYW55LCByZW1vdmVBbGwgfSA9IGNyZWF0ZVVuc29ydGVkU3RhdGVBZGFwdGVyKHNlbGVjdElkKTtcblx0ZnVuY3Rpb24gYWRkT25lTXV0YWJseShlbnRpdHksIHN0YXRlKSB7XG5cdFx0cmV0dXJuIGFkZE1hbnlNdXRhYmx5KFtlbnRpdHldLCBzdGF0ZSk7XG5cdH1cblx0ZnVuY3Rpb24gYWRkTWFueU11dGFibHkobmV3RW50aXRpZXMsIHN0YXRlLCBleGlzdGluZ0lkcykge1xuXHRcdG5ld0VudGl0aWVzID0gZW5zdXJlRW50aXRpZXNBcnJheShuZXdFbnRpdGllcyk7XG5cdFx0Y29uc3QgZXhpc3RpbmdLZXlzID0gbmV3IFNldChleGlzdGluZ0lkcyA/PyBnZXRDdXJyZW50KHN0YXRlLmlkcykpO1xuXHRcdGNvbnN0IGFkZGVkS2V5cyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCk7XG5cdFx0Y29uc3QgbW9kZWxzID0gbmV3RW50aXRpZXMuZmlsdGVyKChtb2RlbCkgPT4ge1xuXHRcdFx0Y29uc3QgbW9kZWxJZCA9IHNlbGVjdElkVmFsdWUobW9kZWwsIHNlbGVjdElkKTtcblx0XHRcdGNvbnN0IG5vdEFkZGVkID0gIWFkZGVkS2V5cy5oYXMobW9kZWxJZCk7XG5cdFx0XHRpZiAobm90QWRkZWQpIGFkZGVkS2V5cy5hZGQobW9kZWxJZCk7XG5cdFx0XHRyZXR1cm4gIWV4aXN0aW5nS2V5cy5oYXMobW9kZWxJZCkgJiYgbm90QWRkZWQ7XG5cdFx0fSk7XG5cdFx0aWYgKG1vZGVscy5sZW5ndGggIT09IDApIG1lcmdlRnVuY3Rpb24oc3RhdGUsIG1vZGVscyk7XG5cdH1cblx0ZnVuY3Rpb24gc2V0T25lTXV0YWJseShlbnRpdHksIHN0YXRlKSB7XG5cdFx0cmV0dXJuIHNldE1hbnlNdXRhYmx5KFtlbnRpdHldLCBzdGF0ZSk7XG5cdH1cblx0ZnVuY3Rpb24gc2V0TWFueU11dGFibHkobmV3RW50aXRpZXMsIHN0YXRlKSB7XG5cdFx0bGV0IGRlZHVwbGljYXRlZEVudGl0aWVzID0ge307XG5cdFx0bmV3RW50aXRpZXMgPSBlbnN1cmVFbnRpdGllc0FycmF5KG5ld0VudGl0aWVzKTtcblx0XHRpZiAobmV3RW50aXRpZXMubGVuZ3RoICE9PSAwKSB7XG5cdFx0XHRmb3IgKGNvbnN0IGl0ZW0gb2YgbmV3RW50aXRpZXMpIHtcblx0XHRcdFx0Y29uc3QgZW50aXR5SWQgPSBzZWxlY3RJZChpdGVtKTtcblx0XHRcdFx0ZGVkdXBsaWNhdGVkRW50aXRpZXNbZW50aXR5SWRdID0gaXRlbTtcblx0XHRcdFx0ZGVsZXRlIHN0YXRlLmVudGl0aWVzW2VudGl0eUlkXTtcblx0XHRcdH1cblx0XHRcdG5ld0VudGl0aWVzID0gZW5zdXJlRW50aXRpZXNBcnJheShkZWR1cGxpY2F0ZWRFbnRpdGllcyk7XG5cdFx0XHRtZXJnZUZ1bmN0aW9uKHN0YXRlLCBuZXdFbnRpdGllcyk7XG5cdFx0fVxuXHR9XG5cdGZ1bmN0aW9uIHNldEFsbE11dGFibHkobmV3RW50aXRpZXMsIHN0YXRlKSB7XG5cdFx0bmV3RW50aXRpZXMgPSBlbnN1cmVFbnRpdGllc0FycmF5KG5ld0VudGl0aWVzKTtcblx0XHRzdGF0ZS5lbnRpdGllcyA9IHt9O1xuXHRcdHN0YXRlLmlkcyA9IFtdO1xuXHRcdHNldE1hbnlNdXRhYmx5KG5ld0VudGl0aWVzLCBzdGF0ZSk7XG5cdH1cblx0ZnVuY3Rpb24gdXBkYXRlT25lTXV0YWJseSh1cGRhdGUsIHN0YXRlKSB7XG5cdFx0cmV0dXJuIHVwZGF0ZU1hbnlNdXRhYmx5KFt1cGRhdGVdLCBzdGF0ZSk7XG5cdH1cblx0ZnVuY3Rpb24gdXBkYXRlTWFueU11dGFibHkodXBkYXRlcywgc3RhdGUpIHtcblx0XHRsZXQgYXBwbGllZFVwZGF0ZXMgPSBmYWxzZTtcblx0XHRsZXQgcmVwbGFjZWRJZHMgPSBmYWxzZTtcblx0XHRjb25zdCB1cGRhdGVzUGVyRW50aXR5ID0ge307XG5cdFx0Zm9yIChjb25zdCB1cGRhdGUgb2YgdXBkYXRlcykgaWYgKHVwZGF0ZS5pZCBpbiBzdGF0ZS5lbnRpdGllcykgdXBkYXRlc1BlckVudGl0eVt1cGRhdGUuaWRdID0ge1xuXHRcdFx0aWQ6IHVwZGF0ZS5pZCxcblx0XHRcdGNoYW5nZXM6IHtcblx0XHRcdFx0Li4udXBkYXRlc1BlckVudGl0eVt1cGRhdGUuaWRdPy5jaGFuZ2VzLFxuXHRcdFx0XHQuLi51cGRhdGUuY2hhbmdlc1xuXHRcdFx0fVxuXHRcdH07XG5cdFx0Zm9yIChjb25zdCB1cGRhdGUgb2YgT2JqZWN0LnZhbHVlcyh1cGRhdGVzUGVyRW50aXR5KSkge1xuXHRcdFx0Y29uc3QgZW50aXR5ID0gc3RhdGUuZW50aXRpZXNbdXBkYXRlLmlkXTtcblx0XHRcdGlmICghZW50aXR5KSBjb250aW51ZTtcblx0XHRcdGFwcGxpZWRVcGRhdGVzID0gdHJ1ZTtcblx0XHRcdE9iamVjdC5hc3NpZ24oZW50aXR5LCB1cGRhdGUuY2hhbmdlcyk7XG5cdFx0XHRjb25zdCBuZXdJZCA9IHNlbGVjdElkKGVudGl0eSk7XG5cdFx0XHRpZiAodXBkYXRlLmlkICE9PSBuZXdJZCkge1xuXHRcdFx0XHRyZXBsYWNlZElkcyA9IHRydWU7XG5cdFx0XHRcdGRlbGV0ZSBzdGF0ZS5lbnRpdGllc1t1cGRhdGUuaWRdO1xuXHRcdFx0XHRjb25zdCBvbGRJbmRleCA9IHN0YXRlLmlkcy5pbmRleE9mKHVwZGF0ZS5pZCk7XG5cdFx0XHRcdHN0YXRlLmlkc1tvbGRJbmRleF0gPSBuZXdJZDtcblx0XHRcdFx0c3RhdGUuZW50aXRpZXNbbmV3SWRdID0gZW50aXR5O1xuXHRcdFx0fVxuXHRcdH1cblx0XHRpZiAoYXBwbGllZFVwZGF0ZXMpIG1lcmdlRnVuY3Rpb24oc3RhdGUsIFtdLCBhcHBsaWVkVXBkYXRlcywgcmVwbGFjZWRJZHMpO1xuXHR9XG5cdGZ1bmN0aW9uIHVwc2VydE9uZU11dGFibHkoZW50aXR5LCBzdGF0ZSkge1xuXHRcdHJldHVybiB1cHNlcnRNYW55TXV0YWJseShbZW50aXR5XSwgc3RhdGUpO1xuXHR9XG5cdGZ1bmN0aW9uIHVwc2VydE1hbnlNdXRhYmx5KG5ld0VudGl0aWVzLCBzdGF0ZSkge1xuXHRcdGNvbnN0IFthZGRlZCwgdXBkYXRlZCwgZXhpc3RpbmdJZHNBcnJheV0gPSBzcGxpdEFkZGVkVXBkYXRlZEVudGl0aWVzKG5ld0VudGl0aWVzLCBzZWxlY3RJZCwgc3RhdGUpO1xuXHRcdGlmIChhZGRlZC5sZW5ndGgpIGFkZE1hbnlNdXRhYmx5KGFkZGVkLCBzdGF0ZSwgZXhpc3RpbmdJZHNBcnJheSk7XG5cdFx0aWYgKHVwZGF0ZWQubGVuZ3RoKSB1cGRhdGVNYW55TXV0YWJseSh1cGRhdGVkLCBzdGF0ZSk7XG5cdH1cblx0ZnVuY3Rpb24gYXJlQXJyYXlzRXF1YWwoYSwgYikge1xuXHRcdGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHJldHVybiBmYWxzZTtcblx0XHRmb3IgKGxldCBpID0gMDsgaSA8IGEubGVuZ3RoOyBpKyspIHtcblx0XHRcdGlmIChhW2ldID09PSBiW2ldKSBjb250aW51ZTtcblx0XHRcdHJldHVybiBmYWxzZTtcblx0XHR9XG5cdFx0cmV0dXJuIHRydWU7XG5cdH1cblx0ZnVuY3Rpb24gbWVyZ2VGdW5jdGlvbihzdGF0ZSwgYWRkZWRJdGVtcywgYXBwbGllZFVwZGF0ZXMsIHJlcGxhY2VkSWRzKSB7XG5cdFx0Y29uc3QgY3VycmVudEVudGl0aWVzID0gZ2V0Q3VycmVudChzdGF0ZS5lbnRpdGllcyk7XG5cdFx0Y29uc3QgY3VycmVudElkcyA9IGdldEN1cnJlbnQoc3RhdGUuaWRzKTtcblx0XHRjb25zdCBzdGF0ZUVudGl0aWVzID0gc3RhdGUuZW50aXRpZXM7XG5cdFx0bGV0IGlkcyA9IGN1cnJlbnRJZHM7XG5cdFx0aWYgKHJlcGxhY2VkSWRzKSBpZHMgPSBuZXcgU2V0KGN1cnJlbnRJZHMpO1xuXHRcdGxldCBzb3J0ZWRFbnRpdGllcyA9IFtdO1xuXHRcdGZvciAoY29uc3QgaWQgb2YgaWRzKSB7XG5cdFx0XHRjb25zdCBlbnRpdHkgPSBjdXJyZW50RW50aXRpZXNbaWRdO1xuXHRcdFx0aWYgKGVudGl0eSkgc29ydGVkRW50aXRpZXMucHVzaChlbnRpdHkpO1xuXHRcdH1cblx0XHRjb25zdCB3YXNQcmV2aW91c2x5RW1wdHkgPSBzb3J0ZWRFbnRpdGllcy5sZW5ndGggPT09IDA7XG5cdFx0Zm9yIChjb25zdCBpdGVtIG9mIGFkZGVkSXRlbXMpIHtcblx0XHRcdHN0YXRlRW50aXRpZXNbc2VsZWN0SWQoaXRlbSldID0gaXRlbTtcblx0XHRcdGlmICghd2FzUHJldmlvdXNseUVtcHR5KSBpbnNlcnQoc29ydGVkRW50aXRpZXMsIGl0ZW0sIGNvbXBhcmVyKTtcblx0XHR9XG5cdFx0aWYgKHdhc1ByZXZpb3VzbHlFbXB0eSkgc29ydGVkRW50aXRpZXMgPSBhZGRlZEl0ZW1zLnNsaWNlKCkuc29ydChjb21wYXJlcik7XG5cdFx0ZWxzZSBpZiAoYXBwbGllZFVwZGF0ZXMpIHNvcnRlZEVudGl0aWVzLnNvcnQoY29tcGFyZXIpO1xuXHRcdGNvbnN0IG5ld1NvcnRlZElkcyA9IHNvcnRlZEVudGl0aWVzLm1hcChzZWxlY3RJZCk7XG5cdFx0aWYgKCFhcmVBcnJheXNFcXVhbChjdXJyZW50SWRzLCBuZXdTb3J0ZWRJZHMpKSBzdGF0ZS5pZHMgPSBuZXdTb3J0ZWRJZHM7XG5cdH1cblx0cmV0dXJuIHtcblx0XHRyZW1vdmVPbmUsXG5cdFx0cmVtb3ZlTWFueSxcblx0XHRyZW1vdmVBbGwsXG5cdFx0YWRkT25lOiBjcmVhdGVTdGF0ZU9wZXJhdG9yKGFkZE9uZU11dGFibHkpLFxuXHRcdHVwZGF0ZU9uZTogY3JlYXRlU3RhdGVPcGVyYXRvcih1cGRhdGVPbmVNdXRhYmx5KSxcblx0XHR1cHNlcnRPbmU6IGNyZWF0ZVN0YXRlT3BlcmF0b3IodXBzZXJ0T25lTXV0YWJseSksXG5cdFx0c2V0T25lOiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHNldE9uZU11dGFibHkpLFxuXHRcdHNldE1hbnk6IGNyZWF0ZVN0YXRlT3BlcmF0b3Ioc2V0TWFueU11dGFibHkpLFxuXHRcdHNldEFsbDogY3JlYXRlU3RhdGVPcGVyYXRvcihzZXRBbGxNdXRhYmx5KSxcblx0XHRhZGRNYW55OiBjcmVhdGVTdGF0ZU9wZXJhdG9yKGFkZE1hbnlNdXRhYmx5KSxcblx0XHR1cGRhdGVNYW55OiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHVwZGF0ZU1hbnlNdXRhYmx5KSxcblx0XHR1cHNlcnRNYW55OiBjcmVhdGVTdGF0ZU9wZXJhdG9yKHVwc2VydE1hbnlNdXRhYmx5KVxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2VudGl0aWVzL2NyZWF0ZV9hZGFwdGVyLnRzXG5mdW5jdGlvbiBjcmVhdGVFbnRpdHlBZGFwdGVyKG9wdGlvbnMgPSB7fSkge1xuXHRjb25zdCB7IHNlbGVjdElkLCBzb3J0Q29tcGFyZXIgfSA9IHtcblx0XHRzb3J0Q29tcGFyZXI6IGZhbHNlLFxuXHRcdHNlbGVjdElkOiAoaW5zdGFuY2UpID0+IGluc3RhbmNlLmlkLFxuXHRcdC4uLm9wdGlvbnNcblx0fTtcblx0Y29uc3Qgc3RhdGVBZGFwdGVyID0gc29ydENvbXBhcmVyID8gY3JlYXRlU29ydGVkU3RhdGVBZGFwdGVyKHNlbGVjdElkLCBzb3J0Q29tcGFyZXIpIDogY3JlYXRlVW5zb3J0ZWRTdGF0ZUFkYXB0ZXIoc2VsZWN0SWQpO1xuXHRjb25zdCBzdGF0ZUZhY3RvcnkgPSBjcmVhdGVJbml0aWFsU3RhdGVGYWN0b3J5KHN0YXRlQWRhcHRlcik7XG5cdGNvbnN0IHNlbGVjdG9yc0ZhY3RvcnkgPSBjcmVhdGVTZWxlY3RvcnNGYWN0b3J5KCk7XG5cdHJldHVybiB7XG5cdFx0c2VsZWN0SWQsXG5cdFx0c29ydENvbXBhcmVyLFxuXHRcdC4uLnN0YXRlRmFjdG9yeSxcblx0XHQuLi5zZWxlY3RvcnNGYWN0b3J5LFxuXHRcdC4uLnN0YXRlQWRhcHRlclxuXHR9O1xufVxuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2xpc3RlbmVyTWlkZGxld2FyZS9leGNlcHRpb25zLnRzXG5jb25zdCB0YXNrID0gXCJ0YXNrXCI7XG5jb25zdCBsaXN0ZW5lciA9IFwibGlzdGVuZXJcIjtcbmNvbnN0IGNvbXBsZXRlZCA9IFwiY29tcGxldGVkXCI7XG5jb25zdCBjYW5jZWxsZWQgPSBcImNhbmNlbGxlZFwiO1xuY29uc3QgdGFza0NhbmNlbGxlZCA9IGB0YXNrLSR7Y2FuY2VsbGVkfWA7XG5jb25zdCB0YXNrQ29tcGxldGVkID0gYHRhc2stJHtjb21wbGV0ZWR9YDtcbmNvbnN0IGxpc3RlbmVyQ2FuY2VsbGVkID0gYCR7bGlzdGVuZXJ9LSR7Y2FuY2VsbGVkfWA7XG5jb25zdCBsaXN0ZW5lckNvbXBsZXRlZCA9IGAke2xpc3RlbmVyfS0ke2NvbXBsZXRlZH1gO1xudmFyIFRhc2tBYm9ydEVycm9yID0gY2xhc3Mge1xuXHRjb2RlO1xuXHRuYW1lID0gXCJUYXNrQWJvcnRFcnJvclwiO1xuXHRtZXNzYWdlO1xuXHRjb25zdHJ1Y3Rvcihjb2RlKSB7XG5cdFx0dGhpcy5jb2RlID0gY29kZTtcblx0XHR0aGlzLm1lc3NhZ2UgPSBgJHt0YXNrfSAke2NhbmNlbGxlZH0gKHJlYXNvbjogJHtjb2RlfSlgO1xuXHR9XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2xpc3RlbmVyTWlkZGxld2FyZS91dGlscy50c1xuY29uc3QgYXNzZXJ0RnVuY3Rpb24gPSAoZnVuYywgZXhwZWN0ZWQpID0+IHtcblx0aWYgKHR5cGVvZiBmdW5jICE9PSBcImZ1bmN0aW9uXCIpIHRocm93IG5ldyBUeXBlRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgzMikgOiBgJHtleHBlY3RlZH0gaXMgbm90IGEgZnVuY3Rpb25gKTtcbn07XG5jb25zdCBub29wID0gKCkgPT4ge307XG5jb25zdCBjYXRjaFJlamVjdGlvbiA9IChwcm9taXNlLCBvbkVycm9yID0gbm9vcCkgPT4ge1xuXHRwcm9taXNlLmNhdGNoKG9uRXJyb3IpO1xuXHRyZXR1cm4gcHJvbWlzZTtcbn07XG5jb25zdCBhZGRBYm9ydFNpZ25hbExpc3RlbmVyID0gKGFib3J0U2lnbmFsLCBjYWxsYmFjaykgPT4ge1xuXHRhYm9ydFNpZ25hbC5hZGRFdmVudExpc3RlbmVyKFwiYWJvcnRcIiwgY2FsbGJhY2ssIHsgb25jZTogdHJ1ZSB9KTtcblx0cmV0dXJuICgpID0+IGFib3J0U2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJhYm9ydFwiLCBjYWxsYmFjayk7XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2xpc3RlbmVyTWlkZGxld2FyZS90YXNrLnRzXG5jb25zdCB2YWxpZGF0ZUFjdGl2ZSA9IChzaWduYWwpID0+IHtcblx0aWYgKHNpZ25hbC5hYm9ydGVkKSB0aHJvdyBuZXcgVGFza0Fib3J0RXJyb3Ioc2lnbmFsLnJlYXNvbik7XG59O1xuZnVuY3Rpb24gcmFjZVdpdGhTaWduYWwoc2lnbmFsLCBwcm9taXNlKSB7XG5cdGxldCBjbGVhbnVwID0gbm9vcDtcblx0cmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRjb25zdCBub3RpZnlSZWplY3Rpb24gPSAoKSA9PiByZWplY3QobmV3IFRhc2tBYm9ydEVycm9yKHNpZ25hbC5yZWFzb24pKTtcblx0XHRpZiAoc2lnbmFsLmFib3J0ZWQpIHtcblx0XHRcdG5vdGlmeVJlamVjdGlvbigpO1xuXHRcdFx0cmV0dXJuO1xuXHRcdH1cblx0XHRjbGVhbnVwID0gYWRkQWJvcnRTaWduYWxMaXN0ZW5lcihzaWduYWwsIG5vdGlmeVJlamVjdGlvbik7XG5cdFx0cHJvbWlzZS5maW5hbGx5KCgpID0+IGNsZWFudXAoKSkudGhlbihyZXNvbHZlLCByZWplY3QpO1xuXHR9KS5maW5hbGx5KCgpID0+IHtcblx0XHRjbGVhbnVwID0gbm9vcDtcblx0fSk7XG59XG5jb25zdCBydW5UYXNrID0gYXN5bmMgKHRhc2ssIGNsZWFuVXApID0+IHtcblx0dHJ5IHtcblx0XHRhd2FpdCBQcm9taXNlLnJlc29sdmUoKTtcblx0XHRyZXR1cm4ge1xuXHRcdFx0c3RhdHVzOiBcIm9rXCIsXG5cdFx0XHR2YWx1ZTogYXdhaXQgdGFzaygpXG5cdFx0fTtcblx0fSBjYXRjaCAoZXJyb3IpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0c3RhdHVzOiBlcnJvciBpbnN0YW5jZW9mIFRhc2tBYm9ydEVycm9yID8gXCJjYW5jZWxsZWRcIiA6IFwicmVqZWN0ZWRcIixcblx0XHRcdGVycm9yXG5cdFx0fTtcblx0fSBmaW5hbGx5IHtcblx0XHRjbGVhblVwPy4oKTtcblx0fVxufTtcbmNvbnN0IGNyZWF0ZVBhdXNlID0gKHNpZ25hbCkgPT4ge1xuXHRyZXR1cm4gKHByb21pc2UpID0+IHtcblx0XHRyZXR1cm4gY2F0Y2hSZWplY3Rpb24ocmFjZVdpdGhTaWduYWwoc2lnbmFsLCBwcm9taXNlKS50aGVuKChvdXRwdXQpID0+IHtcblx0XHRcdHZhbGlkYXRlQWN0aXZlKHNpZ25hbCk7XG5cdFx0XHRyZXR1cm4gb3V0cHV0O1xuXHRcdH0pKTtcblx0fTtcbn07XG5jb25zdCBjcmVhdGVEZWxheSA9IChzaWduYWwpID0+IHtcblx0Y29uc3QgcGF1c2UgPSBjcmVhdGVQYXVzZShzaWduYWwpO1xuXHRyZXR1cm4gKHRpbWVvdXRNcykgPT4ge1xuXHRcdHJldHVybiBwYXVzZShuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCB0aW1lb3V0TXMpKSk7XG5cdH07XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2xpc3RlbmVyTWlkZGxld2FyZS9pbmRleC50c1xuY29uc3QgeyBhc3NpZ24gfSA9IE9iamVjdDtcbmNvbnN0IElOVEVSTkFMX05JTF9UT0tFTiA9IHt9O1xuY29uc3QgYWxtID0gXCJsaXN0ZW5lck1pZGRsZXdhcmVcIjtcbmNvbnN0IGNyZWF0ZUZvcmsgPSAocGFyZW50QWJvcnRTaWduYWwsIHBhcmVudEJsb2NraW5nUHJvbWlzZXMpID0+IHtcblx0Y29uc3QgbGlua0NvbnRyb2xsZXJzID0gKGNvbnRyb2xsZXIpID0+IGFkZEFib3J0U2lnbmFsTGlzdGVuZXIocGFyZW50QWJvcnRTaWduYWwsICgpID0+IGNvbnRyb2xsZXIuYWJvcnQocGFyZW50QWJvcnRTaWduYWwucmVhc29uKSk7XG5cdHJldHVybiAodGFza0V4ZWN1dG9yLCBvcHRzKSA9PiB7XG5cdFx0YXNzZXJ0RnVuY3Rpb24odGFza0V4ZWN1dG9yLCBcInRhc2tFeGVjdXRvclwiKTtcblx0XHRjb25zdCBjaGlsZEFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRsaW5rQ29udHJvbGxlcnMoY2hpbGRBYm9ydENvbnRyb2xsZXIpO1xuXHRcdGNvbnN0IHJlc3VsdCA9IHJ1blRhc2soYXN5bmMgKCkgPT4ge1xuXHRcdFx0dmFsaWRhdGVBY3RpdmUocGFyZW50QWJvcnRTaWduYWwpO1xuXHRcdFx0dmFsaWRhdGVBY3RpdmUoY2hpbGRBYm9ydENvbnRyb2xsZXIuc2lnbmFsKTtcblx0XHRcdGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRhc2tFeGVjdXRvcih7XG5cdFx0XHRcdHBhdXNlOiBjcmVhdGVQYXVzZShjaGlsZEFib3J0Q29udHJvbGxlci5zaWduYWwpLFxuXHRcdFx0XHRkZWxheTogY3JlYXRlRGVsYXkoY2hpbGRBYm9ydENvbnRyb2xsZXIuc2lnbmFsKSxcblx0XHRcdFx0c2lnbmFsOiBjaGlsZEFib3J0Q29udHJvbGxlci5zaWduYWxcblx0XHRcdH0pO1xuXHRcdFx0dmFsaWRhdGVBY3RpdmUoY2hpbGRBYm9ydENvbnRyb2xsZXIuc2lnbmFsKTtcblx0XHRcdHJldHVybiByZXN1bHQ7XG5cdFx0fSwgKCkgPT4gY2hpbGRBYm9ydENvbnRyb2xsZXIuYWJvcnQodGFza0NvbXBsZXRlZCkpO1xuXHRcdGlmIChvcHRzPy5hdXRvSm9pbikgcGFyZW50QmxvY2tpbmdQcm9taXNlcy5wdXNoKHJlc3VsdC5jYXRjaChub29wKSk7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHJlc3VsdDogY3JlYXRlUGF1c2UocGFyZW50QWJvcnRTaWduYWwpKHJlc3VsdCksXG5cdFx0XHRjYW5jZWwoKSB7XG5cdFx0XHRcdGNoaWxkQWJvcnRDb250cm9sbGVyLmFib3J0KHRhc2tDYW5jZWxsZWQpO1xuXHRcdFx0fVxuXHRcdH07XG5cdH07XG59O1xuY29uc3QgY3JlYXRlVGFrZVBhdHRlcm4gPSAoc3RhcnRMaXN0ZW5pbmcsIHNpZ25hbCkgPT4ge1xuXHRjb25zdCB0YWtlID0gYXN5bmMgKHByZWRpY2F0ZSwgdGltZW91dCkgPT4ge1xuXHRcdHZhbGlkYXRlQWN0aXZlKHNpZ25hbCk7XG5cdFx0bGV0IHVuc3Vic2NyaWJlID0gKCkgPT4ge307XG5cdFx0Y29uc3QgcHJvbWlzZXMgPSBbbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuXHRcdFx0bGV0IHN0b3BMaXN0ZW5pbmcgPSBzdGFydExpc3RlbmluZyh7XG5cdFx0XHRcdHByZWRpY2F0ZSxcblx0XHRcdFx0ZWZmZWN0OiAoYWN0aW9uLCBsaXN0ZW5lckFwaSkgPT4ge1xuXHRcdFx0XHRcdGxpc3RlbmVyQXBpLnVuc3Vic2NyaWJlKCk7XG5cdFx0XHRcdFx0cmVzb2x2ZShbXG5cdFx0XHRcdFx0XHRhY3Rpb24sXG5cdFx0XHRcdFx0XHRsaXN0ZW5lckFwaS5nZXRTdGF0ZSgpLFxuXHRcdFx0XHRcdFx0bGlzdGVuZXJBcGkuZ2V0T3JpZ2luYWxTdGF0ZSgpXG5cdFx0XHRcdFx0XSk7XG5cdFx0XHRcdH1cblx0XHRcdH0pO1xuXHRcdFx0dW5zdWJzY3JpYmUgPSAoKSA9PiB7XG5cdFx0XHRcdHN0b3BMaXN0ZW5pbmcoKTtcblx0XHRcdFx0cmVqZWN0KCk7XG5cdFx0XHR9O1xuXHRcdH0pXTtcblx0XHRpZiAodGltZW91dCAhPSBudWxsKSBwcm9taXNlcy5wdXNoKG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIHRpbWVvdXQsIG51bGwpKSk7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbnN0IG91dHB1dCA9IGF3YWl0IHJhY2VXaXRoU2lnbmFsKHNpZ25hbCwgUHJvbWlzZS5yYWNlKHByb21pc2VzKSk7XG5cdFx0XHR2YWxpZGF0ZUFjdGl2ZShzaWduYWwpO1xuXHRcdFx0cmV0dXJuIG91dHB1dDtcblx0XHR9IGZpbmFsbHkge1xuXHRcdFx0dW5zdWJzY3JpYmUoKTtcblx0XHR9XG5cdH07XG5cdHJldHVybiAoKHByZWRpY2F0ZSwgdGltZW91dCkgPT4gY2F0Y2hSZWplY3Rpb24odGFrZShwcmVkaWNhdGUsIHRpbWVvdXQpKSk7XG59O1xuY29uc3QgZ2V0TGlzdGVuZXJFbnRyeVByb3BzRnJvbSA9IChvcHRpb25zKSA9PiB7XG5cdGxldCB7IHR5cGUsIGFjdGlvbkNyZWF0b3IsIG1hdGNoZXIsIHByZWRpY2F0ZSwgZWZmZWN0IH0gPSBvcHRpb25zO1xuXHRpZiAodHlwZSkgcHJlZGljYXRlID0gY3JlYXRlQWN0aW9uKHR5cGUpLm1hdGNoO1xuXHRlbHNlIGlmIChhY3Rpb25DcmVhdG9yKSB7XG5cdFx0dHlwZSA9IGFjdGlvbkNyZWF0b3IudHlwZTtcblx0XHRwcmVkaWNhdGUgPSBhY3Rpb25DcmVhdG9yLm1hdGNoO1xuXHR9IGVsc2UgaWYgKG1hdGNoZXIpIHByZWRpY2F0ZSA9IG1hdGNoZXI7XG5cdGVsc2UgaWYgKHByZWRpY2F0ZSkge30gZWxzZSB0aHJvdyBuZXcgRXJyb3IocHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwicHJvZHVjdGlvblwiID8gZm9ybWF0UHJvZEVycm9yTWVzc2FnZSgyMSkgOiBcIkNyZWF0aW5nIG9yIHJlbW92aW5nIGEgbGlzdGVuZXIgcmVxdWlyZXMgb25lIG9mIHRoZSBrbm93biBmaWVsZHMgZm9yIG1hdGNoaW5nIGFuIGFjdGlvblwiKTtcblx0YXNzZXJ0RnVuY3Rpb24oZWZmZWN0LCBcIm9wdGlvbnMubGlzdGVuZXJcIik7XG5cdHJldHVybiB7XG5cdFx0cHJlZGljYXRlLFxuXHRcdHR5cGUsXG5cdFx0ZWZmZWN0XG5cdH07XG59O1xuY29uc3QgY3JlYXRlTGlzdGVuZXJFbnRyeSA9IC8qIEBfX1BVUkVfXyAqLyBhc3NpZ24oKG9wdGlvbnMpID0+IHtcblx0Y29uc3QgeyB0eXBlLCBwcmVkaWNhdGUsIGVmZmVjdCB9ID0gZ2V0TGlzdGVuZXJFbnRyeVByb3BzRnJvbShvcHRpb25zKTtcblx0cmV0dXJuIHtcblx0XHRpZDogbmFub2lkKCksXG5cdFx0ZWZmZWN0LFxuXHRcdHR5cGUsXG5cdFx0cHJlZGljYXRlLFxuXHRcdHBlbmRpbmc6IC8qIEBfX1BVUkVfXyAqLyBuZXcgU2V0KCksXG5cdFx0dW5zdWJzY3JpYmU6ICgpID0+IHtcblx0XHRcdHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDIyKSA6IFwiVW5zdWJzY3JpYmUgbm90IGluaXRpYWxpemVkXCIpO1xuXHRcdH1cblx0fTtcbn0sIHsgd2l0aFR5cGVzOiAoKSA9PiBjcmVhdGVMaXN0ZW5lckVudHJ5IH0pO1xuY29uc3QgZmluZExpc3RlbmVyRW50cnkgPSAobGlzdGVuZXJNYXAsIG9wdGlvbnMpID0+IHtcblx0Y29uc3QgeyB0eXBlLCBlZmZlY3QsIHByZWRpY2F0ZSB9ID0gZ2V0TGlzdGVuZXJFbnRyeVByb3BzRnJvbShvcHRpb25zKTtcblx0cmV0dXJuIEFycmF5LmZyb20obGlzdGVuZXJNYXAudmFsdWVzKCkpLmZpbmQoKGVudHJ5KSA9PiB7XG5cdFx0cmV0dXJuICh0eXBlb2YgdHlwZSA9PT0gXCJzdHJpbmdcIiA/IGVudHJ5LnR5cGUgPT09IHR5cGUgOiBlbnRyeS5wcmVkaWNhdGUgPT09IHByZWRpY2F0ZSkgJiYgZW50cnkuZWZmZWN0ID09PSBlZmZlY3Q7XG5cdH0pO1xufTtcbmNvbnN0IGNhbmNlbEFjdGl2ZUxpc3RlbmVycyA9IChlbnRyeSkgPT4ge1xuXHRlbnRyeS5wZW5kaW5nLmZvckVhY2goKGNvbnRyb2xsZXIpID0+IHtcblx0XHRjb250cm9sbGVyLmFib3J0KGxpc3RlbmVyQ2FuY2VsbGVkKTtcblx0fSk7XG59O1xuY29uc3QgY3JlYXRlQ2xlYXJMaXN0ZW5lck1pZGRsZXdhcmUgPSAobGlzdGVuZXJNYXAsIGV4ZWN1dGluZ0xpc3RlbmVycykgPT4ge1xuXHRyZXR1cm4gKCkgPT4ge1xuXHRcdGZvciAoY29uc3QgbGlzdGVuZXIgb2YgZXhlY3V0aW5nTGlzdGVuZXJzLmtleXMoKSkgY2FuY2VsQWN0aXZlTGlzdGVuZXJzKGxpc3RlbmVyKTtcblx0XHRsaXN0ZW5lck1hcC5jbGVhcigpO1xuXHR9O1xufTtcbmNvbnN0IHNhZmVseU5vdGlmeUVycm9yID0gKGVycm9ySGFuZGxlciwgZXJyb3JUb05vdGlmeSwgZXJyb3JJbmZvKSA9PiB7XG5cdHRyeSB7XG5cdFx0ZXJyb3JIYW5kbGVyKGVycm9yVG9Ob3RpZnksIGVycm9ySW5mbyk7XG5cdH0gY2F0Y2ggKGVycm9ySGFuZGxlckVycm9yKSB7XG5cdFx0c2V0VGltZW91dCgoKSA9PiB7XG5cdFx0XHR0aHJvdyBlcnJvckhhbmRsZXJFcnJvcjtcblx0XHR9LCAwKTtcblx0fVxufTtcbmNvbnN0IGFkZExpc3RlbmVyID0gLyogQF9fUFVSRV9fICovIGFzc2lnbigvKiBAX19QVVJFX18gKi8gY3JlYXRlQWN0aW9uKGAke2FsbX0vYWRkYCksIHsgd2l0aFR5cGVzOiAoKSA9PiBhZGRMaXN0ZW5lciB9KTtcbmNvbnN0IGNsZWFyQWxsTGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIGNyZWF0ZUFjdGlvbihgJHthbG19L3JlbW92ZUFsbGApO1xuY29uc3QgcmVtb3ZlTGlzdGVuZXIgPSAvKiBAX19QVVJFX18gKi8gYXNzaWduKC8qIEBfX1BVUkVfXyAqLyBjcmVhdGVBY3Rpb24oYCR7YWxtfS9yZW1vdmVgKSwgeyB3aXRoVHlwZXM6ICgpID0+IHJlbW92ZUxpc3RlbmVyIH0pO1xuY29uc3QgZGVmYXVsdEVycm9ySGFuZGxlciA9ICguLi5hcmdzKSA9PiB7XG5cdGNvbnNvbGUuZXJyb3IoYCR7YWxtfS9lcnJvcmAsIC4uLmFyZ3MpO1xufTtcbmNvbnN0IGNyZWF0ZUxpc3RlbmVyTWlkZGxld2FyZSA9IChtaWRkbGV3YXJlT3B0aW9ucyA9IHt9KSA9PiB7XG5cdGNvbnN0IGxpc3RlbmVyTWFwID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0Y29uc3QgZXhlY3V0aW5nTGlzdGVuZXJzID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcblx0Y29uc3QgdHJhY2tFeGVjdXRpbmdMaXN0ZW5lciA9IChlbnRyeSkgPT4ge1xuXHRcdGNvbnN0IGNvdW50ID0gZXhlY3V0aW5nTGlzdGVuZXJzLmdldChlbnRyeSkgPz8gMDtcblx0XHRleGVjdXRpbmdMaXN0ZW5lcnMuc2V0KGVudHJ5LCBjb3VudCArIDEpO1xuXHR9O1xuXHRjb25zdCB1bnRyYWNrRXhlY3V0aW5nTGlzdGVuZXIgPSAoZW50cnkpID0+IHtcblx0XHRjb25zdCBjb3VudCA9IGV4ZWN1dGluZ0xpc3RlbmVycy5nZXQoZW50cnkpID8/IDE7XG5cdFx0aWYgKGNvdW50ID09PSAxKSBleGVjdXRpbmdMaXN0ZW5lcnMuZGVsZXRlKGVudHJ5KTtcblx0XHRlbHNlIGV4ZWN1dGluZ0xpc3RlbmVycy5zZXQoZW50cnksIGNvdW50IC0gMSk7XG5cdH07XG5cdGNvbnN0IHsgZXh0cmEsIG9uRXJyb3IgPSBkZWZhdWx0RXJyb3JIYW5kbGVyIH0gPSBtaWRkbGV3YXJlT3B0aW9ucztcblx0YXNzZXJ0RnVuY3Rpb24ob25FcnJvciwgXCJvbkVycm9yXCIpO1xuXHRjb25zdCBpbnNlcnRFbnRyeSA9IChlbnRyeSkgPT4ge1xuXHRcdGVudHJ5LnVuc3Vic2NyaWJlID0gKCkgPT4gbGlzdGVuZXJNYXAuZGVsZXRlKGVudHJ5LmlkKTtcblx0XHRsaXN0ZW5lck1hcC5zZXQoZW50cnkuaWQsIGVudHJ5KTtcblx0XHRyZXR1cm4gKGNhbmNlbE9wdGlvbnMpID0+IHtcblx0XHRcdGVudHJ5LnVuc3Vic2NyaWJlKCk7XG5cdFx0XHRpZiAoY2FuY2VsT3B0aW9ucz8uY2FuY2VsQWN0aXZlKSBjYW5jZWxBY3RpdmVMaXN0ZW5lcnMoZW50cnkpO1xuXHRcdH07XG5cdH07XG5cdGNvbnN0IHN0YXJ0TGlzdGVuaW5nID0gKChvcHRpb25zKSA9PiB7XG5cdFx0Y29uc3QgZW50cnkgPSBmaW5kTGlzdGVuZXJFbnRyeShsaXN0ZW5lck1hcCwgb3B0aW9ucykgPz8gY3JlYXRlTGlzdGVuZXJFbnRyeShvcHRpb25zKTtcblx0XHRyZXR1cm4gaW5zZXJ0RW50cnkoZW50cnkpO1xuXHR9KTtcblx0YXNzaWduKHN0YXJ0TGlzdGVuaW5nLCB7IHdpdGhUeXBlczogKCkgPT4gc3RhcnRMaXN0ZW5pbmcgfSk7XG5cdGNvbnN0IHN0b3BMaXN0ZW5pbmcgPSAob3B0aW9ucykgPT4ge1xuXHRcdGNvbnN0IGVudHJ5ID0gZmluZExpc3RlbmVyRW50cnkobGlzdGVuZXJNYXAsIG9wdGlvbnMpO1xuXHRcdGlmIChlbnRyeSkge1xuXHRcdFx0ZW50cnkudW5zdWJzY3JpYmUoKTtcblx0XHRcdGlmIChvcHRpb25zLmNhbmNlbEFjdGl2ZSkgY2FuY2VsQWN0aXZlTGlzdGVuZXJzKGVudHJ5KTtcblx0XHR9XG5cdFx0cmV0dXJuICEhZW50cnk7XG5cdH07XG5cdGFzc2lnbihzdG9wTGlzdGVuaW5nLCB7IHdpdGhUeXBlczogKCkgPT4gc3RvcExpc3RlbmluZyB9KTtcblx0Y29uc3Qgbm90aWZ5TGlzdGVuZXIgPSBhc3luYyAoZW50cnksIGFjdGlvbiwgYXBpLCBnZXRPcmlnaW5hbFN0YXRlKSA9PiB7XG5cdFx0Y29uc3QgaW50ZXJuYWxUYXNrQ29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblx0XHRjb25zdCB0YWtlID0gY3JlYXRlVGFrZVBhdHRlcm4oc3RhcnRMaXN0ZW5pbmcsIGludGVybmFsVGFza0NvbnRyb2xsZXIuc2lnbmFsKTtcblx0XHRjb25zdCBhdXRvSm9pblByb21pc2VzID0gW107XG5cdFx0dHJ5IHtcblx0XHRcdGVudHJ5LnBlbmRpbmcuYWRkKGludGVybmFsVGFza0NvbnRyb2xsZXIpO1xuXHRcdFx0dHJhY2tFeGVjdXRpbmdMaXN0ZW5lcihlbnRyeSk7XG5cdFx0XHRhd2FpdCBQcm9taXNlLnJlc29sdmUoZW50cnkuZWZmZWN0KGFjdGlvbiwgYXNzaWduKHt9LCBhcGksIHtcblx0XHRcdFx0Z2V0T3JpZ2luYWxTdGF0ZSxcblx0XHRcdFx0Y29uZGl0aW9uOiAocHJlZGljYXRlLCB0aW1lb3V0KSA9PiB0YWtlKHByZWRpY2F0ZSwgdGltZW91dCkudGhlbihCb29sZWFuKSxcblx0XHRcdFx0dGFrZSxcblx0XHRcdFx0ZGVsYXk6IGNyZWF0ZURlbGF5KGludGVybmFsVGFza0NvbnRyb2xsZXIuc2lnbmFsKSxcblx0XHRcdFx0cGF1c2U6IGNyZWF0ZVBhdXNlKGludGVybmFsVGFza0NvbnRyb2xsZXIuc2lnbmFsKSxcblx0XHRcdFx0ZXh0cmEsXG5cdFx0XHRcdHNpZ25hbDogaW50ZXJuYWxUYXNrQ29udHJvbGxlci5zaWduYWwsXG5cdFx0XHRcdGZvcms6IGNyZWF0ZUZvcmsoaW50ZXJuYWxUYXNrQ29udHJvbGxlci5zaWduYWwsIGF1dG9Kb2luUHJvbWlzZXMpLFxuXHRcdFx0XHR1bnN1YnNjcmliZTogZW50cnkudW5zdWJzY3JpYmUsXG5cdFx0XHRcdHN1YnNjcmliZTogKCkgPT4ge1xuXHRcdFx0XHRcdGxpc3RlbmVyTWFwLnNldChlbnRyeS5pZCwgZW50cnkpO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHRjYW5jZWxBY3RpdmVMaXN0ZW5lcnM6ICgpID0+IHtcblx0XHRcdFx0XHRlbnRyeS5wZW5kaW5nLmZvckVhY2goKGNvbnRyb2xsZXIsIF8sIHNldCkgPT4ge1xuXHRcdFx0XHRcdFx0aWYgKGNvbnRyb2xsZXIgIT09IGludGVybmFsVGFza0NvbnRyb2xsZXIpIHtcblx0XHRcdFx0XHRcdFx0Y29udHJvbGxlci5hYm9ydChsaXN0ZW5lckNhbmNlbGxlZCk7XG5cdFx0XHRcdFx0XHRcdHNldC5kZWxldGUoY29udHJvbGxlcik7XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fSk7XG5cdFx0XHRcdH0sXG5cdFx0XHRcdGNhbmNlbDogKCkgPT4ge1xuXHRcdFx0XHRcdGludGVybmFsVGFza0NvbnRyb2xsZXIuYWJvcnQobGlzdGVuZXJDYW5jZWxsZWQpO1xuXHRcdFx0XHRcdGVudHJ5LnBlbmRpbmcuZGVsZXRlKGludGVybmFsVGFza0NvbnRyb2xsZXIpO1xuXHRcdFx0XHR9LFxuXHRcdFx0XHR0aHJvd0lmQ2FuY2VsbGVkOiAoKSA9PiB7XG5cdFx0XHRcdFx0dmFsaWRhdGVBY3RpdmUoaW50ZXJuYWxUYXNrQ29udHJvbGxlci5zaWduYWwpO1xuXHRcdFx0XHR9XG5cdFx0XHR9KSkpO1xuXHRcdH0gY2F0Y2ggKGxpc3RlbmVyRXJyb3IpIHtcblx0XHRcdGlmICghKGxpc3RlbmVyRXJyb3IgaW5zdGFuY2VvZiBUYXNrQWJvcnRFcnJvcikpIHNhZmVseU5vdGlmeUVycm9yKG9uRXJyb3IsIGxpc3RlbmVyRXJyb3IsIHsgcmFpc2VkQnk6IFwiZWZmZWN0XCIgfSk7XG5cdFx0fSBmaW5hbGx5IHtcblx0XHRcdGF3YWl0IFByb21pc2UuYWxsKGF1dG9Kb2luUHJvbWlzZXMpO1xuXHRcdFx0aW50ZXJuYWxUYXNrQ29udHJvbGxlci5hYm9ydChsaXN0ZW5lckNvbXBsZXRlZCk7XG5cdFx0XHR1bnRyYWNrRXhlY3V0aW5nTGlzdGVuZXIoZW50cnkpO1xuXHRcdFx0ZW50cnkucGVuZGluZy5kZWxldGUoaW50ZXJuYWxUYXNrQ29udHJvbGxlcik7XG5cdFx0fVxuXHR9O1xuXHRjb25zdCBjbGVhckxpc3RlbmVyTWlkZGxld2FyZSA9IGNyZWF0ZUNsZWFyTGlzdGVuZXJNaWRkbGV3YXJlKGxpc3RlbmVyTWFwLCBleGVjdXRpbmdMaXN0ZW5lcnMpO1xuXHRjb25zdCBtaWRkbGV3YXJlID0gKGFwaSkgPT4gKG5leHQpID0+IChhY3Rpb24pID0+IHtcblx0XHRpZiAoIWlzQWN0aW9uKGFjdGlvbikpIHJldHVybiBuZXh0KGFjdGlvbik7XG5cdFx0aWYgKGFkZExpc3RlbmVyLm1hdGNoKGFjdGlvbikpIHJldHVybiBzdGFydExpc3RlbmluZyhhY3Rpb24ucGF5bG9hZCk7XG5cdFx0aWYgKGNsZWFyQWxsTGlzdGVuZXJzLm1hdGNoKGFjdGlvbikpIHtcblx0XHRcdGNsZWFyTGlzdGVuZXJNaWRkbGV3YXJlKCk7XG5cdFx0XHRyZXR1cm47XG5cdFx0fVxuXHRcdGlmIChyZW1vdmVMaXN0ZW5lci5tYXRjaChhY3Rpb24pKSByZXR1cm4gc3RvcExpc3RlbmluZyhhY3Rpb24ucGF5bG9hZCk7XG5cdFx0bGV0IG9yaWdpbmFsU3RhdGUgPSBhcGkuZ2V0U3RhdGUoKTtcblx0XHRjb25zdCBnZXRPcmlnaW5hbFN0YXRlID0gKCkgPT4ge1xuXHRcdFx0aWYgKG9yaWdpbmFsU3RhdGUgPT09IElOVEVSTkFMX05JTF9UT0tFTikgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMjMpIDogYCR7YWxtfTogZ2V0T3JpZ2luYWxTdGF0ZSBjYW4gb25seSBiZSBjYWxsZWQgc3luY2hyb25vdXNseWApO1xuXHRcdFx0cmV0dXJuIG9yaWdpbmFsU3RhdGU7XG5cdFx0fTtcblx0XHRsZXQgcmVzdWx0O1xuXHRcdHRyeSB7XG5cdFx0XHRyZXN1bHQgPSBuZXh0KGFjdGlvbik7XG5cdFx0XHRpZiAobGlzdGVuZXJNYXAuc2l6ZSA+IDApIHtcblx0XHRcdFx0Y29uc3QgY3VycmVudFN0YXRlID0gYXBpLmdldFN0YXRlKCk7XG5cdFx0XHRcdGNvbnN0IGxpc3RlbmVyRW50cmllcyA9IEFycmF5LmZyb20obGlzdGVuZXJNYXAudmFsdWVzKCkpO1xuXHRcdFx0XHRmb3IgKGNvbnN0IGVudHJ5IG9mIGxpc3RlbmVyRW50cmllcykge1xuXHRcdFx0XHRcdGxldCBydW5MaXN0ZW5lciA9IGZhbHNlO1xuXHRcdFx0XHRcdHRyeSB7XG5cdFx0XHRcdFx0XHRydW5MaXN0ZW5lciA9IGVudHJ5LnByZWRpY2F0ZShhY3Rpb24sIGN1cnJlbnRTdGF0ZSwgb3JpZ2luYWxTdGF0ZSk7XG5cdFx0XHRcdFx0fSBjYXRjaCAocHJlZGljYXRlRXJyb3IpIHtcblx0XHRcdFx0XHRcdHJ1bkxpc3RlbmVyID0gZmFsc2U7XG5cdFx0XHRcdFx0XHRzYWZlbHlOb3RpZnlFcnJvcihvbkVycm9yLCBwcmVkaWNhdGVFcnJvciwgeyByYWlzZWRCeTogXCJwcmVkaWNhdGVcIiB9KTtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0aWYgKCFydW5MaXN0ZW5lcikgY29udGludWU7XG5cdFx0XHRcdFx0bm90aWZ5TGlzdGVuZXIoZW50cnksIGFjdGlvbiwgYXBpLCBnZXRPcmlnaW5hbFN0YXRlKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH0gZmluYWxseSB7XG5cdFx0XHRvcmlnaW5hbFN0YXRlID0gSU5URVJOQUxfTklMX1RPS0VOO1xuXHRcdH1cblx0XHRyZXR1cm4gcmVzdWx0O1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdG1pZGRsZXdhcmUsXG5cdFx0c3RhcnRMaXN0ZW5pbmcsXG5cdFx0c3RvcExpc3RlbmluZyxcblx0XHRjbGVhckxpc3RlbmVyczogY2xlYXJMaXN0ZW5lck1pZGRsZXdhcmVcblx0fTtcbn07XG4vLyNlbmRyZWdpb25cbi8vI3JlZ2lvbiBzcmMvZHluYW1pY01pZGRsZXdhcmUvaW5kZXgudHNcbmNvbnN0IGNyZWF0ZU1pZGRsZXdhcmVFbnRyeSA9IChtaWRkbGV3YXJlKSA9PiAoe1xuXHRtaWRkbGV3YXJlLFxuXHRhcHBsaWVkOiAvKiBAX19QVVJFX18gKi8gbmV3IE1hcCgpXG59KTtcbmNvbnN0IG1hdGNoSW5zdGFuY2UgPSAoaW5zdGFuY2VJZCkgPT4gKGFjdGlvbikgPT4gYWN0aW9uPy5tZXRhPy5pbnN0YW5jZUlkID09PSBpbnN0YW5jZUlkO1xuY29uc3QgY3JlYXRlRHluYW1pY01pZGRsZXdhcmUgPSAoKSA9PiB7XG5cdGNvbnN0IGluc3RhbmNlSWQgPSBuYW5vaWQoKTtcblx0Y29uc3QgbWlkZGxld2FyZU1hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5cdGxldCBtaWRkbGV3YXJlVmVyc2lvbiA9IDA7XG5cdGNvbnN0IHdpdGhNaWRkbGV3YXJlID0gT2JqZWN0LmFzc2lnbihjcmVhdGVBY3Rpb24oXCJkeW5hbWljTWlkZGxld2FyZS9hZGRcIiwgKC4uLm1pZGRsZXdhcmVzKSA9PiAoe1xuXHRcdHBheWxvYWQ6IG1pZGRsZXdhcmVzLFxuXHRcdG1ldGE6IHsgaW5zdGFuY2VJZCB9XG5cdH0pKSwgeyB3aXRoVHlwZXM6ICgpID0+IHdpdGhNaWRkbGV3YXJlIH0pO1xuXHRjb25zdCBhZGRNaWRkbGV3YXJlID0gT2JqZWN0LmFzc2lnbihmdW5jdGlvbiBhZGRNaWRkbGV3YXJlKC4uLm1pZGRsZXdhcmVzKSB7XG5cdFx0Y29uc3QgcHJldmlvdXNTaXplID0gbWlkZGxld2FyZU1hcC5zaXplO1xuXHRcdG1pZGRsZXdhcmVzLmZvckVhY2goKG1pZGRsZXdhcmUpID0+IHtcblx0XHRcdGdldE9ySW5zZXJ0Q29tcHV0ZWQobWlkZGxld2FyZU1hcCwgbWlkZGxld2FyZSwgY3JlYXRlTWlkZGxld2FyZUVudHJ5KTtcblx0XHR9KTtcblx0XHRpZiAobWlkZGxld2FyZU1hcC5zaXplICE9PSBwcmV2aW91c1NpemUpIG1pZGRsZXdhcmVWZXJzaW9uKys7XG5cdH0sIHsgd2l0aFR5cGVzOiAoKSA9PiBhZGRNaWRkbGV3YXJlIH0pO1xuXHRjb25zdCBnZXRGaW5hbE1pZGRsZXdhcmUgPSAoYXBpKSA9PiB7XG5cdFx0Y29uc3QgYXBwbGllZE1pZGRsZXdhcmUgPSBBcnJheS5mcm9tKG1pZGRsZXdhcmVNYXAudmFsdWVzKCkpLm1hcCgoZW50cnkpID0+IGdldE9ySW5zZXJ0Q29tcHV0ZWQoZW50cnkuYXBwbGllZCwgYXBpLCBlbnRyeS5taWRkbGV3YXJlKSk7XG5cdFx0cmV0dXJuIGNvbXBvc2UoLi4uYXBwbGllZE1pZGRsZXdhcmUpO1xuXHR9O1xuXHRjb25zdCBpc1dpdGhNaWRkbGV3YXJlID0gaXNBbGxPZih3aXRoTWlkZGxld2FyZSwgbWF0Y2hJbnN0YW5jZShpbnN0YW5jZUlkKSk7XG5cdGNvbnN0IG1pZGRsZXdhcmUgPSAoYXBpKSA9PiAobmV4dCkgPT4ge1xuXHRcdGxldCBhcHBsaWVkVmVyc2lvbiA9IC0xO1xuXHRcdGxldCBkaXNwYXRjaCA9IG5leHQ7XG5cdFx0cmV0dXJuIChhY3Rpb24pID0+IHtcblx0XHRcdGlmIChpc1dpdGhNaWRkbGV3YXJlKGFjdGlvbikpIHtcblx0XHRcdFx0YWRkTWlkZGxld2FyZSguLi5hY3Rpb24ucGF5bG9hZCk7XG5cdFx0XHRcdHJldHVybiBhcGkuZGlzcGF0Y2g7XG5cdFx0XHR9XG5cdFx0XHRpZiAoYXBwbGllZFZlcnNpb24gIT09IG1pZGRsZXdhcmVWZXJzaW9uKSB7XG5cdFx0XHRcdGRpc3BhdGNoID0gZ2V0RmluYWxNaWRkbGV3YXJlKGFwaSkobmV4dCk7XG5cdFx0XHRcdGFwcGxpZWRWZXJzaW9uID0gbWlkZGxld2FyZVZlcnNpb247XG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gZGlzcGF0Y2goYWN0aW9uKTtcblx0XHR9O1xuXHR9O1xuXHRyZXR1cm4ge1xuXHRcdG1pZGRsZXdhcmUsXG5cdFx0YWRkTWlkZGxld2FyZSxcblx0XHR3aXRoTWlkZGxld2FyZSxcblx0XHRpbnN0YW5jZUlkXG5cdH07XG59O1xuLy8jZW5kcmVnaW9uXG4vLyNyZWdpb24gc3JjL2NvbWJpbmVTbGljZXMudHNcbmNvbnN0IGlzU2xpY2VMaWtlID0gKG1heWJlU2xpY2VMaWtlKSA9PiBcInJlZHVjZXJQYXRoXCIgaW4gbWF5YmVTbGljZUxpa2UgJiYgdHlwZW9mIG1heWJlU2xpY2VMaWtlLnJlZHVjZXJQYXRoID09PSBcInN0cmluZ1wiO1xuY29uc3QgZ2V0UmVkdWNlcnMgPSAoc2xpY2VzKSA9PiBzbGljZXMuZmxhdE1hcCgoc2xpY2VPck1hcCkgPT4gaXNTbGljZUxpa2Uoc2xpY2VPck1hcCkgPyBbW3NsaWNlT3JNYXAucmVkdWNlclBhdGgsIHNsaWNlT3JNYXAucmVkdWNlcl1dIDogT2JqZWN0LmVudHJpZXMoc2xpY2VPck1hcCkpO1xuY29uc3QgT1JJR0lOQUxfU1RBVEUgPSBTeW1ib2wuZm9yKFwicnRrLXN0YXRlLXByb3h5LW9yaWdpbmFsXCIpO1xuY29uc3QgaXNTdGF0ZVByb3h5ID0gKHZhbHVlKSA9PiAhIXZhbHVlICYmICEhdmFsdWVbT1JJR0lOQUxfU1RBVEVdO1xuY29uc3QgY3JlYXRlU3RhdGVQcm94eSA9IChzdGF0ZVByb3h5TWFwLCBzdGF0ZSwgcmVkdWNlck1hcCwgaW5pdGlhbFN0YXRlQ2FjaGUpID0+IGdldE9ySW5zZXJ0Q29tcHV0ZWQoc3RhdGVQcm94eU1hcCwgc3RhdGUsICgpID0+IG5ldyBQcm94eShzdGF0ZSwgeyBnZXQ6ICh0YXJnZXQsIHByb3AsIHJlY2VpdmVyKSA9PiB7XG5cdGlmIChwcm9wID09PSBPUklHSU5BTF9TVEFURSkgcmV0dXJuIHRhcmdldDtcblx0Y29uc3QgcmVzdWx0ID0gUmVmbGVjdC5nZXQodGFyZ2V0LCBwcm9wLCByZWNlaXZlcik7XG5cdGlmICh0eXBlb2YgcmVzdWx0ID09PSBcInVuZGVmaW5lZFwiKSB7XG5cdFx0Y29uc3QgY2FjaGVkID0gaW5pdGlhbFN0YXRlQ2FjaGVbcHJvcF07XG5cdFx0aWYgKHR5cGVvZiBjYWNoZWQgIT09IFwidW5kZWZpbmVkXCIpIHJldHVybiBjYWNoZWQ7XG5cdFx0Y29uc3QgcmVkdWNlciA9IHJlZHVjZXJNYXBbcHJvcF07XG5cdFx0aWYgKHJlZHVjZXIpIHtcblx0XHRcdGNvbnN0IHJlZHVjZXJSZXN1bHQgPSByZWR1Y2VyKHZvaWQgMCwgeyB0eXBlOiBuYW5vaWQoKSB9KTtcblx0XHRcdGlmICh0eXBlb2YgcmVkdWNlclJlc3VsdCA9PT0gXCJ1bmRlZmluZWRcIikgdGhyb3cgbmV3IEVycm9yKHByb2Nlc3MuZW52Lk5PREVfRU5WID09PSBcInByb2R1Y3Rpb25cIiA/IGZvcm1hdFByb2RFcnJvck1lc3NhZ2UoMjQpIDogYFRoZSBzbGljZSByZWR1Y2VyIGZvciBrZXkgXCIke3Byb3AudG9TdHJpbmcoKX1cIiByZXR1cm5lZCB1bmRlZmluZWQgd2hlbiBjYWxsZWQgZm9yIHNlbGVjdG9yKCkuIElmIHRoZSBzdGF0ZSBwYXNzZWQgdG8gdGhlIHJlZHVjZXIgaXMgdW5kZWZpbmVkLCB5b3UgbXVzdCBleHBsaWNpdGx5IHJldHVybiB0aGUgaW5pdGlhbCBzdGF0ZS4gVGhlIGluaXRpYWwgc3RhdGUgbWF5IG5vdCBiZSB1bmRlZmluZWQuIElmIHlvdSBkb24ndCB3YW50IHRvIHNldCBhIHZhbHVlIGZvciB0aGlzIHJlZHVjZXIsIHlvdSBjYW4gdXNlIG51bGwgaW5zdGVhZCBvZiB1bmRlZmluZWQuYCk7XG5cdFx0XHRpbml0aWFsU3RhdGVDYWNoZVtwcm9wXSA9IHJlZHVjZXJSZXN1bHQ7XG5cdFx0XHRyZXR1cm4gcmVkdWNlclJlc3VsdDtcblx0XHR9XG5cdH1cblx0cmV0dXJuIHJlc3VsdDtcbn0gfSkpO1xuY29uc3Qgb3JpZ2luYWwkMSA9IChzdGF0ZSkgPT4ge1xuXHRpZiAoIWlzU3RhdGVQcm94eShzdGF0ZSkpIHRocm93IG5ldyBFcnJvcihwcm9jZXNzLmVudi5OT0RFX0VOViA9PT0gXCJwcm9kdWN0aW9uXCIgPyBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKDI1KSA6IFwib3JpZ2luYWwgbXVzdCBiZSB1c2VkIG9uIHN0YXRlIFByb3h5XCIpO1xuXHRyZXR1cm4gc3RhdGVbT1JJR0lOQUxfU1RBVEVdO1xufTtcbmNvbnN0IGVtcHR5T2JqZWN0ID0ge307XG5jb25zdCBub29wUmVkdWNlciA9IChzdGF0ZSA9IGVtcHR5T2JqZWN0KSA9PiBzdGF0ZTtcbmZ1bmN0aW9uIGNvbWJpbmVTbGljZXMoLi4uc2xpY2VzKSB7XG5cdGNvbnN0IHN0YXRlUHJveHlNYXAgPSAvKiBAX19QVVJFX18gKi8gbmV3IFdlYWtNYXAoKTtcblx0Y29uc3QgcmVkdWNlck1hcCA9IE9iamVjdC5mcm9tRW50cmllcyhnZXRSZWR1Y2VycyhzbGljZXMpKTtcblx0Y29uc3QgZ2V0UmVkdWNlciA9ICgpID0+IE9iamVjdC5rZXlzKHJlZHVjZXJNYXApLmxlbmd0aCA/IGNvbWJpbmVSZWR1Y2VycyhyZWR1Y2VyTWFwKSA6IG5vb3BSZWR1Y2VyO1xuXHRsZXQgcmVkdWNlciA9IGdldFJlZHVjZXIoKTtcblx0ZnVuY3Rpb24gY29tYmluZWRSZWR1Y2VyKHN0YXRlLCBhY3Rpb24pIHtcblx0XHRyZXR1cm4gcmVkdWNlcihzdGF0ZSwgYWN0aW9uKTtcblx0fVxuXHRjb21iaW5lZFJlZHVjZXIud2l0aExhenlMb2FkZWRTbGljZXMgPSAoKSA9PiBjb21iaW5lZFJlZHVjZXI7XG5cdGNvbnN0IGluaXRpYWxTdGF0ZUNhY2hlID0ge307XG5cdGNvbnN0IGluamVjdCA9IChzbGljZSwgY29uZmlnID0ge30pID0+IHtcblx0XHRjb25zdCB7IHJlZHVjZXJQYXRoLCByZWR1Y2VyOiByZWR1Y2VyVG9JbmplY3QgfSA9IHNsaWNlO1xuXHRcdGNvbnN0IGN1cnJlbnRSZWR1Y2VyID0gcmVkdWNlck1hcFtyZWR1Y2VyUGF0aF07XG5cdFx0aWYgKCFjb25maWcub3ZlcnJpZGVFeGlzdGluZyAmJiBjdXJyZW50UmVkdWNlciAmJiBjdXJyZW50UmVkdWNlciAhPT0gcmVkdWNlclRvSW5qZWN0KSB7XG5cdFx0XHRpZiAodHlwZW9mIHByb2Nlc3MgIT09IFwidW5kZWZpbmVkXCIgJiYgcHJvY2Vzcy5lbnYuTk9ERV9FTlYgPT09IFwiZGV2ZWxvcG1lbnRcIikgY29uc29sZS5lcnJvcihgY2FsbGVkIFxcYGluamVjdFxcYCB0byBvdmVycmlkZSBhbHJlYWR5LWV4aXN0aW5nIHJlZHVjZXIgJHtyZWR1Y2VyUGF0aH0gd2l0aG91dCBzcGVjaWZ5aW5nIFxcYG92ZXJyaWRlRXhpc3Rpbmc6IHRydWVcXGBgKTtcblx0XHRcdHJldHVybiBjb21iaW5lZFJlZHVjZXI7XG5cdFx0fVxuXHRcdGlmIChjb25maWcub3ZlcnJpZGVFeGlzdGluZyAmJiBjdXJyZW50UmVkdWNlciAhPT0gcmVkdWNlclRvSW5qZWN0KSBkZWxldGUgaW5pdGlhbFN0YXRlQ2FjaGVbcmVkdWNlclBhdGhdO1xuXHRcdHJlZHVjZXJNYXBbcmVkdWNlclBhdGhdID0gcmVkdWNlclRvSW5qZWN0O1xuXHRcdHJlZHVjZXIgPSBnZXRSZWR1Y2VyKCk7XG5cdFx0cmV0dXJuIGNvbWJpbmVkUmVkdWNlcjtcblx0fTtcblx0Y29uc3Qgc2VsZWN0b3IgPSBPYmplY3QuYXNzaWduKGZ1bmN0aW9uIG1ha2VTZWxlY3RvcihzZWxlY3RvckZuLCBzZWxlY3RTdGF0ZSkge1xuXHRcdHJldHVybiBmdW5jdGlvbiBzZWxlY3RvcihzdGF0ZSwgLi4uYXJncykge1xuXHRcdFx0cmV0dXJuIHNlbGVjdG9yRm4oY3JlYXRlU3RhdGVQcm94eShzdGF0ZVByb3h5TWFwLCBzZWxlY3RTdGF0ZSA/IHNlbGVjdFN0YXRlKHN0YXRlLCAuLi5hcmdzKSA6IHN0YXRlLCByZWR1Y2VyTWFwLCBpbml0aWFsU3RhdGVDYWNoZSksIC4uLmFyZ3MpO1xuXHRcdH07XG5cdH0sIHsgb3JpZ2luYWw6IG9yaWdpbmFsJDEgfSk7XG5cdHJldHVybiBPYmplY3QuYXNzaWduKGNvbWJpbmVkUmVkdWNlciwge1xuXHRcdGluamVjdCxcblx0XHRzZWxlY3RvclxuXHR9KTtcbn1cbi8vI2VuZHJlZ2lvblxuLy8jcmVnaW9uIHNyYy9mb3JtYXRQcm9kRXJyb3JNZXNzYWdlLnRzXG5mdW5jdGlvbiBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlKGNvZGUpIHtcblx0cmV0dXJuIGBNaW5pZmllZCBSZWR1eCBUb29sa2l0IGVycm9yICMke2NvZGV9OyB2aXNpdCBodHRwczovL3JlZHV4LXRvb2xraXQuanMub3JnL0Vycm9ycz9jb2RlPSR7Y29kZX0gZm9yIHRoZSBmdWxsIG1lc3NhZ2Ugb3IgdXNlIHRoZSBub24tbWluaWZpZWQgZGV2IGVudmlyb25tZW50IGZvciBmdWxsIGVycm9ycy4gYDtcbn1cbi8vI2VuZHJlZ2lvblxuZXhwb3J0IHsgUmVkdWNlclR5cGUsIFNIT1VMRF9BVVRPQkFUQ0gsIFRhc2tBYm9ydEVycm9yLCBUdXBsZSwgYWRkTGlzdGVuZXIsIGFzeW5jVGh1bmtDcmVhdG9yLCBhdXRvQmF0Y2hFbmhhbmNlciwgYnVpbGRDcmVhdGVTbGljZSwgY2xlYXJBbGxMaXN0ZW5lcnMsIGNvbWJpbmVTbGljZXMsIGNvbmZpZ3VyZVN0b3JlLCBjcmVhdGVBY3Rpb24sIGNyZWF0ZUFjdGlvbkNyZWF0b3JJbnZhcmlhbnRNaWRkbGV3YXJlLCBjcmVhdGVBc3luY1RodW5rLCBjcmVhdGVEcmFmdFNhZmVTZWxlY3RvciwgY3JlYXRlRHJhZnRTYWZlU2VsZWN0b3JDcmVhdG9yLCBjcmVhdGVEeW5hbWljTWlkZGxld2FyZSwgY3JlYXRlRW50aXR5QWRhcHRlciwgY3JlYXRlSW1tdXRhYmxlU3RhdGVJbnZhcmlhbnRNaWRkbGV3YXJlLCBjcmVhdGVMaXN0ZW5lck1pZGRsZXdhcmUsIGNyZWF0ZU5leHRTdGF0ZSwgY3JlYXRlUmVkdWNlciwgY3JlYXRlU2VsZWN0b3IsIGNyZWF0ZVNlbGVjdG9yQ3JlYXRvciwgY3JlYXRlU2VyaWFsaXphYmxlU3RhdGVJbnZhcmlhbnRNaWRkbGV3YXJlLCBjcmVhdGVTbGljZSwgY3VycmVudCwgZmluZE5vblNlcmlhbGl6YWJsZVZhbHVlLCBmb3JtYXRQcm9kRXJyb3JNZXNzYWdlLCBmcmVlemUsIGlzQWN0aW9uQ3JlYXRvciwgaXNBbGxPZiwgaXNBbnlPZiwgaXNBc3luY1RodW5rQWN0aW9uLCBpc0RyYWZ0LCBpc0ZTQSBhcyBpc0ZsdXhTdGFuZGFyZEFjdGlvbiwgaXNGdWxmaWxsZWQsIGlzSW1tdXRhYmxlRGVmYXVsdCwgaXNQZW5kaW5nLCBpc1BsYWluLCBpc1JlamVjdGVkLCBpc1JlamVjdGVkV2l0aFZhbHVlLCBscnVNZW1vaXplLCBtaW5pU2VyaWFsaXplRXJyb3IsIG5hbm9pZCwgb3JpZ2luYWwsIHByZXBhcmVBdXRvQmF0Y2hlZCwgcmVtb3ZlTGlzdGVuZXIsIHVud3JhcFJlc3VsdCwgd2Vha01hcE1lbW9pemUgfTtcblxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVkdXgtdG9vbGtpdC5tb2Rlcm4ubWpzLm1hcCJdLCJpZ25vcmVMaXN0IjpbMCwxLDIsMyw0XSwibWFwcGluZ3MiOiI7QUFPQSxJQUFJLDRCQUE0Qix1QkFEVSxPQUFPLFdBQVcsY0FBYyxPQUFPLGNBQWMsZUFBQSxDQUNwRDtBQUczQyxJQUFJLHFCQUFxQixLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVMsRUFBRSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRztBQU1uRixJQUFJLHNCQUFzQjtDQUp4QixNQUFNLGVBQStCLDZCQUFhO0NBQ2xELFNBQVMsa0JBQWtDLDZCQUFhO0NBQ3hELDRCQUE0QiwrQkFBK0IsYUFBYTtBQUV0QztBQUdwQyxTQUFTLGNBQWMsS0FBSztDQUMxQixJQUFJLE9BQU8sUUFBUSxZQUFZLFFBQVEsTUFDckMsT0FBTztDQUNULElBQUksUUFBUTtDQUNaLE9BQU8sT0FBTyxlQUFlLEtBQUssTUFBTSxNQUN0QyxRQUFRLE9BQU8sZUFBZSxLQUFLO0NBRXJDLE9BQU8sT0FBTyxlQUFlLEdBQUcsTUFBTSxTQUFTLE9BQU8sZUFBZSxHQUFHLE1BQU07QUFDaEY7QUFHQSxTQUFTLFdBQVcsS0FBSztDQUN2QixJQUFJLFFBQVEsS0FBSyxHQUNmLE9BQU87Q0FDVCxJQUFJLFFBQVEsTUFDVixPQUFPO0NBQ1QsTUFBTSxPQUFPLE9BQU87Q0FDcEIsUUFBUSxNQUFSO0VBQ0UsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUssWUFDSCxPQUFPO0NBRVg7Q0FDQSxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQ25CLE9BQU87Q0FDVCxJQUFJLE9BQU8sR0FBRyxHQUNaLE9BQU87Q0FDVCxJQUFJLFFBQVEsR0FBRyxHQUNiLE9BQU87Q0FDVCxNQUFNLGtCQUFrQixTQUFTLEdBQUc7Q0FDcEMsUUFBUSxpQkFBUjtFQUNFLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSztFQUNMLEtBQUs7RUFDTCxLQUFLO0VBQ0wsS0FBSyxPQUNILE9BQU87Q0FDWDtDQUNBLE9BQU8sT0FBTyxVQUFVLFNBQVMsS0FBSyxHQUFHLENBQUMsQ0FBQyxNQUFNLEdBQUcsRUFBRSxDQUFDLENBQUMsWUFBWSxDQUFDLENBQUMsUUFBUSxPQUFPLEVBQUU7QUFDekY7QUFDQSxTQUFTLFNBQVMsS0FBSztDQUNyQixPQUFPLE9BQU8sSUFBSSxnQkFBZ0IsYUFBYSxJQUFJLFlBQVksT0FBTztBQUN4RTtBQUNBLFNBQVMsUUFBUSxLQUFLO0NBQ3BCLE9BQU8sZUFBZSxTQUFTLE9BQU8sSUFBSSxZQUFZLFlBQVksSUFBSSxlQUFlLE9BQU8sSUFBSSxZQUFZLG9CQUFvQjtBQUNsSTtBQUNBLFNBQVMsT0FBTyxLQUFLO0NBQ25CLElBQUksZUFBZSxNQUNqQixPQUFPO0NBQ1QsT0FBTyxPQUFPLElBQUksaUJBQWlCLGNBQWMsT0FBTyxJQUFJLFlBQVksY0FBYyxPQUFPLElBQUksWUFBWTtBQUMvRztBQUNBLFNBQVMsT0FBTyxLQUFLO0NBQ25CLElBQUksWUFBWSxPQUFPO0NBRXJCLFlBQVksV0FBVyxHQUFHO0NBRTVCLE9BQU87QUFDVDtBQUdBLFNBQVMsWUFBWSxTQUFTLGdCQUFnQixVQUFVO0NBQ3RELElBQUksT0FBTyxZQUFZLFlBQ3JCLE1BQU0sSUFBSSxNQUEwRSxtRUFBbUUsT0FBTyxPQUFPLEVBQUUsRUFBRTtDQUUzSyxJQUFJLE9BQU8sbUJBQW1CLGNBQWMsT0FBTyxhQUFhLGNBQWMsT0FBTyxhQUFhLGNBQWMsT0FBTyxVQUFVLE9BQU8sWUFDdEksTUFBTSxJQUFJLE1BQTBFLGtRQUFrUTtDQUV4VixJQUFJLE9BQU8sbUJBQW1CLGNBQWMsT0FBTyxhQUFhLGFBQWE7RUFDM0UsV0FBVztFQUNYLGlCQUFpQixLQUFLO0NBQ3hCO0NBQ0EsSUFBSSxPQUFPLGFBQWEsYUFBYTtFQUNuQyxJQUFJLE9BQU8sYUFBYSxZQUN0QixNQUFNLElBQUksTUFBMEUsK0RBQStELE9BQU8sUUFBUSxFQUFFLEVBQUU7RUFFeEssT0FBTyxTQUFTLFdBQVcsQ0FBQyxDQUFDLFNBQVMsY0FBYztDQUN0RDtDQUNBLElBQUksaUJBQWlCO0NBQ3JCLElBQUksZUFBZTtDQUNuQixJQUFJLG1DQUFtQyxJQUFJLElBQUk7Q0FDL0MsSUFBSSxnQkFBZ0I7Q0FDcEIsSUFBSSxvQkFBb0I7Q0FDeEIsSUFBSSxnQkFBZ0I7Q0FDcEIsU0FBUywrQkFBK0I7RUFDdEMsSUFBSSxrQkFBa0Isa0JBQWtCO0dBQ3RDLGdDQUFnQyxJQUFJLElBQUk7R0FDeEMsaUJBQWlCLFNBQVMsVUFBVSxRQUFRO0lBQzFDLGNBQWMsSUFBSSxLQUFLLFFBQVE7R0FDakMsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxTQUFTLFdBQVc7RUFDbEIsSUFBSSxlQUNGLE1BQU0sSUFBSSxNQUEwRSxzTUFBc007RUFFNVIsT0FBTztDQUNUO0NBQ0EsU0FBUyxVQUFVLFVBQVU7RUFDM0IsSUFBSSxPQUFPLGFBQWEsWUFDdEIsTUFBTSxJQUFJLE1BQTBFLCtEQUErRCxPQUFPLFFBQVEsRUFBRSxFQUFFO0VBRXhLLElBQUksZUFDRixNQUFNLElBQUksTUFBMEUsaVRBQWlUO0VBRXZZLElBQUksZUFBZTtFQUNuQiw2QkFBNkI7RUFDN0IsTUFBTSxhQUFhO0VBQ25CLGNBQWMsSUFBSSxZQUFZLFFBQVE7RUFDdEMsT0FBTyxTQUFTLGNBQWM7R0FDNUIsSUFBSSxDQUFDLGNBQ0g7R0FFRixJQUFJLGVBQ0YsTUFBTSxJQUFJLE1BQTBFLHNKQUFzSjtHQUU1TyxlQUFlO0dBQ2YsNkJBQTZCO0dBQzdCLGNBQWMsT0FBTyxVQUFVO0dBQy9CLG1CQUFtQjtFQUNyQjtDQUNGO0NBQ0EsU0FBUyxTQUFTLFFBQVE7RUFDeEIsSUFBSSxDQUFDLGNBQWMsTUFBTSxHQUN2QixNQUFNLElBQUksTUFBMEUsaUVBQWlFLE9BQU8sTUFBTSxFQUFFLDJVQUEyVTtFQUVqZixJQUFJLE9BQU8sT0FBTyxTQUFTLGFBQ3pCLE1BQU0sSUFBSSxNQUEwRSw4R0FBNEc7RUFFbE0sSUFBSSxPQUFPLE9BQU8sU0FBUyxVQUN6QixNQUFNLElBQUksTUFBMkUsMkVBQTJFLE9BQU8sT0FBTyxJQUFJLEVBQUUsaUJBQWlCLE9BQU8sS0FBSyxnQkFBZ0I7RUFFbk8sSUFBSSxlQUNGLE1BQU0sSUFBSSxNQUEwRSxvQ0FBb0M7RUFFMUgsSUFBSTtHQUNGLGdCQUFnQjtHQUNoQixlQUFlLGVBQWUsY0FBYyxNQUFNO0VBQ3BELFVBQVU7R0FDUixnQkFBZ0I7RUFDbEI7RUFFQSxDQURrQixtQkFBbUIsY0FBQSxDQUMzQixTQUFTLGFBQWE7R0FDOUIsU0FBUztFQUNYLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLGVBQWUsYUFBYTtFQUNuQyxJQUFJLE9BQU8sZ0JBQWdCLFlBQ3pCLE1BQU0sSUFBSSxNQUEyRSxrRUFBa0UsT0FBTyxXQUFXLEdBQUc7RUFFOUssaUJBQWlCO0VBQ2pCLFNBQVMsRUFDUCxNQUFNLG9CQUFvQixRQUM1QixDQUFDO0NBQ0g7Q0FDQSxTQUFTLGFBQWE7RUFDcEIsTUFBTSxpQkFBaUI7RUFDdkIsT0FBTzs7Ozs7Ozs7O0dBU0wsVUFBVSxVQUFVO0lBQ2xCLElBQUksT0FBTyxhQUFhLFlBQVksYUFBYSxNQUMvQyxNQUFNLElBQUksTUFBMkUsOERBQThELE9BQU8sUUFBUSxFQUFFLEVBQUU7SUFFeEssU0FBUyxlQUFlO0tBQ3RCLE1BQU0scUJBQXFCO0tBQzNCLElBQUksbUJBQW1CLE1BQ3JCLG1CQUFtQixLQUFLLFNBQVMsQ0FBQztJQUV0QztJQUNBLGFBQWE7SUFFYixPQUFPLEVBQ0wsYUFGa0IsZUFBZSxZQUV2QixFQUNaO0dBQ0Y7R0FDQSxDQUFDLDZCQUE2QjtJQUM1QixPQUFPO0dBQ1Q7RUFDRjtDQUNGO0NBQ0EsU0FBUyxFQUNQLE1BQU0sb0JBQW9CLEtBQzVCLENBQUM7Q0FRRCxPQUFPO0VBTkw7RUFDQTtFQUNBO0VBQ0E7R0FDQyw0QkFBNEI7Q0FFcEI7QUFDYjtBQUNBLFNBQVMsbUJBQW1CLFNBQVMsZ0JBQWdCLFVBQVU7Q0FDN0QsT0FBTyxZQUFZLFNBQVMsZ0JBQWdCLFFBQVE7QUFDdEQ7QUFHQSxTQUFTLFFBQVEsU0FBUztDQUN4QixJQUFJLE9BQU8sWUFBWSxlQUFlLE9BQU8sUUFBUSxVQUFVLFlBQzdELFFBQVEsTUFBTSxPQUFPO0NBRXZCLElBQUk7RUFDRixNQUFNLElBQUksTUFBTSxPQUFPO0NBQ3pCLFNBQVMsR0FBRyxDQUNaO0FBQ0Y7QUFHQSxTQUFTLHNDQUFzQyxZQUFZLFVBQVUsUUFBUSxvQkFBb0I7Q0FDL0YsTUFBTSxjQUFjLE9BQU8sS0FBSyxRQUFRO0NBQ3hDLE1BQU0sZUFBZSxVQUFVLE9BQU8sU0FBUyxvQkFBb0IsT0FBTyxrREFBa0Q7Q0FDNUgsSUFBSSxZQUFZLFdBQVcsR0FDekIsT0FBTztDQUVULElBQUksQ0FBQyxjQUFjLFVBQVUsR0FDM0IsT0FBTyxPQUFPLGFBQWEsMkJBQTJCLE9BQU8sVUFBVSxFQUFFLGlFQUFpRSxZQUFZLEtBQUssUUFBTSxFQUFFO0NBRXJLLE1BQU0saUJBQWlCLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBQyxRQUFRLFFBQVEsQ0FBQyxTQUFTLGVBQWUsR0FBRyxLQUFLLENBQUMsbUJBQW1CLElBQUk7Q0FDeEgsZUFBZSxTQUFTLFFBQVE7RUFDOUIsbUJBQW1CLE9BQU87Q0FDNUIsQ0FBQztDQUNELElBQUksVUFBVSxPQUFPLFNBQVMsb0JBQW9CLFNBQ2hEO0NBQ0YsSUFBSSxlQUFlLFNBQVMsR0FDMUIsT0FBTyxjQUFjLGVBQWUsU0FBUyxJQUFJLFNBQVMsTUFBTSxJQUFJLGVBQWUsS0FBSyxRQUFNLEVBQUUsYUFBYSxhQUFhLDZEQUE2RCxZQUFZLEtBQUssUUFBTSxFQUFFO0FBRXBOO0FBQ0EsU0FBUyxtQkFBbUIsVUFBVTtDQUNwQyxPQUFPLEtBQUssUUFBUSxDQUFDLENBQUMsU0FBUyxRQUFRO0VBQ3JDLE1BQU0sVUFBVSxTQUFTO0VBSXpCLElBQUksT0FIaUIsUUFBUSxLQUFLLEdBQUcsRUFDbkMsTUFBTSxvQkFBb0IsS0FDNUIsQ0FDc0IsTUFBTSxhQUMxQixNQUFNLElBQUksTUFBMkUsOEJBQThCLElBQUksNlFBQTZRO0VBRXRZLElBQUksT0FBTyxRQUFRLEtBQUssR0FBRyxFQUN6QixNQUFNLG9CQUFvQixxQkFBcUIsRUFDakQsQ0FBQyxNQUFNLGFBQ0wsTUFBTSxJQUFJLE1BQTJFLDhCQUE4QixJQUFJLDRFQUE0RSxvQkFBb0IsS0FBSyw2U0FBNlM7Q0FFN2dCLENBQUM7QUFDSDtBQUNBLFNBQVMsZ0JBQWdCLFVBQVU7Q0FDakMsTUFBTSxjQUFjLE9BQU8sS0FBSyxRQUFRO0NBQ3hDLE1BQU0sZ0JBQWdCLENBQUM7Q0FDdkIsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLFlBQVksUUFBUSxLQUFLO0VBQzNDLE1BQU0sTUFBTSxZQUFZO0VBRXRCLElBQUksT0FBTyxTQUFTLFNBQVMsYUFDM0IsUUFBUSxnQ0FBZ0MsSUFBSSxFQUFFO0VBR2xELElBQUksT0FBTyxTQUFTLFNBQVMsWUFDM0IsY0FBYyxPQUFPLFNBQVM7Q0FFbEM7Q0FDQSxNQUFNLG1CQUFtQixPQUFPLEtBQUssYUFBYTtDQUNsRCxJQUFJLHFCQUVtQixDQUFDO0NBRXhCLElBQUk7Q0FDSixJQUFJO0VBQ0YsbUJBQW1CLGFBQWE7Q0FDbEMsU0FBUyxHQUFHO0VBQ1Ysc0JBQXNCO0NBQ3hCO0NBQ0EsT0FBTyxTQUFTLFlBQVksUUFBUSxDQUFDLEdBQUcsUUFBUTtFQUM5QyxJQUFJLHFCQUNGLE1BQU07RUFFbUM7R0FDekMsTUFBTSxpQkFBaUIsc0NBQXNDLE9BQU8sZUFBZSxRQUFRLGtCQUFrQjtHQUM3RyxJQUFJLGdCQUNGLFFBQVEsY0FBYztFQUUxQjtFQUNBLElBQUksYUFBYTtFQUNqQixNQUFNLFlBQVksQ0FBQztFQUNuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksaUJBQWlCLFFBQVEsS0FBSztHQUNoRCxNQUFNLE1BQU0saUJBQWlCO0dBQzdCLE1BQU0sVUFBVSxjQUFjO0dBQzlCLE1BQU0sc0JBQXNCLE1BQU07R0FDbEMsTUFBTSxrQkFBa0IsUUFBUSxxQkFBcUIsTUFBTTtHQUMzRCxJQUFJLE9BQU8sb0JBQW9CLGFBQWE7SUFDMUMsTUFBTSxhQUFhLFVBQVUsT0FBTztJQUNwQyxNQUFNLElBQUksTUFBMkUsc0NBQXNDLGFBQWEsSUFBSSxPQUFPLFVBQVUsRUFBRSxLQUFLLGlCQUFpQiwrQkFBK0IsSUFBSSwrS0FBK0s7R0FDelk7R0FDQSxVQUFVLE9BQU87R0FDakIsYUFBYSxjQUFjLG9CQUFvQjtFQUNqRDtFQUNBLGFBQWEsY0FBYyxpQkFBaUIsV0FBVyxPQUFPLEtBQUssS0FBSyxDQUFDLENBQUM7RUFDMUUsT0FBTyxhQUFhLFlBQVk7Q0FDbEM7QUFDRjtBQUdBLFNBQVMsa0JBQWtCLGVBQWUsVUFBVTtDQUNsRCxPQUFPLFNBQVMsR0FBRyxNQUFNO0VBQ3ZCLE9BQU8sU0FBUyxjQUFjLE1BQU0sTUFBTSxJQUFJLENBQUM7Q0FDakQ7QUFDRjtBQUNBLFNBQVMsbUJBQW1CLGdCQUFnQixVQUFVO0NBQ3BELElBQUksT0FBTyxtQkFBbUIsWUFDNUIsT0FBTyxrQkFBa0IsZ0JBQWdCLFFBQVE7Q0FFbkQsSUFBSSxPQUFPLG1CQUFtQixZQUFZLG1CQUFtQixNQUMzRCxNQUFNLElBQUksTUFBMkUsK0VBQStFLE9BQU8sY0FBYyxFQUFFLDRGQUE0RjtDQUV6UixNQUFNLHNCQUFzQixDQUFDO0NBQzdCLEtBQUssTUFBTSxPQUFPLGdCQUFnQjtFQUNoQyxNQUFNLGdCQUFnQixlQUFlO0VBQ3JDLElBQUksT0FBTyxrQkFBa0IsWUFDM0Isb0JBQW9CLE9BQU8sa0JBQWtCLGVBQWUsUUFBUTtDQUV4RTtDQUNBLE9BQU87QUFDVDtBQUdBLFNBQVMsUUFBUSxHQUFHLE9BQU87Q0FDekIsSUFBSSxNQUFNLFdBQVcsR0FDbkIsUUFBUSxRQUFRO0NBRWxCLElBQUksTUFBTSxXQUFXLEdBQ25CLE9BQU8sTUFBTTtDQUVmLE9BQU8sTUFBTSxRQUFRLEdBQUcsT0FBTyxHQUFHLFNBQVMsRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLENBQUM7QUFDMUQ7QUFHQSxTQUFTLGdCQUFnQixHQUFHLGFBQWE7Q0FDdkMsUUFBUSxrQkFBa0IsU0FBUyxtQkFBbUI7RUFDcEQsTUFBTSxRQUFRLGFBQWEsU0FBUyxjQUFjO0VBQ2xELElBQUksaUJBQWlCO0dBQ25CLE1BQU0sSUFBSSxNQUEyRSx3SEFBd0g7RUFDL007RUFDQSxNQUFNLGdCQUFnQjtHQUNwQixVQUFVLE1BQU07R0FDaEIsV0FBVyxRQUFRLEdBQUcsU0FBUyxTQUFTLFFBQVEsR0FBRyxJQUFJO0VBQ3pEO0VBRUEsV0FBVyxRQUFRLEdBREwsWUFBWSxLQUFLLGVBQWUsV0FBVyxhQUFhLENBQzVDLENBQUMsQ0FBQyxDQUFDLE1BQU0sUUFBUTtFQUMzQyxPQUFPO0dBQ0wsR0FBRztHQUNIO0VBQ0Y7Q0FDRjtBQUNGO0FBR0EsU0FBUyxTQUFTLFFBQVE7Q0FDeEIsT0FBTyxjQUFjLE1BQU0sS0FBSyxVQUFVLFVBQVUsT0FBTyxPQUFPLFNBQVM7QUFDN0U7OztBQy9YQSxJQUFJLFVBQVUsT0FBTyxJQUFJLGVBQWU7QUFDeEMsSUFBSSxZQUFZLE9BQU8sSUFBSSxpQkFBaUI7QUFDNUMsSUFBSSxjQUFjLE9BQU8sSUFBSSxhQUFhO0FBRzFDLElBQUksU0FBaUQ7Q0FFbkQsU0FBUyxRQUFRO0VBQ2YsT0FBTyxtQkFBbUIsT0FBTyxrRkFBa0YsT0FBTztDQUM1SDtDQUNBLFNBQVMsT0FBTztFQUNkLE9BQU8sc0pBQXNKLE1BQU07Q0FDcks7Q0FDQTtDQUNBLFNBQVMsTUFBTTtFQUNiLE9BQU8seUhBQXlIO0NBQ2xJO0NBQ0E7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBO0NBQ0EsU0FBUyxPQUFPO0VBQ2QsT0FBTyxtQ0FBbUM7Q0FDNUM7Q0FDQTtDQUNBO0NBQ0E7Q0FDQTtDQUNBLFNBQVMsT0FBTztFQUNkLE9BQU8sb0NBQW9DO0NBQzdDO0FBR0Y7QUFDQSxTQUFTLElBQUksT0FBTyxHQUFHLE1BQU07Q0FDZ0I7RUFDekMsTUFBTSxJQUFJLE9BQU87RUFDakIsTUFBTSxNQUFNLFdBQVcsQ0FBQyxJQUFJLEVBQUUsTUFBTSxNQUFNLElBQUksSUFBSTtFQUNsRCxNQUFNLElBQUksTUFBTSxXQUFXLEtBQUs7Q0FDbEM7QUFJRjtBQUdBLElBQUksSUFBSTtBQUNSLElBQUksaUJBQWlCLEVBQUU7QUFDdkIsSUFBSSxjQUFjO0FBQ2xCLElBQUksWUFBWTtBQUNoQixJQUFJLGVBQWU7QUFDbkIsSUFBSSxhQUFhO0FBQ2pCLElBQUksV0FBVztBQUNmLElBQUksUUFBUTtBQUNaLElBQUksV0FBVyxVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQzVDLFNBQVMsWUFBWSxPQUFPO0NBQzFCLElBQUksQ0FBQyxPQUNILE9BQU87Q0FDVCxPQUFPQSxnQkFBYyxLQUFLLEtBQUssUUFBUSxLQUFLLEtBQUssQ0FBQyxDQUFDLE1BQU0sY0FBYyxDQUFDLENBQUMsTUFBTSxZQUFZLEdBQUcsY0FBYyxNQUFNLEtBQUssS0FBSyxNQUFNLEtBQUs7QUFDekk7QUFDQSxJQUFJLG1CQUFtQixFQUFFLFVBQVUsQ0FBQyxZQUFZLENBQUMsU0FBUztBQUMxRCxJQUFJLG9DQUFvQyxJQUFJLFFBQVE7QUFDcEQsU0FBU0EsZ0JBQWMsT0FBTztDQUM1QixJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksS0FBSyxHQUM5QixPQUFPO0NBQ1QsTUFBTSxRQUFRLGVBQWUsS0FBSztDQUNsQyxJQUFJLFVBQVUsUUFBUSxVQUFVLEVBQUUsWUFDaEMsT0FBTztDQUNULE1BQU0sT0FBTyxFQUFFLGVBQWUsS0FBSyxPQUFPLFdBQVcsS0FBSyxNQUFNO0NBQ2hFLElBQUksU0FBUyxRQUNYLE9BQU87Q0FDVCxJQUFJLENBQUMsV0FBVyxJQUFJLEdBQ2xCLE9BQU87Q0FDVCxJQUFJLGFBQWEsa0JBQWtCLElBQUksSUFBSTtDQUMzQyxJQUFJLGVBQWUsS0FBSyxHQUFHO0VBQ3pCLGFBQWEsU0FBUyxTQUFTLEtBQUssSUFBSTtFQUN4QyxrQkFBa0IsSUFBSSxNQUFNLFVBQVU7Q0FDeEM7Q0FDQSxPQUFPLGVBQWU7QUFDeEI7QUFDQSxTQUFTLFNBQVMsT0FBTztDQUN2QixJQUFJLENBQUMsUUFBUSxLQUFLLEdBQ2hCLElBQUksSUFBSSxLQUFLO0NBQ2YsT0FBTyxNQUFNLFlBQVksQ0FBQztBQUM1QjtBQUNBLFNBQVMsS0FBSyxLQUFLLE1BQU0sU0FBUyxNQUFNO0NBQ3RDLElBQUksWUFBWSxHQUFHLE1BQU0sR0FFdkIsQ0FEYSxTQUFTLFFBQVEsUUFBUSxHQUFHLElBQUksRUFBRSxLQUFLLEdBQUcsRUFBQSxDQUNsRCxTQUFTLFFBQVE7RUFDcEIsS0FBSyxLQUFLLElBQUksTUFBTSxHQUFHO0NBQ3pCLENBQUM7TUFFRCxJQUFJLFNBQVMsT0FBTyxVQUFVLEtBQUssT0FBTyxPQUFPLEdBQUcsQ0FBQztBQUV6RDtBQUNBLFNBQVMsWUFBWSxPQUFPO0NBQzFCLE1BQU0sUUFBUSxNQUFNO0NBQ3BCLE9BQU8sUUFBUSxNQUFNLFFBQVEsUUFBUSxLQUFLLElBQUksSUFBZ0IsTUFBTSxLQUFLLElBQUksSUFBYyxNQUFNLEtBQUssSUFBSSxJQUFjO0FBQzFIO0FBQ0EsSUFBSSxPQUFPLE9BQU8sTUFBTSxPQUFPLFlBQVksS0FBSyxNQUFNLFNBQVMsSUFBYyxNQUFNLElBQUksSUFBSSxJQUFJLEVBQUUsVUFBVSxDQUFDLGVBQWUsS0FBSyxPQUFPLElBQUk7QUFDM0ksSUFBSSxPQUFPLE9BQU8sTUFBTSxPQUFPLFlBQVksS0FBSyxNQUU5QyxTQUFTLElBQWMsTUFBTSxJQUFJLElBQUksSUFBSSxNQUFNO0FBRWpELElBQUksT0FBTyxPQUFPLGdCQUFnQixPQUFPLE9BQU8sWUFBWSxLQUFLLE1BQU07Q0FDckUsSUFBSSxTQUFTLEdBQ1gsTUFBTSxJQUFJLGdCQUFnQixLQUFLO01BQzVCLElBQUksU0FBUyxHQUNoQixNQUFNLElBQUksS0FBSztNQUVmLE1BQU0sa0JBQWtCO0FBQzVCO0FBQ0EsU0FBUyxHQUFHLEdBQUcsR0FBRztDQUNoQixJQUFJLE1BQU0sR0FDUixPQUFPLE1BQU0sS0FBSyxJQUFJLE1BQU0sSUFBSTtNQUVoQyxPQUFPLE1BQU0sS0FBSyxNQUFNO0FBRTVCO0FBQ0EsSUFBSSxVQUFVLE1BQU07QUFDcEIsSUFBSSxTQUFTLFdBQVcsa0JBQWtCO0FBQzFDLElBQUksU0FBUyxXQUFXLGtCQUFrQjtBQUMxQyxJQUFJLGVBQWUsV0FBVyxPQUFPLFdBQVc7QUFDaEQsSUFBSSxjQUFjLFdBQVcsT0FBTyxXQUFXO0FBQy9DLElBQUlDLGVBQWEsV0FBVyxPQUFPLFdBQVc7QUFDOUMsU0FBUyxhQUFhLE9BQU87Q0FDM0IsTUFBTSxJQUFJLENBQUM7Q0FDWCxPQUFPLE9BQU8sVUFBVSxDQUFDLEtBQUssT0FBTyxDQUFDLE1BQU07QUFDOUM7QUFNQSxJQUFJLFVBQVUsVUFBVSxNQUFNLFNBQVMsTUFBTTtBQUs3QyxJQUFJLGlCQUFpQixVQUFVLE1BQU0sWUFBWSxNQUFNLFFBQVEsTUFBTTtBQUNyRSxTQUFTLFlBQVksTUFBTSxRQUFRO0NBQ2pDLElBQUksTUFBTSxJQUFJLEdBQ1osT0FBTyxJQUFJLElBQUksSUFBSTtDQUVyQixJQUFJLE1BQU0sSUFBSSxHQUNaLE9BQU8sSUFBSSxJQUFJLElBQUk7Q0FFckIsSUFBSSxRQUFRLElBQUksR0FDZCxPQUFPLE1BQU0sVUFBVSxDQUFDLE1BQU0sS0FBSyxJQUFJO0NBQ3pDLE1BQU0sVUFBVUQsZ0JBQWMsSUFBSTtDQUNsQyxJQUFJLFdBQVcsUUFBUSxXQUFXLGdCQUFnQixDQUFDLFNBQVM7RUFDMUQsTUFBTSxjQUFjLEVBQUUsMEJBQTBCLElBQUk7RUFDcEQsT0FBTyxZQUFZO0VBQ25CLElBQUksT0FBTyxRQUFRLFFBQVEsV0FBVztFQUN0QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksS0FBSyxRQUFRLEtBQUs7R0FDcEMsTUFBTSxNQUFNLEtBQUs7R0FDakIsTUFBTSxPQUFPLFlBQVk7R0FDekIsSUFBSSxLQUFLLGNBQWMsT0FBTztJQUM1QixLQUFLLFlBQVk7SUFDakIsS0FBSyxnQkFBZ0I7R0FDdkI7R0FDQSxJQUFJLEtBQUssT0FBTyxLQUFLLEtBQ25CLFlBQVksT0FBTztLQUNoQixlQUFlO0tBQ2YsV0FBVztLQUVYLGFBQWEsS0FBSztLQUNsQixRQUFRLEtBQUs7R0FDaEI7RUFDSjtFQUNBLE9BQU8sRUFBRSxPQUFPLGVBQWUsSUFBSSxHQUFHLFdBQVc7Q0FDbkQsT0FBTztFQUNMLE1BQU0sUUFBUSxlQUFlLElBQUk7RUFDakMsSUFBSSxVQUFVLFFBQVEsU0FDcEIsT0FBTyxFQUFFLEdBQUcsS0FBSztFQUVuQixNQUFNLE1BQU0sRUFBRSxPQUFPLEtBQUs7RUFDMUIsT0FBTyxFQUFFLE9BQU8sS0FBSyxJQUFJO0NBQzNCO0FBQ0Y7QUFDQSxTQUFTLE9BQU8sS0FBSyxPQUFPLE9BQU87Q0FDakMsSUFBSSxTQUFTLEdBQUcsS0FBSyxRQUFRLEdBQUcsS0FBSyxDQUFDLFlBQVksR0FBRyxHQUNuRCxPQUFPO0NBQ1QsSUFBSSxZQUFZLEdBQUcsSUFBSSxHQUNyQixFQUFFLGlCQUFpQixLQUFLO0VBQ3RCLEtBQUs7RUFDTCxLQUFLO0VBQ0wsT0FBTztFQUNQLFFBQVE7Q0FDVixDQUFDO0NBRUgsRUFBRSxPQUFPLEdBQUc7Q0FDWixJQUFJLE1BQ0YsS0FDRSxNQUNDLE1BQU0sVUFBVTtFQUNmLE9BQU8sT0FBTyxJQUFJO0NBQ3BCLEdBQ0EsS0FDRjtDQUNGLE9BQU87QUFDVDtBQUNBLFNBQVMsOEJBQThCO0NBQ3JDLElBQUksQ0FBQztBQUNQO0FBQ0EsSUFBSSwyQkFBMkIsR0FDNUIsUUFBUSw0QkFDWDtBQUNBLFNBQVMsU0FBUyxLQUFLO0NBQ3JCLElBQUksUUFBUSxRQUFRLENBQUMsWUFBWSxHQUFHLEdBQ2xDLE9BQU87Q0FDVCxPQUFPLEVBQUUsU0FBUyxHQUFHO0FBQ3ZCO0FBR0EsSUFBSSxlQUFlO0FBQ25CLElBQUksZ0JBQWdCO0FBQ3BCLElBQUkscUJBQXFCO0FBQ3pCLElBQUksVUFBVSxDQUFDO0FBQ2YsU0FBUyxVQUFVLFdBQVc7Q0FDNUIsTUFBTSxTQUFTLFFBQVE7Q0FDdkIsSUFBSSxDQUFDLFFBQ0gsSUFBSSxHQUFHLFNBQVM7Q0FFbEIsT0FBTztBQUNUO0FBQ0EsSUFBSSxrQkFBa0IsY0FBYyxDQUFDLENBQUMsUUFBUTtBQU85QyxJQUFJO0FBQ0osSUFBSSx3QkFBd0I7QUFDNUIsSUFBSSxlQUFlLFNBQVMsWUFBWTtDQUN0QyxTQUFTLENBQUM7Q0FDVjtDQUNBO0NBR0EsZ0JBQWdCO0NBQ2hCLG9CQUFvQjtDQUNwQiw2QkFBNkIsSUFBSSxJQUFJO0NBQ3JDLHNDQUFzQyxJQUFJLElBQUk7Q0FDOUMsZUFBZSxlQUFlLFlBQVksSUFBSSxVQUFVLFlBQVksSUFBSSxLQUFLO0NBQzdFLHFCQUFxQixlQUFlLGtCQUFrQixJQUFJLFVBQVUsa0JBQWtCLElBQUksS0FBSztBQUNqRztBQUNBLFNBQVMsa0JBQWtCLE9BQU8sZUFBZTtDQUMvQyxJQUFJLGVBQWU7RUFDakIsTUFBTSxlQUFlLFVBQVUsYUFBYTtFQUM1QyxNQUFNLFdBQVcsQ0FBQztFQUNsQixNQUFNLGtCQUFrQixDQUFDO0VBQ3pCLE1BQU0saUJBQWlCO0NBQ3pCO0FBQ0Y7QUFDQSxTQUFTLFlBQVksT0FBTztDQUMxQixXQUFXLEtBQUs7Q0FDaEIsTUFBTSxRQUFRLFFBQVEsV0FBVztDQUNqQyxNQUFNLFVBQVU7QUFDbEI7QUFDQSxTQUFTLFdBQVcsT0FBTztDQUN6QixJQUFJLFVBQVUsY0FDWixlQUFlLE1BQU07QUFFekI7QUFDQSxJQUFJLGNBQWMsV0FBVyxlQUFlLFlBQVksY0FBYyxNQUFNO0FBQzVFLFNBQVMsWUFBWSxPQUFPO0NBQzFCLE1BQU0sUUFBUSxNQUFNO0NBQ3BCLElBQUksTUFBTSxVQUFVLEtBQWtCLE1BQU0sVUFBVSxHQUNwRCxNQUFNLFFBQVE7TUFFZCxNQUFNLFdBQVc7QUFDckI7QUFHQSxTQUFTLGNBQWMsUUFBUSxPQUFPO0NBQ3BDLE1BQU0scUJBQXFCLE1BQU0sUUFBUTtDQUN6QyxNQUFNLFlBQVksTUFBTSxRQUFRO0NBRWhDLElBRG1CLFdBQVcsS0FBSyxLQUFLLFdBQVcsV0FDbkM7RUFDZCxJQUFJLFVBQVUsWUFBWSxDQUFDLFdBQVc7R0FDcEMsWUFBWSxLQUFLO0dBQ2pCLElBQUksQ0FBQztFQUNQO0VBQ0EsSUFBSSxZQUFZLE1BQU0sR0FDcEIsU0FBUyxTQUFTLE9BQU8sTUFBTTtFQUVqQyxNQUFNLEVBQUUsaUJBQWlCO0VBQ3pCLElBQUksY0FDRixhQUFhLDRCQUNYLFVBQVUsWUFBWSxDQUFDLE9BQ3ZCLFFBQ0EsS0FDRjtDQUVKLE9BQ0UsU0FBUyxTQUFTLE9BQU8sU0FBUztDQUVwQyxZQUFZLE9BQU8sUUFBUSxJQUFJO0NBQy9CLFlBQVksS0FBSztDQUNqQixJQUFJLE1BQU0sVUFDUixNQUFNLGVBQWUsTUFBTSxVQUFVLE1BQU0sZUFBZTtDQUU1RCxPQUFPLFdBQVcsVUFBVSxTQUFTLEtBQUs7QUFDNUM7QUFDQSxTQUFTLFNBQVMsV0FBVyxPQUFPO0NBQ2xDLElBQUksU0FBUyxLQUFLLEdBQ2hCLE9BQU87Q0FDVCxNQUFNLFFBQVEsTUFBTTtDQUNwQixJQUFJLENBQUMsT0FFSCxPQURtQixZQUFZLE9BQU8sVUFBVSxhQUFhLFNBQzdDO0NBRWxCLElBQUksQ0FBQyxZQUFZLE9BQU8sU0FBUyxHQUMvQixPQUFPO0NBRVQsSUFBSSxDQUFDLE1BQU0sV0FDVCxPQUFPLE1BQU07Q0FFZixJQUFJLENBQUMsTUFBTSxZQUFZO0VBQ3JCLE1BQU0sRUFBRSxlQUFlO0VBQ3ZCLElBQUksWUFDRixPQUFPLFdBQVcsU0FBUyxHQUV6QixXQUQ0QixJQUNyQixDQUFDLENBQUMsU0FBUztFQUd0QiwyQkFBMkIsT0FBTyxTQUFTO0NBQzdDO0NBQ0EsT0FBTyxNQUFNO0FBQ2Y7QUFDQSxTQUFTLFlBQVksT0FBTyxPQUFPLE9BQU8sT0FBTztDQUMvQyxJQUFJLENBQUMsTUFBTSxXQUFXLE1BQU0sT0FBTyxlQUFlLE1BQU0sZ0JBQ3RELE9BQU8sT0FBTyxJQUFJO0FBRXRCO0FBQ0EsU0FBUyxtQkFBbUIsT0FBTztDQUNqQyxNQUFNLGFBQWE7Q0FDbkIsTUFBTSxPQUFPO0FBQ2Y7QUFDQSxJQUFJLGVBQWUsT0FBTyxjQUFjLE1BQU0sV0FBVztBQUN6RCxJQUFJLHlCQUF5QixDQUFDO0FBQzlCLFNBQVMsb0JBQW9CLFFBQVEsWUFBWSxnQkFBZ0IsYUFBYTtDQUM1RSxNQUFNLGFBQWEsT0FBTyxNQUFNO0NBQ2hDLE1BQU0sYUFBYSxPQUFPO0NBQzFCLElBQUksZ0JBQWdCLEtBQUssR0FDRjtNQUFBLElBQUksWUFBWSxhQUFhLFVBQ25DLE1BQU0sWUFBWTtHQUMvQixJQUFJLFlBQVksYUFBYSxnQkFBZ0IsVUFBVTtHQUN2RDtFQUNGOztDQUVGLElBQUksQ0FBQyxPQUFPLGlCQUFpQjtFQUMzQixNQUFNLGlCQUFpQixPQUFPLGtDQUFrQyxJQUFJLElBQUk7RUFDeEUsS0FBSyxhQUFhLEtBQUssVUFBVTtHQUMvQixJQUFJLFFBQVEsS0FBSyxHQUFHO0lBQ2xCLE1BQU0sT0FBTyxlQUFlLElBQUksS0FBSyxLQUFLLENBQUM7SUFDM0MsS0FBSyxLQUFLLEdBQUc7SUFDYixlQUFlLElBQUksT0FBTyxJQUFJO0dBQ2hDO0VBQ0YsQ0FBQztDQUNIO0NBQ0EsTUFBTSxZQUFZLE9BQU8sZ0JBQWdCLElBQUksVUFBVSxLQUFLO0NBQzVELEtBQUssTUFBTSxZQUFZLFdBQ3JCLElBQUksWUFBWSxVQUFVLGdCQUFnQixVQUFVO0FBRXhEO0FBQ0EsU0FBUyxrQ0FBa0MsUUFBUSxPQUFPLEtBQUs7Q0FDN0QsT0FBTyxXQUFXLEtBQUssU0FBUyxhQUFhLFdBQVc7RUFDdEQsTUFBTSxRQUFRO0VBQ2QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLE9BQU8sU0FBUyxHQUN6QztFQUVGLFVBQVUsZUFBZSxlQUFlLEtBQUs7RUFDN0MsTUFBTSxpQkFBaUIsY0FBYyxLQUFLO0VBQzFDLG9CQUFvQixRQUFRLE1BQU0sVUFBVSxPQUFPLGdCQUFnQixHQUFHO0VBQ3RFLDJCQUEyQixPQUFPLFNBQVM7Q0FDN0MsQ0FBQztBQUNIO0FBQ0EsU0FBUywyQkFBMkIsT0FBTyxXQUFXO0NBRXBELElBRHVCLE1BQU0sYUFBYSxDQUFDLE1BQU0sZUFBZSxNQUFNLFVBQVUsS0FBZSxNQUFNLFVBQVUsS0FBaUIsTUFBTSwwQkFBMEIsTUFBTSxXQUFXLFFBQVEsS0FBSyxJQUMxSztFQUNsQixNQUFNLEVBQUUsaUJBQWlCO0VBQ3pCLElBQUksY0FBYztHQUNoQixNQUFNLFdBQVcsYUFBYSxRQUFRLEtBQUs7R0FDM0MsSUFBSSxVQUNGLGFBQWEsaUJBQWlCLE9BQU8sVUFBVSxTQUFTO0VBRTVEO0VBQ0EsbUJBQW1CLEtBQUs7Q0FDMUI7QUFDRjtBQUNBLFNBQVMscUJBQXFCLFFBQVEsS0FBSyxPQUFPO0NBQ2hELE1BQU0sRUFBRSxXQUFXO0NBQ25CLElBQUksUUFBUSxLQUFLLEdBQUc7RUFDbEIsTUFBTSxRQUFRLE1BQU07RUFDcEIsSUFBSSxZQUFZLE9BQU8sTUFBTSxHQUMzQixNQUFNLFdBQVcsS0FBSyxTQUFTLHdCQUF3QjtHQUNyRCxZQUFZLE1BQU07R0FFbEIsb0JBQW9CLFFBQVEsT0FETCxjQUFjLEtBQ1csR0FBRyxHQUFHO0VBQ3hELENBQUM7Q0FFTCxPQUFPLElBQUksWUFBWSxLQUFLLEdBQzFCLE9BQU8sV0FBVyxLQUFLLFNBQVMscUJBQXFCO0VBQ25ELE1BQU0sYUFBYSxPQUFPLE1BQU07RUFDaEMsSUFBSSxPQUFPLFVBQVUsR0FDZjtPQUFBLFdBQVcsSUFBSSxLQUFLLEdBQ3RCLFlBQVksT0FBTyxPQUFPLGFBQWEsTUFBTTtFQUFBLE9BRy9DLElBQUksSUFBSSxZQUFZLEtBQUssT0FBTyxLQUFLLE1BQU0sT0FDckM7T0FBQSxPQUFPLFFBQVEsU0FBUyxNQUFNLE9BQU8sVUFBVSxJQUFJLEdBQUcsS0FBSyxXQUFXLFFBQVEsT0FBTyxPQUN2RixZQUNFLElBQUksT0FBTyxPQUFPLEtBQUssT0FBTyxLQUFLLEdBQ25DLE9BQU8sYUFDUCxNQUNGO0VBQUE7Q0FJUixDQUFDO0FBRUw7QUFDQSxTQUFTLFlBQVksUUFBUSxZQUFZLFdBQVc7Q0FDbEQsSUFBSSxDQUFDLFVBQVUsT0FBTyxlQUFlLFVBQVUscUJBQXFCLEdBQ2xFLE9BQU87Q0FFVCxJQUFJLFFBQVEsTUFBTSxLQUFLLFdBQVcsSUFBSSxNQUFNLEtBQUssQ0FBQyxZQUFZLE1BQU0sS0FBSyxTQUFTLE1BQU0sR0FDdEYsT0FBTztDQUVULFdBQVcsSUFBSSxNQUFNO0NBQ3JCLEtBQUssU0FBUyxLQUFLLFVBQVU7RUFDM0IsSUFBSSxRQUFRLEtBQUssR0FBRztHQUNsQixNQUFNLFFBQVEsTUFBTTtHQUNwQixJQUFJLFlBQVksT0FBTyxTQUFTLEdBQUc7SUFFakMsSUFBSSxRQUFRLEtBRFMsY0FBYyxLQUNQLEdBQUcsT0FBTyxLQUFLO0lBQzNDLG1CQUFtQixLQUFLO0dBQzFCO0VBQ0YsT0FBTyxJQUFJLFlBQVksS0FBSyxHQUMxQixZQUFZLE9BQU8sWUFBWSxTQUFTO0NBRTVDLENBQUM7Q0FDRCxPQUFPO0FBQ1Q7QUFHQSxTQUFTLGlCQUFpQixNQUFNLFFBQVE7Q0FDdEMsTUFBTSxjQUFjLFFBQVEsSUFBSTtDQUNoQyxNQUFNLFFBQVE7RUFDWixPQUFPLGNBQWMsSUFBZ0I7RUFFckMsUUFBUSxTQUFTLE9BQU8sU0FBUyxnQkFBZ0I7RUFFakQsV0FBVztFQUVYLFlBQVk7RUFHWixXQUFXLEtBQUs7RUFFaEIsU0FBUztFQUVULE9BQU87RUFFUCxRQUFRO0VBR1IsT0FBTztFQUVQLFNBQVM7RUFDVCxXQUFXO0VBRVgsWUFBWSxLQUFLO0NBQ25CO0NBQ0EsSUFBSSxTQUFTO0NBQ2IsSUFBSSxRQUFRO0NBQ1osSUFBSSxhQUFhO0VBQ2YsU0FBUyxDQUFDLEtBQUs7RUFDZixRQUFRO0NBQ1Y7Q0FDQSxNQUFNLEVBQUUsUUFBUSxVQUFVLE1BQU0sVUFBVSxRQUFRLEtBQUs7Q0FDdkQsTUFBTSxTQUFTO0NBQ2YsTUFBTSxVQUFVO0NBQ2hCLE9BQU8sQ0FBQyxPQUFPLEtBQUs7QUFDdEI7QUFDQSxJQUFJLGNBQWM7Q0FDaEIsSUFBSSxPQUFPLE1BQU07RUFDZixJQUFJLFNBQVMsYUFDWCxPQUFPO0VBQ1QsSUFBSSxjQUFjLE1BQU0sT0FBTztFQUMvQixNQUFNLHdCQUF3QixNQUFNLFVBQVUsS0FBaUIsT0FBTyxTQUFTO0VBQy9FLElBQUksdUJBQ0U7T0FBQSxhQUFhLHVCQUF1QixJQUFJLEdBQzFDLE9BQU8sWUFBWSx3QkFBd0IsT0FBTyxJQUFJO0VBQUE7RUFHMUQsTUFBTSxTQUFTLE9BQU8sS0FBSztFQUMzQixJQUFJLENBQUMsSUFBSSxRQUFRLE1BQU0sTUFBTSxLQUFLLEdBQ2hDLE9BQU8sa0JBQWtCLE9BQU8sUUFBUSxJQUFJO0VBRTlDLE1BQU0sUUFBUSxPQUFPO0VBQ3JCLElBQUksTUFBTSxjQUFjLENBQUMsWUFBWSxLQUFLLEdBQ3hDLE9BQU87RUFFVCxJQUFJLHlCQUF5QixNQUFNLG1CQUFtQixhQUFhLHNCQUNqRSxNQUFNLGVBQ1IsS0FBSyxhQUFhLElBQUksR0FDcEIsT0FBTztFQUVULElBQUksVUFBVSxLQUFLLE1BQU0sT0FBTyxJQUFJLEtBQUssbUJBQW1CLE9BQU8sTUFBTSxLQUFLLEdBQUc7R0FDL0UsWUFBWSxLQUFLO0dBQ2pCLE1BQU0sV0FBVyxNQUFNLFVBQVUsSUFBZ0IsQ0FBQyxPQUFPO0dBQ3pELE1BQU0sYUFBYSxZQUFZLE1BQU0sUUFBUSxPQUFPLE9BQU8sUUFBUTtHQUNuRSxPQUFPLE1BQU0sTUFBTSxZQUFZO0VBQ2pDO0VBQ0EsT0FBTztDQUNUO0NBQ0EsSUFBSSxPQUFPLE1BQU07RUFDZixPQUFPLFFBQVEsT0FBTyxLQUFLO0NBQzdCO0NBQ0EsUUFBUSxPQUFPO0VBQ2IsT0FBTyxRQUFRLFFBQVEsT0FBTyxLQUFLLENBQUM7Q0FDdEM7Q0FDQSxJQUFJLE9BQU8sTUFBTSxPQUFPO0VBQ3RCLE1BQU0sT0FBTyx1QkFBdUIsT0FBTyxLQUFLLEdBQUcsSUFBSTtFQUN2RCxJQUFJLE1BQU0sS0FBSztHQUNiLEtBQUssSUFBSSxLQUFLLE1BQU0sUUFBUSxLQUFLO0dBQ2pDLE9BQU87RUFDVDtFQUNBLElBQUksQ0FBQyxNQUFNLFdBQVc7R0FDcEIsTUFBTSxXQUFXLEtBQUssT0FBTyxLQUFLLEdBQUcsSUFBSTtHQUN6QyxNQUFNLGVBQWUsV0FBVztHQUNoQyxJQUFJLGdCQUFnQixhQUFhLFVBQVUsT0FBTztJQUNoRCxNQUFNLE1BQU0sUUFBUTtJQUNwQixNQUFNLFVBQVUsT0FBTyxJQUFJO0lBQzNCLE9BQU87R0FDVDtHQUNBLElBQUksR0FBRyxPQUFPLFFBQVEsTUFBTSxVQUFVLEtBQUssS0FBSyxJQUFJLE1BQU0sT0FBTyxNQUFNLE1BQU0sS0FBSyxJQUNoRixPQUFPO0dBQ1QsWUFBWSxLQUFLO0dBQ2pCLFlBQVksS0FBSztFQUNuQjtFQUNBLElBQUksTUFBTSxNQUFNLFVBQVUsVUFDekIsVUFBVSxLQUFLLEtBQUssSUFBSSxNQUFNLE9BQU8sTUFBTSxNQUFNLEtBQUssTUFDdkQsT0FBTyxNQUFNLEtBQUssS0FBSyxPQUFPLE1BQU0sTUFBTSxNQUFNLEtBQUssR0FDbkQsT0FBTztFQUNULE1BQU0sTUFBTSxRQUFRO0VBQ3BCLE1BQU0sVUFBVSxJQUFJLE1BQU0sSUFBSTtFQUM5QixxQkFBcUIsT0FBTyxNQUFNLEtBQUs7RUFDdkMsT0FBTztDQUNUO0NBQ0EsZUFBZSxPQUFPLE1BQU07RUFDMUIsWUFBWSxLQUFLO0VBQ2pCLElBQUksS0FBSyxNQUFNLE9BQU8sSUFBSSxNQUFNLEtBQUssS0FBSyxRQUFRLE1BQU0sT0FBTztHQUM3RCxNQUFNLFVBQVUsSUFBSSxNQUFNLEtBQUs7R0FDL0IsWUFBWSxLQUFLO0VBQ25CLE9BQ0UsTUFBTSxVQUFVLE9BQU8sSUFBSTtFQUU3QixJQUFJLE1BQU0sT0FDUixPQUFPLE1BQU0sTUFBTTtFQUVyQixPQUFPO0NBQ1Q7Q0FHQSx5QkFBeUIsT0FBTyxNQUFNO0VBQ3BDLE1BQU0sUUFBUSxPQUFPLEtBQUs7RUFDMUIsTUFBTSxPQUFPLFFBQVEseUJBQXlCLE9BQU8sSUFBSTtFQUN6RCxJQUFJLENBQUMsTUFDSCxPQUFPO0VBQ1QsT0FBTztJQUNKLFdBQVc7SUFDWCxlQUFlLE1BQU0sVUFBVSxLQUFpQixTQUFTO0lBQ3pELGFBQWEsS0FBSztJQUNsQixRQUFRLE1BQU07RUFDakI7Q0FDRjtDQUNBLGlCQUFpQjtFQUNmLElBQUksRUFBRTtDQUNSO0NBQ0EsZUFBZSxPQUFPO0VBQ3BCLE9BQU8sZUFBZSxNQUFNLEtBQUs7Q0FDbkM7Q0FDQSxpQkFBaUI7RUFDZixJQUFJLEVBQUU7Q0FDUjtBQUNGO0FBQ0EsSUFBSSxhQUFhLENBQUM7QUFDbEIsS0FBSyxJQUFJLE9BQU8sYUFBYTtDQUMzQixJQUFJLEtBQUssWUFBWTtDQUNyQixXQUFXLE9BQU8sV0FBVztFQUMzQixNQUFNLE9BQU87RUFDYixLQUFLLEtBQUssS0FBSyxFQUFFLENBQUM7RUFDbEIsT0FBTyxHQUFHLE1BQU0sTUFBTSxJQUFJO0NBQzVCO0FBQ0Y7QUFDQSxXQUFXLGlCQUFpQixTQUFTLE9BQU8sTUFBTTtDQUNoRCxJQUE2QyxNQUFNLFNBQVMsSUFBSSxDQUFDLEdBQy9ELElBQUksRUFBRTtDQUNSLE9BQU8sV0FBVyxJQUFJLEtBQUssTUFBTSxPQUFPLE1BQU0sS0FBSyxDQUFDO0FBQ3REO0FBQ0EsV0FBVyxNQUFNLFNBQVMsT0FBTyxNQUFNLE9BQU87Q0FDNUMsSUFBNkMsU0FBUyxZQUFZLE1BQU0sU0FBUyxJQUFJLENBQUMsR0FDcEYsSUFBSSxFQUFFO0NBQ1IsT0FBTyxZQUFZLElBQUksS0FBSyxNQUFNLE1BQU0sSUFBSSxNQUFNLE9BQU8sTUFBTSxFQUFFO0FBQ25FO0FBQ0EsU0FBUyxLQUFLLE9BQU8sTUFBTTtDQUN6QixNQUFNLFFBQVEsTUFBTTtDQUVwQixRQURlLFFBQVEsT0FBTyxLQUFLLElBQUksTUFBQSxDQUN6QjtBQUNoQjtBQUNBLFNBQVMsbUJBQW1CLE9BQU8sTUFBTSxPQUFPO0NBQzlDLElBQUksTUFBTSxVQUFVLEtBQWlCLENBQUMsTUFBTSx5QkFBeUIsTUFBTSxXQUFXLElBQUksSUFBSSxLQUFLLENBQUMsWUFBWSxLQUFLLEtBQUssTUFBTSxjQUM5SCxPQUFPO0NBRVQsT0FBTyxNQUFNLFVBQVUsSUFBSSxLQUFLO0FBQ2xDO0FBQ0EsU0FBUyxrQkFBa0IsT0FBTyxRQUFRLE1BQU07Q0FDOUMsTUFBTSxPQUFPLHVCQUF1QixRQUFRLElBQUk7Q0FDaEQsT0FBTyxPQUFPLFNBQVMsT0FBTyxLQUFLLFNBR2pDLEtBQUssS0FBSyxLQUFLLE1BQU0sTUFBTSxJQUN6QixLQUFLO0FBQ1g7QUFDQSxTQUFTLHVCQUF1QixRQUFRLE1BQU07Q0FDNUMsSUFBSSxFQUFFLFFBQVEsU0FDWixPQUFPLEtBQUs7Q0FDZCxJQUFJLFFBQVEsZUFBZSxNQUFNO0NBQ2pDLE9BQU8sT0FBTztFQUNaLE1BQU0sT0FBTyxPQUFPLHlCQUF5QixPQUFPLElBQUk7RUFDeEQsSUFBSSxNQUNGLE9BQU87RUFDVCxRQUFRLGVBQWUsS0FBSztDQUM5QjtBQUVGO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsSUFBSSxDQUFDLE1BQU0sV0FBVztFQUNwQixNQUFNLFlBQVk7RUFDbEIsSUFBSSxNQUFNLFNBQ1IsWUFBWSxNQUFNLE9BQU87Q0FFN0I7QUFDRjtBQUNBLFNBQVMsWUFBWSxPQUFPO0NBQzFCLElBQUksQ0FBQyxNQUFNLE9BQU87RUFDaEIsTUFBTSw0QkFBNEIsSUFBSSxJQUFJO0VBQzFDLE1BQU0sUUFBUSxZQUNaLE1BQU0sT0FDTixNQUFNLE9BQU8sT0FBTyxxQkFDdEI7Q0FDRjtBQUNGO0FBR0EsSUFBSSxTQUFTLE1BQU07Q0FDakIsWUFBWSxRQUFRO0VBQ2xCLEtBQUssY0FBYztFQUNuQixLQUFLLHdCQUF3QjtFQUM3QixLQUFLLHNCQUFzQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFvQjNCLEtBQUssV0FBVyxNQUFNLFFBQVEsa0JBQWtCO0dBQzlDLElBQUksV0FBVyxJQUFJLEtBQUssQ0FBQyxXQUFXLE1BQU0sR0FBRztJQUMzQyxNQUFNLGNBQWM7SUFDcEIsU0FBUztJQUNULE1BQU0sT0FBTztJQUNiLE9BQU8sU0FBUyxlQUFlLFFBQVEsYUFBYSxHQUFHLE1BQU07S0FDM0QsT0FBTyxLQUFLLFFBQVEsUUFBUSxVQUFVLE9BQU8sS0FBSyxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUM7SUFDekU7R0FDRjtHQUNBLElBQUksQ0FBQyxXQUFXLE1BQU0sR0FDcEIsSUFBSSxDQUFDO0dBQ1AsSUFBSSxrQkFBa0IsS0FBSyxLQUFLLENBQUMsV0FBVyxhQUFhLEdBQ3ZELElBQUksQ0FBQztHQUNQLElBQUk7R0FDSixJQUFJLFlBQVksSUFBSSxHQUFHO0lBQ3JCLE1BQU0sUUFBUSxXQUFXLElBQUk7SUFDN0IsTUFBTSxRQUFRLFlBQVksT0FBTyxNQUFNLEtBQUssQ0FBQztJQUM3QyxJQUFJLFdBQVc7SUFDZixJQUFJO0tBQ0YsU0FBUyxPQUFPLEtBQUs7S0FDckIsV0FBVztJQUNiLFVBQVU7S0FDUixJQUFJLFVBQ0YsWUFBWSxLQUFLO1VBRWpCLFdBQVcsS0FBSztJQUNwQjtJQUNBLGtCQUFrQixPQUFPLGFBQWE7SUFDdEMsT0FBTyxjQUFjLFFBQVEsS0FBSztHQUNwQyxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUMsWUFBWSxJQUFJLEdBQUc7SUFDdEMsU0FBUyxPQUFPLElBQUk7SUFDcEIsSUFBSSxXQUFXLEtBQUssR0FDbEIsU0FBUztJQUNYLElBQUksV0FBVyxTQUNiLFNBQVMsS0FBSztJQUNoQixJQUFJLEtBQUssYUFDUCxPQUFPLFFBQVEsSUFBSTtJQUNyQixJQUFJLGVBQWU7S0FDakIsTUFBTSxJQUFJLENBQUM7S0FDWCxNQUFNLEtBQUssQ0FBQztLQUNaLFVBQVUsYUFBYSxDQUFDLENBQUMsNEJBQTRCLE1BQU0sUUFBUTtNQUNqRSxVQUFVO01BQ1YsaUJBQWlCO0tBQ25CLENBQUM7S0FDRCxjQUFjLEdBQUcsRUFBRTtJQUNyQjtJQUNBLE9BQU87R0FDVCxPQUNFLElBQUksR0FBRyxJQUFJO0VBQ2Y7RUFDQSxLQUFLLHNCQUFzQixNQUFNLFdBQVc7R0FDMUMsSUFBSSxXQUFXLElBQUksR0FDakIsUUFBUSxPQUFPLEdBQUcsU0FBUyxLQUFLLG1CQUFtQixRQUFRLFVBQVUsS0FBSyxPQUFPLEdBQUcsSUFBSSxDQUFDO0dBRTNGLElBQUksU0FBUztHQUtiLE9BQU87SUFKUSxLQUFLLFFBQVEsTUFBTSxTQUFTLEdBQUcsT0FBTztLQUNuRCxVQUFVO0tBQ1YsaUJBQWlCO0lBQ25CLENBQ2E7SUFBRztJQUFTO0dBQWM7RUFDekM7RUFDQSxJQUFJQyxZQUFVLFFBQVEsVUFBVSxHQUM5QixLQUFLLGNBQWMsT0FBTyxVQUFVO0VBQ3RDLElBQUlBLFlBQVUsUUFBUSxvQkFBb0IsR0FDeEMsS0FBSyx3QkFBd0IsT0FBTyxvQkFBb0I7RUFDMUQsSUFBSUEsWUFBVSxRQUFRLGtCQUFrQixHQUN0QyxLQUFLLHNCQUFzQixPQUFPLGtCQUFrQjtDQUN4RDtDQUNBLFlBQVksTUFBTTtFQUNoQixJQUFJLENBQUMsWUFBWSxJQUFJLEdBQ25CLElBQUksQ0FBQztFQUNQLElBQUksUUFBUSxJQUFJLEdBQ2QsT0FBTyxRQUFRLElBQUk7RUFDckIsTUFBTSxRQUFRLFdBQVcsSUFBSTtFQUM3QixNQUFNLFFBQVEsWUFBWSxPQUFPLE1BQU0sS0FBSyxDQUFDO0VBQzdDLE1BQU0sWUFBWSxDQUFDLFlBQVk7RUFDL0IsV0FBVyxLQUFLO0VBQ2hCLE9BQU87Q0FDVDtDQUNBLFlBQVksT0FBTyxlQUFlO0VBQ2hDLE1BQU0sUUFBUSxTQUFTLE1BQU07RUFDN0IsSUFBSSxDQUFDLFNBQVMsQ0FBQyxNQUFNLFdBQ25CLElBQUksQ0FBQztFQUNQLE1BQU0sRUFBRSxRQUFRLFVBQVU7RUFDMUIsa0JBQWtCLE9BQU8sYUFBYTtFQUN0QyxPQUFPLGNBQWMsS0FBSyxHQUFHLEtBQUs7Q0FDcEM7Ozs7OztDQU1BLGNBQWMsT0FBTztFQUNuQixLQUFLLGNBQWM7Q0FDckI7Ozs7OztDQU1BLHdCQUF3QixPQUFPO0VBQzdCLEtBQUssd0JBQXdCO0NBQy9COzs7Ozs7O0NBT0Esc0JBQXNCLE9BQU87RUFDM0IsS0FBSyxzQkFBc0I7Q0FDN0I7Q0FDQSwyQkFBMkI7RUFDekIsT0FBTyxLQUFLO0NBQ2Q7Q0FDQSxhQUFhLE1BQU0sU0FBUztFQUMxQixJQUFJO0VBQ0osS0FBSyxJQUFJLFFBQVEsU0FBUyxHQUFHLEtBQUssR0FBRyxLQUFLO0dBQ3hDLE1BQU0sUUFBUSxRQUFRO0dBQ3RCLElBQUksTUFBTSxLQUFLLFdBQVcsS0FBSyxNQUFNLE9BQU8sV0FBVztJQUNyRCxPQUFPLE1BQU07SUFDYjtHQUNGO0VBQ0Y7RUFDQSxJQUFJLElBQUksSUFDTixVQUFVLFFBQVEsTUFBTSxJQUFJLENBQUM7RUFFL0IsTUFBTSxtQkFBbUIsVUFBVSxhQUFhLENBQUMsQ0FBQztFQUNsRCxJQUFJLFFBQVEsSUFBSSxHQUNkLE9BQU8saUJBQWlCLE1BQU0sT0FBTztFQUV2QyxPQUFPLEtBQUssUUFDVixPQUNDLFVBQVUsaUJBQWlCLE9BQU8sT0FBTyxDQUM1QztDQUNGO0FBQ0Y7QUFDQSxTQUFTLFlBQVksV0FBVyxPQUFPLFFBQVEsS0FBSztDQUNsRCxNQUFNLENBQUMsT0FBTyxTQUFTLE1BQU0sS0FBSyxJQUFJLFVBQVUsWUFBWSxDQUFDLENBQUMsVUFBVSxPQUFPLE1BQU0sSUFBSSxNQUFNLEtBQUssSUFBSSxVQUFVLFlBQVksQ0FBQyxDQUFDLFVBQVUsT0FBTyxNQUFNLElBQUksaUJBQWlCLE9BQU8sTUFBTTtDQUV6TCxDQURjLFFBQVEsVUFBVSxnQkFBZ0IsRUFBQSxDQUMxQyxRQUFRLEtBQUssS0FBSztDQUN4QixNQUFNLGFBQWEsUUFBUSxjQUFjLENBQUM7Q0FDMUMsTUFBTSxPQUFPO0NBQ2IsSUFBSSxVQUFVLFFBQVEsS0FBSyxHQUN6QixrQ0FBa0MsUUFBUSxPQUFPLEdBQUc7TUFFcEQsTUFBTSxXQUFXLEtBQUssU0FBUyxpQkFBaUIsWUFBWTtFQUMxRCxXQUFXLGVBQWUsZUFBZSxLQUFLO0VBQzlDLE1BQU0sRUFBRSxpQkFBaUI7RUFDekIsSUFBSSxNQUFNLGFBQWEsY0FDckIsYUFBYSxpQkFBaUIsT0FBTyxDQUFDLEdBQUcsVUFBVTtDQUV2RCxDQUFDO0NBRUgsT0FBTztBQUNUO0FBR0EsU0FBUyxRQUFRLE9BQU87Q0FDdEIsSUFBSSxDQUFDLFFBQVEsS0FBSyxHQUNoQixJQUFJLElBQUksS0FBSztDQUNmLE9BQU8sWUFBWSxLQUFLO0FBQzFCO0FBQ0EsU0FBUyxZQUFZLE9BQU87Q0FDMUIsSUFBSSxDQUFDLFlBQVksS0FBSyxLQUFLLFNBQVMsS0FBSyxHQUN2QyxPQUFPO0NBQ1QsTUFBTSxRQUFRLE1BQU07Q0FDcEIsSUFBSTtDQUNKLElBQUksU0FBUztDQUNiLElBQUksT0FBTztFQUNULElBQUksQ0FBQyxNQUFNLFdBQ1QsT0FBTyxNQUFNO0VBQ2YsTUFBTSxhQUFhO0VBQ25CLE9BQU8sWUFBWSxPQUFPLE1BQU0sT0FBTyxPQUFPLHFCQUFxQjtFQUNuRSxTQUFTLE1BQU0sT0FBTyxPQUFPLHlCQUF5QjtDQUN4RCxPQUNFLE9BQU8sWUFBWSxPQUFPLElBQUk7Q0FFaEMsS0FDRSxPQUNDLEtBQUssZUFBZTtFQUNuQixJQUFJLE1BQU0sS0FBSyxZQUFZLFVBQVUsQ0FBQztDQUN4QyxHQUNBLE1BQ0Y7Q0FDQSxJQUFJLE9BQ0YsTUFBTSxhQUFhO0NBRXJCLE9BQU87QUFDVDtBQXNUc0IsV0FBVyxVQUNhO0FBcWU5QyxJQUFJLFVBQVUsSUFERSxPQUNGLENBQUEsQ0FBTTs7O0FDdm9EcEIsSUFBSSw2QkFBNkI7QUFDakMsSUFBSSxxQkFBcUIsV0FBVyxhQUFhO0NBQy9DLElBQUksUUFBUSxLQUFLO0NBQ2pCLElBQUk7RUFDRixNQUFNLElBQUksTUFBTTtDQUNsQixTQUFTLEdBQUc7RUFFVixDQUFDLENBQUUsU0FBVTtDQUNmO0NBQ0EsUUFBUSxLQUNOLDBDQUEwQyxXQUFXLE9BQU8sU0FBUyxPQUFPLEdBQUcsaUJBQWlCLFVBQVU7OztzRkFJMUcsRUFBRSxNQUFNLENBQ1Y7QUFDRjtBQUdBLElBQUksc0JBQXNCO0NBQ3hCLHFCQUFxQjtDQUNyQix1QkFBdUI7Q0FDdkIsZ0JBQWdCO0FBQ2xCO0FBTUEsSUFBSSxZQUFZLE1BQU07Q0FDcEIsWUFBWSxPQUFPO0VBQ2pCLEtBQUssUUFBUTtDQUNmO0NBQ0EsUUFBUTtFQUNOLE9BQU8sS0FBSztDQUNkO0FBQ0Y7QUFDQSxJQUFJLG1CQUFtQixPQUFPLFlBQVksY0FBYyxZQUFZO0FBQ3BFLElBQUksTUFBc0IsMkJBQVc7QUFDckMsSUFBSSxlQUFlO0FBQ25CLElBQUksYUFBYTtBQUNqQixTQUFTLGtCQUFrQjtDQUN6QixPQUFPO0VBQ0wsR0FBRztFQUNILEdBQUcsS0FBSztFQUNSLEdBQUc7RUFDSCxHQUFHO0NBQ0w7QUFDRjtBQUNBLFNBQVMsV0FBVyxHQUFHO0NBQ3JCLElBQUksYUFBYSxLQUNmLE9BQU8sRUFBRSxNQUFNO0NBRWpCLE9BQU87QUFDVDtBQUNBLFNBQVMsZUFBZSxNQUFNLFVBQVUsQ0FBQyxHQUFHO0NBQzFDLElBQUksU0FBUyxnQkFBZ0I7Q0FDN0IsTUFBTSxFQUFFLHFCQUFxQixZQUFZO0NBQ3pDLE1BQU0saUJBQWlCLFlBQVksS0FBSztDQUN4QyxJQUFJLG1CQUFtQixDQUFDLE9BQU8sVUFBVSxPQUFPLEtBQUssVUFBVSxJQUM3RCxNQUFNLElBQUksVUFDUixpREFBaUQsU0FDbkQ7Q0FFRixJQUFJLFdBQVc7Q0FDZixJQUFJLGlCQUFpQjtDQUNyQixJQUFJO0NBQ0osSUFBSSxlQUFlO0NBQ25CLElBQUksMEJBQTBCO0NBQzlCLFNBQVMsdUJBQXVCO0VBQzlCLElBQUksa0JBQWtCLFNBQVM7R0FDN0IsV0FBVztHQUNYLFNBQVMsZ0JBQWdCO0dBQ3pCLGlCQUFpQjtFQUNuQjtDQUNGO0NBQ0EsU0FBUyxXQUFXO0VBQ2xCLElBQUksWUFBWTtFQUNoQixNQUFNLEVBQUUsV0FBVztFQUNuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxJQUFJLEdBQUcsS0FBSztHQUN0QyxNQUFNLE1BQU0sVUFBVTtHQUN0QixJQUFJLE9BQU8sUUFBUSxjQUFjLE9BQU8sUUFBUSxZQUFZLFFBQVEsTUFBTTtJQUN4RSxJQUFJLGNBQWMsVUFBVTtJQUM1QixJQUFJLGdCQUFnQixNQUNsQixVQUFVLElBQUksOEJBQThCLElBQUksUUFBUTtJQUUxRCxNQUFNLGFBQWEsWUFBWSxJQUFJLEdBQUc7SUFDdEMsSUFBSSxlQUFlLEtBQUssR0FBRztLQUN6QixZQUFZLGdCQUFnQjtLQUM1QixZQUFZLElBQUksS0FBSyxTQUFTO0lBQ2hDLE9BQ0UsWUFBWTtHQUVoQixPQUFPO0lBQ0wsSUFBSSxpQkFBaUIsVUFBVTtJQUMvQixJQUFJLG1CQUFtQixNQUNyQixVQUFVLElBQUksaUNBQWlDLElBQUksSUFBSTtJQUV6RCxNQUFNLGdCQUFnQixlQUFlLElBQUksR0FBRztJQUM1QyxJQUFJLGtCQUFrQixLQUFLLEdBQUc7S0FDNUIsWUFBWSxnQkFBZ0I7S0FDNUIsZUFBZSxJQUFJLEtBQUssU0FBUztLQUNqQztLQUVFLElBQUksZUFBZSxPQUFPLDRCQUE0QjtNQUNwRCxNQUFNLEVBQUUsbUJBQW1CO01BQzNCLElBQUksbUJBQW1CLFlBQVksbUJBQW1CLFVBQVUsQ0FBQyx5QkFBeUI7T0FDeEYsMEJBQTBCO09BQzFCLGtCQUFrQixlQUFlLE1BQU0sS0FBSyxJQUFJO01BQ2xEO0tBQ0Y7SUFFSixPQUNFLFlBQVk7R0FFaEI7RUFDRjtFQUNBLElBQUksVUFBVSxNQUFNLFlBQ2xCLE9BQU8sVUFBVTtFQUVuQixJQUFJLGFBQWEsTUFBTTtHQUNyQixJQUFJLGdCQUFnQjtHQUNwQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxJQUFJLEdBQUcsS0FBSztJQUN0QyxNQUFNLE1BQU0sVUFBVTtJQUN0QixJQUFJO0lBQ0osSUFBSSxPQUFPLFFBQVEsY0FBYyxPQUFPLFFBQVEsWUFBWSxRQUFRLE1BQU07S0FDeEUsTUFBTSxrQkFBa0IsY0FBYztLQUN0QyxPQUFPLG9CQUFvQixPQUFPLGdCQUFnQixJQUFJLEdBQUcsSUFBSSxLQUFLO0lBQ3BFLE9BQU87S0FDTCxNQUFNLHFCQUFxQixjQUFjO0tBQ3pDLE9BQU8sdUJBQXVCLE9BQU8sbUJBQW1CLElBQUksR0FBRyxJQUFJLEtBQUs7SUFDMUU7SUFDQSxJQUFJLFNBQVMsS0FBSyxHQUFHO0tBQ25CLGdCQUFnQjtLQUNoQjtJQUNGO0lBQ0EsZ0JBQWdCO0dBQ2xCO0dBQ0EsSUFBSSxrQkFBa0IsUUFBUSxjQUFjLE1BQU0sWUFBWTtJQUM1RCxNQUFNLGVBQWU7SUFDckIsYUFBYSxJQUFJO0lBQ2pCLGFBQWEsSUFBSSxjQUFjO0lBQy9CLHFCQUFxQjtJQUNyQixPQUFPLGNBQWM7R0FDdkI7RUFDRjtFQUNBLE1BQU0saUJBQWlCO0VBQ3ZCLElBQUksU0FBUyxLQUFLLE1BQU0sTUFBTSxTQUFTO0VBQ3ZDO0VBQ0EsSUFBSSxxQkFBcUI7R0FDdkIsTUFBTSxrQkFBa0IsV0FBVyxVQUFVO0dBQzdDLElBQUksbUJBQW1CLFFBQVEsb0JBQW9CLGlCQUFpQixNQUFNLEdBQUc7SUFDM0UsU0FBUztJQUNULGlCQUFpQixLQUFLO0dBQ3hCO0dBRUEsYUFEcUIsT0FBTyxXQUFXLFlBQVksV0FBVyxRQUFRLE9BQU8sV0FBVyw2QkFDNUMsSUFBSSxJQUFJLE1BQU0sSUFBSTtFQUNoRTtFQUNBLGVBQWUsSUFBSTtFQUNuQixlQUFlLElBQUk7RUFDbkIsSUFBSSxnQkFDRixxQkFBcUI7RUFFdkIsT0FBTztDQUNUO0NBQ0EsU0FBUyxtQkFBbUI7RUFDMUIsU0FBUyxnQkFBZ0I7RUFDekIsV0FBVztFQUNYLGlCQUFpQjtFQUNqQixTQUFTLGtCQUFrQjtFQUV6QiwwQkFBMEI7Q0FFOUI7Q0FDQSxTQUFTLHFCQUFxQjtDQUM5QixTQUFTLDBCQUEwQjtFQUNqQyxlQUFlO0NBQ2pCO0NBQ0EsT0FBTztBQUNUO0FBR0EsSUFBSSw0QkFBNEIsWUFBWSx1QkFBdUIseUJBQXlCO0NBQzFGLElBQUksc0JBQXNCLFdBQVcsS0FBSyxzQkFBc0IsT0FBTyxzQkFBc0I7RUFDM0YsSUFBSSxzQkFBc0I7RUFDMUIsSUFBSTtHQUNGLE1BQU0sY0FBYyxDQUFDO0dBQ3JCLElBQUksV0FBVyxXQUFXLE1BQU0sYUFBYSxzQkFBc0I7RUFDckUsUUFBUSxDQUNSO0VBQ0EsSUFBSSxxQkFBcUI7R0FDdkIsSUFBSSxRQUFRLEtBQUs7R0FDakIsSUFBSTtJQUNGLE1BQU0sSUFBSSxNQUFNO0dBQ2xCLFNBQVMsR0FBRztJQUVWLENBQUMsQ0FBRSxTQUFVO0dBQ2Y7R0FDQSxRQUFRLEtBQ04sbVRBQ0EsRUFBRSxNQUFNLENBQ1Y7RUFDRjtDQUNGO0FBQ0Y7QUFHQSxJQUFJLDhCQUE4QixXQUFXO0NBQzNDLElBQUksV0FBVyxRQUFRLE9BQU8sV0FBVyxZQUFZLEVBQUUseUJBQXlCLFNBQzlFLE9BQU87Q0FFVCxNQUFNLGFBQWEsRUFBRSxHQUFHLE9BQU87Q0FDL0IsT0FBTyxXQUFXO0NBQ2xCLE9BQU87QUFDVDtBQUNBLElBQUksMEJBQTBCLDRCQUE0QixTQUFTLHNCQUFzQjtDQUN2RixNQUFNLEVBQUUsU0FBUyxtQkFBbUI7Q0FDcEMsTUFBTSxFQUFFLHNCQUFzQiw2QkFBNkI7Q0FDM0QsTUFBTSxzQkFBc0IsQ0FBQztDQUM3QixNQUFNLEVBQUUsV0FBVztDQUNuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUMxQixvQkFBb0IsS0FBSywyQkFBMkIsZUFBZSxFQUFFLENBQUM7Q0FFeEUsTUFBTSxzQkFBc0IsZUFBZSxDQUFDLElBQUksR0FBRyxtQkFBbUI7Q0FFdEUsSUFBSSxFQURpQyxvQkFBb0IsTUFBTSxNQUFNLG9CQUFvQixNQUFNLG9CQUFvQixNQUFNLE1BQU0sd0JBQXdCLElBQ3BIO0VBQ2pDLElBQUksUUFBUSxLQUFLO0VBQ2pCLElBQUk7R0FDRixNQUFNLElBQUksTUFBTTtFQUNsQixTQUFTLEdBQUc7R0FFVixDQUFDLENBQUUsU0FBVTtFQUNmO0VBQ0EsUUFBUSxLQUNOLHlUQUNBO0dBQ0UsV0FBVztHQUNYLGFBQWE7R0FDYixjQUFjO0dBQ2Q7RUFDRixDQUNGO0NBQ0Y7QUFDRjtBQUdBLElBQUksWUFBNEIsdUJBQU8sV0FBVztBQUNsRCxTQUFTLGlCQUFpQixNQUFNLGVBQWUseUNBQXlDLE9BQU8sUUFBUTtDQUNyRyxJQUFJLE9BQU8sU0FBUyxZQUNsQixNQUFNLElBQUksVUFBVSxZQUFZO0FBRXBDO0FBTUEsU0FBUyx5QkFBeUIsT0FBTyxlQUFlLDhFQUE4RTtDQUNwSSxJQUFJLENBQUMsTUFBTSxPQUFPLFNBQVMsT0FBTyxTQUFTLFVBQVUsR0FBRztFQUN0RCxNQUFNLFlBQVksTUFBTSxLQUNyQixTQUFTLE9BQU8sU0FBUyxhQUFhLFlBQVksS0FBSyxRQUFRLFVBQVUsTUFBTSxPQUFPLElBQ3pGLENBQUMsQ0FBQyxLQUFLLElBQUk7RUFDWCxNQUFNLElBQUksVUFBVSxHQUFHLGFBQWEsR0FBRyxVQUFVLEVBQUU7Q0FDckQ7QUFDRjtBQUNBLElBQUksaUJBQWlCLFNBQVM7Q0FDNUIsT0FBTyxNQUFNLFFBQVEsSUFBSSxJQUFJLE9BQU8sQ0FBQyxJQUFJO0FBQzNDO0FBQ0EsU0FBUyxnQkFBZ0Isb0JBQW9CO0NBQzNDLE1BQU0sZUFBZSxNQUFNLFFBQVEsbUJBQW1CLEVBQUUsSUFBSSxtQkFBbUIsS0FBSztDQUNwRix5QkFDRSxjQUNBLGdHQUNGO0NBQ0EsT0FBTztBQUNUO0FBQ0EsU0FBUyw0QkFBNEIsY0FBYyxtQkFBbUI7Q0FDcEUsTUFBTSx1QkFBdUIsQ0FBQztDQUM5QixNQUFNLEVBQUUsV0FBVztDQUNuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUMxQixxQkFBcUIsS0FBSyxhQUFhLEVBQUUsQ0FBQyxNQUFNLE1BQU0saUJBQWlCLENBQUM7Q0FFMUUsT0FBTztBQUNUO0FBR0EsU0FBUyxzQkFBc0Isa0JBQWtCLEdBQUcsd0JBQXdCO0NBQzFFLE1BQU0sK0JBQStCLE9BQU8scUJBQXFCLGFBQWE7RUFDNUUsU0FBUztFQUNULGdCQUFnQjtDQUNsQixJQUFJO0NBQ0osTUFBTSxtQkFBbUIsR0FBRyx1QkFBdUI7RUFDakQsSUFBSSxpQkFBaUI7RUFDckIsSUFBSSwyQkFBMkI7RUFDL0IsSUFBSTtFQUNKLElBQUksd0JBQXdCLENBQUM7RUFDN0IsSUFBSSxhQUFhLG1CQUFtQixJQUFJO0VBQ3hDLElBQUksT0FBTyxlQUFlLFVBQVU7R0FDbEMsd0JBQXdCO0dBQ3hCLGFBQWEsbUJBQW1CLElBQUk7RUFDdEM7RUFDQSxpQkFDRSxZQUNBLDhFQUE4RSxPQUFPLFdBQVcsRUFDbEc7RUFDQSxNQUFNLGtCQUFrQjtHQUN0QixHQUFHO0dBQ0gsR0FBRztFQUNMO0VBQ0EsTUFBTSxFQUNKLFNBQ0EsaUJBQWlCLENBQUMsR0FDbEIsY0FBYyxnQkFDZCxxQkFBcUIsQ0FBQyxNQUNwQjtFQUNKLE1BQU0sc0JBQXNCLGNBQWMsY0FBYztFQUN4RCxNQUFNLDBCQUEwQixjQUFjLGtCQUFrQjtFQUNoRSxNQUFNLGVBQWUsZ0JBQWdCLGtCQUFrQjtFQUN2RCxNQUFNLHFCQUFxQixRQUFRLFNBQVMsdUJBQXVCO0dBQ2pFO0dBQ0EsT0FBTyxXQUFXLE1BQ2hCLE1BQ0EsU0FDRjtFQUNGLEdBQUcsR0FBRyxtQkFBbUI7RUFDekIsSUFBSSxXQUFXO0VBQ2YsTUFBTSxXQUFXLFlBQVksU0FBUyxzQkFBc0I7R0FDMUQ7R0FDQSxNQUFNLEVBQUUsV0FBVztHQUNuQixNQUFNLHVCQUF1QixJQUFJLE1BQU0sTUFBTTtHQUM3QyxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUMxQixxQkFBcUIsS0FBSyxhQUFhLEVBQUUsQ0FBQyxNQUFNLE1BQU0sU0FBUztHQUVqRSxhQUFhLG1CQUFtQixNQUFNLE1BQU0sb0JBQW9CO0dBQ3JCO0lBQ3pDLE1BQU0sRUFBRSxrQkFBa0I7SUFDMUIsTUFBTSx3QkFBd0Isa0JBQWtCLEtBQUssS0FBSyxPQUFPLFVBQVUsZUFBZSxLQUN4RixlQUNBLHVCQUNGLElBQUksY0FBYyx3QkFBd0Isb0JBQW9CO0lBQzlELE1BQU0sc0JBQXNCLGtCQUFrQixLQUFLLEtBQUssT0FBTyxVQUFVLGVBQWUsS0FDdEYsZUFDQSxxQkFDRixJQUFJLGNBQWMsc0JBQXNCLG9CQUFvQjtJQUM1RCxJQUFJLDBCQUEwQixZQUFZLDBCQUEwQixVQUFVLFVBQzVFLHlCQUNFLFlBQ0Esc0JBQ0EsVUFDRjtJQUVGLElBQUksd0JBQXdCLFlBQVksd0JBQXdCLFVBQVUsVUFLeEUsdUJBQ0U7S0FBRTtLQUFzQiwwQkFMTyw0QkFDL0IsY0FDQSxTQUcrQztJQUFFLEdBQ2pEO0tBQUU7S0FBUyxnQkFBZ0I7SUFBb0IsR0FDL0MsU0FDRjtJQUVGLElBQUksVUFBVSxXQUFXO0dBQzNCO0dBQ0EsT0FBTztFQUNULEdBQUcsR0FBRyx1QkFBdUI7RUFDN0IsT0FBTyxPQUFPLE9BQU8sVUFBVTtHQUM3QjtHQUNBO0dBQ0E7R0FDQSxnQ0FBZ0M7R0FDaEMscUNBQXFDO0lBQ25DLDJCQUEyQjtHQUM3QjtHQUNBLGtCQUFrQjtHQUNsQixzQkFBc0I7R0FDdEIsMkJBQTJCO0lBQ3pCLGlCQUFpQjtHQUNuQjtHQUNBO0dBQ0E7RUFDRixDQUFDO0NBQ0g7Q0FDQSxPQUFPLE9BQU8saUJBQWlCLEVBQzdCLGlCQUFpQixnQkFDbkIsQ0FBQztDQUNELE9BQU87QUFDVDtBQUNBLElBQUksaUJBQWlDLHNDQUFzQixjQUFjO0FBNEJ6RSxTQUFTLHFCQUFxQixRQUFRO0NBQ3BDLElBQUk7Q0FDSixPQUFPO0VBQ0wsSUFBSSxLQUFLO0dBQ1AsSUFBSSxTQUFTLE9BQU8sTUFBTSxLQUFLLEdBQUcsR0FDaEMsT0FBTyxNQUFNO0dBRWYsT0FBTztFQUNUO0VBQ0EsSUFBSSxLQUFLLE9BQU87R0FDZCxRQUFRO0lBQUU7SUFBSztHQUFNO0VBQ3ZCO0VBQ0Esa0JBQWtCLE9BQU8scUJBQXFCO0dBQzVDLE1BQU0sVUFBVTtHQUNoQixPQUFPLFlBQVksS0FBSyxLQUFLLG9CQUFvQixRQUFRLE9BQU8sS0FBSyxJQUFJLFVBQVUsS0FBSztFQUMxRjtFQUNBLFFBQVE7R0FDTixRQUFRLEtBQUs7RUFDZjtDQUNGO0FBQ0Y7QUFDQSxTQUFTLGVBQWUsU0FBUyxRQUFRO0NBQ3ZDLElBQUksVUFBVSxDQUFDO0NBQ2YsU0FBUyxJQUFJLEtBQUs7RUFDaEIsTUFBTSxhQUFhLFFBQVEsV0FBVyxVQUFVLE9BQU8sTUFBTSxLQUFLLEdBQUcsQ0FBQztFQUN0RSxJQUFJLGFBQWEsSUFBSTtHQUNuQixNQUFNLFFBQVEsUUFBUTtHQUN0QixJQUFJLGFBQWEsR0FBRztJQUNsQixRQUFRLE9BQU8sWUFBWSxDQUFDO0lBQzVCLFFBQVEsUUFBUSxLQUFLO0dBQ3ZCO0dBQ0EsT0FBTyxNQUFNO0VBQ2Y7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxTQUFTLElBQUksS0FBSyxPQUFPO0VBQ3ZCLFFBQVEsUUFBUTtHQUFFO0dBQUs7RUFBTSxDQUFDO0VBQzlCLElBQUksUUFBUSxTQUFTLFNBQ25CLFFBQVEsSUFBSTtDQUVoQjtDQUNBLFNBQVMsa0JBQWtCLE9BQU8scUJBQXFCO0VBQ3JELE1BQU0saUJBQWlCO0VBQ3ZCLE1BQU0sRUFBRSxXQUFXO0VBQ25CLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxRQUFRLEtBQUs7R0FDL0IsTUFBTSxRQUFRLGVBQWU7R0FDN0IsSUFBSSxvQkFBb0IsTUFBTSxPQUFPLEtBQUssR0FDeEMsT0FBTztFQUVYO0NBRUY7Q0FDQSxTQUFTLFFBQVE7RUFDZixVQUFVLENBQUM7Q0FDYjtDQUNBLE9BQU87RUFBRTtFQUFLO0VBQUs7RUFBbUI7Q0FBTTtBQUM5QztBQUNBLElBQUksMEJBQTBCLEdBQUcsTUFBTSxNQUFNO0FBQzdDLFNBQVMseUJBQXlCLGVBQWU7Q0FDL0MsT0FBTyxTQUFTLDJCQUEyQixNQUFNLE1BQU07RUFDckQsSUFBSSxTQUFTLFFBQVEsU0FBUyxRQUFRLEtBQUssV0FBVyxLQUFLLFFBQ3pELE9BQU87RUFFVCxNQUFNLEVBQUUsV0FBVztFQUNuQixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksUUFBUSxLQUMxQixJQUFJLENBQUMsY0FBYyxLQUFLLElBQUksS0FBSyxFQUFFLEdBQ2pDLE9BQU87RUFHWCxPQUFPO0NBQ1Q7QUFDRjtBQUNBLFNBQVMsV0FBVyxNQUFNLHdCQUF3QjtDQUVoRCxNQUFNLEVBQ0osZ0JBQWdCLHdCQUNoQixVQUFVLEdBQ1Ysd0JBSnNCLE9BQU8sMkJBQTJCLFdBQVcseUJBQXlCLEVBQUUsZUFBZSx1QkFBdUI7Q0FNdEksTUFBTSxhQUFhLHlCQUF5QixhQUFhO0NBQ3pELElBQUksZUFBZTtDQUNuQixNQUFNLFFBQVEsV0FBVyxJQUFJLHFCQUFxQixVQUFVLElBQUksZUFBZSxTQUFTLFVBQVU7Q0FDbEcsU0FBUyxXQUFXO0VBQ2xCLElBQUksUUFBUSxNQUFNLElBQUksU0FBUztFQUMvQixJQUFJLFVBQVUsV0FBVztHQUN2QixRQUFRLEtBQUssTUFBTSxNQUFNLFNBQVM7R0FDbEM7R0FDQSxJQUFJLHFCQUFxQjtJQUN2QixNQUFNLGdCQUFnQixNQUFNLGtCQUMxQixPQUNBLG1CQUNGO0lBQ0EsSUFBSSxlQUFlO0tBQ2pCLFFBQVEsY0FBYztLQUN0QixpQkFBaUIsS0FBSztJQUN4QjtHQUNGO0dBQ0EsTUFBTSxJQUFJLFdBQVcsS0FBSztFQUM1QjtFQUNBLE9BQU87Q0FDVDtDQUNBLFNBQVMsbUJBQW1CO0VBQzFCLE1BQU0sTUFBTTtFQUNaLFNBQVMsa0JBQWtCO0NBQzdCO0NBQ0EsU0FBUyxxQkFBcUI7Q0FDOUIsU0FBUywwQkFBMEI7RUFDakMsZUFBZTtDQUNqQjtDQUNBLE9BQU87QUFDVDs7O0FDOWdCQSxTQUFTLHNCQUFzQixlQUFlO0NBQzVDLE1BQU0sY0FBYyxFQUFFLFVBQVUsZ0JBQWdCLFVBQVUsV0FBVztFQUNuRSxJQUFJLE9BQU8sV0FBVyxZQUNwQixPQUFPLE9BQU8sVUFBVSxVQUFVLGFBQWE7RUFFakQsT0FBTyxLQUFLLE1BQU07Q0FDcEI7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFJLFFBQVEsc0JBQXNCO0FBQ2xDLElBQUksb0JBQW9COzs7QUNMeEIsSUFBTSxrQ0FBa0MsR0FBRyxTQUFTO0NBQ25ELE1BQU0saUJBQWlCLHNCQUFzQixHQUFHLElBQUk7Q0FDcEQsTUFBTSwwQkFBMEIsT0FBTyxRQUFRLEdBQUcsU0FBUztFQUMxRCxNQUFNLFdBQVcsZUFBZSxHQUFHLElBQUk7RUFDdkMsTUFBTSxtQkFBbUIsT0FBTyxHQUFHLFNBQVMsU0FBUyxRQUFRLEtBQUssSUFBSSxRQUFRLEtBQUssSUFBSSxPQUFPLEdBQUcsSUFBSTtFQUNyRyxPQUFPLE9BQU8saUJBQWlCLFFBQVE7RUFDdkMsT0FBTztDQUNSLEdBQUcsRUFBRSxpQkFBaUIsd0JBQXdCLENBQUM7Q0FDL0MsT0FBTztBQUNSO0FBQ0EsSUFBTSwwQkFBMEMsK0NBQStCLGNBQWM7QUFHN0YsSUFBTSxzQkFBc0IsT0FBTyxXQUFXLGVBQWUsT0FBTyx1Q0FBdUMsT0FBTyx1Q0FBdUMsV0FBVztDQUNuSyxJQUFJLFVBQVUsV0FBVyxHQUFHLE9BQU8sS0FBSztDQUN4QyxJQUFJLE9BQU8sVUFBVSxPQUFPLFVBQVUsT0FBTztDQUM3QyxPQUFPLFFBQVEsTUFBTSxNQUFNLFNBQVM7QUFDckM7QUFDQSxPQUFPLFdBQVcsZUFBZSxPQUFPLGdDQUFnQyxPQUFPO0FBRy9FLElBQU0sb0JBQW9CLE1BQU07Q0FDL0IsT0FBTyxLQUFLLE9BQU8sRUFBRSxVQUFVO0FBQ2hDO0FBR0EsU0FBUyxhQUFhLE1BQU0sZUFBZTtDQUMxQyxTQUFTLGNBQWMsR0FBRyxNQUFNO0VBQy9CLElBQUksZUFBZTtHQUNsQixJQUFJLFdBQVcsY0FBYyxHQUFHLElBQUk7R0FDcEMsSUFBSSxDQUFDLFVBQVUsTUFBTSxJQUFJLE1BQTBFLHdDQUF3QztHQUMzSSxPQUFPO0lBQ047SUFDQSxTQUFTLFNBQVM7SUFDbEIsR0FBRyxVQUFVLFlBQVksRUFBRSxNQUFNLFNBQVMsS0FBSztJQUMvQyxHQUFHLFdBQVcsWUFBWSxFQUFFLE9BQU8sU0FBUyxNQUFNO0dBQ25EO0VBQ0Q7RUFDQSxPQUFPO0dBQ047R0FDQSxTQUFTLEtBQUs7RUFDZjtDQUNEO0NBQ0EsY0FBYyxpQkFBaUIsR0FBRztDQUNsQyxjQUFjLE9BQU87Q0FDckIsY0FBYyxTQUFTLFdBQVcsU0FBUyxNQUFNLEtBQUssT0FBTyxTQUFTO0NBQ3RFLE9BQU87QUFDUjtBQUNBLFNBQVMsZ0JBQWdCLFFBQVE7Q0FDaEMsT0FBTyxPQUFPLFdBQVcsY0FBYyxVQUFVLFVBQVUsaUJBQWlCLE1BQU07QUFDbkY7QUFDQSxTQUFTLE1BQU0sUUFBUTtDQUN0QixPQUFPLFNBQVMsTUFBTSxLQUFLLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxNQUFNLFVBQVU7QUFDaEU7QUFDQSxTQUFTLFdBQVcsS0FBSztDQUN4QixPQUFPO0VBQ047RUFDQTtFQUNBO0VBQ0E7Q0FDRCxDQUFDLENBQUMsUUFBUSxHQUFHLElBQUk7QUFDbEI7QUFHQSxTQUFTLFdBQVcsTUFBTTtDQUN6QixNQUFNLFlBQVksT0FBTyxHQUFHLE9BQU8sTUFBTSxHQUFHLElBQUksQ0FBQztDQUNqRCxNQUFNLGFBQWEsVUFBVSxVQUFVLFNBQVMsTUFBTTtDQUN0RCxPQUFPLHlDQUF5QyxRQUFRLFVBQVU7a0ZBQ2UsV0FBVyw4QkFBOEIsV0FBVztBQUN0STtBQUNBLFNBQVMsdUNBQXVDLFVBQVUsQ0FBQyxHQUFHO0NBRTdELE1BQU0sRUFBRSxpQkFBaUIsb0JBQW9CLG9CQUFvQjtDQUNqRSxjQUFjLFVBQVUsV0FBVztFQUNsQyxJQUFJLGtCQUFrQixNQUFNLEdBQUcsUUFBUSxLQUFLLFdBQVcsT0FBTyxJQUFJLENBQUM7RUFDbkUsT0FBTyxLQUFLLE1BQU07Q0FDbkI7QUFDRDtBQUdBLFNBQVMsb0JBQW9CLFVBQVUsUUFBUTtDQUM5QyxJQUFJLFVBQVU7Q0FDZCxPQUFPO0VBQ04sWUFBWSxJQUFJO0dBQ2YsTUFBTSxVQUFVLEtBQUssSUFBSTtHQUN6QixJQUFJO0lBQ0gsT0FBTyxHQUFHO0dBQ1gsVUFBVTtJQUNULFdBQVcsS0FBSyxJQUFJLElBQUk7R0FDekI7RUFDRDtFQUNBLGlCQUFpQjtHQUNoQixJQUFJLFVBQVUsVUFBVSxRQUFRLEtBQUssR0FBRyxPQUFPLFFBQVEsUUFBUSxrREFBa0QsU0FBUzs7NEVBRWpEO0VBQzFFO0NBQ0Q7QUFDRDtBQUNBLElBQUksUUFBUSxNQUFNLGNBQWMsTUFBTTtDQUNyQyxZQUFZLEdBQUcsT0FBTztFQUNyQixNQUFNLEdBQUcsS0FBSztFQUNkLE9BQU8sZUFBZSxNQUFNLE1BQU0sU0FBUztDQUM1QztDQUNBLFlBQVksT0FBTyxXQUFXO0VBQzdCLE9BQU87Q0FDUjtDQUNBLE9BQU8sR0FBRyxLQUFLO0VBQ2QsT0FBTyxNQUFNLE9BQU8sTUFBTSxNQUFNLEdBQUc7Q0FDcEM7Q0FDQSxRQUFRLEdBQUcsS0FBSztFQUNmLElBQUksSUFBSSxXQUFXLEtBQUssTUFBTSxRQUFRLElBQUksRUFBRSxHQUFHLE9BQU8sSUFBSSxNQUFNLEdBQUcsSUFBSSxFQUFFLENBQUMsT0FBTyxJQUFJLENBQUM7RUFDdEYsT0FBTyxJQUFJLE1BQU0sR0FBRyxJQUFJLE9BQU8sSUFBSSxDQUFDO0NBQ3JDO0FBQ0Q7QUFDQSxTQUFTLGdCQUFnQixLQUFLO0NBQzdCLE9BQU8sWUFBWSxHQUFHLElBQUlDLFFBQWdCLFdBQVcsQ0FBQyxDQUFDLElBQUk7QUFDNUQ7QUFDQSxTQUFTLG9CQUFvQixLQUFLLEtBQUssU0FBUztDQUMvQyxJQUFJLElBQUksSUFBSSxHQUFHLEdBQUcsT0FBTyxJQUFJLElBQUksR0FBRztDQUNwQyxPQUFPLElBQUksSUFBSSxLQUFLLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxJQUFJLEdBQUc7QUFDMUM7QUFHQSxTQUFTLG1CQUFtQixPQUFPO0NBQ2xDLE9BQU8sT0FBTyxVQUFVLFlBQVksU0FBUyxRQUFRLE9BQU8sU0FBUyxLQUFLO0FBQzNFO0FBQ0EsU0FBUyxrQkFBa0IsYUFBYSxjQUFjLEtBQUs7Q0FDMUQsTUFBTSxvQkFBb0IsZ0JBQWdCLGFBQWEsY0FBYyxHQUFHO0NBQ3hFLE9BQU8sRUFBRSxrQkFBa0I7RUFDMUIsT0FBTyxnQkFBZ0IsYUFBYSxjQUFjLG1CQUFtQixHQUFHO0NBQ3pFLEVBQUU7QUFDSDtBQUNBLFNBQVMsZ0JBQWdCLGFBQWEsZUFBZSxDQUFDLEdBQUcsS0FBSyxPQUFPLElBQUksNkJBQTZCLElBQUksSUFBSSxHQUFHO0NBQ2hILE1BQU0sVUFBVSxFQUFFLE9BQU8sSUFBSTtDQUM3QixJQUFJLENBQUMsWUFBWSxHQUFHLEdBQUc7RUFDdEIsTUFBTSxvQkFBb0IsV0FBVyxJQUFJLEdBQUc7RUFDNUMsSUFBSSxtQkFBbUIsT0FBTztFQUM5QixRQUFRLFdBQVcsQ0FBQztFQUNwQixXQUFXLElBQUksS0FBSyxPQUFPO0VBQzNCLE1BQU0sa0JBQWtCLGFBQWEsU0FBUztFQUM5QyxLQUFLLE1BQU0sT0FBTyxLQUFLO0dBQ3RCLE1BQU0sYUFBYSxPQUFPLE9BQU8sTUFBTSxNQUFNO0dBQzdDLElBQUksaUJBQ0M7UUFBQSxhQUFhLE1BQU0sWUFBWTtLQUNsQyxJQUFJLG1CQUFtQixRQUFRLE9BQU8sUUFBUSxLQUFLLFVBQVU7S0FDN0QsT0FBTyxlQUFlO0lBQ3ZCLENBQUMsR0FBRztHQUFBO0dBRUwsUUFBUSxTQUFTLE9BQU8sZ0JBQWdCLGFBQWEsY0FBYyxJQUFJLE1BQU0sWUFBWSxVQUFVO0VBQ3BHO0VBQ0EsV0FBVyxPQUFPLEdBQUc7Q0FDdEI7Q0FDQSxPQUFPO0FBQ1I7QUFDQSxTQUFTLGdCQUFnQixhQUFhLGVBQWUsQ0FBQyxHQUFHLGlCQUFpQixLQUFLLGdCQUFnQixPQUFPLE9BQU8sSUFBSSx1QkFBdUIsSUFBSSxJQUFJLEdBQUc7Q0FDbEosTUFBTSxVQUFVLGtCQUFrQixnQkFBZ0IsUUFBUSxLQUFLO0NBQy9ELE1BQU0sVUFBVSxZQUFZO0NBQzVCLElBQUksaUJBQWlCLENBQUMsV0FBVyxDQUFDLE9BQU8sTUFBTSxHQUFHLEdBQUcsT0FBTztFQUMzRCxZQUFZO0VBQ1o7Q0FDRDtDQUNBLElBQUksWUFBWSxPQUFPLEtBQUssWUFBWSxHQUFHLEdBQUcsT0FBTyxFQUFFLFlBQVksTUFBTTtDQUN6RSxJQUFJLGFBQWEsS0FBSyxJQUFJLGVBQWU7Q0FDekMsSUFBSSxDQUFDLFlBQVk7RUFDaEIsNkJBQTZCLElBQUksSUFBSTtFQUNyQyxLQUFLLElBQUksaUJBQWlCLFVBQVU7Q0FDckMsT0FBTyxJQUFJLFdBQVcsSUFBSSxHQUFHLEdBQUcsT0FBTyxFQUFFLFlBQVksTUFBTTtDQUMzRCxXQUFXLElBQUksR0FBRztDQUNsQixNQUFNLGVBQWUsQ0FBQztDQUN0QixLQUFLLElBQUksT0FBTyxnQkFBZ0IsVUFBVSxhQUFhLE9BQU87Q0FDOUQsS0FBSyxJQUFJLE9BQU8sS0FBSyxhQUFhLE9BQU87Q0FDekMsTUFBTSxrQkFBa0IsYUFBYSxTQUFTO0NBQzlDLEtBQUssSUFBSSxPQUFPLGNBQWM7RUFDN0IsTUFBTSxhQUFhLE9BQU8sT0FBTyxNQUFNLE1BQU07RUFDN0MsSUFBSSxpQkFDQztPQUFBLGFBQWEsTUFBTSxZQUFZO0lBQ2xDLElBQUksbUJBQW1CLFFBQVEsT0FBTyxRQUFRLEtBQUssVUFBVTtJQUM3RCxPQUFPLGVBQWU7R0FDdkIsQ0FBQyxHQUFHO0VBQUE7RUFFTCxNQUFNLFNBQVMsZ0JBQWdCLGFBQWEsY0FBYyxnQkFBZ0IsU0FBUyxNQUFNLElBQUksTUFBTSxTQUFTLFlBQVksSUFBSTtFQUM1SCxJQUFJLE9BQU8sWUFBWSxPQUFPO0NBQy9CO0NBQ0EsT0FBTyxFQUFFLFlBQVksTUFBTTtBQUM1QjtBQUNBLFNBQVMsd0NBQXdDLFVBQVUsQ0FBQyxHQUFHO0NBRXpEO0VBQ0osU0FBUyxVQUFVLEtBQUssWUFBWSxRQUFRLFVBQVU7R0FDckQsT0FBTyxLQUFLLFVBQVUsS0FBSyxhQUFhLFlBQVksUUFBUSxHQUFHLE1BQU07RUFDdEU7RUFDQSxTQUFTLGFBQWEsWUFBWSxVQUFVO0dBQzNDLElBQUksUUFBUSxDQUFDLEdBQUcsT0FBTyxDQUFDO0dBQ3hCLElBQUksQ0FBQyxVQUFVLFdBQVcsU0FBUyxHQUFHLE9BQU87SUFDNUMsSUFBSSxNQUFNLE9BQU8sT0FBTyxPQUFPO0lBQy9CLE9BQU8saUJBQWlCLEtBQUssTUFBTSxHQUFHLE1BQU0sUUFBUSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxJQUFJO0dBQ3pFO0dBQ0EsT0FBTyxTQUFTLEtBQUssT0FBTztJQUMzQixJQUFJLE1BQU0sU0FBUyxHQUFHO0tBQ3JCLElBQUksVUFBVSxNQUFNLFFBQVEsSUFBSTtLQUNoQyxJQUFJLENBQUMsU0FBUztNQUNiLE1BQU0sT0FBTyxVQUFVLENBQUM7TUFDeEIsS0FBSyxPQUFPLFNBQVMsVUFBVSxHQUFHO0tBQ25DLE9BQU87TUFDTixNQUFNLEtBQUssSUFBSTtNQUNmLEtBQUssS0FBSyxHQUFHO0tBQ2Q7S0FDQSxJQUFJLENBQUMsTUFBTSxRQUFRLEtBQUssR0FBRyxRQUFRLFNBQVMsS0FBSyxNQUFNLEtBQUssS0FBSztJQUNsRSxPQUFPLE1BQU0sS0FBSyxLQUFLO0lBQ3ZCLE9BQU8sY0FBYyxPQUFPLFFBQVEsV0FBVyxLQUFLLE1BQU0sS0FBSyxLQUFLO0dBQ3JFO0VBQ0Q7RUFDQSxJQUFJLEVBQUUsY0FBYyxvQkFBb0IsY0FBYyxZQUFZLE9BQU87RUFDekUsTUFBTSxRQUFRLGtCQUFrQixLQUFLLE1BQU0sYUFBYSxZQUFZO0VBQ3BFLFFBQVEsRUFBRSxlQUFlO0dBQ3hCLElBQUksUUFBUSxTQUFTO0dBQ3JCLElBQUksVUFBVSxNQUFNLEtBQUs7R0FDekIsSUFBSTtHQUNKLFFBQVEsVUFBVSxXQUFXO0lBQzVCLE1BQU0sZUFBZSxvQkFBb0IsV0FBVyxtQ0FBbUM7SUFDdkYsYUFBYSxrQkFBa0I7S0FDOUIsUUFBUSxTQUFTO0tBQ2pCLFNBQVMsUUFBUSxnQkFBZ0I7S0FDakMsVUFBVSxNQUFNLEtBQUs7S0FDckIsSUFBSSxPQUFPLFlBQVksTUFBTSxJQUFJLE1BQTJFLGtFQUFrRSxPQUFPLFFBQVEsR0FBRywwR0FBMEc7SUFDM1MsQ0FBQztJQUNELE1BQU0sbUJBQW1CLEtBQUssTUFBTTtJQUNwQyxhQUFhLGtCQUFrQjtLQUM5QixRQUFRLFNBQVM7S0FDakIsU0FBUyxRQUFRLGdCQUFnQjtLQUNqQyxVQUFVLE1BQU0sS0FBSztLQUNyQixJQUFJLE9BQU8sWUFBWSxNQUFNLElBQUksTUFBMkUsaUVBQWlFLE9BQU8sUUFBUSxHQUFHLHNEQUFzRCxVQUFVLE1BQU0sRUFBRSxxRUFBcUU7SUFDN1UsQ0FBQztJQUNELGFBQWEsZUFBZTtJQUM1QixPQUFPO0dBQ1I7RUFDRDtDQUNEO0FBQ0Q7QUFHQSxTQUFTLFFBQVEsS0FBSztDQUNyQixNQUFNLE9BQU8sT0FBTztDQUNwQixPQUFPLE9BQU8sUUFBUSxTQUFTLFlBQVksU0FBUyxhQUFhLFNBQVMsWUFBWSxNQUFNLFFBQVEsR0FBRyxLQUFLLGNBQWMsR0FBRztBQUM5SDtBQUNBLFNBQVMseUJBQXlCLE9BQU8sT0FBTyxJQUFJLGlCQUFpQixTQUFTLFlBQVksZUFBZSxDQUFDLEdBQUcsT0FBTztDQUNuSCxJQUFJO0NBQ0osSUFBSSxDQUFDLGVBQWUsS0FBSyxHQUFHLE9BQU87RUFDbEMsU0FBUyxRQUFRO0VBQ2pCO0NBQ0Q7Q0FDQSxJQUFJLE9BQU8sVUFBVSxZQUFZLFVBQVUsTUFBTSxPQUFPO0NBQ3hELElBQUksT0FBTyxJQUFJLEtBQUssR0FBRyxPQUFPO0NBQzlCLE1BQU0sVUFBVSxjQUFjLE9BQU8sV0FBVyxLQUFLLElBQUksT0FBTyxRQUFRLEtBQUs7Q0FDN0UsTUFBTSxrQkFBa0IsYUFBYSxTQUFTO0NBQzlDLEtBQUssTUFBTSxDQUFDLEtBQUssZ0JBQWdCLFNBQVM7RUFDekMsTUFBTSxhQUFhLE9BQU8sT0FBTyxNQUFNLE1BQU07RUFDN0MsSUFBSSxpQkFDQztPQUFBLGFBQWEsTUFBTSxZQUFZO0lBQ2xDLElBQUksbUJBQW1CLFFBQVEsT0FBTyxRQUFRLEtBQUssVUFBVTtJQUM3RCxPQUFPLGVBQWU7R0FDdkIsQ0FBQyxHQUFHO0VBQUE7RUFFTCxJQUFJLENBQUMsZUFBZSxXQUFXLEdBQUcsT0FBTztHQUN4QyxTQUFTO0dBQ1QsT0FBTztFQUNSO0VBQ0EsSUFBSSxPQUFPLGdCQUFnQixVQUFVO0dBQ3BDLDBCQUEwQix5QkFBeUIsYUFBYSxZQUFZLGdCQUFnQixZQUFZLGNBQWMsS0FBSztHQUMzSCxJQUFJLHlCQUF5QixPQUFPO0VBQ3JDO0NBQ0Q7Q0FDQSxJQUFJLFNBQVMsZUFBZSxLQUFLLEdBQUcsTUFBTSxJQUFJLEtBQUs7Q0FDbkQsT0FBTztBQUNSO0FBQ0EsU0FBUyxlQUFlLE9BQU87Q0FDOUIsSUFBSSxDQUFDLE9BQU8sU0FBUyxLQUFLLEdBQUcsT0FBTztDQUNwQyxLQUFLLE1BQU0sZUFBZSxPQUFPLE9BQU8sS0FBSyxHQUFHO0VBQy9DLElBQUksT0FBTyxnQkFBZ0IsWUFBWSxnQkFBZ0IsTUFBTTtFQUM3RCxJQUFJLENBQUMsZUFBZSxXQUFXLEdBQUcsT0FBTztDQUMxQztDQUNBLE9BQU87QUFDUjtBQUNBLFNBQVMsMkNBQTJDLFVBQVUsQ0FBQyxHQUFHO0NBRTVEO0VBQ0osTUFBTSxFQUFFLGlCQUFpQixTQUFTLFlBQVksaUJBQWlCLENBQUMsR0FBRyxxQkFBcUIsQ0FBQyxZQUFZLG9CQUFvQixHQUFHLGVBQWUsQ0FBQyxHQUFHLFlBQVksSUFBSSxjQUFjLE9BQU8sZ0JBQWdCLE9BQU8sZUFBZSxVQUFVO0VBQ3BPLE1BQU0sUUFBUSxDQUFDLGdCQUFnQiwwQkFBMEIsSUFBSSxRQUFRLElBQUksS0FBSztFQUM5RSxRQUFRLGNBQWMsVUFBVSxXQUFXO0dBQzFDLElBQUksQ0FBQyxTQUFTLE1BQU0sR0FBRyxPQUFPLEtBQUssTUFBTTtHQUN6QyxNQUFNLFNBQVMsS0FBSyxNQUFNO0dBQzFCLE1BQU0sZUFBZSxvQkFBb0IsV0FBVyxzQ0FBc0M7R0FDMUYsSUFBSSxDQUFDLGlCQUFpQixFQUFFLGVBQWUsVUFBVSxlQUFlLFFBQVEsT0FBTyxJQUFJLE1BQU0sS0FBSyxhQUFhLGtCQUFrQjtJQUM1SCxNQUFNLGtDQUFrQyx5QkFBeUIsUUFBUSxJQUFJLGdCQUFnQixZQUFZLG9CQUFvQixLQUFLO0lBQ2xJLElBQUksaUNBQWlDO0tBQ3BDLE1BQU0sRUFBRSxTQUFTLFVBQVU7S0FDM0IsUUFBUSxNQUFNLHNFQUFzRSxRQUFRLGFBQWEsT0FBTyw0REFBNEQsUUFBUSxnSEFBZ0gsNkhBQTZIO0lBQ2xhO0dBQ0QsQ0FBQztHQUNELElBQUksQ0FBQyxhQUFhO0lBQ2pCLGFBQWEsa0JBQWtCO0tBQzlCLE1BQU0saUNBQWlDLHlCQUF5QixTQUFTLFNBQVMsR0FBRyxJQUFJLGdCQUFnQixZQUFZLGNBQWMsS0FBSztLQUN4SSxJQUFJLGdDQUFnQztNQUNuQyxNQUFNLEVBQUUsU0FBUyxVQUFVO01BQzNCLFFBQVEsTUFBTSxzRUFBc0UsUUFBUSxhQUFhLE9BQU87MkRBQzNELE9BQU8sS0FBSzsrSEFDd0Q7S0FDMUg7SUFDRCxDQUFDO0lBQ0QsYUFBYSxlQUFlO0dBQzdCO0dBQ0EsT0FBTztFQUNSO0NBQ0Q7QUFDRDtBQUdBLFNBQVMsVUFBVSxHQUFHO0NBQ3JCLE9BQU8sT0FBTyxNQUFNO0FBQ3JCO0FBQ0EsSUFBTSxrQ0FBa0MsU0FBUyxxQkFBcUIsU0FBUztDQUM5RSxNQUFNLEVBQUUsT0FBTyxVQUFVLE1BQU0saUJBQWlCLE1BQU0sb0JBQW9CLE1BQU0scUJBQXFCLFNBQVMsV0FBVyxDQUFDO0NBQzFILElBQUksa0JBQWtCLElBQUksTUFBTTtDQUNoQyxJQUFJLFNBQVM7RUFDWixJQUFJLFVBQVUsT0FBTyxHQUFHLGdCQUFnQixLQUFLLEtBQUs7T0FDN0MsZ0JBQWdCLEtBQUssa0JBQWtCLFFBQVEsYUFBYSxDQUFDO0NBQ25FO0NBRUMsSUFBSSxnQkFBZ0I7RUFDbkIsSUFBSSxtQkFBbUIsQ0FBQztFQUN4QixJQUFJLENBQUMsVUFBVSxjQUFjLEdBQUcsbUJBQW1CO0VBQ25ELGdCQUFnQixRQUFRLHdDQUF3QyxnQkFBZ0IsQ0FBQztDQUNsRjtDQUNBLElBQUksbUJBQW1CO0VBQ3RCLElBQUksc0JBQXNCLENBQUM7RUFDM0IsSUFBSSxDQUFDLFVBQVUsaUJBQWlCLEdBQUcsc0JBQXNCO0VBQ3pELGdCQUFnQixLQUFLLDJDQUEyQyxtQkFBbUIsQ0FBQztDQUNyRjtDQUNBLElBQUksb0JBQW9CO0VBQ3ZCLElBQUksdUJBQXVCLENBQUM7RUFDNUIsSUFBSSxDQUFDLFVBQVUsa0JBQWtCLEdBQUcsdUJBQXVCO0VBQzNELGdCQUFnQixRQUFRLHVDQUF1QyxvQkFBb0IsQ0FBQztDQUNyRjtDQUVELE9BQU87QUFDUjtBQUdBLElBQU0sbUJBQW1CO0FBQ3pCLElBQU0sNEJBQTRCLGFBQWE7Q0FDOUM7Q0FDQSxNQUFNLEdBQUcsbUJBQW1CLEtBQUs7QUFDbEM7QUFDQSxJQUFNLHdCQUF3QixZQUFZO0NBQ3pDLFFBQVEsV0FBVztFQUNsQixXQUFXLFFBQVEsT0FBTztDQUMzQjtBQUNEO0FBQ0EsSUFBTSw4QkFBOEIsS0FBSyxZQUFZO0NBQ3BELFFBQVEsV0FBVztFQUNsQixJQUFJLFNBQVM7RUFDYixJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0saUJBQWlCO0dBQ3RCLElBQUksUUFBUTtHQUNaLFNBQVM7R0FDVCxxQkFBcUIsS0FBSztHQUMxQixhQUFhLE9BQU87R0FDcEIsT0FBTztFQUNSO0VBQ0EsUUFBUSxJQUFJLFFBQVE7RUFDcEIsVUFBVSxXQUFXLFVBQVUsT0FBTztDQUN2QztBQUNEO0FBQ0EsSUFBTSxxQkFBcUIsVUFBVSxFQUFFLE1BQU0sTUFBTSxPQUFPLFVBQVUsR0FBRyxTQUFTO0NBQy9FLE1BQU0sUUFBUSxLQUFLLEdBQUcsSUFBSTtDQUMxQixJQUFJLFlBQVk7Q0FDaEIsSUFBSSwwQkFBMEI7Q0FDOUIsSUFBSSxxQkFBcUI7Q0FDekIsTUFBTSw0QkFBNEIsSUFBSSxJQUFJO0NBQzFDLE1BQU0sZ0JBQWdCLFFBQVEsU0FBUyxTQUFTLGlCQUFpQixRQUFRLFNBQVMsUUFBUSxPQUFPLFdBQVcsZUFBZSxPQUFPLHdCQUF3QiwyQkFBMkIsT0FBTyx1QkFBdUIsR0FBRyxJQUFJLHFCQUFxQixFQUFFLElBQUksUUFBUSxTQUFTLGFBQWEsUUFBUSxvQkFBb0IscUJBQXFCLFFBQVEsT0FBTztDQUNuVixNQUFNLHdCQUF3QjtFQUM3QixxQkFBcUI7RUFDckIsSUFBSSx5QkFBeUI7R0FDNUIsMEJBQTBCO0dBQzFCLFVBQVUsU0FBUyxNQUFNLEVBQUUsQ0FBQztFQUM3QjtDQUNEO0NBQ0EsT0FBTyxPQUFPLE9BQU8sQ0FBQyxHQUFHLE9BQU87RUFDL0IsVUFBVSxVQUFVO0dBQ25CLE1BQU0sd0JBQXdCLGFBQWEsU0FBUztHQUNwRCxNQUFNLGNBQWMsTUFBTSxVQUFVLGVBQWU7R0FDbkQsVUFBVSxJQUFJLFFBQVE7R0FDdEIsYUFBYTtJQUNaLFlBQVk7SUFDWixVQUFVLE9BQU8sUUFBUTtHQUMxQjtFQUNEO0VBQ0EsU0FBUyxRQUFRO0dBQ2hCLElBQUk7SUFDSCxZQUFZLENBQUMsUUFBUSxPQUFPO0lBQzVCLDBCQUEwQixDQUFDO0lBQzNCLElBQUkseUJBQ0M7U0FBQSxDQUFDLG9CQUFvQjtNQUN4QixxQkFBcUI7TUFDckIsY0FBYyxlQUFlO0tBQzlCOztJQUVELE9BQU8sTUFBTSxTQUFTLE1BQU07R0FDN0IsVUFBVTtJQUNULFlBQVk7R0FDYjtFQUNEO0NBQ0QsQ0FBQztBQUNGO0FBR0EsSUFBTSw0QkFBNEIsdUJBQXVCLFNBQVMsb0JBQW9CLFNBQVM7Q0FDOUYsTUFBTSxFQUFFLFlBQVksU0FBUyxXQUFXLENBQUM7Q0FDekMsSUFBSSxnQkFBZ0IsSUFBSSxNQUFNLGtCQUFrQjtDQUNoRCxJQUFJLFdBQVcsY0FBYyxLQUFLLGtCQUFrQixPQUFPLGNBQWMsV0FBVyxZQUFZLEtBQUssQ0FBQyxDQUFDO0NBQ3ZHLE9BQU87QUFDUjtBQUdBLFNBQVMsZUFBZSxTQUFTO0NBQ2hDLE1BQU0sdUJBQXVCLDBCQUEwQjtDQUN2RCxNQUFNLEVBQUUsVUFBVSxLQUFLLEdBQUcsWUFBWSxXQUFXLE1BQU0sMkJBQTJCLE1BQU0saUJBQWlCLEtBQUssR0FBRyxZQUFZLEtBQUssTUFBTSxXQUFXLENBQUM7Q0FDcEosSUFBSTtDQUNKLElBQUksT0FBTyxZQUFZLFlBQVksY0FBYztNQUM1QyxJQUFJLGNBQWMsT0FBTyxHQUFHLGNBQWNDLGdCQUFrQixPQUFPO01BQ25FLE1BQU0sSUFBSSxNQUEwRSwwSEFBMEg7Q0FDbk4sSUFBNkMsY0FBYyxPQUFPLGVBQWUsWUFBWSxNQUFNLElBQUksTUFBMEUsdUNBQXVDO0NBQ3hOLElBQUk7Q0FDSixJQUFJLE9BQU8sZUFBZSxZQUFZO0VBQ3JDLGtCQUFrQixXQUFXLG9CQUFvQjtFQUNqRCxJQUE2QyxDQUFDLE1BQU0sUUFBUSxlQUFlLEdBQUcsTUFBTSxJQUFJLE1BQTBFLG1GQUFtRjtDQUN0UCxPQUFPLGtCQUFrQixxQkFBcUI7Q0FDOUMsSUFBNkMsZ0JBQWdCLE1BQU0sU0FBUyxPQUFPLFNBQVMsVUFBVSxHQUFHLE1BQU0sSUFBSSxNQUEwRSwrREFBK0Q7Q0FDNVAsSUFBNkMsMEJBQTBCO0VBQ3RFLElBQUksdUNBQXVDLElBQUksSUFBSTtFQUNuRCxnQkFBZ0IsU0FBUyxlQUFlO0dBQ3ZDLElBQUkscUJBQXFCLElBQUksVUFBVSxHQUFHLE1BQU0sSUFBSSxNQUEyRSxtSEFBbUg7R0FDbFAscUJBQXFCLElBQUksVUFBVTtFQUNwQyxDQUFDO0NBQ0Y7Q0FDQSxJQUFJLGVBQWU7Q0FDbkIsSUFBSSxVQUFVLGVBQWUsb0JBQW9CO0VBQ2hELE9BQU87RUFDUCxHQUFHLE9BQU8sYUFBYSxZQUFZO0NBQ3BDLENBQUM7Q0FDRCxNQUFNLHFCQUFxQixnQkFBZ0IsR0FBRyxlQUFlO0NBQzdELE1BQU0sc0JBQXNCLHlCQUF5QixrQkFBa0I7Q0FDdkUsSUFBNkMsYUFBYSxPQUFPLGNBQWMsWUFBWSxNQUFNLElBQUksTUFBMEUsc0NBQXNDO0NBQ3JOLElBQUksaUJBQWlCLE9BQU8sY0FBYyxhQUFhLFVBQVUsbUJBQW1CLElBQUksb0JBQW9CO0NBQzVHLElBQTZDLENBQUMsTUFBTSxRQUFRLGNBQWMsR0FBRyxNQUFNLElBQUksTUFBMEUsMkNBQTJDO0NBQzVNLElBQTZDLGVBQWUsTUFBTSxTQUFTLE9BQU8sU0FBUyxVQUFVLEdBQUcsTUFBTSxJQUFJLE1BQTBFLDZEQUE2RDtDQUN6UCxJQUE2QyxnQkFBZ0IsVUFBVSxDQUFDLGVBQWUsU0FBUyxrQkFBa0IsR0FBRyxRQUFRLE1BQU0sa0lBQWtJO0NBQ3JRLE1BQU0sbUJBQW1CLGFBQWEsR0FBRyxjQUFjO0NBQ3ZELE9BQU8sWUFBWSxhQUFhLGdCQUFnQixnQkFBZ0I7QUFDakU7QUFHQSxTQUFTLDhCQUE4QixpQkFBaUI7Q0FDdkQsTUFBTSxhQUFhLENBQUM7Q0FDcEIsTUFBTSxpQkFBaUIsQ0FBQztDQUN4QixJQUFJO0NBQ0osTUFBTSxVQUFVO0VBQ2YsUUFBUSxxQkFBcUIsU0FBUztHQUVwQyxJQUFJLGVBQWUsU0FBUyxHQUFHLE1BQU0sSUFBSSxNQUEyRSw2RUFBNkU7R0FDak0sSUFBSSxvQkFBb0IsTUFBTSxJQUFJLE1BQTJFLGlGQUFpRjtHQUUvTCxNQUFNLE9BQU8sT0FBTyx3QkFBd0IsV0FBVyxzQkFBc0Isb0JBQW9CO0dBQ2pHLElBQUksQ0FBQyxNQUFNLE1BQU0sSUFBSSxNQUEyRSw4REFBOEQ7R0FDOUosSUFBSSxRQUFRLFlBQVksTUFBTSxJQUFJLE1BQTJFLG9GQUFvRixLQUFLLEVBQUU7R0FDeE0sV0FBVyxRQUFRO0dBQ25CLE9BQU87RUFDUjtFQUNBLGNBQWMsWUFBWSxVQUFVO0dBRWxDLElBQUksb0JBQW9CLE1BQU0sSUFBSSxNQUEyRSx1RkFBdUY7R0FFck0sSUFBSSxTQUFTLFNBQVMsV0FBVyxXQUFXLFFBQVEsUUFBUSxTQUFTO0dBQ3JFLElBQUksU0FBUyxVQUFVLFdBQVcsV0FBVyxTQUFTLFFBQVEsU0FBUztHQUN2RSxJQUFJLFNBQVMsV0FBVyxXQUFXLFdBQVcsVUFBVSxRQUFRLFNBQVM7R0FDekUsSUFBSSxTQUFTLFNBQVMsZUFBZSxLQUFLO0lBQ3pDLFNBQVMsV0FBVztJQUNwQixTQUFTLFNBQVM7R0FDbkIsQ0FBQztHQUNELE9BQU87RUFDUjtFQUNBLFdBQVcsU0FBUyxTQUFTO0dBRTNCLElBQUksb0JBQW9CLE1BQU0sSUFBSSxNQUEyRSxvRkFBb0Y7R0FFbE0sZUFBZSxLQUFLO0lBQ25CO0lBQ0E7R0FDRCxDQUFDO0dBQ0QsT0FBTztFQUNSO0VBQ0EsZUFBZSxTQUFTO0dBRXRCLElBQUksb0JBQW9CLE1BQU0sSUFBSSxNQUEyRSxrREFBa0Q7R0FFaEsscUJBQXFCO0dBQ3JCLE9BQU87RUFDUjtDQUNEO0NBQ0EsZ0JBQWdCLE9BQU87Q0FDdkIsT0FBTztFQUNOO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7QUFHQSxTQUFTLGdCQUFnQixHQUFHO0NBQzNCLE9BQU8sT0FBTyxNQUFNO0FBQ3JCO0FBQ0EsU0FBUyxjQUFjLGNBQWMsc0JBQXNCO0NBRXpELElBQUksT0FBTyx5QkFBeUIsVUFBVSxNQUFNLElBQUksTUFBMEUsOEpBQThKO0NBRWpTLElBQUksQ0FBQyxZQUFZLHFCQUFxQiwyQkFBMkIsOEJBQThCLG9CQUFvQjtDQUNuSCxJQUFJO0NBQ0osSUFBSSxnQkFBZ0IsWUFBWSxHQUFHLHdCQUF3QixnQkFBZ0IsYUFBYSxDQUFDO01BQ3BGO0VBQ0osTUFBTSxxQkFBcUIsZ0JBQWdCLFlBQVk7RUFDdkQsd0JBQXdCO0NBQ3pCO0NBQ0EsU0FBUyxRQUFRLFFBQVEsZ0JBQWdCLEdBQUcsUUFBUTtFQUNuRCxJQUFJLGVBQWUsQ0FBQyxXQUFXLE9BQU8sT0FBTyxHQUFHLG9CQUFvQixRQUFRLEVBQUUsY0FBYyxRQUFRLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLGNBQWMsT0FBTyxDQUFDO0VBQzFJLElBQUksYUFBYSxRQUFRLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLFdBQVcsR0FBRyxlQUFlLENBQUMsdUJBQXVCO0VBQzNGLE9BQU8sYUFBYSxRQUFRLGVBQWUsZ0JBQWdCO0dBQzFELElBQUksYUFBYTtJQUNoQixJQUFJLFFBQVEsYUFBYSxHQUFHO0tBQzNCLE1BQU0sU0FBUyxZQUFZLGVBQWUsTUFBTTtLQUNoRCxJQUFJLFdBQVcsS0FBSyxHQUFHLE9BQU87S0FDOUIsT0FBTztJQUNSLE9BQU8sSUFBSSxDQUFDLFlBQVksYUFBYSxHQUFHO0tBQ3ZDLE1BQU0sU0FBUyxZQUFZLGVBQWUsTUFBTTtLQUNoRCxJQUFJLFdBQVcsS0FBSyxHQUFHO01BQ3RCLElBQUksa0JBQWtCLE1BQU0sT0FBTztNQUNuQyxNQUFNLElBQUksTUFBMEUsbUVBQW1FO0tBQ3hKO0tBQ0EsT0FBTztJQUNSLE9BQU8sT0FBT0QsUUFBZ0IsZ0JBQWdCLFVBQVU7S0FDdkQsT0FBTyxZQUFZLE9BQU8sTUFBTTtJQUNqQyxDQUFDO0dBQ0Y7R0FDQSxPQUFPO0VBQ1IsR0FBRyxLQUFLO0NBQ1Q7Q0FDQSxRQUFRLGtCQUFrQjtDQUMxQixPQUFPO0FBQ1I7QUFHQSxJQUFNLFdBQVcsU0FBUyxXQUFXO0NBQ3BDLElBQUksaUJBQWlCLE9BQU8sR0FBRyxPQUFPLFFBQVEsTUFBTSxNQUFNO01BQ3JELE9BQU8sUUFBUSxNQUFNO0FBQzNCO0FBQ0EsU0FBUyxRQUFRLEdBQUcsVUFBVTtDQUM3QixRQUFRLFdBQVc7RUFDbEIsT0FBTyxTQUFTLE1BQU0sWUFBWSxRQUFRLFNBQVMsTUFBTSxDQUFDO0NBQzNEO0FBQ0Q7QUFDQSxTQUFTLFFBQVEsR0FBRyxVQUFVO0NBQzdCLFFBQVEsV0FBVztFQUNsQixPQUFPLFNBQVMsT0FBTyxZQUFZLFFBQVEsU0FBUyxNQUFNLENBQUM7Q0FDNUQ7QUFDRDtBQUNBLFNBQVMsMkJBQTJCLFFBQVEsYUFBYTtDQUN4RCxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sTUFBTSxPQUFPO0NBQ3BDLE1BQU0sb0JBQW9CLE9BQU8sT0FBTyxLQUFLLGNBQWM7Q0FDM0QsTUFBTSx3QkFBd0IsWUFBWSxRQUFRLE9BQU8sS0FBSyxhQUFhLElBQUk7Q0FDL0UsT0FBTyxxQkFBcUI7QUFDN0I7QUFDQSxTQUFTLGtCQUFrQixHQUFHO0NBQzdCLE9BQU8sT0FBTyxFQUFFLE9BQU8sY0FBYyxhQUFhLEVBQUUsTUFBTSxlQUFlLEVBQUUsTUFBTSxjQUFjLEVBQUU7QUFDbEc7QUFDQSxTQUFTLFVBQVUsR0FBRyxhQUFhO0NBQ2xDLElBQUksWUFBWSxXQUFXLEdBQUcsUUFBUSxXQUFXLDJCQUEyQixRQUFRLENBQUMsU0FBUyxDQUFDO0NBQy9GLElBQUksQ0FBQyxrQkFBa0IsV0FBVyxHQUFHLE9BQU8sVUFBVSxDQUFDLENBQUMsWUFBWSxFQUFFO0NBQ3RFLE9BQU8sUUFBUSxHQUFHLFlBQVksS0FBSyxlQUFlLFdBQVcsT0FBTyxDQUFDO0FBQ3RFO0FBQ0EsU0FBUyxXQUFXLEdBQUcsYUFBYTtDQUNuQyxJQUFJLFlBQVksV0FBVyxHQUFHLFFBQVEsV0FBVywyQkFBMkIsUUFBUSxDQUFDLFVBQVUsQ0FBQztDQUNoRyxJQUFJLENBQUMsa0JBQWtCLFdBQVcsR0FBRyxPQUFPLFdBQVcsQ0FBQyxDQUFDLFlBQVksRUFBRTtDQUN2RSxPQUFPLFFBQVEsR0FBRyxZQUFZLEtBQUssZUFBZSxXQUFXLFFBQVEsQ0FBQztBQUN2RTtBQUNBLFNBQVMsb0JBQW9CLEdBQUcsYUFBYTtDQUM1QyxNQUFNLFdBQVcsV0FBVztFQUMzQixPQUFPLFVBQVUsT0FBTyxRQUFRLE9BQU8sS0FBSztDQUM3QztDQUNBLElBQUksWUFBWSxXQUFXLEdBQUcsT0FBTyxRQUFRLFdBQVcsR0FBRyxXQUFXLEdBQUcsT0FBTztDQUNoRixJQUFJLENBQUMsa0JBQWtCLFdBQVcsR0FBRyxPQUFPLG9CQUFvQixDQUFDLENBQUMsWUFBWSxFQUFFO0NBQ2hGLE9BQU8sUUFBUSxXQUFXLEdBQUcsV0FBVyxHQUFHLE9BQU87QUFDbkQ7QUFDQSxTQUFTLFlBQVksR0FBRyxhQUFhO0NBQ3BDLElBQUksWUFBWSxXQUFXLEdBQUcsUUFBUSxXQUFXLDJCQUEyQixRQUFRLENBQUMsV0FBVyxDQUFDO0NBQ2pHLElBQUksQ0FBQyxrQkFBa0IsV0FBVyxHQUFHLE9BQU8sWUFBWSxDQUFDLENBQUMsWUFBWSxFQUFFO0NBQ3hFLE9BQU8sUUFBUSxHQUFHLFlBQVksS0FBSyxlQUFlLFdBQVcsU0FBUyxDQUFDO0FBQ3hFO0FBQ0EsU0FBUyxtQkFBbUIsR0FBRyxhQUFhO0NBQzNDLElBQUksWUFBWSxXQUFXLEdBQUcsUUFBUSxXQUFXLDJCQUEyQixRQUFRO0VBQ25GO0VBQ0E7RUFDQTtDQUNELENBQUM7Q0FDRCxJQUFJLENBQUMsa0JBQWtCLFdBQVcsR0FBRyxPQUFPLG1CQUFtQixDQUFDLENBQUMsWUFBWSxFQUFFO0NBQy9FLE9BQU8sUUFBUSxHQUFHLFlBQVksU0FBUyxlQUFlO0VBQ3JELFdBQVc7RUFDWCxXQUFXO0VBQ1gsV0FBVztDQUNaLENBQUMsQ0FBQztBQUNIO0FBR0EsSUFBSSxjQUFjO0FBQ2xCLElBQUksVUFBVSxPQUFPLE9BQU87Q0FDM0IsSUFBSSxLQUFLO0NBQ1QsSUFBSSxJQUFJO0NBQ1IsT0FBTyxLQUFLLE1BQU0sWUFBWSxLQUFLLE9BQU8sSUFBSSxLQUFLO0NBQ25ELE9BQU87QUFDUjtBQUdBLElBQU0sbUJBQW1CO0NBQ3hCO0NBQ0E7Q0FDQTtDQUNBO0FBQ0Q7QUFDQSxJQUFJLGtCQUFrQixNQUFNO0NBQzNCO0NBQ0E7Q0FDQTtDQUNBLFlBQVksU0FBUyxNQUFNO0VBQzFCLEtBQUssVUFBVTtFQUNmLEtBQUssT0FBTztDQUNiO0FBQ0Q7QUFDQSxJQUFJLGtCQUFrQixNQUFNO0NBQzNCO0NBQ0E7Q0FDQTtDQUNBLFlBQVksU0FBUyxNQUFNO0VBQzFCLEtBQUssVUFBVTtFQUNmLEtBQUssT0FBTztDQUNiO0FBQ0Q7QUFDQSxJQUFNLHNCQUFzQixVQUFVO0NBQ3JDLElBQUksT0FBTyxVQUFVLFlBQVksVUFBVSxNQUFNO0VBQ2hELE1BQU0sY0FBYyxDQUFDO0VBQ3JCLEtBQUssTUFBTSxZQUFZLGtCQUFrQixJQUFJLE9BQU8sTUFBTSxjQUFjLFVBQVUsWUFBWSxZQUFZLE1BQU07RUFDaEgsT0FBTztDQUNSO0NBQ0EsT0FBTyxFQUFFLFNBQVMsT0FBTyxLQUFLLEVBQUU7QUFDakM7QUFDQSxJQUFNLHVCQUF1QjtBQUM3QixJQUFNLG1CQUFtQyx1QkFBTztDQUMvQyxTQUFTLGlCQUFpQixZQUFZLGdCQUFnQixTQUFTO0VBQzlELE1BQU0sWUFBWSxhQUFhLGFBQWEsZUFBZSxTQUFTLFdBQVcsS0FBSyxVQUFVO0dBQzdGO0dBQ0EsTUFBTTtJQUNMLEdBQUcsUUFBUSxDQUFDO0lBQ1o7SUFDQTtJQUNBLGVBQWU7R0FDaEI7RUFDRCxFQUFFO0VBQ0YsTUFBTSxVQUFVLGFBQWEsYUFBYSxhQUFhLFdBQVcsS0FBSyxVQUFVO0dBQ2hGLFNBQVMsS0FBSztHQUNkLE1BQU07SUFDTCxHQUFHLFFBQVEsQ0FBQztJQUNaO0lBQ0E7SUFDQSxlQUFlO0dBQ2hCO0VBQ0QsRUFBRTtFQUNGLE1BQU0sV0FBVyxhQUFhLGFBQWEsY0FBYyxPQUFPLFdBQVcsS0FBSyxTQUFTLFVBQVU7R0FDbEc7R0FDQSxRQUFRLFdBQVcsUUFBUSxrQkFBa0IsbUJBQUEsQ0FBb0IsU0FBUyxVQUFVO0dBQ3BGLE1BQU07SUFDTCxHQUFHLFFBQVEsQ0FBQztJQUNaO0lBQ0E7SUFDQSxtQkFBbUIsWUFBWSxLQUFLO0lBQ3BDLGVBQWU7SUFDZixTQUFTLE9BQU8sU0FBUztJQUN6QixXQUFXLE9BQU8sU0FBUztHQUM1QjtFQUNELEVBQUU7RUFDRixTQUFTLGNBQWMsS0FBSyxFQUFFLFdBQVcsQ0FBQyxHQUFHO0dBQzVDLFFBQVEsVUFBVSxVQUFVLFVBQVU7SUFDckMsTUFBTSxZQUFZLFNBQVMsY0FBYyxRQUFRLFlBQVksR0FBRyxJQUFJLE9BQU87SUFDM0UsTUFBTSxrQkFBa0IsSUFBSSxnQkFBZ0I7SUFDNUMsSUFBSTtJQUNKLElBQUk7SUFDSixTQUFTLE1BQU0sUUFBUTtLQUN0QixjQUFjO0tBQ2QsZ0JBQWdCLE1BQU07SUFDdkI7SUFDQSxJQUFJLFFBQVE7S0FDWCxJQUFJLE9BQU8sU0FBUyxNQUFNLG9CQUFvQjtVQUN6QyxPQUFPLGlCQUFpQixlQUFlLE1BQU0sb0JBQW9CLEdBQUcsRUFBRSxNQUFNLEtBQUssQ0FBQztJQUN4RjtJQUNBLE1BQU0sVUFBVSxpQkFBaUI7S0FDaEMsSUFBSTtLQUNKLElBQUk7TUFDSCxJQUFJLGtCQUFrQixTQUFTLFlBQVksS0FBSztPQUMvQztPQUNBO01BQ0QsQ0FBQztNQUNELElBQUksV0FBVyxlQUFlLEdBQUcsa0JBQWtCLE1BQU07TUFDekQsSUFBSSxvQkFBb0IsT0FBTyxNQUFNO09BQ3BDLE1BQU07T0FDTixTQUFTO01BQ1Y7TUFDQSxJQUFJLGdCQUFnQixPQUFPLFNBQVMsTUFBTTtPQUN6QyxNQUFNO09BQ04sU0FBUyxlQUFlO01BQ3pCO01BQ0EsTUFBTSxpQkFBaUIsSUFBSSxTQUFTLEdBQUcsV0FBVztPQUNqRCxxQkFBcUI7UUFDcEIsT0FBTztTQUNOLE1BQU07U0FDTixTQUFTLGVBQWU7UUFDekIsQ0FBQztPQUNGO09BQ0EsZ0JBQWdCLE9BQU8saUJBQWlCLFNBQVMsY0FBYyxFQUFFLE1BQU0sS0FBSyxDQUFDO01BQzlFLENBQUM7TUFDRCxTQUFTLFFBQVEsV0FBVyxLQUFLLFNBQVMsaUJBQWlCO09BQzFEO09BQ0E7TUFDRCxHQUFHO09BQ0Y7T0FDQTtNQUNELENBQUMsQ0FBQyxDQUFDO01BQ0gsY0FBYyxNQUFNLFFBQVEsS0FBSyxDQUFDLGdCQUFnQixRQUFRLFFBQVEsZUFBZSxLQUFLO09BQ3JGO09BQ0E7T0FDQTtPQUNBO09BQ0EsUUFBUSxnQkFBZ0I7T0FDeEI7T0FDQSxtQkFBbUIsT0FBTyxTQUFTO1FBQ2xDLE9BQU8sSUFBSSxnQkFBZ0IsT0FBTyxJQUFJO09BQ3ZDO09BQ0Esb0JBQW9CLE9BQU8sU0FBUztRQUNuQyxPQUFPLElBQUksZ0JBQWdCLE9BQU8sSUFBSTtPQUN2QztNQUNELENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxXQUFXO09BQ3BCLElBQUksa0JBQWtCLGlCQUFpQixNQUFNO09BQzdDLElBQUksa0JBQWtCLGlCQUFpQixPQUFPLFVBQVUsT0FBTyxTQUFTLFdBQVcsS0FBSyxPQUFPLElBQUk7T0FDbkcsT0FBTyxVQUFVLFFBQVEsV0FBVyxHQUFHO01BQ3hDLENBQUMsQ0FBQyxDQUFDO0tBQ0osU0FBUyxLQUFLO01BQ2IsY0FBYyxlQUFlLGtCQUFrQixTQUFTLE1BQU0sV0FBVyxLQUFLLElBQUksU0FBUyxJQUFJLElBQUksSUFBSSxTQUFTLEtBQUssV0FBVyxHQUFHO0tBQ3BJLFVBQVU7TUFDVCxJQUFJLGNBQWMsZ0JBQWdCLE9BQU8sb0JBQW9CLFNBQVMsWUFBWTtLQUNuRjtLQUNBLElBQUksRUFBRSxXQUFXLENBQUMsUUFBUSw4QkFBOEIsU0FBUyxNQUFNLFdBQVcsS0FBSyxZQUFZLEtBQUssWUFBWSxTQUFTLFdBQVc7S0FDeEksT0FBTztJQUNSLEVBQUU7SUFDRixPQUFPLE9BQU8sT0FBTyxTQUFTO0tBQzdCO0tBQ0E7S0FDQTtLQUNBLFNBQVM7TUFDUixPQUFPLFFBQVEsS0FBSyxZQUFZO0tBQ2pDO0lBQ0QsQ0FBQztHQUNGO0VBQ0Q7RUFDQSxPQUFPLE9BQU8sT0FBTyxlQUFlO0dBQ25DO0dBQ0E7R0FDQTtHQUNBLFNBQVMsUUFBUSxVQUFVLFNBQVM7R0FDcEM7RUFDRCxDQUFDO0NBQ0Y7Q0FDQSxpQkFBaUIsa0JBQWtCO0NBQ25DLE9BQU87QUFDUixFQUFBLENBQUc7QUFDSCxTQUFTLGFBQWEsUUFBUTtDQUM3QixJQUFJLE9BQU8sUUFBUSxPQUFPLEtBQUssbUJBQW1CLE1BQU0sT0FBTztDQUMvRCxJQUFJLE9BQU8sT0FBTyxNQUFNLE9BQU87Q0FDL0IsT0FBTyxPQUFPO0FBQ2Y7QUFDQSxTQUFTLFdBQVcsT0FBTztDQUMxQixPQUFPLFVBQVUsUUFBUSxPQUFPLFVBQVUsWUFBWSxPQUFPLE1BQU0sU0FBUztBQUM3RTtBQUdBLElBQU0sbUJBQW1DLHVCQUFPLElBQUksNEJBQTRCO0FBQ2hGLElBQU0sb0JBQW9CLEdBQUcsbUJBQW1CLGlCQUFpQjtBQUNqRSxJQUFJLGNBQThCLHlCQUFTLGFBQWE7Q0FDdkQsWUFBWSxhQUFhO0NBQ3pCLFlBQVksd0JBQXdCO0NBQ3BDLFlBQVksZ0JBQWdCO0NBQzVCLE9BQU87QUFDUixFQUFFLENBQUMsQ0FBQztBQUNKLFNBQVMsUUFBUSxPQUFPLFdBQVc7Q0FDbEMsT0FBTyxHQUFHLE1BQU0sR0FBRztBQUNwQjtBQUNBLFNBQVMsaUJBQWlCLEVBQUUsYUFBYSxDQUFDLEdBQUc7Q0FDNUMsTUFBTSxNQUFNLFVBQVUsYUFBYTtDQUNuQyxPQUFPLFNBQVMsWUFBWSxTQUFTO0VBQ3BDLE1BQU0sRUFBRSxNQUFNLGNBQWMsU0FBUztFQUNyQyxJQUFJLENBQUMsTUFBTSxNQUFNLElBQUksTUFBMkUsNkNBQTZDO0VBQzdJLElBQUksT0FBTyxZQUFZLGVBQWUsTUFDakM7T0FBQSxRQUFRLGlCQUFpQixLQUFLLEdBQUcsUUFBUSxNQUFNLDBHQUEwRztFQUFBO0VBRTlKLE1BQU0sWUFBWSxPQUFPLFFBQVEsYUFBYSxhQUFhLFFBQVEsU0FBUyxxQkFBcUIsQ0FBQyxJQUFJLFFBQVEsYUFBYSxDQUFDO0VBQzVILE1BQU0sZUFBZSxPQUFPLEtBQUssUUFBUTtFQUN6QyxNQUFNLFVBQVU7R0FDZix5QkFBeUIsQ0FBQztHQUMxQix5QkFBeUIsQ0FBQztHQUMxQixnQkFBZ0IsQ0FBQztHQUNqQixlQUFlLENBQUM7RUFDakI7RUFDQSxNQUFNLGlCQUFpQjtHQUN0QixRQUFRLHFCQUFxQixTQUFTO0lBQ3JDLE1BQU0sT0FBTyxPQUFPLHdCQUF3QixXQUFXLHNCQUFzQixvQkFBb0I7SUFDakcsSUFBSSxDQUFDLE1BQU0sTUFBTSxJQUFJLE1BQTJFLDhEQUE4RDtJQUM5SixJQUFJLFFBQVEsUUFBUSx5QkFBeUIsTUFBTSxJQUFJLE1BQTJFLG9GQUFvRixJQUFJO0lBQzFOLFFBQVEsd0JBQXdCLFFBQVE7SUFDeEMsT0FBTztHQUNSO0dBQ0EsV0FBVyxTQUFTLFNBQVM7SUFDNUIsUUFBUSxjQUFjLEtBQUs7S0FDMUI7S0FDQTtJQUNELENBQUM7SUFDRCxPQUFPO0dBQ1I7R0FDQSxhQUFhLE1BQU0sZUFBZTtJQUNqQyxRQUFRLGVBQWUsUUFBUTtJQUMvQixPQUFPO0dBQ1I7R0FDQSxrQkFBa0IsTUFBTSxTQUFTO0lBQ2hDLFFBQVEsd0JBQXdCLFFBQVE7SUFDeEMsT0FBTztHQUNSO0VBQ0Q7RUFDQSxhQUFhLFNBQVMsZ0JBQWdCO0dBQ3JDLE1BQU0sb0JBQW9CLFNBQVM7R0FDbkMsTUFBTSxpQkFBaUI7SUFDdEI7SUFDQSxNQUFNLFFBQVEsTUFBTSxXQUFXO0lBQy9CLGdCQUFnQixPQUFPLFFBQVEsYUFBYTtHQUM3QztHQUNBLElBQUksbUNBQW1DLGlCQUFpQixHQUFHLGlDQUFpQyxnQkFBZ0IsbUJBQW1CLGdCQUFnQixHQUFHO1FBQzdJLDhCQUE4QixnQkFBZ0IsbUJBQW1CLGNBQWM7RUFDckYsQ0FBQztFQUNELFNBQVMsZUFBZTtHQUV0QixJQUFJLE9BQU8sUUFBUSxrQkFBa0IsVUFBVSxNQUFNLElBQUksTUFBMkUsd0tBQXdLO0dBRTdTLE1BQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLGlCQUFpQixDQUFDLEdBQUcscUJBQXFCLEtBQUssS0FBSyxPQUFPLFFBQVEsa0JBQWtCLGFBQWEsOEJBQThCLFFBQVEsYUFBYSxJQUFJLENBQUMsUUFBUSxhQUFhO0dBQzFNLE1BQU0sb0JBQW9CO0lBQ3pCLEdBQUc7SUFDSCxHQUFHLFFBQVE7R0FDWjtHQUNBLE9BQU8sY0FBYyxRQUFRLGVBQWUsWUFBWTtJQUN2RCxLQUFLLElBQUksT0FBTyxtQkFBbUIsUUFBUSxRQUFRLEtBQUssa0JBQWtCLElBQUk7SUFDOUUsS0FBSyxJQUFJLE1BQU0sUUFBUSxlQUFlLFFBQVEsV0FBVyxHQUFHLFNBQVMsR0FBRyxPQUFPO0lBQy9FLEtBQUssSUFBSSxLQUFLLGdCQUFnQixRQUFRLFdBQVcsRUFBRSxTQUFTLEVBQUUsT0FBTztJQUNyRSxJQUFJLG9CQUFvQixRQUFRLGVBQWUsa0JBQWtCO0dBQ2xFLENBQUM7RUFDRjtFQUNBLE1BQU0sY0FBYyxVQUFVO0VBQzlCLE1BQU0sd0NBQXdDLElBQUksSUFBSTtFQUN0RCxNQUFNLHFDQUFxQyxJQUFJLFFBQVE7RUFDdkQsSUFBSTtFQUNKLFNBQVMsUUFBUSxPQUFPLFFBQVE7R0FDL0IsSUFBSSxDQUFDLFVBQVUsV0FBVyxhQUFhO0dBQ3ZDLE9BQU8sU0FBUyxPQUFPLE1BQU07RUFDOUI7RUFDQSxTQUFTLGtCQUFrQjtHQUMxQixJQUFJLENBQUMsVUFBVSxXQUFXLGFBQWE7R0FDdkMsT0FBTyxTQUFTLGdCQUFnQjtFQUNqQztFQUNBLFNBQVMsa0JBQWtCLGFBQWEsV0FBVyxPQUFPO0dBQ3pELFNBQVMsWUFBWSxPQUFPO0lBQzNCLElBQUksYUFBYSxNQUFNO0lBQ3ZCLElBQUksT0FBTyxlQUFlLGFBQWE7S0FDdEMsSUFBSSxVQUFVLGFBQWEsb0JBQW9CLG9CQUFvQixhQUFhLGVBQWU7VUFDL0MsTUFBTSxJQUFJLE1BQTJFLGdFQUFnRTtJQUN0TTtJQUNBLE9BQU87R0FDUjtHQUNBLFNBQVMsYUFBYSxjQUFjLFlBQVk7SUFDL0MsT0FBTyxvQkFBb0Isb0JBQW9CLHVCQUF1QixnQ0FBZ0MsSUFBSSxRQUFRLENBQUMsR0FBRyxtQkFBbUI7S0FDeEksTUFBTSxNQUFNLENBQUM7S0FDYixLQUFLLE1BQU0sQ0FBQyxNQUFNLGFBQWEsT0FBTyxRQUFRLFFBQVEsYUFBYSxDQUFDLENBQUMsR0FBRyxJQUFJLFFBQVEsYUFBYSxVQUFVLG1CQUFtQixvQkFBb0Isb0JBQW9CLGFBQWEsZUFBZSxHQUFHLFFBQVE7S0FDN00sT0FBTztJQUNSLENBQUM7R0FDRjtHQUNBLE9BQU87SUFDTjtJQUNBO0lBQ0EsSUFBSSxZQUFZO0tBQ2YsT0FBTyxhQUFhLFdBQVc7SUFDaEM7SUFDQTtHQUNEO0VBQ0Q7RUFDQSxNQUFNLFFBQVE7R0FDYjtHQUNBO0dBQ0EsU0FBUyxRQUFRO0dBQ2pCLGNBQWMsUUFBUTtHQUN0QjtHQUNBLEdBQUcsa0JBQWtCLFdBQVc7R0FDaEMsV0FBVyxZQUFZLEVBQUUsYUFBYSxTQUFTLEdBQUcsV0FBVyxDQUFDLEdBQUc7SUFDaEUsTUFBTSxpQkFBaUIsV0FBVztJQUNsQyxXQUFXLE9BQU87S0FDakIsYUFBYTtLQUNiO0lBQ0QsR0FBRyxNQUFNO0lBQ1QsT0FBTztLQUNOLEdBQUc7S0FDSCxHQUFHLGtCQUFrQixnQkFBZ0IsSUFBSTtJQUMxQztHQUNEO0VBQ0Q7RUFDQSxPQUFPO0NBQ1I7QUFDRDtBQUNBLFNBQVMsYUFBYSxVQUFVLGFBQWEsaUJBQWlCLFVBQVU7Q0FDdkUsU0FBUyxRQUFRLFdBQVcsR0FBRyxNQUFNO0VBQ3BDLElBQUksYUFBYSxZQUFZLFNBQVM7RUFDdEMsSUFBSSxPQUFPLGVBQWUsYUFBYTtHQUN0QyxJQUFJLFVBQVUsYUFBYSxnQkFBZ0I7UUFDSyxNQUFNLElBQUksTUFBMkUsZ0VBQWdFO0VBQ3RNO0VBQ0EsT0FBTyxTQUFTLFlBQVksR0FBRyxJQUFJO0NBQ3BDO0NBQ0EsUUFBUSxZQUFZO0NBQ3BCLE9BQU87QUFDUjtBQUNBLElBQU0sY0FBOEIsaUNBQWlCO0FBQ3JELFNBQVMsdUJBQXVCO0NBQy9CLFNBQVMsV0FBVyxnQkFBZ0IsUUFBUTtFQUMzQyxPQUFPO0dBQ04sd0JBQXdCO0dBQ3hCO0dBQ0EsR0FBRztFQUNKO0NBQ0Q7Q0FDQSxXQUFXLGtCQUFrQjtDQUM3QixPQUFPO0VBQ04sUUFBUSxhQUFhO0dBQ3BCLE9BQU8sT0FBTyxPQUFPLEVBQUUsQ0FBQyxZQUFZLE1BQU0sR0FBRyxNQUFNO0lBQ2xELE9BQU8sWUFBWSxHQUFHLElBQUk7R0FDM0IsRUFBRSxFQUFFLFlBQVksT0FBTyxFQUFFLHdCQUF3QixVQUFVLENBQUM7RUFDN0Q7RUFDQSxnQkFBZ0IsU0FBUyxTQUFTO0dBQ2pDLE9BQU87SUFDTix3QkFBd0I7SUFDeEI7SUFDQTtHQUNEO0VBQ0Q7RUFDQTtDQUNEO0FBQ0Q7QUFDQSxTQUFTLDhCQUE4QixFQUFFLE1BQU0sYUFBYSxrQkFBa0IseUJBQXlCLFNBQVM7Q0FDL0csSUFBSTtDQUNKLElBQUk7Q0FDSixJQUFJLGFBQWEseUJBQXlCO0VBQ3pDLElBQUksa0JBQWtCLENBQUMsbUNBQW1DLHVCQUF1QixHQUFHLE1BQU0sSUFBSSxNQUEyRSwyR0FBMkc7RUFDcFIsY0FBYyx3QkFBd0I7RUFDdEMsa0JBQWtCLHdCQUF3QjtDQUMzQyxPQUFPLGNBQWM7Q0FDckIsUUFBUSxRQUFRLE1BQU0sV0FBVyxDQUFDLENBQUMsa0JBQWtCLGFBQWEsV0FBVyxDQUFDLENBQUMsYUFBYSxhQUFhLGtCQUFrQixhQUFhLE1BQU0sZUFBZSxJQUFJLGFBQWEsSUFBSSxDQUFDO0FBQ3BMO0FBQ0EsU0FBUyxtQ0FBbUMsbUJBQW1CO0NBQzlELE9BQU8sa0JBQWtCLDJCQUEyQjtBQUNyRDtBQUNBLFNBQVMsbUNBQW1DLG1CQUFtQjtDQUM5RCxPQUFPLGtCQUFrQiwyQkFBMkI7QUFDckQ7QUFDQSxTQUFTLGlDQUFpQyxFQUFFLE1BQU0sZUFBZSxtQkFBbUIsU0FBUyxLQUFLO0NBQ2pHLElBQUksQ0FBQyxLQUFLLE1BQU0sSUFBSSxNQUEyRSx3TEFBd0w7Q0FDdlIsTUFBTSxFQUFFLGdCQUFnQixXQUFXLFNBQVMsVUFBVSxTQUFTLFlBQVk7Q0FDM0UsTUFBTSxRQUFRLElBQUksTUFBTSxnQkFBZ0IsT0FBTztDQUMvQyxRQUFRLGFBQWEsYUFBYSxLQUFLO0NBQ3ZDLElBQUksV0FBVyxRQUFRLFFBQVEsTUFBTSxXQUFXLFNBQVM7Q0FDekQsSUFBSSxTQUFTLFFBQVEsUUFBUSxNQUFNLFNBQVMsT0FBTztDQUNuRCxJQUFJLFVBQVUsUUFBUSxRQUFRLE1BQU0sVUFBVSxRQUFRO0NBQ3RELElBQUksU0FBUyxRQUFRLFdBQVcsTUFBTSxTQUFTLE9BQU87Q0FDdEQsUUFBUSxrQkFBa0IsYUFBYTtFQUN0QyxXQUFXLGFBQWE7RUFDeEIsU0FBUyxXQUFXO0VBQ3BCLFVBQVUsWUFBWTtFQUN0QixTQUFTLFdBQVc7Q0FDckIsQ0FBQztBQUNGO0FBQ0EsU0FBUyxTQUFTLENBQUM7QUFHbkIsU0FBUyx3QkFBd0I7Q0FDaEMsT0FBTztFQUNOLEtBQUssQ0FBQztFQUNOLFVBQVUsQ0FBQztDQUNaO0FBQ0Q7QUFDQSxTQUFTLDBCQUEwQixjQUFjO0NBQ2hELFNBQVMsZ0JBQWdCLGtCQUFrQixDQUFDLEdBQUcsVUFBVTtFQUN4RCxNQUFNLFFBQVEsT0FBTyxPQUFPLHNCQUFzQixHQUFHLGVBQWU7RUFDcEUsT0FBTyxXQUFXLGFBQWEsT0FBTyxPQUFPLFFBQVEsSUFBSTtDQUMxRDtDQUNBLE9BQU8sRUFBRSxnQkFBZ0I7QUFDMUI7QUFHQSxTQUFTLHlCQUF5QjtDQUNqQyxTQUFTLGFBQWEsYUFBYSxVQUFVLENBQUMsR0FBRztFQUNoRCxNQUFNLEVBQUUsaUJBQWlCLDRCQUE0QjtFQUNyRCxNQUFNLGFBQWEsVUFBVSxNQUFNO0VBQ25DLE1BQU0sa0JBQWtCLFVBQVUsTUFBTTtFQUN4QyxNQUFNLFlBQVksZUFBZSxXQUFXLGlCQUFpQixLQUFLLGFBQWEsSUFBSSxLQUFLLE9BQU8sU0FBUyxHQUFHLENBQUM7RUFDNUcsTUFBTSxZQUFZLEdBQUcsT0FBTztFQUM1QixNQUFNLGNBQWMsVUFBVSxPQUFPLFNBQVM7RUFDOUMsTUFBTSxjQUFjLGVBQWUsWUFBWSxRQUFRLElBQUksTUFBTTtFQUNqRSxJQUFJLENBQUMsYUFBYSxPQUFPO0dBQ3hCO0dBQ0E7R0FDQTtHQUNBO0dBQ0EsWUFBWSxlQUFlLGdCQUFnQixVQUFVLFVBQVU7RUFDaEU7RUFDQSxNQUFNLDJCQUEyQixlQUFlLGFBQWEsY0FBYztFQUMzRSxPQUFPO0dBQ04sV0FBVyxlQUFlLGFBQWEsU0FBUztHQUNoRCxnQkFBZ0I7R0FDaEIsV0FBVyxlQUFlLGFBQWEsU0FBUztHQUNoRCxhQUFhLGVBQWUsYUFBYSxXQUFXO0dBQ3BELFlBQVksZUFBZSwwQkFBMEIsVUFBVSxVQUFVO0VBQzFFO0NBQ0Q7Q0FDQSxPQUFPLEVBQUUsYUFBYTtBQUN2QjtBQUdBLElBQU0sZUFBZTtBQUNyQixTQUFTLGtDQUFrQyxTQUFTO0NBQ25ELE1BQU0sV0FBVyxxQkFBcUIsR0FBRyxVQUFVLFFBQVEsS0FBSyxDQUFDO0NBQ2pFLE9BQU8sU0FBUyxVQUFVLE9BQU87RUFDaEMsT0FBTyxTQUFTLE9BQU8sS0FBSyxDQUFDO0NBQzlCO0FBQ0Q7QUFDQSxTQUFTLG9CQUFvQixTQUFTO0NBQ3JDLE9BQU8sU0FBUyxVQUFVLE9BQU8sS0FBSztFQUNyQyxTQUFTLHdCQUF3QixLQUFLO0dBQ3JDLE9BQU8sTUFBTSxHQUFHO0VBQ2pCO0VBQ0EsTUFBTSxjQUFjLFVBQVU7R0FDN0IsSUFBSSx3QkFBd0IsR0FBRyxHQUFHLFFBQVEsSUFBSSxTQUFTLEtBQUs7UUFDdkQsUUFBUSxLQUFLLEtBQUs7RUFDeEI7RUFDQSxJQUFJLGFBQWEsS0FBSyxHQUFHO0dBQ3hCLFdBQVcsS0FBSztHQUNoQixPQUFPO0VBQ1I7RUFDQSxPQUFPQSxRQUFnQixPQUFPLFVBQVU7Q0FDekM7QUFDRDtBQUdBLFNBQVMsY0FBYyxRQUFRLFVBQVU7Q0FDeEMsTUFBTSxNQUFNLFNBQVMsTUFBTTtDQUMzQixJQUE2QyxRQUFRLEtBQUssR0FBRyxRQUFRLEtBQUssMEVBQTBFLG1FQUFtRSwrQkFBK0IsUUFBUSxrQ0FBa0MsU0FBUyxTQUFTLENBQUM7Q0FDblQsT0FBTztBQUNSO0FBQ0EsU0FBUyxvQkFBb0IsVUFBVTtDQUN0QyxJQUFJLENBQUMsTUFBTSxRQUFRLFFBQVEsR0FBRyxXQUFXLE9BQU8sT0FBTyxRQUFRO0NBQy9ELE9BQU87QUFDUjtBQUNBLFNBQVMsV0FBVyxPQUFPO0NBQzFCLE9BQU8sUUFBUSxLQUFLLElBQUksUUFBUSxLQUFLLElBQUk7QUFDMUM7QUFDQSxTQUFTLDBCQUEwQixhQUFhLFVBQVUsT0FBTztDQUNoRSxjQUFjLG9CQUFvQixXQUFXO0NBQzdDLE1BQU0sbUJBQW1CLFdBQVcsTUFBTSxHQUFHO0NBQzdDLE1BQU0sY0FBYyxJQUFJLElBQUksZ0JBQWdCO0NBQzVDLE1BQU0sUUFBUSxDQUFDO0NBQ2YsTUFBTSwyQkFBMkIsSUFBSSxJQUFJLENBQUMsQ0FBQztDQUMzQyxNQUFNLFVBQVUsQ0FBQztDQUNqQixLQUFLLE1BQU0sVUFBVSxhQUFhO0VBQ2pDLE1BQU0sS0FBSyxjQUFjLFFBQVEsUUFBUTtFQUN6QyxJQUFJLFlBQVksSUFBSSxFQUFFLEtBQUssU0FBUyxJQUFJLEVBQUUsR0FBRyxRQUFRLEtBQUs7R0FDekQ7R0FDQSxTQUFTO0VBQ1YsQ0FBQztPQUNJO0dBQ0osU0FBUyxJQUFJLEVBQUU7R0FDZixNQUFNLEtBQUssTUFBTTtFQUNsQjtDQUNEO0NBQ0EsT0FBTztFQUNOO0VBQ0E7RUFDQTtDQUNEO0FBQ0Q7QUFHQSxTQUFTLDJCQUEyQixVQUFVO0NBQzdDLFNBQVMsY0FBYyxRQUFRLE9BQU87RUFDckMsTUFBTSxNQUFNLGNBQWMsUUFBUSxRQUFRO0VBQzFDLElBQUksT0FBTyxNQUFNLFVBQVU7RUFDM0IsTUFBTSxJQUFJLEtBQUssR0FBRztFQUNsQixNQUFNLFNBQVMsT0FBTztDQUN2QjtDQUNBLFNBQVMsZUFBZSxhQUFhLE9BQU87RUFDM0MsY0FBYyxvQkFBb0IsV0FBVztFQUM3QyxLQUFLLE1BQU0sVUFBVSxhQUFhLGNBQWMsUUFBUSxLQUFLO0NBQzlEO0NBQ0EsU0FBUyxjQUFjLFFBQVEsT0FBTztFQUNyQyxNQUFNLE1BQU0sY0FBYyxRQUFRLFFBQVE7RUFDMUMsSUFBSSxFQUFFLE9BQU8sTUFBTSxXQUFXLE1BQU0sSUFBSSxLQUFLLEdBQUc7RUFDaEQsTUFBTSxTQUFTLE9BQU87Q0FDdkI7Q0FDQSxTQUFTLGVBQWUsYUFBYSxPQUFPO0VBQzNDLGNBQWMsb0JBQW9CLFdBQVc7RUFDN0MsS0FBSyxNQUFNLFVBQVUsYUFBYSxjQUFjLFFBQVEsS0FBSztDQUM5RDtDQUNBLFNBQVMsY0FBYyxhQUFhLE9BQU87RUFDMUMsY0FBYyxvQkFBb0IsV0FBVztFQUM3QyxNQUFNLE1BQU0sQ0FBQztFQUNiLE1BQU0sV0FBVyxDQUFDO0VBQ2xCLGVBQWUsYUFBYSxLQUFLO0NBQ2xDO0NBQ0EsU0FBUyxpQkFBaUIsS0FBSyxPQUFPO0VBQ3JDLE9BQU8sa0JBQWtCLENBQUMsR0FBRyxHQUFHLEtBQUs7Q0FDdEM7Q0FDQSxTQUFTLGtCQUFrQixNQUFNLE9BQU87RUFDdkMsSUFBSSxZQUFZO0VBQ2hCLEtBQUssU0FBUyxRQUFRO0dBQ3JCLElBQUksT0FBTyxNQUFNLFVBQVU7SUFDMUIsT0FBTyxNQUFNLFNBQVM7SUFDdEIsWUFBWTtHQUNiO0VBQ0QsQ0FBQztFQUNELElBQUksV0FBVyxNQUFNLE1BQU0sTUFBTSxJQUFJLFFBQVEsT0FBTyxNQUFNLE1BQU0sUUFBUTtDQUN6RTtDQUNBLFNBQVMsaUJBQWlCLE9BQU87RUFDaEMsT0FBTyxPQUFPLE9BQU87R0FDcEIsS0FBSyxDQUFDO0dBQ04sVUFBVSxDQUFDO0VBQ1osQ0FBQztDQUNGO0NBQ0EsU0FBUyxXQUFXLE1BQU0sUUFBUSxPQUFPO0VBQ3hDLE1BQU0sV0FBVyxNQUFNLFNBQVMsT0FBTztFQUN2QyxJQUFJLGFBQWEsS0FBSyxHQUFHLE9BQU87RUFDaEMsTUFBTSxVQUFVLE9BQU8sT0FBTyxDQUFDLEdBQUcsVUFBVSxPQUFPLE9BQU87RUFDMUQsTUFBTSxTQUFTLGNBQWMsU0FBUyxRQUFRO0VBQzlDLE1BQU0sWUFBWSxXQUFXLE9BQU87RUFDcEMsSUFBSSxXQUFXO0dBQ2QsS0FBSyxPQUFPLE1BQU07R0FDbEIsT0FBTyxNQUFNLFNBQVMsT0FBTztFQUM5QjtFQUNBLE1BQU0sU0FBUyxVQUFVO0VBQ3pCLE9BQU87Q0FDUjtDQUNBLFNBQVMsaUJBQWlCLFFBQVEsT0FBTztFQUN4QyxPQUFPLGtCQUFrQixDQUFDLE1BQU0sR0FBRyxLQUFLO0NBQ3pDO0NBQ0EsU0FBUyxrQkFBa0IsU0FBUyxPQUFPO0VBQzFDLE1BQU0sVUFBVSxDQUFDO0VBQ2pCLE1BQU0sbUJBQW1CLENBQUM7RUFDMUIsUUFBUSxTQUFTLFdBQVc7R0FDM0IsSUFBSSxPQUFPLE1BQU0sTUFBTSxVQUFVLGlCQUFpQixPQUFPLE1BQU07SUFDOUQsSUFBSSxPQUFPO0lBQ1gsU0FBUztLQUNSLEdBQUcsaUJBQWlCLE9BQU8sR0FBRyxFQUFFO0tBQ2hDLEdBQUcsT0FBTztJQUNYO0dBQ0Q7RUFDRCxDQUFDO0VBQ0QsVUFBVSxPQUFPLE9BQU8sZ0JBQWdCO0VBQ3hDLElBQUksUUFBUSxTQUFTLEdBQ2hCO09BQUEsUUFBUSxRQUFRLFdBQVcsV0FBVyxTQUFTLFFBQVEsS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLEdBQUcsTUFBTSxNQUFNLE9BQU8sT0FBTyxNQUFNLFFBQVEsQ0FBQyxDQUFDLEtBQUssTUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDO0VBQUE7Q0FFaEs7Q0FDQSxTQUFTLGlCQUFpQixRQUFRLE9BQU87RUFDeEMsT0FBTyxrQkFBa0IsQ0FBQyxNQUFNLEdBQUcsS0FBSztDQUN6QztDQUNBLFNBQVMsa0JBQWtCLGFBQWEsT0FBTztFQUM5QyxNQUFNLENBQUMsT0FBTyxXQUFXLDBCQUEwQixhQUFhLFVBQVUsS0FBSztFQUMvRSxlQUFlLE9BQU8sS0FBSztFQUMzQixrQkFBa0IsU0FBUyxLQUFLO0NBQ2pDO0NBQ0EsT0FBTztFQUNOLFdBQVcsa0NBQWtDLGdCQUFnQjtFQUM3RCxRQUFRLG9CQUFvQixhQUFhO0VBQ3pDLFNBQVMsb0JBQW9CLGNBQWM7RUFDM0MsUUFBUSxvQkFBb0IsYUFBYTtFQUN6QyxTQUFTLG9CQUFvQixjQUFjO0VBQzNDLFFBQVEsb0JBQW9CLGFBQWE7RUFDekMsV0FBVyxvQkFBb0IsZ0JBQWdCO0VBQy9DLFlBQVksb0JBQW9CLGlCQUFpQjtFQUNqRCxXQUFXLG9CQUFvQixnQkFBZ0I7RUFDL0MsWUFBWSxvQkFBb0IsaUJBQWlCO0VBQ2pELFdBQVcsb0JBQW9CLGdCQUFnQjtFQUMvQyxZQUFZLG9CQUFvQixpQkFBaUI7Q0FDbEQ7QUFDRDtBQUdBLFNBQVMsZ0JBQWdCLGFBQWEsTUFBTSxvQkFBb0I7Q0FDL0QsSUFBSSxXQUFXO0NBQ2YsSUFBSSxZQUFZLFlBQVk7Q0FDNUIsT0FBTyxXQUFXLFdBQVc7RUFDNUIsSUFBSSxjQUFjLFdBQVcsY0FBYztFQUMzQyxNQUFNLGNBQWMsWUFBWTtFQUNoQyxJQUFJLG1CQUFtQixNQUFNLFdBQVcsS0FBSyxHQUFHLFdBQVcsY0FBYztPQUNwRSxZQUFZO0NBQ2xCO0NBQ0EsT0FBTztBQUNSO0FBQ0EsU0FBUyxPQUFPLGFBQWEsTUFBTSxvQkFBb0I7Q0FDdEQsTUFBTSxnQkFBZ0IsZ0JBQWdCLGFBQWEsTUFBTSxrQkFBa0I7Q0FDM0UsWUFBWSxPQUFPLGVBQWUsR0FBRyxJQUFJO0NBQ3pDLE9BQU87QUFDUjtBQUNBLFNBQVMseUJBQXlCLFVBQVUsVUFBVTtDQUNyRCxNQUFNLEVBQUUsV0FBVyxZQUFZLGNBQWMsMkJBQTJCLFFBQVE7Q0FDaEYsU0FBUyxjQUFjLFFBQVEsT0FBTztFQUNyQyxPQUFPLGVBQWUsQ0FBQyxNQUFNLEdBQUcsS0FBSztDQUN0QztDQUNBLFNBQVMsZUFBZSxhQUFhLE9BQU8sYUFBYTtFQUN4RCxjQUFjLG9CQUFvQixXQUFXO0VBQzdDLE1BQU0sZUFBZSxJQUFJLElBQUksZUFBZSxXQUFXLE1BQU0sR0FBRyxDQUFDO0VBQ2pFLE1BQU0sNEJBQTRCLElBQUksSUFBSTtFQUMxQyxNQUFNLFNBQVMsWUFBWSxRQUFRLFVBQVU7R0FDNUMsTUFBTSxVQUFVLGNBQWMsT0FBTyxRQUFRO0dBQzdDLE1BQU0sV0FBVyxDQUFDLFVBQVUsSUFBSSxPQUFPO0dBQ3ZDLElBQUksVUFBVSxVQUFVLElBQUksT0FBTztHQUNuQyxPQUFPLENBQUMsYUFBYSxJQUFJLE9BQU8sS0FBSztFQUN0QyxDQUFDO0VBQ0QsSUFBSSxPQUFPLFdBQVcsR0FBRyxjQUFjLE9BQU8sTUFBTTtDQUNyRDtDQUNBLFNBQVMsY0FBYyxRQUFRLE9BQU87RUFDckMsT0FBTyxlQUFlLENBQUMsTUFBTSxHQUFHLEtBQUs7Q0FDdEM7Q0FDQSxTQUFTLGVBQWUsYUFBYSxPQUFPO0VBQzNDLElBQUksdUJBQXVCLENBQUM7RUFDNUIsY0FBYyxvQkFBb0IsV0FBVztFQUM3QyxJQUFJLFlBQVksV0FBVyxHQUFHO0dBQzdCLEtBQUssTUFBTSxRQUFRLGFBQWE7SUFDL0IsTUFBTSxXQUFXLFNBQVMsSUFBSTtJQUM5QixxQkFBcUIsWUFBWTtJQUNqQyxPQUFPLE1BQU0sU0FBUztHQUN2QjtHQUNBLGNBQWMsb0JBQW9CLG9CQUFvQjtHQUN0RCxjQUFjLE9BQU8sV0FBVztFQUNqQztDQUNEO0NBQ0EsU0FBUyxjQUFjLGFBQWEsT0FBTztFQUMxQyxjQUFjLG9CQUFvQixXQUFXO0VBQzdDLE1BQU0sV0FBVyxDQUFDO0VBQ2xCLE1BQU0sTUFBTSxDQUFDO0VBQ2IsZUFBZSxhQUFhLEtBQUs7Q0FDbEM7Q0FDQSxTQUFTLGlCQUFpQixRQUFRLE9BQU87RUFDeEMsT0FBTyxrQkFBa0IsQ0FBQyxNQUFNLEdBQUcsS0FBSztDQUN6QztDQUNBLFNBQVMsa0JBQWtCLFNBQVMsT0FBTztFQUMxQyxJQUFJLGlCQUFpQjtFQUNyQixJQUFJLGNBQWM7RUFDbEIsTUFBTSxtQkFBbUIsQ0FBQztFQUMxQixLQUFLLE1BQU0sVUFBVSxTQUFTLElBQUksT0FBTyxNQUFNLE1BQU0sVUFBVSxpQkFBaUIsT0FBTyxNQUFNO0dBQzVGLElBQUksT0FBTztHQUNYLFNBQVM7SUFDUixHQUFHLGlCQUFpQixPQUFPLEdBQUcsRUFBRTtJQUNoQyxHQUFHLE9BQU87R0FDWDtFQUNEO0VBQ0EsS0FBSyxNQUFNLFVBQVUsT0FBTyxPQUFPLGdCQUFnQixHQUFHO0dBQ3JELE1BQU0sU0FBUyxNQUFNLFNBQVMsT0FBTztHQUNyQyxJQUFJLENBQUMsUUFBUTtHQUNiLGlCQUFpQjtHQUNqQixPQUFPLE9BQU8sUUFBUSxPQUFPLE9BQU87R0FDcEMsTUFBTSxRQUFRLFNBQVMsTUFBTTtHQUM3QixJQUFJLE9BQU8sT0FBTyxPQUFPO0lBQ3hCLGNBQWM7SUFDZCxPQUFPLE1BQU0sU0FBUyxPQUFPO0lBQzdCLE1BQU0sV0FBVyxNQUFNLElBQUksUUFBUSxPQUFPLEVBQUU7SUFDNUMsTUFBTSxJQUFJLFlBQVk7SUFDdEIsTUFBTSxTQUFTLFNBQVM7R0FDekI7RUFDRDtFQUNBLElBQUksZ0JBQWdCLGNBQWMsT0FBTyxDQUFDLEdBQUcsZ0JBQWdCLFdBQVc7Q0FDekU7Q0FDQSxTQUFTLGlCQUFpQixRQUFRLE9BQU87RUFDeEMsT0FBTyxrQkFBa0IsQ0FBQyxNQUFNLEdBQUcsS0FBSztDQUN6QztDQUNBLFNBQVMsa0JBQWtCLGFBQWEsT0FBTztFQUM5QyxNQUFNLENBQUMsT0FBTyxTQUFTLG9CQUFvQiwwQkFBMEIsYUFBYSxVQUFVLEtBQUs7RUFDakcsSUFBSSxNQUFNLFFBQVEsZUFBZSxPQUFPLE9BQU8sZ0JBQWdCO0VBQy9ELElBQUksUUFBUSxRQUFRLGtCQUFrQixTQUFTLEtBQUs7Q0FDckQ7Q0FDQSxTQUFTLGVBQWUsR0FBRyxHQUFHO0VBQzdCLElBQUksRUFBRSxXQUFXLEVBQUUsUUFBUSxPQUFPO0VBQ2xDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxFQUFFLFFBQVEsS0FBSztHQUNsQyxJQUFJLEVBQUUsT0FBTyxFQUFFLElBQUk7R0FDbkIsT0FBTztFQUNSO0VBQ0EsT0FBTztDQUNSO0NBQ0EsU0FBUyxjQUFjLE9BQU8sWUFBWSxnQkFBZ0IsYUFBYTtFQUN0RSxNQUFNLGtCQUFrQixXQUFXLE1BQU0sUUFBUTtFQUNqRCxNQUFNLGFBQWEsV0FBVyxNQUFNLEdBQUc7RUFDdkMsTUFBTSxnQkFBZ0IsTUFBTTtFQUM1QixJQUFJLE1BQU07RUFDVixJQUFJLGFBQWEsTUFBTSxJQUFJLElBQUksVUFBVTtFQUN6QyxJQUFJLGlCQUFpQixDQUFDO0VBQ3RCLEtBQUssTUFBTSxNQUFNLEtBQUs7R0FDckIsTUFBTSxTQUFTLGdCQUFnQjtHQUMvQixJQUFJLFFBQVEsZUFBZSxLQUFLLE1BQU07RUFDdkM7RUFDQSxNQUFNLHFCQUFxQixlQUFlLFdBQVc7RUFDckQsS0FBSyxNQUFNLFFBQVEsWUFBWTtHQUM5QixjQUFjLFNBQVMsSUFBSSxLQUFLO0dBQ2hDLElBQUksQ0FBQyxvQkFBb0IsT0FBTyxnQkFBZ0IsTUFBTSxRQUFRO0VBQy9EO0VBQ0EsSUFBSSxvQkFBb0IsaUJBQWlCLFdBQVcsTUFBTSxDQUFDLENBQUMsS0FBSyxRQUFRO09BQ3BFLElBQUksZ0JBQWdCLGVBQWUsS0FBSyxRQUFRO0VBQ3JELE1BQU0sZUFBZSxlQUFlLElBQUksUUFBUTtFQUNoRCxJQUFJLENBQUMsZUFBZSxZQUFZLFlBQVksR0FBRyxNQUFNLE1BQU07Q0FDNUQ7Q0FDQSxPQUFPO0VBQ047RUFDQTtFQUNBO0VBQ0EsUUFBUSxvQkFBb0IsYUFBYTtFQUN6QyxXQUFXLG9CQUFvQixnQkFBZ0I7RUFDL0MsV0FBVyxvQkFBb0IsZ0JBQWdCO0VBQy9DLFFBQVEsb0JBQW9CLGFBQWE7RUFDekMsU0FBUyxvQkFBb0IsY0FBYztFQUMzQyxRQUFRLG9CQUFvQixhQUFhO0VBQ3pDLFNBQVMsb0JBQW9CLGNBQWM7RUFDM0MsWUFBWSxvQkFBb0IsaUJBQWlCO0VBQ2pELFlBQVksb0JBQW9CLGlCQUFpQjtDQUNsRDtBQUNEO0FBR0EsU0FBUyxvQkFBb0IsVUFBVSxDQUFDLEdBQUc7Q0FDMUMsTUFBTSxFQUFFLFVBQVUsaUJBQWlCO0VBQ2xDLGNBQWM7RUFDZCxXQUFXLGFBQWEsU0FBUztFQUNqQyxHQUFHO0NBQ0o7Q0FDQSxNQUFNLGVBQWUsZUFBZSx5QkFBeUIsVUFBVSxZQUFZLElBQUksMkJBQTJCLFFBQVE7Q0FDMUgsTUFBTSxlQUFlLDBCQUEwQixZQUFZO0NBQzNELE1BQU0sbUJBQW1CLHVCQUF1QjtDQUNoRCxPQUFPO0VBQ047RUFDQTtFQUNBLEdBQUc7RUFDSCxHQUFHO0VBQ0gsR0FBRztDQUNKO0FBQ0Q7QUFHQSxJQUFNLE9BQU87QUFDYixJQUFNLFdBQVc7QUFDakIsSUFBTSxZQUFZO0FBQ2xCLElBQU0sWUFBWTtBQUNsQixJQUFNLGdCQUFnQixRQUFRO0FBQzlCLElBQU0sZ0JBQWdCLFFBQVE7QUFDOUIsSUFBTSxvQkFBb0IsR0FBRyxTQUFTLEdBQUc7QUFDekMsSUFBTSxvQkFBb0IsR0FBRyxTQUFTLEdBQUc7QUFDekMsSUFBSSxpQkFBaUIsTUFBTTtDQUMxQjtDQUNBLE9BQU87Q0FDUDtDQUNBLFlBQVksTUFBTTtFQUNqQixLQUFLLE9BQU87RUFDWixLQUFLLFVBQVUsR0FBRyxLQUFLLEdBQUcsVUFBVSxZQUFZLEtBQUs7Q0FDdEQ7QUFDRDtBQUdBLElBQU0sa0JBQWtCLE1BQU0sYUFBYTtDQUMxQyxJQUFJLE9BQU8sU0FBUyxZQUFZLE1BQU0sSUFBSSxVQUErRSxHQUFHLFNBQVMsbUJBQW1CO0FBQ3pKO0FBQ0EsSUFBTSxhQUFhLENBQUM7QUFDcEIsSUFBTSxrQkFBa0IsU0FBUyxVQUFVLFNBQVM7Q0FDbkQsUUFBUSxNQUFNLE9BQU87Q0FDckIsT0FBTztBQUNSO0FBQ0EsSUFBTSwwQkFBMEIsYUFBYSxhQUFhO0NBQ3pELFlBQVksaUJBQWlCLFNBQVMsVUFBVSxFQUFFLE1BQU0sS0FBSyxDQUFDO0NBQzlELGFBQWEsWUFBWSxvQkFBb0IsU0FBUyxRQUFRO0FBQy9EO0FBR0EsSUFBTSxrQkFBa0IsV0FBVztDQUNsQyxJQUFJLE9BQU8sU0FBUyxNQUFNLElBQUksZUFBZSxPQUFPLE1BQU07QUFDM0Q7QUFDQSxTQUFTLGVBQWUsUUFBUSxTQUFTO0NBQ3hDLElBQUksVUFBVTtDQUNkLE9BQU8sSUFBSSxTQUFTLFNBQVMsV0FBVztFQUN2QyxNQUFNLHdCQUF3QixPQUFPLElBQUksZUFBZSxPQUFPLE1BQU0sQ0FBQztFQUN0RSxJQUFJLE9BQU8sU0FBUztHQUNuQixnQkFBZ0I7R0FDaEI7RUFDRDtFQUNBLFVBQVUsdUJBQXVCLFFBQVEsZUFBZTtFQUN4RCxRQUFRLGNBQWMsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLFNBQVMsTUFBTTtDQUN0RCxDQUFDLENBQUMsQ0FBQyxjQUFjO0VBQ2hCLFVBQVU7Q0FDWCxDQUFDO0FBQ0Y7QUFDQSxJQUFNLFVBQVUsT0FBTyxNQUFNLFlBQVk7Q0FDeEMsSUFBSTtFQUNILE1BQU0sUUFBUSxRQUFRO0VBQ3RCLE9BQU87R0FDTixRQUFRO0dBQ1IsT0FBTyxNQUFNLEtBQUs7RUFDbkI7Q0FDRCxTQUFTLE9BQU87RUFDZixPQUFPO0dBQ04sUUFBUSxpQkFBaUIsaUJBQWlCLGNBQWM7R0FDeEQ7RUFDRDtDQUNELFVBQVU7RUFDVCxVQUFVO0NBQ1g7QUFDRDtBQUNBLElBQU0sZUFBZSxXQUFXO0NBQy9CLFFBQVEsWUFBWTtFQUNuQixPQUFPLGVBQWUsZUFBZSxRQUFRLE9BQU8sQ0FBQyxDQUFDLE1BQU0sV0FBVztHQUN0RSxlQUFlLE1BQU07R0FDckIsT0FBTztFQUNSLENBQUMsQ0FBQztDQUNIO0FBQ0Q7QUFDQSxJQUFNLGVBQWUsV0FBVztDQUMvQixNQUFNLFFBQVEsWUFBWSxNQUFNO0NBQ2hDLFFBQVEsY0FBYztFQUNyQixPQUFPLE1BQU0sSUFBSSxTQUFTLFlBQVksV0FBVyxTQUFTLFNBQVMsQ0FBQyxDQUFDO0NBQ3RFO0FBQ0Q7QUFHQSxJQUFNLEVBQUUsV0FBVztBQUNuQixJQUFNLHFCQUFxQixDQUFDO0FBQzVCLElBQU0sTUFBTTtBQUNaLElBQU0sY0FBYyxtQkFBbUIsMkJBQTJCO0NBQ2pFLE1BQU0sbUJBQW1CLGVBQWUsdUJBQXVCLHlCQUF5QixXQUFXLE1BQU0sa0JBQWtCLE1BQU0sQ0FBQztDQUNsSSxRQUFRLGNBQWMsU0FBUztFQUM5QixlQUFlLGNBQWMsY0FBYztFQUMzQyxNQUFNLHVCQUF1QixJQUFJLGdCQUFnQjtFQUNqRCxnQkFBZ0Isb0JBQW9CO0VBQ3BDLE1BQU0sU0FBUyxRQUFRLFlBQVk7R0FDbEMsZUFBZSxpQkFBaUI7R0FDaEMsZUFBZSxxQkFBcUIsTUFBTTtHQUMxQyxNQUFNLFNBQVMsTUFBTSxhQUFhO0lBQ2pDLE9BQU8sWUFBWSxxQkFBcUIsTUFBTTtJQUM5QyxPQUFPLFlBQVkscUJBQXFCLE1BQU07SUFDOUMsUUFBUSxxQkFBcUI7R0FDOUIsQ0FBQztHQUNELGVBQWUscUJBQXFCLE1BQU07R0FDMUMsT0FBTztFQUNSLFNBQVMscUJBQXFCLE1BQU0sYUFBYSxDQUFDO0VBQ2xELElBQUksTUFBTSxVQUFVLHVCQUF1QixLQUFLLE9BQU8sTUFBTSxJQUFJLENBQUM7RUFDbEUsT0FBTztHQUNOLFFBQVEsWUFBWSxpQkFBaUIsQ0FBQyxDQUFDLE1BQU07R0FDN0MsU0FBUztJQUNSLHFCQUFxQixNQUFNLGFBQWE7R0FDekM7RUFDRDtDQUNEO0FBQ0Q7QUFDQSxJQUFNLHFCQUFxQixnQkFBZ0IsV0FBVztDQUNyRCxNQUFNLE9BQU8sT0FBTyxXQUFXLFlBQVk7RUFDMUMsZUFBZSxNQUFNO0VBQ3JCLElBQUksb0JBQW9CLENBQUM7RUFDekIsTUFBTSxXQUFXLENBQUMsSUFBSSxTQUFTLFNBQVMsV0FBVztHQUNsRCxJQUFJLGdCQUFnQixlQUFlO0lBQ2xDO0lBQ0EsU0FBUyxRQUFRLGdCQUFnQjtLQUNoQyxZQUFZLFlBQVk7S0FDeEIsUUFBUTtNQUNQO01BQ0EsWUFBWSxTQUFTO01BQ3JCLFlBQVksaUJBQWlCO0tBQzlCLENBQUM7SUFDRjtHQUNELENBQUM7R0FDRCxvQkFBb0I7SUFDbkIsY0FBYztJQUNkLE9BQU87R0FDUjtFQUNELENBQUMsQ0FBQztFQUNGLElBQUksV0FBVyxNQUFNLFNBQVMsS0FBSyxJQUFJLFNBQVMsWUFBWSxXQUFXLFNBQVMsU0FBUyxJQUFJLENBQUMsQ0FBQztFQUMvRixJQUFJO0dBQ0gsTUFBTSxTQUFTLE1BQU0sZUFBZSxRQUFRLFFBQVEsS0FBSyxRQUFRLENBQUM7R0FDbEUsZUFBZSxNQUFNO0dBQ3JCLE9BQU87RUFDUixVQUFVO0dBQ1QsWUFBWTtFQUNiO0NBQ0Q7Q0FDQSxTQUFTLFdBQVcsWUFBWSxlQUFlLEtBQUssV0FBVyxPQUFPLENBQUM7QUFDeEU7QUFDQSxJQUFNLDZCQUE2QixZQUFZO0NBQzlDLElBQUksRUFBRSxNQUFNLGVBQWUsU0FBUyxXQUFXLFdBQVc7Q0FDMUQsSUFBSSxNQUFNLFlBQVksYUFBYSxJQUFJLENBQUMsQ0FBQztNQUNwQyxJQUFJLGVBQWU7RUFDdkIsT0FBTyxjQUFjO0VBQ3JCLFlBQVksY0FBYztDQUMzQixPQUFPLElBQUksU0FBUyxZQUFZO01BQzNCLElBQUksV0FBVyxDQUFDLE9BQU8sTUFBTSxJQUFJLE1BQTJFLHlGQUF5RjtDQUMxTSxlQUFlLFFBQVEsa0JBQWtCO0NBQ3pDLE9BQU87RUFDTjtFQUNBO0VBQ0E7Q0FDRDtBQUNEO0FBQ0EsSUFBTSxzQkFBc0Msd0JBQVEsWUFBWTtDQUMvRCxNQUFNLEVBQUUsTUFBTSxXQUFXLFdBQVcsMEJBQTBCLE9BQU87Q0FDckUsT0FBTztFQUNOLElBQUksT0FBTztFQUNYO0VBQ0E7RUFDQTtFQUNBLHlCQUF5QixJQUFJLElBQUk7RUFDakMsbUJBQW1CO0dBQ2xCLE1BQU0sSUFBSSxNQUEyRSw2QkFBNkI7RUFDbkg7Q0FDRDtBQUNELEdBQUcsRUFBRSxpQkFBaUIsb0JBQW9CLENBQUM7QUFDM0MsSUFBTSxxQkFBcUIsYUFBYSxZQUFZO0NBQ25ELE1BQU0sRUFBRSxNQUFNLFFBQVEsY0FBYywwQkFBMEIsT0FBTztDQUNyRSxPQUFPLE1BQU0sS0FBSyxZQUFZLE9BQU8sQ0FBQyxDQUFDLENBQUMsTUFBTSxVQUFVO0VBQ3ZELFFBQVEsT0FBTyxTQUFTLFdBQVcsTUFBTSxTQUFTLE9BQU8sTUFBTSxjQUFjLGNBQWMsTUFBTSxXQUFXO0NBQzdHLENBQUM7QUFDRjtBQUNBLElBQU0seUJBQXlCLFVBQVU7Q0FDeEMsTUFBTSxRQUFRLFNBQVMsZUFBZTtFQUNyQyxXQUFXLE1BQU0saUJBQWlCO0NBQ25DLENBQUM7QUFDRjtBQUNBLElBQU0saUNBQWlDLGFBQWEsdUJBQXVCO0NBQzFFLGFBQWE7RUFDWixLQUFLLE1BQU0sWUFBWSxtQkFBbUIsS0FBSyxHQUFHLHNCQUFzQixRQUFRO0VBQ2hGLFlBQVksTUFBTTtDQUNuQjtBQUNEO0FBQ0EsSUFBTSxxQkFBcUIsY0FBYyxlQUFlLGNBQWM7Q0FDckUsSUFBSTtFQUNILGFBQWEsZUFBZSxTQUFTO0NBQ3RDLFNBQVMsbUJBQW1CO0VBQzNCLGlCQUFpQjtHQUNoQixNQUFNO0VBQ1AsR0FBRyxDQUFDO0NBQ0w7QUFDRDtBQUNBLElBQU0sY0FBOEIsdUJBQXVCLDZCQUFhLEdBQUcsSUFBSSxLQUFLLEdBQUcsRUFBRSxpQkFBaUIsWUFBWSxDQUFDO0FBQ3ZILElBQU0sb0JBQW9DLDZCQUFhLEdBQUcsSUFBSSxXQUFXO0FBQ3pFLElBQU0saUJBQWlDLHVCQUF1Qiw2QkFBYSxHQUFHLElBQUksUUFBUSxHQUFHLEVBQUUsaUJBQWlCLGVBQWUsQ0FBQztBQUNoSSxJQUFNLHVCQUF1QixHQUFHLFNBQVM7Q0FDeEMsUUFBUSxNQUFNLEdBQUcsSUFBSSxTQUFTLEdBQUcsSUFBSTtBQUN0QztBQUNBLElBQU0sNEJBQTRCLG9CQUFvQixDQUFDLE1BQU07Q0FDNUQsTUFBTSw4QkFBOEIsSUFBSSxJQUFJO0NBQzVDLE1BQU0scUNBQXFDLElBQUksSUFBSTtDQUNuRCxNQUFNLDBCQUEwQixVQUFVO0VBQ3pDLE1BQU0sUUFBUSxtQkFBbUIsSUFBSSxLQUFLLEtBQUs7RUFDL0MsbUJBQW1CLElBQUksT0FBTyxRQUFRLENBQUM7Q0FDeEM7Q0FDQSxNQUFNLDRCQUE0QixVQUFVO0VBQzNDLE1BQU0sUUFBUSxtQkFBbUIsSUFBSSxLQUFLLEtBQUs7RUFDL0MsSUFBSSxVQUFVLEdBQUcsbUJBQW1CLE9BQU8sS0FBSztPQUMzQyxtQkFBbUIsSUFBSSxPQUFPLFFBQVEsQ0FBQztDQUM3QztDQUNBLE1BQU0sRUFBRSxPQUFPLFVBQVUsd0JBQXdCO0NBQ2pELGVBQWUsU0FBUyxTQUFTO0NBQ2pDLE1BQU0sZUFBZSxVQUFVO0VBQzlCLE1BQU0sb0JBQW9CLFlBQVksT0FBTyxNQUFNLEVBQUU7RUFDckQsWUFBWSxJQUFJLE1BQU0sSUFBSSxLQUFLO0VBQy9CLFFBQVEsa0JBQWtCO0dBQ3pCLE1BQU0sWUFBWTtHQUNsQixJQUFJLGVBQWUsY0FBYyxzQkFBc0IsS0FBSztFQUM3RDtDQUNEO0NBQ0EsTUFBTSxtQkFBbUIsWUFBWTtFQUNwQyxNQUFNLFFBQVEsa0JBQWtCLGFBQWEsT0FBTyxLQUFLLG9CQUFvQixPQUFPO0VBQ3BGLE9BQU8sWUFBWSxLQUFLO0NBQ3pCO0NBQ0EsT0FBTyxnQkFBZ0IsRUFBRSxpQkFBaUIsZUFBZSxDQUFDO0NBQzFELE1BQU0saUJBQWlCLFlBQVk7RUFDbEMsTUFBTSxRQUFRLGtCQUFrQixhQUFhLE9BQU87RUFDcEQsSUFBSSxPQUFPO0dBQ1YsTUFBTSxZQUFZO0dBQ2xCLElBQUksUUFBUSxjQUFjLHNCQUFzQixLQUFLO0VBQ3REO0VBQ0EsT0FBTyxDQUFDLENBQUM7Q0FDVjtDQUNBLE9BQU8sZUFBZSxFQUFFLGlCQUFpQixjQUFjLENBQUM7Q0FDeEQsTUFBTSxpQkFBaUIsT0FBTyxPQUFPLFFBQVEsS0FBSyxxQkFBcUI7RUFDdEUsTUFBTSx5QkFBeUIsSUFBSSxnQkFBZ0I7RUFDbkQsTUFBTSxPQUFPLGtCQUFrQixnQkFBZ0IsdUJBQXVCLE1BQU07RUFDNUUsTUFBTSxtQkFBbUIsQ0FBQztFQUMxQixJQUFJO0dBQ0gsTUFBTSxRQUFRLElBQUksc0JBQXNCO0dBQ3hDLHVCQUF1QixLQUFLO0dBQzVCLE1BQU0sUUFBUSxRQUFRLE1BQU0sT0FBTyxRQUFRLE9BQU8sQ0FBQyxHQUFHLEtBQUs7SUFDMUQ7SUFDQSxZQUFZLFdBQVcsWUFBWSxLQUFLLFdBQVcsT0FBTyxDQUFDLENBQUMsS0FBSyxPQUFPO0lBQ3hFO0lBQ0EsT0FBTyxZQUFZLHVCQUF1QixNQUFNO0lBQ2hELE9BQU8sWUFBWSx1QkFBdUIsTUFBTTtJQUNoRDtJQUNBLFFBQVEsdUJBQXVCO0lBQy9CLE1BQU0sV0FBVyx1QkFBdUIsUUFBUSxnQkFBZ0I7SUFDaEUsYUFBYSxNQUFNO0lBQ25CLGlCQUFpQjtLQUNoQixZQUFZLElBQUksTUFBTSxJQUFJLEtBQUs7SUFDaEM7SUFDQSw2QkFBNkI7S0FDNUIsTUFBTSxRQUFRLFNBQVMsWUFBWSxHQUFHLFFBQVE7TUFDN0MsSUFBSSxlQUFlLHdCQUF3QjtPQUMxQyxXQUFXLE1BQU0saUJBQWlCO09BQ2xDLElBQUksT0FBTyxVQUFVO01BQ3RCO0tBQ0QsQ0FBQztJQUNGO0lBQ0EsY0FBYztLQUNiLHVCQUF1QixNQUFNLGlCQUFpQjtLQUM5QyxNQUFNLFFBQVEsT0FBTyxzQkFBc0I7SUFDNUM7SUFDQSx3QkFBd0I7S0FDdkIsZUFBZSx1QkFBdUIsTUFBTTtJQUM3QztHQUNELENBQUMsQ0FBQyxDQUFDO0VBQ0osU0FBUyxlQUFlO0dBQ3ZCLElBQUksRUFBRSx5QkFBeUIsaUJBQWlCLGtCQUFrQixTQUFTLGVBQWUsRUFBRSxVQUFVLFNBQVMsQ0FBQztFQUNqSCxVQUFVO0dBQ1QsTUFBTSxRQUFRLElBQUksZ0JBQWdCO0dBQ2xDLHVCQUF1QixNQUFNLGlCQUFpQjtHQUM5Qyx5QkFBeUIsS0FBSztHQUM5QixNQUFNLFFBQVEsT0FBTyxzQkFBc0I7RUFDNUM7Q0FDRDtDQUNBLE1BQU0sMEJBQTBCLDhCQUE4QixhQUFhLGtCQUFrQjtDQUM3RixNQUFNLGNBQWMsU0FBUyxVQUFVLFdBQVc7RUFDakQsSUFBSSxDQUFDLFNBQVMsTUFBTSxHQUFHLE9BQU8sS0FBSyxNQUFNO0VBQ3pDLElBQUksWUFBWSxNQUFNLE1BQU0sR0FBRyxPQUFPLGVBQWUsT0FBTyxPQUFPO0VBQ25FLElBQUksa0JBQWtCLE1BQU0sTUFBTSxHQUFHO0dBQ3BDLHdCQUF3QjtHQUN4QjtFQUNEO0VBQ0EsSUFBSSxlQUFlLE1BQU0sTUFBTSxHQUFHLE9BQU8sY0FBYyxPQUFPLE9BQU87RUFDckUsSUFBSSxnQkFBZ0IsSUFBSSxTQUFTO0VBQ2pDLE1BQU0seUJBQXlCO0dBQzlCLElBQUksa0JBQWtCLG9CQUFvQixNQUFNLElBQUksTUFBMkUsR0FBRyxJQUFJLG9EQUFvRDtHQUMxTCxPQUFPO0VBQ1I7RUFDQSxJQUFJO0VBQ0osSUFBSTtHQUNILFNBQVMsS0FBSyxNQUFNO0dBQ3BCLElBQUksWUFBWSxPQUFPLEdBQUc7SUFDekIsTUFBTSxlQUFlLElBQUksU0FBUztJQUNsQyxNQUFNLGtCQUFrQixNQUFNLEtBQUssWUFBWSxPQUFPLENBQUM7SUFDdkQsS0FBSyxNQUFNLFNBQVMsaUJBQWlCO0tBQ3BDLElBQUksY0FBYztLQUNsQixJQUFJO01BQ0gsY0FBYyxNQUFNLFVBQVUsUUFBUSxjQUFjLGFBQWE7S0FDbEUsU0FBUyxnQkFBZ0I7TUFDeEIsY0FBYztNQUNkLGtCQUFrQixTQUFTLGdCQUFnQixFQUFFLFVBQVUsWUFBWSxDQUFDO0tBQ3JFO0tBQ0EsSUFBSSxDQUFDLGFBQWE7S0FDbEIsZUFBZSxPQUFPLFFBQVEsS0FBSyxnQkFBZ0I7SUFDcEQ7R0FDRDtFQUNELFVBQVU7R0FDVCxnQkFBZ0I7RUFDakI7RUFDQSxPQUFPO0NBQ1I7Q0FDQSxPQUFPO0VBQ047RUFDQTtFQUNBO0VBQ0EsZ0JBQWdCO0NBQ2pCO0FBQ0Q7QUFHQSxJQUFNLHlCQUF5QixnQkFBZ0I7Q0FDOUM7Q0FDQSx5QkFBeUIsSUFBSSxJQUFJO0FBQ2xDO0FBQ0EsSUFBTSxpQkFBaUIsZ0JBQWdCLFdBQVcsUUFBUSxNQUFNLGVBQWU7QUFDL0UsSUFBTSxnQ0FBZ0M7Q0FDckMsTUFBTSxhQUFhLE9BQU87Q0FDMUIsTUFBTSxnQ0FBZ0MsSUFBSSxJQUFJO0NBQzlDLElBQUksb0JBQW9CO0NBQ3hCLE1BQU0saUJBQWlCLE9BQU8sT0FBTyxhQUFhLDBCQUEwQixHQUFHLGlCQUFpQjtFQUMvRixTQUFTO0VBQ1QsTUFBTSxFQUFFLFdBQVc7Q0FDcEIsRUFBRSxHQUFHLEVBQUUsaUJBQWlCLGVBQWUsQ0FBQztDQUN4QyxNQUFNLGdCQUFnQixPQUFPLE9BQU8sU0FBUyxjQUFjLEdBQUcsYUFBYTtFQUMxRSxNQUFNLGVBQWUsY0FBYztFQUNuQyxZQUFZLFNBQVMsZUFBZTtHQUNuQyxvQkFBb0IsZUFBZSxZQUFZLHFCQUFxQjtFQUNyRSxDQUFDO0VBQ0QsSUFBSSxjQUFjLFNBQVMsY0FBYztDQUMxQyxHQUFHLEVBQUUsaUJBQWlCLGNBQWMsQ0FBQztDQUNyQyxNQUFNLHNCQUFzQixRQUFRO0VBRW5DLE9BQU8sUUFBUSxHQURXLE1BQU0sS0FBSyxjQUFjLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxVQUFVLG9CQUFvQixNQUFNLFNBQVMsS0FBSyxNQUFNLFVBQVUsQ0FDbEgsQ0FBaUI7Q0FDcEM7Q0FDQSxNQUFNLG1CQUFtQixRQUFRLGdCQUFnQixjQUFjLFVBQVUsQ0FBQztDQUMxRSxNQUFNLGNBQWMsU0FBUyxTQUFTO0VBQ3JDLElBQUksaUJBQWlCO0VBQ3JCLElBQUksV0FBVztFQUNmLFFBQVEsV0FBVztHQUNsQixJQUFJLGlCQUFpQixNQUFNLEdBQUc7SUFDN0IsY0FBYyxHQUFHLE9BQU8sT0FBTztJQUMvQixPQUFPLElBQUk7R0FDWjtHQUNBLElBQUksbUJBQW1CLG1CQUFtQjtJQUN6QyxXQUFXLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxJQUFJO0lBQ3ZDLGlCQUFpQjtHQUNsQjtHQUNBLE9BQU8sU0FBUyxNQUFNO0VBQ3ZCO0NBQ0Q7Q0FDQSxPQUFPO0VBQ047RUFDQTtFQUNBO0VBQ0E7Q0FDRDtBQUNEO0FBR0EsSUFBTSxlQUFlLG1CQUFtQixpQkFBaUIsa0JBQWtCLE9BQU8sZUFBZSxnQkFBZ0I7QUFDakgsSUFBTSxlQUFlLFdBQVcsT0FBTyxTQUFTLGVBQWUsWUFBWSxVQUFVLElBQUksQ0FBQyxDQUFDLFdBQVcsYUFBYSxXQUFXLE9BQU8sQ0FBQyxJQUFJLE9BQU8sUUFBUSxVQUFVLENBQUM7QUFDcEssSUFBTSxpQkFBaUIsT0FBTyxJQUFJLDBCQUEwQjtBQUM1RCxJQUFNLGdCQUFnQixVQUFVLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxNQUFNO0FBQ25ELElBQU0sb0JBQW9CLGVBQWUsT0FBTyxZQUFZLHNCQUFzQixvQkFBb0IsZUFBZSxhQUFhLElBQUksTUFBTSxPQUFPLEVBQUUsTUFBTSxRQUFRLE1BQU0sYUFBYTtDQUNyTCxJQUFJLFNBQVMsZ0JBQWdCLE9BQU87Q0FDcEMsTUFBTSxTQUFTLFFBQVEsSUFBSSxRQUFRLE1BQU0sUUFBUTtDQUNqRCxJQUFJLE9BQU8sV0FBVyxhQUFhO0VBQ2xDLE1BQU0sU0FBUyxrQkFBa0I7RUFDakMsSUFBSSxPQUFPLFdBQVcsYUFBYSxPQUFPO0VBQzFDLE1BQU0sVUFBVSxXQUFXO0VBQzNCLElBQUksU0FBUztHQUNaLE1BQU0sZ0JBQWdCLFFBQVEsS0FBSyxHQUFHLEVBQUUsTUFBTSxPQUFPLEVBQUUsQ0FBQztHQUN4RCxJQUFJLE9BQU8sa0JBQWtCLGFBQWEsTUFBTSxJQUFJLE1BQTJFLDhCQUE4QixLQUFLLFNBQVMsRUFBRSxrUkFBa1I7R0FDL2Isa0JBQWtCLFFBQVE7R0FDMUIsT0FBTztFQUNSO0NBQ0Q7Q0FDQSxPQUFPO0FBQ1IsRUFBRSxDQUFDLENBQUM7QUFDSixJQUFNLGNBQWMsVUFBVTtDQUM3QixJQUFJLENBQUMsYUFBYSxLQUFLLEdBQUcsTUFBTSxJQUFJLE1BQTJFLHNDQUFzQztDQUNySixPQUFPLE1BQU07QUFDZDtBQUNBLElBQU0sY0FBYyxDQUFDO0FBQ3JCLElBQU0sZUFBZSxRQUFRLGdCQUFnQjtBQUM3QyxTQUFTLGNBQWMsR0FBRyxRQUFRO0NBQ2pDLE1BQU0sZ0NBQWdDLElBQUksUUFBUTtDQUNsRCxNQUFNLGFBQWEsT0FBTyxZQUFZLFlBQVksTUFBTSxDQUFDO0NBQ3pELE1BQU0sbUJBQW1CLE9BQU8sS0FBSyxVQUFVLENBQUMsQ0FBQyxTQUFTLGdCQUFnQixVQUFVLElBQUk7Q0FDeEYsSUFBSSxVQUFVLFdBQVc7Q0FDekIsU0FBUyxnQkFBZ0IsT0FBTyxRQUFRO0VBQ3ZDLE9BQU8sUUFBUSxPQUFPLE1BQU07Q0FDN0I7Q0FDQSxnQkFBZ0IsNkJBQTZCO0NBQzdDLE1BQU0sb0JBQW9CLENBQUM7Q0FDM0IsTUFBTSxVQUFVLE9BQU8sU0FBUyxDQUFDLE1BQU07RUFDdEMsTUFBTSxFQUFFLGFBQWEsU0FBUyxvQkFBb0I7RUFDbEQsTUFBTSxpQkFBaUIsV0FBVztFQUNsQyxJQUFJLENBQUMsT0FBTyxvQkFBb0Isa0JBQWtCLG1CQUFtQixpQkFBaUI7R0FDckYsSUFBSSxPQUFPLFlBQVksZUFBZSxNQUF3QyxRQUFRLE1BQU0sMERBQTBELFlBQVksK0NBQStDO0dBQ2pOLE9BQU87RUFDUjtFQUNBLElBQUksT0FBTyxvQkFBb0IsbUJBQW1CLGlCQUFpQixPQUFPLGtCQUFrQjtFQUM1RixXQUFXLGVBQWU7RUFDMUIsVUFBVSxXQUFXO0VBQ3JCLE9BQU87Q0FDUjtDQUNBLE1BQU0sV0FBVyxPQUFPLE9BQU8sU0FBUyxhQUFhLFlBQVksYUFBYTtFQUM3RSxPQUFPLFNBQVMsU0FBUyxPQUFPLEdBQUcsTUFBTTtHQUN4QyxPQUFPLFdBQVcsaUJBQWlCLGVBQWUsY0FBYyxZQUFZLE9BQU8sR0FBRyxJQUFJLElBQUksT0FBTyxZQUFZLGlCQUFpQixHQUFHLEdBQUcsSUFBSTtFQUM3STtDQUNELEdBQUcsRUFBRSxVQUFVLFdBQVcsQ0FBQztDQUMzQixPQUFPLE9BQU8sT0FBTyxpQkFBaUI7RUFDckM7RUFDQTtDQUNELENBQUM7QUFDRjtBQUdBLFNBQVMsdUJBQXVCLE1BQU07Q0FDckMsT0FBTyxpQ0FBaUMsS0FBSyxtREFBbUQsS0FBSztBQUN0RyIsInhfZ29vZ2xlX2lnbm9yZUxpc3QiOlswLDEsMiwzLDRdfQ==