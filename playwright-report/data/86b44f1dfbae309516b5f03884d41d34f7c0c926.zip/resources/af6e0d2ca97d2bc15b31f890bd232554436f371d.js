import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/pages/posts/PostPage.tsx");const useEffect = __vite__cjsImport0_react["useEffect"];const useState = __vite__cjsImport3_react["useState"];const _jsxDEV = __vite__cjsImport8_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport8_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=55f59584";
import { useAppDispatch, useAppSelector } from "/src/app/store/hooks/hooks.ts";
import { fetchPosts } from "/src/app/store/PostSlice.ts";
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=55f59584";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
import Toast from "/src/components/toast/Toast.tsx";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=6824eab0";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/PostPage.tsx";
import __vite__cjsImport8_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
const POSTS_PER_PAGE = 10;
const TOAST_DURATION = 3e3;
const PostsPage = () => {
	_s();
	const location = useLocation();
	const navigate = useNavigate();
	const dispatch = useAppDispatch();
	const { t } = useTranslation();
	const isGuest = localStorage.getItem("userType") === "guest";
	const posts = useAppSelector((state) => state.posts.posts);
	const loading = useAppSelector((state) => state.posts.loading);
	const [search, setSearch] = useState("");
	const [page, setPage] = useState(1);
	const [successMessage, setSuccessMessage] = useState(null);
	const showSuccessMessage = (message) => {
		setSuccessMessage(message);
	};
	useEffect(() => {
		if (location.state?.successMessage) {
			showSuccessMessage(location.state.successMessage);
		}
	}, [location.state]);
	useEffect(() => {
		if (!successMessage) {
			return;
		}
		const timer = setTimeout(() => {
			setSuccessMessage(null);
		}, TOAST_DURATION);
		return () => clearTimeout(timer);
	}, [successMessage]);
	//Paginacion
	const filteredPosts = posts.filter((post) => post.title.toLowerCase().includes(search.toLowerCase()));
	const paginatedPosts = filteredPosts.slice((page - 1) * POSTS_PER_PAGE, page * POSTS_PER_PAGE);
	const totalPages = Math.ceil(filteredPosts.length / POSTS_PER_PAGE);
	useEffect(() => {
		dispatch(fetchPosts());
	}, [dispatch]);
	if (loading) {
		return /* @__PURE__ */ _jsxDEV("p", { children: "Loading..." }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 71,
			columnNumber: 16
		}, this);
	}
	;
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: [
		successMessage && /* @__PURE__ */ _jsxDEV(Toast, { message: successMessage }, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 76,
			columnNumber: 29
		}, this),
		/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 79,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "search-input",
			children: /* @__PURE__ */ _jsxDEV("input", {
				value: search,
				onChange: (e) => {
					setSearch(e.target.value);
					setPage(1);
				},
				placeholder: "Buscar por título"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 81,
				columnNumber: 13
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 80,
			columnNumber: 9
		}, this),
		/* @__PURE__ */ _jsxDEV("br", {}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 90,
			columnNumber: 13
		}, this),
		!isGuest && /* @__PURE__ */ _jsxDEV("button", {
			className: "app-button",
			onClick: () => navigate("/posts/create"),
			children: t("app.create")
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 93,
			columnNumber: 13
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "posts-grid",
			children: paginatedPosts.map((post) => /* @__PURE__ */ _jsxDEV("div", {
				className: "posts-card",
				onClick: () => navigate(`/posts/detail/${post.id}`),
				children: [/* @__PURE__ */ _jsxDEV("h3", { children: post.title }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 108,
					columnNumber: 17
				}, this), /* @__PURE__ */ _jsxDEV("p", { children: ["ID: ", post.id] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 110,
					columnNumber: 17
				}, this)]
			}, post.id, true, {
				fileName: _jsxFileName,
				lineNumber: 101,
				columnNumber: 17
			}, this))
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 99,
			columnNumber: 13
		}, this),
		/* @__PURE__ */ _jsxDEV("div", {
			className: "pagination",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					className: "app-button",
					disabled: page === 1,
					onClick: () => setPage(page - 1),
					children: t("app.previous")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 118,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("span", { children: [
					" ",
					page,
					" - ",
					totalPages
				] }, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 123,
					columnNumber: 17
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					className: "app-button",
					disabled: page === totalPages,
					onClick: () => setPage(page + 1),
					children: t("app.next")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 125,
					columnNumber: 17
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 117,
			columnNumber: 13
		}, this)
	] }, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 75,
		columnNumber: 5
	}, this);
};
_s(PostsPage, "f+VL0a++Bqdla4GZC0YMHgGzgvc=", false, function() {
	return [
		useLocation,
		useNavigate,
		useAppDispatch,
		useTranslation,
		useAppSelector,
		useAppSelector
	];
});
_c = PostsPage;
export default PostsPage;
var _c;
$RefreshReg$(_c, "PostsPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app/pages/posts/PostPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/PostPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/PostPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/PostPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxnQkFBZ0Isc0JBQXNCO0FBQy9DLFNBQVMsa0JBQWtCO0FBQzNCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVEsbUJBQWtCO0FBQzFCLFNBQVMsbUJBQW1CO0FBQzVCLE9BQU8sV0FBVztBQUNsQixTQUFTLHNCQUFzQjs7OztBQUcvQixNQUFNLGlCQUFpQjtBQUN2QixNQUFNLGlCQUFpQjtBQUV2QixNQUFNLGtCQUFrQjs7Q0FDcEIsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxXQUFXLGVBQWU7Q0FDaEMsTUFBTSxFQUFFLE1BQU0sZUFBZTtDQUU3QixNQUFNLFVBQVUsYUFBYSxRQUFRLFVBQVUsTUFBTTtDQUVyRCxNQUFNLFFBQVEsZ0JBQWdCLFVBQVUsTUFBTSxNQUFNLEtBQUs7Q0FFekQsTUFBTSxVQUFVLGdCQUFnQixVQUFVLE1BQU0sTUFBTSxPQUFPO0NBRTdELE1BQU0sQ0FBQyxRQUFRLGFBQWEsU0FBUyxFQUFFO0NBQ3ZDLE1BQU0sQ0FBQyxNQUFNLFdBQVcsU0FBUyxDQUFDO0NBQ2xDLE1BQU0sQ0FBQyxnQkFBZ0IscUJBQXFCLFNBQXdCLElBQUk7Q0FFeEUsTUFBTSxzQkFDRixZQUNPO0VBQ1Asa0JBQWtCLE9BQU87Q0FDN0I7Q0FHQSxnQkFBZ0I7RUFDWixJQUFJLFNBQVMsT0FBTyxnQkFBZ0I7R0FDaEMsbUJBQW1CLFNBQVMsTUFBTSxjQUFjO0VBQ3BEO0NBQ0osR0FBRyxDQUFDLFNBQVMsS0FBSyxDQUFDO0NBRW5CLGdCQUFnQjtFQUNaLElBQUksQ0FBQyxnQkFBZ0I7R0FDakI7RUFDSjtFQUVBLE1BQU0sUUFBUSxpQkFBaUI7R0FDM0Isa0JBQWtCLElBQUk7RUFDMUIsR0FBRyxjQUFjO0VBRWpCLGFBQWEsYUFBYSxLQUFLO0NBQ25DLEdBQUcsQ0FBQyxjQUFjLENBQUM7O0NBR25CLE1BQU0sZ0JBQWdCLE1BQU0sUUFBUSxTQUNoQyxLQUFLLE1BQU0sWUFBWSxDQUFDLENBQUMsU0FBUyxPQUFPLFlBQVksQ0FBQyxDQUMxRDtDQUVBLE1BQU0saUJBQWlCLGNBQWMsT0FBTyxPQUFPLEtBQUssZ0JBQWdCLE9BQU8sY0FBYztDQUU3RixNQUFNLGFBQWEsS0FBSyxLQUFLLGNBQWMsU0FBUyxjQUFjO0NBR2xFLGdCQUFnQjtFQUNaLFNBQVMsV0FBVyxDQUFDO0NBQ3pCLEdBQUcsQ0FBQyxRQUFRLENBQUM7Q0FHYixJQUFJLFNBQVM7RUFDVCxPQUFPLHdCQUFDLEtBQUQsWUFBRyxhQUFhOzs7OztDQUMzQjtDQUFDO0NBRUwsT0FDSTtFQUNLLGtCQUFtQix3QkFBQyxPQUFELEVBQU8sU0FBUyxlQUFpQjs7Ozs7RUFHckQsd0JBQUMsTUFBRCxDQUFROzs7OztFQUNSLHdCQUFDLE9BQUQ7R0FBSyxXQUFVO2FBQ1gsd0JBQUMsU0FBRDtJQUNJLE9BQU87SUFDUCxXQUFXLE1BQU07S0FDYixVQUFVLEVBQUUsT0FBTyxLQUFLO0tBQ3hCLFFBQVEsQ0FBQztJQUNiO0lBQ0EsYUFBWTtHQUNmOzs7OztFQUNBOzs7OztFQUNELHdCQUFDLE1BQUQsQ0FBUTs7Ozs7RUFFUCxDQUFDLFdBQ0Ysd0JBQUMsVUFBRDtHQUFRLFdBQVU7R0FDZCxlQUFlLFNBQVMsZUFBZTthQUFJLEVBQUUsWUFBWTtFQUNyRDs7Ozs7RUFJUix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUNWLGVBQWUsS0FBSyxTQUNyQix3QkFBQyxPQUFEO0lBRUksV0FBVTtJQUNWLGVBQ0osU0FBUyxpQkFBaUIsS0FBSyxJQUFJO2NBSm5DLENBT0Esd0JBQUMsTUFBRCxZQUFLLEtBQUssTUFBVTs7OztjQUVwQix3QkFBQyxLQUFELGFBQUcsUUFDTSxLQUFLLEVBQ1g7Ozs7WUFDRTtNQVhJLEtBQUs7Ozs7VUFXVCxDQUNSO0VBQ0k7Ozs7O0VBRUwsd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNJLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO0tBQ2QsVUFBVSxTQUFTO0tBQUcsZUFBZSxRQUFRLE9BQU8sQ0FBQztlQUNwRCxFQUFFLGNBQWM7SUFDYjs7Ozs7SUFFUix3QkFBQyxRQUFEO0tBQU07S0FBRTtLQUFLO0tBQUk7SUFBaUI7Ozs7O0lBRWxDLHdCQUFDLFVBQUQ7S0FBUSxXQUFVO0tBQ2QsVUFBVSxTQUFTO0tBQVksZUFBZSxRQUFRLE9BQU8sQ0FBQztlQUM3RCxFQUFFLFVBQVU7SUFDVDs7Ozs7R0FDUDs7Ozs7O0NBQ1A7Ozs7O0FBRVY7Ozs7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUG9zdFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VBcHBEaXNwYXRjaCwgdXNlQXBwU2VsZWN0b3IgfSBmcm9tIFwiLi4vLi4vc3RvcmUvaG9va3MvaG9va3NcIjtcclxuaW1wb3J0IHsgZmV0Y2hQb3N0cyB9IGZyb20gXCIuLi8uLi9zdG9yZS9Qb3N0U2xpY2VcIjtcclxuaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHt1c2VOYXZpZ2F0ZX0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgVG9hc3QgZnJvbSBcIi4uLy4uLy4uL2NvbXBvbmVudHMvdG9hc3QvVG9hc3RcIjtcclxuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tIFwicmVhY3QtaTE4bmV4dFwiO1xyXG5cclxuXHJcbmNvbnN0IFBPU1RTX1BFUl9QQUdFID0gMTA7XHJcbmNvbnN0IFRPQVNUX0RVUkFUSU9OID0gMzAwMDtcclxuXHJcbmNvbnN0IFBvc3RzUGFnZSA9ICgpID0+IHtcclxuICAgIGNvbnN0IGxvY2F0aW9uID0gdXNlTG9jYXRpb24oKTtcclxuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICAgIGNvbnN0IGRpc3BhdGNoID0gdXNlQXBwRGlzcGF0Y2goKTtcclxuICAgIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcclxuXHJcbiAgICBjb25zdCBpc0d1ZXN0ID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VyVHlwZVwiKSA9PT0gXCJndWVzdFwiO1xyXG5cclxuICAgIGNvbnN0IHBvc3RzID0gdXNlQXBwU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS5wb3N0cy5wb3N0cyk7XHJcblxyXG4gICAgY29uc3QgbG9hZGluZyA9IHVzZUFwcFNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUucG9zdHMubG9hZGluZyk7XHJcblxyXG4gICAgY29uc3QgW3NlYXJjaCwgc2V0U2VhcmNoXSA9IHVzZVN0YXRlKFwiXCIpO1xyXG4gICAgY29uc3QgW3BhZ2UsIHNldFBhZ2VdID0gdXNlU3RhdGUoMSk7XHJcbiAgICBjb25zdCBbc3VjY2Vzc01lc3NhZ2UsIHNldFN1Y2Nlc3NNZXNzYWdlXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xyXG5cclxuICAgIGNvbnN0IHNob3dTdWNjZXNzTWVzc2FnZSA9IChcclxuICAgICAgICBtZXNzYWdlOiBzdHJpbmdcclxuICAgICk6IHZvaWQgPT4ge1xyXG4gICAgICAgIHNldFN1Y2Nlc3NNZXNzYWdlKG1lc3NhZ2UpO1xyXG4gICAgfTtcclxuXHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAobG9jYXRpb24uc3RhdGU/LnN1Y2Nlc3NNZXNzYWdlKSB7XHJcbiAgICAgICAgICAgIHNob3dTdWNjZXNzTWVzc2FnZShsb2NhdGlvbi5zdGF0ZS5zdWNjZXNzTWVzc2FnZSk7XHJcbiAgICAgICAgfVxyXG4gICAgfSwgW2xvY2F0aW9uLnN0YXRlXSk7XHJcblxyXG4gICAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgICAgICBpZiAoIXN1Y2Nlc3NNZXNzYWdlKSB7XHJcbiAgICAgICAgICAgIHJldHVybjtcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGNvbnN0IHRpbWVyID0gc2V0VGltZW91dCgoKSA9PiB7XHJcbiAgICAgICAgICAgIHNldFN1Y2Nlc3NNZXNzYWdlKG51bGwpO1xyXG4gICAgICAgIH0sIFRPQVNUX0RVUkFUSU9OKTtcclxuXHJcbiAgICAgICAgcmV0dXJuICgpID0+IGNsZWFyVGltZW91dCh0aW1lcik7XHJcbiAgICB9LCBbc3VjY2Vzc01lc3NhZ2VdKTtcclxuXHJcbiAgICAvL1BhZ2luYWNpb25cclxuICAgIGNvbnN0IGZpbHRlcmVkUG9zdHMgPSBwb3N0cy5maWx0ZXIoKHBvc3QpID0+XHJcbiAgICAgICAgcG9zdC50aXRsZS50b0xvd2VyQ2FzZSgpLmluY2x1ZGVzKHNlYXJjaC50b0xvd2VyQ2FzZSgpKVxyXG4gICAgKTtcclxuXHJcbiAgICBjb25zdCBwYWdpbmF0ZWRQb3N0cyA9IGZpbHRlcmVkUG9zdHMuc2xpY2UoKHBhZ2UgLSAxKSAqIFBPU1RTX1BFUl9QQUdFLCBwYWdlICogUE9TVFNfUEVSX1BBR0UpO1xyXG5cclxuICAgIGNvbnN0IHRvdGFsUGFnZXMgPSBNYXRoLmNlaWwoZmlsdGVyZWRQb3N0cy5sZW5ndGggLyBQT1NUU19QRVJfUEFHRSk7XHJcblxyXG5cclxuICAgIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICAgICAgZGlzcGF0Y2goZmV0Y2hQb3N0cygpKTtcclxuICAgIH0sIFtkaXNwYXRjaF0pO1xyXG5cclxuXHJcbiAgICBpZiAobG9hZGluZykge1xyXG4gICAgICAgIHJldHVybiA8cD5Mb2FkaW5nLi4uPC9wPjtcclxuICAgIH07XHJcblxyXG5yZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgICB7c3VjY2Vzc01lc3NhZ2UgJiYgKDxUb2FzdCBtZXNzYWdlPXtzdWNjZXNzTWVzc2FnZX0gLz5cclxuICAgICAgICApfVxyXG4gICAgICAgICAgICBcclxuICAgICAgICA8YnI+PC9icj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNlYXJjaC1pbnB1dFwiPlxyXG4gICAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgICAgIHZhbHVlPXtzZWFyY2h9XHJcbiAgICAgICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBzZXRTZWFyY2goZS50YXJnZXQudmFsdWUpO1xyXG4gICAgICAgICAgICAgICAgICAgIHNldFBhZ2UoMSk7IC8vIFJlc2V0ZWFyIGEgbGEgcHJpbWVyYSBww6FnaW5hIGFsIGNhbWJpYXIgbGEgYsO6c3F1ZWRhXHJcbiAgICAgICAgICAgICAgICB9fVxyXG4gICAgICAgICAgICAgICAgcGxhY2Vob2xkZXI9XCJCdXNjYXIgcG9yIHTDrXR1bG9cIlxyXG4gICAgICAgICAgICAvPiAgICAgICAgICAgIFxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgICA8YnI+PC9icj5cclxuXHJcbiAgICAgICAgICAgIHshaXNHdWVzdCAmJiAoXHJcbiAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYXBwLWJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZShcIi9wb3N0cy9jcmVhdGVcIil9Pnt0KFwiYXBwLmNyZWF0ZVwiKX1cclxuICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgICl9XHJcblxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJwb3N0cy1ncmlkXCI+XHJcbiAgICAgICAgICAgICAgICB7cGFnaW5hdGVkUG9zdHMubWFwKChwb3N0KSA9PiAoXHJcbiAgICAgICAgICAgICAgICA8ZGl2XHJcbiAgICAgICAgICAgICAgICAgICAga2V5PXtwb3N0LmlkfVxyXG4gICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInBvc3RzLWNhcmRcIlxyXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICBuYXZpZ2F0ZShgL3Bvc3RzL2RldGFpbC8ke3Bvc3QuaWR9YCl9PlxyXG4gICAgICAgICAgICBcclxuICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgPGgzPntwb3N0LnRpdGxlfTwvaDM+XHJcblxyXG4gICAgICAgICAgICAgICAgPHA+XHJcbiAgICAgICAgICAgICAgICAgICAgSUQ6IHtwb3N0LmlkfVxyXG4gICAgICAgICAgICAgICAgPC9wPlxyXG4gICAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICkpfVxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgICAgXHJcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicGFnaW5hdGlvblwiPlxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhcHAtYnV0dG9uXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UgPT09IDF9IG9uQ2xpY2s9eygpID0+IHNldFBhZ2UocGFnZSAtIDEpfT5cclxuICAgICAgICAgICAgICAgICAgICB7dChcImFwcC5wcmV2aW91c1wiKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgIDxzcGFuPiB7cGFnZX0gLSB7dG90YWxQYWdlc308L3NwYW4+XHJcblxyXG4gICAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJhcHAtYnV0dG9uXCIgXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzYWJsZWQ9e3BhZ2UgPT09IHRvdGFsUGFnZXN9IG9uQ2xpY2s9eygpID0+IHNldFBhZ2UocGFnZSArIDEpfT5cclxuICAgICAgICAgICAgICAgICAgICB7dChcImFwcC5uZXh0XCIpfVxyXG4gICAgICAgICAgICAgICAgPC9idXR0b24+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDwvPlxyXG4gICAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFBvc3RzUGFnZTsiXX0=