import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Header.tsx");const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport5_react_jsxDevRuntime["Fragment"];import { Link, useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
import { useTheme } from "/src/app/store/hooks/theme.ts";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=6824eab0";
import LanguageSelector from "/src/components/layout/languageSelector.tsx";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/Header.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
export const Header = () => {
	_s();
	const navigate = useNavigate();
	const location = useLocation();
	const { theme, setTheme } = useTheme();
	const { t } = useTranslation();
	if (location.pathname === "/") {
		return null;
	}
	const handleuLogout = () => {
		localStorage.removeItem("isAuthenticated");
		localStorage.removeItem("userType");
		navigate("/");
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("header", {
		className: "app-header",
		children: [/* @__PURE__ */ _jsxDEV("nav", {
			className: "app-headerNav",
			children: [
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/",
					children: t("app.home")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 21
				}, this),
				" | ",
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/posts",
					children: "Posts"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 30,
					columnNumber: 21
				}, this),
				" | ",
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/dashboard",
					children: t("app.dashboard")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 32,
					columnNumber: 21
				}, this),
				" | ",
				/* @__PURE__ */ _jsxDEV(Link, {
					to: "/profile",
					children: t("app.profile")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 34,
					columnNumber: 21
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 27,
			columnNumber: 17
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "header-actions",
			children: [
				/* @__PURE__ */ _jsxDEV("button", {
					"data-testid": "theme-toggle",
					className: "theme-button",
					onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
					children: theme === "dark" ? "☀️" : "🌙"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 38,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV(LanguageSelector, {}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 21
				}, this),
				/* @__PURE__ */ _jsxDEV("button", {
					className: "logout-link",
					onClick: handleuLogout,
					children: t("app.logout")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 54,
					columnNumber: 21
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 37,
			columnNumber: 17
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 26,
		columnNumber: 13
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 25,
		columnNumber: 9
	}, this);
};
_s(Header, "MWIAygGQFkuKCccpZneNpoKeikk=", false, function() {
	return [
		useNavigate,
		useLocation,
		useTheme,
		useTranslation
	];
});
_c = Header;
export default Header;
var _c;
$RefreshReg$(_c, "Header");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Header.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/Header.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/Header.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/Header.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxNQUFNLG1CQUFtQjtBQUNsQyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLGdCQUFnQjtBQUN6QixTQUFTLHNCQUFzQjtBQUMvQixPQUFPLHNCQUFzQjs7OztBQUU3QixPQUFPLE1BQU0sZUFBZTs7Q0FDeEIsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxFQUFDLE9BQU8sYUFBWSxTQUFTO0NBQ25DLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FFN0IsSUFBSSxTQUFTLGFBQWEsS0FBSztFQUMzQixPQUFPO0NBQ1g7Q0FFQSxNQUFNLHNCQUE0QjtFQUM5QixhQUFhLFdBQVcsaUJBQWlCO0VBQ3pDLGFBQWEsV0FBVyxVQUFVO0VBRWxDLFNBQVMsR0FBRztDQUNoQjtDQUVBLE9BQ0ksK0NBQ0ksd0JBQUMsVUFBRDtFQUFRLFdBQVU7WUFBbEIsQ0FDSSx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0ksd0JBQUMsTUFBRDtLQUFNLElBQUc7ZUFBSyxFQUFFLFVBQVU7SUFBUTs7Ozs7SUFDakM7SUFDRCx3QkFBQyxNQUFEO0tBQU0sSUFBRztlQUFTO0lBQVc7Ozs7O0lBQzVCO0lBQ0Qsd0JBQUMsTUFBRDtLQUFNLElBQUc7ZUFBYyxFQUFFLGVBQWU7SUFBUTs7Ozs7SUFDL0M7SUFDRCx3QkFBQyxNQUFEO0tBQU0sSUFBRztlQUFZLEVBQUUsYUFBYTtJQUFROzs7OztHQUMzQzs7Ozs7WUFFTCx3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmO0lBQ0ksd0JBQUMsVUFBRDtLQUFRLGVBQVk7S0FBZSxXQUFVO0tBQ3pDLGVBQ0ksU0FDSSxVQUFVLFNBQ0osVUFDQSxNQUNWO2VBR0gsVUFBVSxTQUNMLE9BQ0E7SUFDRjs7Ozs7SUFFUix3QkFBQyxrQkFBRCxDQUFtQjs7Ozs7SUFFbkIsd0JBQUMsVUFBRDtLQUFRLFdBQVU7S0FBYyxTQUFTO2VBQ3BDLEVBQUUsWUFBWTtJQUNYOzs7OztHQUNQOzs7OztVQUVEOzs7OztVQUNWOzs7OztBQUVWOzs7Ozs7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJIZWFkZXIudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IExpbmssIHVzZUxvY2F0aW9uIH0gZnJvbSBcInJlYWN0LXJvdXRlci1kb21cIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VUaGVtZSB9IGZyb20gXCIuLi8uLi9hcHAvc3RvcmUvaG9va3MvdGhlbWVcIjtcclxuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tIFwicmVhY3QtaTE4bmV4dFwiO1xyXG5pbXBvcnQgTGFuZ3VhZ2VTZWxlY3RvciBmcm9tIFwiLi9sYW5ndWFnZVNlbGVjdG9yXCI7XHJcblxyXG5leHBvcnQgY29uc3QgSGVhZGVyID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gICAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xyXG4gICAgY29uc3Qge3RoZW1lLCBzZXRUaGVtZX0gPSB1c2VUaGVtZSgpO1xyXG4gICAgY29uc3QgeyB0IH0gPSB1c2VUcmFuc2xhdGlvbigpO1xyXG5cclxuICAgIGlmIChsb2NhdGlvbi5wYXRobmFtZSA9PT0gXCIvXCIpIHtcclxuICAgICAgICByZXR1cm4gbnVsbDtcclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBoYW5kbGV1TG9nb3V0ID0gKCk6IHZvaWQgPT4ge1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwiaXNBdXRoZW50aWNhdGVkXCIpO1xyXG4gICAgICAgIGxvY2FsU3RvcmFnZS5yZW1vdmVJdGVtKFwidXNlclR5cGVcIik7XHJcblxyXG4gICAgICAgIG5hdmlnYXRlKFwiL1wiKTtcclxuICAgIH07XHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8PlxyXG4gICAgICAgICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cImFwcC1oZWFkZXJcIj5cclxuICAgICAgICAgICAgICAgIDxuYXYgY2xhc3NOYW1lPVwiYXBwLWhlYWRlck5hdlwiPlxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL1wiPnt0KFwiYXBwLmhvbWVcIil9PC9MaW5rPlxyXG4gICAgICAgICAgICAgICAgICAgIHtcIiB8IFwifVxyXG4gICAgICAgICAgICAgICAgICAgIDxMaW5rIHRvPVwiL3Bvc3RzXCI+UG9zdHM8L0xpbms+XHJcbiAgICAgICAgICAgICAgICAgICAge1wiIHwgXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPExpbmsgdG89XCIvZGFzaGJvYXJkXCI+e3QoXCJhcHAuZGFzaGJvYXJkXCIpfTwvTGluaz5cclxuICAgICAgICAgICAgICAgICAgICB7XCIgfCBcIn1cclxuICAgICAgICAgICAgICAgICAgICA8TGluayB0bz1cIi9wcm9maWxlXCI+e3QoXCJhcHAucHJvZmlsZVwiKX08L0xpbms+XHJcbiAgICAgICAgICAgICAgICA8L25hdj5cclxuXHJcbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImhlYWRlci1hY3Rpb25zXCI+XHJcbiAgICAgICAgICAgICAgICAgICAgPGJ1dHRvbiBkYXRhLXRlc3RpZD1cInRoZW1lLXRvZ2dsZVwiIGNsYXNzTmFtZT1cInRoZW1lLWJ1dHRvblwiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzZXRUaGVtZShcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGVtZSA9PT0gXCJkYXJrXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBcImxpZ2h0XCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBcImRhcmtcIlxyXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgICAgPlxyXG4gICAgICAgICAgICAgICAgICAgICAgICB7dGhlbWUgPT09IFwiZGFya1wiXHJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICA/IFwi4piA77iPXCJcclxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDogXCLwn4yZXCJ9XHJcbiAgICAgICAgICAgICAgICAgICAgPC9idXR0b24+XHJcblxyXG4gICAgICAgICAgICAgICAgICAgIDxMYW5ndWFnZVNlbGVjdG9yIC8+ICAgIFxyXG5cclxuICAgICAgICAgICAgICAgICAgICA8YnV0dG9uIGNsYXNzTmFtZT1cImxvZ291dC1saW5rXCIgb25DbGljaz17aGFuZGxldUxvZ291dH0+XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHt0KFwiYXBwLmxvZ291dFwiKX1cclxuICAgICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgPC9oZWFkZXI+XHJcbiAgICAgICAgPC8+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgSGVhZGVyOyJdfQ==