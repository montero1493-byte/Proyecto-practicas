const StrictMode = __vite__cjsImport0_react["StrictMode"];const createRoot = __vite__cjsImport1_reactDom_client["createRoot"];const _jsxDEV = __vite__cjsImport7_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=55f59584";
import __vite__cjsImport1_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=a82ac997";
import { Provider } from "/node_modules/.vite/deps/react-redux.js?v=ce7770b7";
import "/src/i18n/index.ts";
import App from "/src/App.tsx";
import { store } from "/src/app/store/store.ts";
import "/src/index.css";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/main.tsx";
import __vite__cjsImport7_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
createRoot(document.getElementById("root")).render(/* @__PURE__ */ _jsxDEV(StrictMode, { children: /* @__PURE__ */ _jsxDEV(Provider, {
	store,
	children: /* @__PURE__ */ _jsxDEV(App, {}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 13
	}, this)
}, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 12,
	columnNumber: 9
}, this) }, void 0, false, {
	fileName: _jsxFileName,
	lineNumber: 11,
	columnNumber: 5
}, this));

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxnQkFBZ0I7QUFDekIsT0FBTztBQUNQLE9BQU8sU0FBUztBQUNoQixTQUFTLGFBQWE7QUFFdEIsT0FBTzs7O0FBRVAsV0FBVyxTQUFTLGVBQWUsTUFBTSxDQUFFLENBQUMsQ0FBQyxPQUN6Qyx3QkFBQyxZQUFELFlBQ0ksd0JBQUMsVUFBRDtDQUFpQjtXQUNiLHdCQUFDLEtBQUQsQ0FBTTs7Ozs7QUFDQTs7OztTQUNGOzs7O1FBQ2hCIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIm1haW4udHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFN0cmljdE1vZGUgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IHsgY3JlYXRlUm9vdCB9IGZyb20gXCJyZWFjdC1kb20vY2xpZW50XCI7XHJcbmltcG9ydCB7IFByb3ZpZGVyIH0gZnJvbSBcInJlYWN0LXJlZHV4XCI7XHJcbmltcG9ydCBcIi4vaTE4blwiO1xyXG5pbXBvcnQgQXBwIGZyb20gXCIuL0FwcC50c3hcIjtcclxuaW1wb3J0IHsgc3RvcmUgfSBmcm9tIFwiLi9hcHAvc3RvcmUvc3RvcmUudHNcIjtcclxuXHJcbmltcG9ydCBcIi4vaW5kZXguY3NzXCI7XHJcblxyXG5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicm9vdFwiKSEpLnJlbmRlcihcclxuICAgIDxTdHJpY3RNb2RlPlxyXG4gICAgICAgIDxQcm92aWRlciBzdG9yZT17c3RvcmV9PlxyXG4gICAgICAgICAgICA8QXBwIC8+XHJcbiAgICAgICAgPC9Qcm92aWRlcj5cclxuICAgIDwvU3RyaWN0TW9kZT5cclxuKTsiXX0=