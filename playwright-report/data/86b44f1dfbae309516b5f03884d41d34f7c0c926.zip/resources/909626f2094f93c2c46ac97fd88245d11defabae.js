import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/Breadcrumbs.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { useLocation } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/Breadcrumbs.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
export const Breadcrumbs = () => {
	_s();
	const location = useLocation();
	const paths = location.pathname.split("/").filter(Boolean);
	return /* @__PURE__ */ _jsxDEV("div", { children: paths.length === 0 ? "Home" : `Home / ${paths.join(" / ")}` }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 9,
		columnNumber: 9
	}, this);
};
_s(Breadcrumbs, "pkHmaVRPskBaU4tMJuJJpV42k1I=", false, function() {
	return [useLocation];
});
_c = Breadcrumbs;
export default Breadcrumbs;
var _c;
$RefreshReg$(_c, "Breadcrumbs");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/Breadcrumbs.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/Breadcrumbs.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/Breadcrumbs.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/Breadcrumbs.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxtQkFBbUI7Ozs7QUFFNUIsT0FBTyxNQUFNLG9CQUFvQjs7Q0FDN0IsTUFBTSxXQUFXLFlBQVk7Q0FFN0IsTUFBTSxRQUFRLFNBQVMsU0FBUyxNQUFNLEdBQUcsQ0FBQyxDQUFDLE9BQU8sT0FBTztDQUV6RCxPQUNJLHdCQUFDLE9BQUQsWUFDSyxNQUFNLFdBQVcsSUFDWixTQUNBLFVBQVUsTUFBTSxLQUFLLEtBQUssSUFDL0I7Ozs7O0FBRWI7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJCcmVhZGNydW1icy50c3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlTG9jYXRpb24gfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IEJyZWFkY3J1bWJzID0gKCkgPT4ge1xyXG4gICAgY29uc3QgbG9jYXRpb24gPSB1c2VMb2NhdGlvbigpO1xyXG5cclxuICAgIGNvbnN0IHBhdGhzID0gbG9jYXRpb24ucGF0aG5hbWUuc3BsaXQoXCIvXCIpLmZpbHRlcihCb29sZWFuKTtcclxuXHJcbiAgICByZXR1cm4gKFxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIHtwYXRocy5sZW5ndGggPT09IDBcclxuICAgICAgICAgICAgICAgID8gXCJIb21lXCJcclxuICAgICAgICAgICAgICAgIDogYEhvbWUgLyAke3BhdGhzLmpvaW4oXCIgLyBcIil9YH1cclxuICAgICAgICA8L2Rpdj5cclxuICAgICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBCcmVhZGNydW1iczsiXX0=