import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/pages/home/HomePage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport3_react_jsxDevRuntime["jsxDEV"]; const _Fragment = __vite__cjsImport3_react_jsxDevRuntime["Fragment"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=55f59584";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=6824eab0";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/home/HomePage.tsx";
import __vite__cjsImport3_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
const HomePage = () => {
	_s();
	const navigate = useNavigate();
	const { t } = useTranslation();
	const [username, setUsername] = useState("");
	const [password, setPassword] = useState("");
	const handleLogin = (event) => {
		event.preventDefault();
		if (!username.trim() || !password.trim()) {
			alert("completa todos los campos");
			return;
		}
		localStorage.setItem("isAuthenticated", "true");
		localStorage.setItem("userType", "registered");
		localStorage.setItem("username", username);
		navigate("/posts");
	};
	const handleGuestLogin = () => {
		localStorage.setItem("isAuthenticated", "true");
		localStorage.setItem("userType", "guest");
		navigate("/posts");
	};
	return /* @__PURE__ */ _jsxDEV(_Fragment, { children: /* @__PURE__ */ _jsxDEV("div", {
		className: "login-page",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "login-card",
			children: [/* @__PURE__ */ _jsxDEV("h1", { children: t("homepage.title") }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 54,
				columnNumber: 13
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				className: "login-form",
				onSubmit: handleLogin,
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "username",
						children: t("homepage.user")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 58,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "username",
						type: "text",
						value: username,
						onChange: (event) => setUsername(event.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 62,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 57,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", {
						htmlFor: "password",
						children: t("homepage.password")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 70,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						id: "password",
						type: "password",
						value: password,
						onChange: (event) => setPassword(event.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 74,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 69,
						columnNumber: 15
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "login-button ",
						children: [/* @__PURE__ */ _jsxDEV("button", {
							className: "app-button",
							type: "submit",
							children: t("homepage.login")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 83,
							columnNumber: 17
						}, this), /* @__PURE__ */ _jsxDEV("button", {
							className: "app-button",
							type: "button",
							onClick: handleGuestLogin,
							children: t("homepage.guest")
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 87,
							columnNumber: 17
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 82,
						columnNumber: 15
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 56,
				columnNumber: 13
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 53,
			columnNumber: 9
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 52,
		columnNumber: 7
	}, this) }, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 51,
		columnNumber: 5
	}, this);
};
_s(HomePage, "viS4+fo1L1LnoSfuZN0F1eUuMMU=", false, function() {
	return [useNavigate, useTranslation];
});
_c = HomePage;
export default HomePage;
var _c;
$RefreshReg$(_c, "HomePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app/pages/home/HomePage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/home/HomePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/home/HomePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/home/HomePage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxzQkFBc0I7Ozs7QUFFL0IsTUFBTSxpQkFBaUI7O0NBQ3JCLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FFN0IsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FDM0MsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFTLEVBQUU7Q0FFM0MsTUFBTSxlQUNKLFVBQTRDO0VBQzFDLE1BQU0sZUFBZTtFQUVyQixJQUFJLENBQUMsU0FBUyxLQUFLLEtBQUssQ0FBQyxTQUFTLEtBQUssR0FBRztHQUMxQyxNQUFNLDJCQUEyQjtHQUNqQztFQUNGO0VBRUUsYUFBYSxRQUNYLG1CQUNBLE1BQU07RUFFUixhQUFhLFFBQ1gsWUFDQSxZQUFZO0VBRWQsYUFBYSxRQUNYLFlBQ0EsUUFBUTtFQUVWLFNBQVMsUUFBUTtDQUNuQjtDQUVGLE1BQU0seUJBQXlCO0VBQzdCLGFBQWEsUUFDWCxtQkFDQSxNQUNGO0VBRUEsYUFBYSxRQUNYLFlBQ0EsT0FDRjtFQUVBLFNBQVMsUUFBUTtDQUNuQjtDQUVBLE9BQ0UsK0NBQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0ksd0JBQUMsTUFBRCxZQUFLLEVBQUUsZ0JBQWdCLEVBQU07Ozs7YUFFN0Isd0JBQUMsUUFBRDtJQUFNLFdBQVU7SUFBYSxVQUFVO2NBQXZDO0tBQ0Usd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO2dCQUNaLEVBQUUsZUFBZTtLQUNiOzs7O2VBRVAsd0JBQUMsU0FBRDtNQUNFLElBQUc7TUFDSCxNQUFLO01BQ0wsT0FBTztNQUNQLFdBQVcsVUFDVCxZQUFZLE1BQU0sT0FBTyxLQUFLO0tBQUc7Ozs7YUFDbEM7Ozs7O0tBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQ7TUFBTyxTQUFRO2dCQUNaLEVBQUUsbUJBQW1CO0tBQ2pCOzs7O2VBRVAsd0JBQUMsU0FBRDtNQUNFLElBQUc7TUFDSCxNQUFLO01BQ0wsT0FBTztNQUNQLFdBQVcsVUFDVCxZQUFZLE1BQU0sT0FBTyxLQUFLO0tBQUc7Ozs7YUFDbEM7Ozs7O0tBRUwsd0JBQUMsT0FBRDtNQUFLLFdBQVU7Z0JBQWYsQ0FDRSx3QkFBQyxVQUFEO09BQVEsV0FBVTtPQUFhLE1BQUs7aUJBQ2pDLEVBQUUsZ0JBQWdCO01BQ2I7Ozs7Z0JBRVIsd0JBQUMsVUFBRDtPQUFRLFdBQVU7T0FBYSxNQUFLO09BQ3BDLFNBQVM7aUJBQ04sRUFBRSxnQkFBZ0I7TUFDYjs7OztjQUNMOzs7Ozs7SUFFRDs7Ozs7V0FHTDs7Ozs7O0NBQ0Y7Ozs7VUFDTDs7Ozs7QUFFTjs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkhvbWVQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gXCJyZWFjdC1yb3V0ZXItZG9tXCI7XHJcbmltcG9ydCB7IHVzZVRyYW5zbGF0aW9uIH0gZnJvbSBcInJlYWN0LWkxOG5leHRcIjtcclxuXHJcbmNvbnN0IEhvbWVQYWdlID0gKCkgPT4ge1xyXG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcclxuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XHJcblxyXG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoXCJcIik7XHJcbiAgY29uc3QgW3Bhc3N3b3JkLCBzZXRQYXNzd29yZF0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgaGFuZGxlTG9naW4gPSAoXHJcbiAgICBldmVudDogUmVhY3QuRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pID0+IHtcclxuICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICAgIGlmICghdXNlcm5hbWUudHJpbSgpIHx8ICFwYXNzd29yZC50cmltKCkpIHtcclxuICAgICAgYWxlcnQoXCJjb21wbGV0YSB0b2RvcyBsb3MgY2FtcG9zXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcclxuICAgICAgICBcImlzQXV0aGVudGljYXRlZFwiLFxyXG4gICAgICAgIFwidHJ1ZVwiKTtcclxuXHJcbiAgICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFxyXG4gICAgICAgIFwidXNlclR5cGVcIixcclxuICAgICAgICBcInJlZ2lzdGVyZWRcIik7XHJcblxyXG4gICAgICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbShcclxuICAgICAgICBcInVzZXJuYW1lXCIsXHJcbiAgICAgICAgdXNlcm5hbWUpO1xyXG5cclxuICAgICAgbmF2aWdhdGUoXCIvcG9zdHNcIik7XHJcbiAgICB9O1xyXG5cclxuICBjb25zdCBoYW5kbGVHdWVzdExvZ2luID0gKCkgPT4ge1xyXG4gICAgbG9jYWxTdG9yYWdlLnNldEl0ZW0oXHJcbiAgICAgIFwiaXNBdXRoZW50aWNhdGVkXCIsXHJcbiAgICAgIFwidHJ1ZVwiXHJcbiAgICApO1xyXG5cclxuICAgIGxvY2FsU3RvcmFnZS5zZXRJdGVtKFxyXG4gICAgICBcInVzZXJUeXBlXCIsXHJcbiAgICAgIFwiZ3Vlc3RcIlxyXG4gICAgKTtcclxuXHJcbiAgICBuYXZpZ2F0ZShcIi9wb3N0c1wiKTtcclxuICB9O1xyXG4gIFxyXG4gIHJldHVybiAoXHJcbiAgICA8PlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLXBhZ2VcIj5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLWNhcmRcIj5cclxuICAgICAgICAgICAgPGgxPnt0KFwiaG9tZXBhZ2UudGl0bGVcIil9PC9oMT5cclxuXHJcbiAgICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT1cImxvZ2luLWZvcm1cIiBvblN1Ym1pdD17aGFuZGxlTG9naW59PlxyXG4gICAgICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgICAgICA8bGFiZWwgaHRtbEZvcj1cInVzZXJuYW1lXCI+XHJcbiAgICAgICAgICAgICAgICAgIHt0KFwiaG9tZXBhZ2UudXNlclwiKX1cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwidXNlcm5hbWVcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwidGV4dFwiXHJcbiAgICAgICAgICAgICAgICAgIHZhbHVlPXt1c2VybmFtZX1cclxuICAgICAgICAgICAgICAgICAgb25DaGFuZ2U9eyhldmVudCkgPT5cclxuICAgICAgICAgICAgICAgICAgICBzZXRVc2VybmFtZShldmVudC50YXJnZXQudmFsdWUpfS8+XHJcbiAgICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgICAgIDxsYWJlbCBodG1sRm9yPVwicGFzc3dvcmRcIj5cclxuICAgICAgICAgICAgICAgICAge3QoXCJob21lcGFnZS5wYXNzd29yZFwiKX1cclxuICAgICAgICAgICAgICAgIDwvbGFiZWw+XHJcblxyXG4gICAgICAgICAgICAgICAgPGlucHV0XHJcbiAgICAgICAgICAgICAgICAgIGlkPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICB0eXBlPVwicGFzc3dvcmRcIlxyXG4gICAgICAgICAgICAgICAgICB2YWx1ZT17cGFzc3dvcmR9XHJcbiAgICAgICAgICAgICAgICAgIG9uQ2hhbmdlPXsoZXZlbnQpID0+XHJcbiAgICAgICAgICAgICAgICAgICAgc2V0UGFzc3dvcmQoZXZlbnQudGFyZ2V0LnZhbHVlKX0vPlxyXG4gICAgICAgICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxvZ2luLWJ1dHRvbiBcIj5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYXBwLWJ1dHRvblwiIHR5cGU9XCJzdWJtaXRcIj5cclxuICAgICAgICAgICAgICAgICAge3QoXCJob21lcGFnZS5sb2dpblwiKX1cclxuICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxyXG5cclxuICAgICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwiYXBwLWJ1dHRvblwiIHR5cGU9XCJidXR0b25cIlxyXG4gICAgICAgICAgICAgICAgb25DbGljaz17aGFuZGxlR3Vlc3RMb2dpbn0+XHJcbiAgICAgICAgICAgICAgICAgIHt0KFwiaG9tZXBhZ2UuZ3Vlc3RcIil9XHJcbiAgICAgICAgICAgICAgICA8L2J1dHRvbj5cclxuICAgICAgICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgICAgIDwvZm9ybT5cclxuXHJcbiAgICAgICAgICAgIFxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj5cclxuICAgIDwvPlxyXG4gICk7XHJcbn07XHJcblxyXG5leHBvcnQgZGVmYXVsdCBIb21lUGFnZTsiXX0=