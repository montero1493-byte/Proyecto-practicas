//#region node_modules/.pnpm/i18next@26.6.0_typescript@6.0.3/node_modules/i18next/dist/esm/i18next.js
var isString = (obj) => typeof obj === "string";
var defer = () => {
	let res;
	let rej;
	const promise = new Promise((resolve, reject) => {
		res = resolve;
		rej = reject;
	});
	promise.resolve = res;
	promise.reject = rej;
	return promise;
};
var makeString = (object) => {
	if (object == null) return "";
	return String(object);
};
var copy = (a, s, t) => {
	a.forEach((m) => {
		if (s[m]) t[m] = s[m];
	});
};
var lastOfPathSeparatorRegExp = /###/g;
var cleanKey = (key) => key && key.includes("###") ? key.replace(lastOfPathSeparatorRegExp, ".") : key;
var canNotTraverseDeeper = (object) => !object || isString(object);
var getLastOfPath = (object, path, Empty) => {
	const stack = !isString(path) ? path : path.split(".");
	let stackIndex = 0;
	while (stackIndex < stack.length - 1) {
		if (canNotTraverseDeeper(object)) return {};
		const key = cleanKey(stack[stackIndex]);
		if (!object[key] && Empty) object[key] = new Empty();
		if (Object.prototype.hasOwnProperty.call(object, key)) object = object[key];
		else object = {};
		++stackIndex;
	}
	if (canNotTraverseDeeper(object)) return {};
	return {
		obj: object,
		k: cleanKey(stack[stackIndex])
	};
};
var setPath = (object, path, newValue) => {
	const { obj, k } = getLastOfPath(object, path, Object);
	if (obj !== void 0 || path.length === 1) {
		obj[k] = newValue;
		return;
	}
	let e = path[path.length - 1];
	let p = path.slice(0, path.length - 1);
	let last = getLastOfPath(object, p, Object);
	while (last.obj === void 0 && p.length) {
		e = `${p[p.length - 1]}.${e}`;
		p = p.slice(0, p.length - 1);
		last = getLastOfPath(object, p, Object);
		if (last?.obj && typeof last.obj[`${last.k}.${e}`] !== "undefined") last.obj = void 0;
	}
	last.obj[`${last.k}.${e}`] = newValue;
};
var pushPath = (object, path, newValue, concat) => {
	const { obj, k } = getLastOfPath(object, path, Object);
	obj[k] = obj[k] || [];
	obj[k].push(newValue);
};
var getPath = (object, path) => {
	const { obj, k } = getLastOfPath(object, path);
	if (!obj) return void 0;
	if (!Object.prototype.hasOwnProperty.call(obj, k)) return void 0;
	return obj[k];
};
var getPathWithDefaults = (data, defaultData, key) => {
	const value = getPath(data, key);
	if (value !== void 0) return value;
	return getPath(defaultData, key);
};
var deepExtend = (target, source, overwrite) => {
	for (const prop in source) if (prop !== "__proto__" && prop !== "constructor") {
		if (Object.prototype.hasOwnProperty.call(target, prop)) {
			if (isString(target[prop]) || target[prop] instanceof String || isString(source[prop]) || source[prop] instanceof String) {
				if (overwrite) target[prop] = source[prop];
			} else deepExtend(target[prop], source[prop], overwrite);
		} else target[prop] = source[prop];
	}
	return target;
};
var regexEscape = (str) => str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
var _entityMap = {
	"&": "&amp;",
	"<": "&lt;",
	">": "&gt;",
	"\"": "&quot;",
	"'": "&#39;",
	"/": "&#x2F;"
};
var escape = (data) => {
	if (isString(data)) return data.replace(/[&<>"'\/]/g, (s) => _entityMap[s]);
	return data;
};
var RegExpCache = class {
	constructor(capacity) {
		this.capacity = capacity;
		this.regExpMap = /* @__PURE__ */ new Map();
		this.regExpQueue = [];
	}
	getRegExp(pattern) {
		const regExpFromCache = this.regExpMap.get(pattern);
		if (regExpFromCache !== void 0) return regExpFromCache;
		const regExpNew = new RegExp(pattern);
		if (this.regExpQueue.length === this.capacity) this.regExpMap.delete(this.regExpQueue.shift());
		this.regExpMap.set(pattern, regExpNew);
		this.regExpQueue.push(pattern);
		return regExpNew;
	}
};
var chars = [
	" ",
	",",
	"?",
	"!",
	";"
];
var looksLikeObjectPathRegExpCache = new RegExpCache(20);
var looksLikeObjectPath = (key, nsSeparator, keySeparator) => {
	nsSeparator = nsSeparator || "";
	keySeparator = keySeparator || "";
	const possibleChars = chars.filter((c) => !nsSeparator.includes(c) && !keySeparator.includes(c));
	if (possibleChars.length === 0) return true;
	const r = looksLikeObjectPathRegExpCache.getRegExp(`(${possibleChars.map((c) => c === "?" ? "\\?" : c).join("|")})`);
	let matched = !r.test(key);
	if (!matched) {
		const ki = key.indexOf(keySeparator);
		if (ki > 0 && !r.test(key.substring(0, ki))) matched = true;
	}
	return matched;
};
var deepFind = (obj, path, keySeparator = ".") => {
	if (!obj) return void 0;
	if (obj[path]) {
		if (!Object.prototype.hasOwnProperty.call(obj, path)) return void 0;
		return obj[path];
	}
	const tokens = path.split(keySeparator);
	let current = obj;
	for (let i = 0; i < tokens.length;) {
		if (!current || typeof current !== "object") return;
		let next;
		let nextPath = "";
		for (let j = i; j < tokens.length; ++j) {
			if (j !== i) nextPath += keySeparator;
			nextPath += tokens[j];
			next = current[nextPath];
			if ((typeof next === "function" || nextPath === "__proto__") && !Object.prototype.hasOwnProperty.call(current, nextPath)) next = void 0;
			if (next !== void 0) {
				if ([
					"string",
					"number",
					"boolean"
				].includes(typeof next) && j < tokens.length - 1) continue;
				i += j - i + 1;
				break;
			}
		}
		current = next;
	}
	return current;
};
var getCleanedCode = (code) => code?.replace(/_/g, "-");
var consoleLogger = {
	type: "logger",
	log(args) {
		this.output("log", args);
	},
	warn(args) {
		this.output("warn", args);
	},
	error(args) {
		this.output("error", args);
	},
	output(type, args) {
		console?.[type]?.apply?.(console, args);
	}
};
var baseLogger = new class Logger {
	constructor(concreteLogger, options = {}) {
		this.init(concreteLogger, options);
	}
	init(concreteLogger, options = {}) {
		this.prefix = options.prefix || "i18next:";
		this.logger = concreteLogger || consoleLogger;
		this.options = options;
		this.debug = options.debug;
	}
	log(...args) {
		return this.forward(args, "log", "", true);
	}
	warn(...args) {
		return this.forward(args, "warn", "", true);
	}
	error(...args) {
		return this.forward(args, "error", "");
	}
	deprecate(...args) {
		return this.forward(args, "warn", "WARNING DEPRECATED: ", true);
	}
	forward(args, lvl, prefix, debugOnly) {
		if (debugOnly && !this.debug) return null;
		args = args.map((a) => isString(a) ? a.replace(/[\r\n\x00-\x1F\x7F]/g, " ") : a);
		if (isString(args[0])) args[0] = `${prefix}${this.prefix} ${args[0]}`;
		return this.logger[lvl](args);
	}
	create(moduleName) {
		return new Logger(this.logger, {
			prefix: `${this.prefix}:${moduleName}:`,
			...this.options
		});
	}
	clone(options) {
		options = options || this.options;
		options.prefix = options.prefix || this.prefix;
		return new Logger(this.logger, options);
	}
}();
var EventEmitter = class {
	constructor() {
		this.observers = {};
	}
	on(events, listener) {
		events.split(" ").forEach((event) => {
			if (!this.observers[event]) this.observers[event] = /* @__PURE__ */ new Map();
			const numListeners = this.observers[event].get(listener) || 0;
			this.observers[event].set(listener, numListeners + 1);
		});
		return this;
	}
	off(event, listener) {
		if (!this.observers[event]) return;
		if (!listener) {
			delete this.observers[event];
			return;
		}
		this.observers[event].delete(listener);
	}
	once(event, listener) {
		const wrapper = (...args) => {
			listener(...args);
			this.off(event, wrapper);
		};
		this.on(event, wrapper);
		return this;
	}
	emit(event, ...args) {
		if (this.observers[event]) Array.from(this.observers[event].entries()).forEach(([observer, numTimesAdded]) => {
			for (let i = 0; i < numTimesAdded; i++) observer(...args);
		});
		if (this.observers["*"]) Array.from(this.observers["*"].entries()).forEach(([observer, numTimesAdded]) => {
			for (let i = 0; i < numTimesAdded; i++) observer(event, ...args);
		});
	}
};
var nonEmptyBundles = /* @__PURE__ */ new WeakSet();
var ResourceStore = class extends EventEmitter {
	constructor(data, options = {
		ns: ["translation"],
		defaultNS: "translation"
	}) {
		super();
		this.data = data || {};
		this.options = options;
		if (this.options.keySeparator === void 0) this.options.keySeparator = ".";
		if (this.options.ignoreJSONStructure === void 0) this.options.ignoreJSONStructure = true;
	}
	addNamespaces(ns) {
		if (!this.options.ns.includes(ns)) this.options.ns.push(ns);
	}
	removeNamespaces(ns) {
		const index = this.options.ns.indexOf(ns);
		if (index > -1) this.options.ns.splice(index, 1);
	}
	getResource(lng, ns, key, options = {}) {
		const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
		const ignoreJSONStructure = options.ignoreJSONStructure !== void 0 ? options.ignoreJSONStructure : this.options.ignoreJSONStructure;
		let path;
		if (lng.includes(".")) path = lng.split(".");
		else {
			path = [lng, ns];
			if (key) {
				if (Array.isArray(key)) path.push(...key);
				else if (isString(key) && keySeparator) path.push(...key.split(keySeparator));
				else path.push(key);
			}
		}
		const result = getPath(this.data, path);
		if (result == null && !ns && !key && lng.includes(".")) {
			lng = path[0];
			ns = path[1];
			key = path.slice(2).join(".");
		}
		if (result != null || !ignoreJSONStructure || !isString(key)) return result;
		return deepFind(this.data?.[lng]?.[ns], key, keySeparator);
	}
	addResource(lng, ns, key, value, options = { silent: false }) {
		const keySeparator = options.keySeparator !== void 0 ? options.keySeparator : this.options.keySeparator;
		let path = [lng, ns];
		if (key) path = path.concat(keySeparator ? key.split(keySeparator) : key);
		if (lng.includes(".")) {
			path = lng.split(".");
			value = ns;
			ns = path[1];
		}
		this.addNamespaces(ns);
		setPath(this.data, path, value);
		if (!options.silent) this.emit("added", lng, ns, key, value);
	}
	addResources(lng, ns, resources, options = { silent: false }) {
		for (const m in resources) if (isString(resources[m]) || Array.isArray(resources[m])) this.addResource(lng, ns, m, resources[m], { silent: true });
		if (!options.silent) this.emit("added", lng, ns, resources);
	}
	addResourceBundle(lng, ns, resources, deep, overwrite, options = {
		silent: false,
		skipCopy: false
	}) {
		let path = [lng, ns];
		if (lng.includes(".")) {
			path = lng.split(".");
			deep = resources;
			resources = ns;
			ns = path[1];
		}
		this.addNamespaces(ns);
		let pack = getPath(this.data, path) || {};
		if (!options.skipCopy) resources = JSON.parse(JSON.stringify(resources));
		if (deep) deepExtend(pack, resources, overwrite);
		else pack = {
			...pack,
			...resources
		};
		setPath(this.data, path, pack);
		if (!options.silent) this.emit("added", lng, ns, resources);
	}
	removeResourceBundle(lng, ns) {
		if (this.hasResourceBundle(lng, ns)) delete this.data[lng][ns];
		this.removeNamespaces(ns);
		this.emit("removed", lng, ns);
	}
	hasResourceBundle(lng, ns) {
		return this.getResource(lng, ns) !== void 0;
	}
	getResourceBundle(lng, ns) {
		if (!ns) ns = this.options.defaultNS;
		return this.getResource(lng, ns);
	}
	getDataByLanguage(lng) {
		return this.data[lng];
	}
	hasLanguageSomeTranslations(lng) {
		const data = this.getDataByLanguage(lng);
		return !!(data && Object.keys(data) || []).find((v) => {
			const bundle = data[v];
			if (nonEmptyBundles.has(bundle)) return true;
			if (!bundle || Object.keys(bundle).length === 0) return false;
			if (typeof bundle === "object") nonEmptyBundles.add(bundle);
			return true;
		});
	}
	toJSON() {
		return this.data;
	}
};
var postProcessor = {
	processors: {},
	addPostProcessor(module) {
		this.processors[module.name] = module;
	},
	handle(processors, value, key, options, translator) {
		processors.forEach((processor) => {
			value = this.processors[processor]?.process(value, key, options, translator) ?? value;
		});
		return value;
	}
};
var PATH_KEY = Symbol("i18next/PATH_KEY");
function createProxy() {
	const state = [];
	const handler = Object.create(null);
	let proxy;
	handler.get = (target, key) => {
		proxy?.revoke?.();
		if (key === PATH_KEY) return state;
		state.push(key);
		proxy = Proxy.revocable(target, handler);
		return proxy.proxy;
	};
	return Proxy.revocable(Object.create(null), handler).proxy;
}
function keysFromSelector(selector, opts) {
	const { [PATH_KEY]: path } = selector(createProxy());
	const keySeparator = opts?.keySeparator ?? ".";
	const nsSeparator = opts?.nsSeparator ?? ":";
	const strict = opts?.enableSelector === "strict";
	if (path.length > 1 && nsSeparator) {
		const ns = opts?.ns;
		const nsList = strict ? Array.isArray(ns) ? ns : ns ? [ns] : null : Array.isArray(ns) ? ns : null;
		if (nsList) {
			if ((strict ? nsList : nsList.length > 1 ? nsList.slice(1) : []).includes(path[0])) return `${path[0]}${nsSeparator}${path.slice(1).join(keySeparator)}`;
		}
	}
	return path.join(keySeparator);
}
var shouldHandleAsObject = (res) => !isString(res) && typeof res !== "boolean" && typeof res !== "number";
var Translator = class Translator extends EventEmitter {
	constructor(services, options = {}) {
		super();
		copy([
			"resourceStore",
			"languageUtils",
			"pluralResolver",
			"interpolator",
			"backendConnector",
			"i18nFormat",
			"utils"
		], services, this);
		this.options = options;
		if (this.options.keySeparator === void 0) this.options.keySeparator = ".";
		this.logger = baseLogger.create("translator");
		this.checkedLoadedFor = {};
	}
	changeLanguage(lng) {
		if (lng) this.language = lng;
	}
	exists(key, o = { interpolation: {} }) {
		const opt = { ...o };
		if (key == null) return false;
		const resolved = this.resolve(key, opt);
		if (resolved?.res === void 0) return false;
		const isObject = shouldHandleAsObject(resolved.res);
		if (opt.returnObjects === false && isObject) return false;
		return true;
	}
	extractFromKey(key, opt) {
		let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
		if (nsSeparator === void 0) nsSeparator = ":";
		const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
		let namespaces = opt.ns || this.options.defaultNS || [];
		const wouldCheckForNsInKey = nsSeparator && key.includes(nsSeparator);
		const seemsNaturalLanguage = !this.options.userDefinedKeySeparator && !opt.keySeparator && !this.options.userDefinedNsSeparator && !opt.nsSeparator && !looksLikeObjectPath(key, nsSeparator, keySeparator);
		if (wouldCheckForNsInKey && !seemsNaturalLanguage) {
			const m = key.match(this.interpolator.nestingRegexp);
			if (m && m.length > 0) return {
				key,
				namespaces: isString(namespaces) ? [namespaces] : namespaces
			};
			const parts = key.split(nsSeparator);
			if (nsSeparator !== keySeparator || nsSeparator === keySeparator && this.options.ns.includes(parts[0])) namespaces = parts.shift();
			key = parts.join(keySeparator);
		}
		return {
			key,
			namespaces: isString(namespaces) ? [namespaces] : namespaces
		};
	}
	translate(keys, o, lastKey) {
		let opt = typeof o === "object" ? { ...o } : o;
		if (typeof opt !== "object" && this.options.overloadTranslationOptionHandler) opt = this.options.overloadTranslationOptionHandler(arguments);
		if (typeof opt === "object") opt = { ...opt };
		if (!opt) opt = {};
		if (keys == null) return "";
		if (typeof keys === "function") keys = keysFromSelector(keys, {
			...this.options,
			...opt
		});
		if (!Array.isArray(keys)) keys = [String(keys)];
		keys = keys.map((k) => typeof k === "function" ? keysFromSelector(k, {
			...this.options,
			...opt
		}) : String(k));
		const returnDetails = opt.returnDetails !== void 0 ? opt.returnDetails : this.options.returnDetails;
		const keySeparator = opt.keySeparator !== void 0 ? opt.keySeparator : this.options.keySeparator;
		const { key, namespaces } = this.extractFromKey(keys[keys.length - 1], opt);
		const namespace = namespaces[namespaces.length - 1];
		let nsSeparator = opt.nsSeparator !== void 0 ? opt.nsSeparator : this.options.nsSeparator;
		if (nsSeparator === void 0) nsSeparator = ":";
		const lng = opt.lng || this.language;
		const appendNamespaceToCIMode = opt.appendNamespaceToCIMode || this.options.appendNamespaceToCIMode;
		if (lng?.toLowerCase() === "cimode") {
			if (appendNamespaceToCIMode) {
				if (returnDetails) return {
					res: `${namespace}${nsSeparator}${key}`,
					usedKey: key,
					exactUsedKey: key,
					usedLng: lng,
					usedNS: namespace,
					usedParams: this.getUsedParamsDetails(opt)
				};
				return `${namespace}${nsSeparator}${key}`;
			}
			if (returnDetails) return {
				res: key,
				usedKey: key,
				exactUsedKey: key,
				usedLng: lng,
				usedNS: namespace,
				usedParams: this.getUsedParamsDetails(opt)
			};
			return key;
		}
		const resolved = this.resolve(keys, opt);
		let res = resolved?.res;
		const resUsedKey = resolved?.usedKey || key;
		const resExactUsedKey = resolved?.exactUsedKey || key;
		const noObject = [
			"[object Number]",
			"[object Function]",
			"[object RegExp]"
		];
		const joinArrays = opt.joinArrays !== void 0 ? opt.joinArrays : this.options.joinArrays;
		const handleAsObjectInI18nFormat = !this.i18nFormat || this.i18nFormat.handleAsObject;
		const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
		const hasDefaultValue = Translator.hasDefaultValue(opt);
		const defaultValueSuffix = needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, opt) : "";
		const defaultValueSuffixOrdinalFallback = opt.ordinal && needsPluralHandling ? this.pluralResolver.getSuffix(lng, opt.count, { ordinal: false }) : "";
		const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
		const defaultValue = needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] || opt[`defaultValue${defaultValueSuffix}`] || opt[`defaultValue${defaultValueSuffixOrdinalFallback}`] || opt.defaultValue;
		let resForObjHndl = res;
		if (handleAsObjectInI18nFormat && !res && hasDefaultValue) resForObjHndl = defaultValue;
		const handleAsObject = shouldHandleAsObject(resForObjHndl);
		const resType = Object.prototype.toString.apply(resForObjHndl);
		if (handleAsObjectInI18nFormat && resForObjHndl && handleAsObject && !noObject.includes(resType) && !(isString(joinArrays) && Array.isArray(resForObjHndl))) {
			if (!opt.returnObjects && !this.options.returnObjects) {
				if (!this.options.returnedObjectHandler) this.logger.warn("accessing an object - but returnObjects options is not enabled!");
				const r = this.options.returnedObjectHandler ? this.options.returnedObjectHandler(resUsedKey, resForObjHndl, {
					...opt,
					ns: namespaces
				}) : `key '${key} (${this.language})' returned an object instead of string.`;
				if (returnDetails) {
					resolved.res = r;
					resolved.usedParams = this.getUsedParamsDetails(opt);
					return resolved;
				}
				return r;
			}
			if (keySeparator) {
				const resTypeIsArray = Array.isArray(resForObjHndl);
				const copy = resTypeIsArray ? [] : {};
				const newKeyToUse = resTypeIsArray ? resExactUsedKey : resUsedKey;
				for (const m in resForObjHndl) if (Object.prototype.hasOwnProperty.call(resForObjHndl, m)) {
					const deepKey = `${newKeyToUse}${keySeparator}${m}`;
					if (hasDefaultValue && !res) copy[m] = this.translate(deepKey, {
						...opt,
						defaultValue: shouldHandleAsObject(defaultValue) ? defaultValue[m] : void 0,
						joinArrays: false,
						ns: namespaces
					});
					else copy[m] = this.translate(deepKey, {
						...opt,
						joinArrays: false,
						ns: namespaces
					});
					if (copy[m] === deepKey) copy[m] = resForObjHndl[m];
				}
				res = copy;
			}
		} else if (handleAsObjectInI18nFormat && isString(joinArrays) && Array.isArray(res)) {
			res = res.join(joinArrays);
			if (res) res = this.extendTranslation(res, keys, opt, resolved, lastKey);
		} else {
			let usedDefault = false;
			let usedKey = false;
			if (!this.isValidLookup(res) && hasDefaultValue) {
				usedDefault = true;
				res = defaultValue;
			}
			if (!this.isValidLookup(res)) {
				usedKey = true;
				res = key;
			}
			const resForMissing = (opt.missingKeyNoValueFallbackToKey || this.options.missingKeyNoValueFallbackToKey) && usedKey ? void 0 : res;
			const updateMissing = hasDefaultValue && defaultValue !== res && this.options.updateMissing;
			if (usedKey || usedDefault || updateMissing) {
				this.logger.log(updateMissing ? "updateKey" : "missingKey", lng, namespace, needsPluralHandling && !updateMissing ? `${key}${this.pluralResolver.getSuffix(lng, opt.count, opt)}` : key, updateMissing ? defaultValue : res);
				if (keySeparator) {
					const fk = this.resolve(key, {
						...opt,
						keySeparator: false
					});
					if (fk && fk.res) this.logger.warn("Seems the loaded translations were in flat JSON format instead of nested. Either set keySeparator: false on init or make sure your translations are published in nested format.");
				}
				let lngs = [];
				const fallbackLngs = this.languageUtils.getFallbackCodes(this.options.fallbackLng, opt.lng || this.language);
				if (this.options.saveMissingTo === "fallback" && fallbackLngs && fallbackLngs[0]) for (let i = 0; i < fallbackLngs.length; i++) lngs.push(fallbackLngs[i]);
				else if (this.options.saveMissingTo === "all") lngs = this.languageUtils.toResolveHierarchy(opt.lng || this.language);
				else lngs.push(opt.lng || this.language);
				const send = (l, k, specificDefaultValue) => {
					const defaultForMissing = hasDefaultValue && specificDefaultValue !== res ? specificDefaultValue : resForMissing;
					if (this.options.missingKeyHandler) this.options.missingKeyHandler(l, namespace, k, defaultForMissing, updateMissing, opt);
					else if (this.backendConnector?.saveMissing) this.backendConnector.saveMissing(l, namespace, k, defaultForMissing, updateMissing, opt);
					this.emit("missingKey", l, namespace, k, res);
				};
				if (this.options.saveMissing) {
					if (this.options.saveMissingPlurals && needsPluralHandling) lngs.forEach((language) => {
						const suffixes = this.pluralResolver.getSuffixes(language, opt);
						if (needsZeroSuffixLookup && opt[`defaultValue${this.options.pluralSeparator}zero`] && !suffixes.includes(`${this.options.pluralSeparator}zero`)) suffixes.push(`${this.options.pluralSeparator}zero`);
						suffixes.forEach((suffix) => {
							send([language], key + suffix, opt[`defaultValue${suffix}`] || defaultValue);
						});
					});
					else send(lngs, key, defaultValue);
				}
			}
			res = this.extendTranslation(res, keys, opt, resolved, lastKey);
			if (usedKey && res === key && this.options.appendNamespaceToMissingKey) res = `${namespace}${nsSeparator}${key}`;
			if ((usedKey || usedDefault) && this.options.parseMissingKeyHandler) res = this.options.parseMissingKeyHandler(this.options.appendNamespaceToMissingKey ? `${namespace}${nsSeparator}${key}` : key, usedDefault ? res : void 0, opt);
		}
		if (returnDetails) {
			resolved.res = res;
			resolved.usedParams = this.getUsedParamsDetails(opt);
			return resolved;
		}
		return res;
	}
	extendTranslation(res, key, opt, resolved, lastKey) {
		if (this.i18nFormat?.parse) res = this.i18nFormat.parse(res, {
			...this.options.interpolation.defaultVariables,
			...opt
		}, opt.lng || this.language || resolved.usedLng, resolved.usedNS, resolved.usedKey, { resolved });
		else if (!opt.skipInterpolation) {
			if (opt.interpolation) this.interpolator.init({
				...opt,
				interpolation: {
					...this.options.interpolation,
					...opt.interpolation
				}
			});
			const skipOnVariables = isString(res) && (opt?.interpolation?.skipOnVariables !== void 0 ? opt.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables);
			let nestBef;
			if (skipOnVariables) {
				const nb = res.match(this.interpolator.nestingRegexp);
				nestBef = nb && nb.length;
			}
			let data = opt.replace && !isString(opt.replace) ? opt.replace : opt;
			if (this.options.interpolation.defaultVariables) data = {
				...this.options.interpolation.defaultVariables,
				...data
			};
			res = this.interpolator.interpolate(res, data, opt.lng || this.language || resolved.usedLng, opt);
			if (skipOnVariables) {
				const na = res.match(this.interpolator.nestingRegexp);
				const nestAft = na && na.length;
				if (nestBef < nestAft) opt.nest = false;
			}
			if (!opt.lng && resolved && resolved.res) opt.lng = this.language || resolved.usedLng;
			if (opt.nest !== false) res = this.interpolator.nest(res, (...args) => {
				if (lastKey?.[0] === args[0] && !opt.context) {
					this.logger.warn(`It seems you are nesting recursively key: ${args[0]} in key: ${key[0]}`);
					return null;
				}
				return this.translate(...args, key);
			}, opt);
			if (opt.interpolation) this.interpolator.reset();
		}
		const postProcess = opt.postProcess || this.options.postProcess;
		const postProcessorNames = isString(postProcess) ? [postProcess] : postProcess;
		if (res != null && postProcessorNames?.length && opt.applyPostProcessor !== false) res = postProcessor.handle(postProcessorNames, res, key, this.options && this.options.postProcessPassResolved ? {
			i18nResolved: {
				...resolved,
				usedParams: this.getUsedParamsDetails(opt)
			},
			...opt
		} : opt, this);
		return res;
	}
	resolve(keys, opt = {}) {
		let found;
		let usedKey;
		let exactUsedKey;
		let usedLng;
		let usedNS;
		if (isString(keys)) keys = [keys];
		if (Array.isArray(keys)) keys = keys.map((k) => typeof k === "function" ? keysFromSelector(k, {
			...this.options,
			...opt
		}) : k);
		keys.forEach((k) => {
			if (this.isValidLookup(found)) return;
			const extracted = this.extractFromKey(k, opt);
			const key = extracted.key;
			usedKey = key;
			let namespaces = extracted.namespaces;
			if (this.options.fallbackNS) namespaces = namespaces.concat(this.options.fallbackNS);
			const needsPluralHandling = opt.count !== void 0 && !isString(opt.count);
			const needsZeroSuffixLookup = needsPluralHandling && !opt.ordinal && opt.count === 0;
			const needsContextHandling = opt.context !== void 0 && (isString(opt.context) || typeof opt.context === "number") && opt.context !== "";
			const codes = opt.lngs ? opt.lngs : this.languageUtils.toResolveHierarchy(opt.lng || this.language, opt.fallbackLng);
			namespaces.forEach((ns) => {
				if (this.isValidLookup(found)) return;
				usedNS = ns;
				if (!this.checkedLoadedFor[`${codes[0]}-${ns}`] && this.utils?.hasLoadedNamespace && !this.utils?.hasLoadedNamespace(usedNS)) {
					this.checkedLoadedFor[`${codes[0]}-${ns}`] = true;
					this.logger.warn(`key "${usedKey}" for languages "${codes.join(", ")}" won't get resolved as namespace "${usedNS}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
				}
				codes.forEach((code) => {
					if (this.isValidLookup(found)) return;
					usedLng = code;
					const finalKeys = [key];
					if (this.i18nFormat?.addLookupKeys) this.i18nFormat.addLookupKeys(finalKeys, key, code, ns, opt);
					else {
						let pluralSuffix;
						if (needsPluralHandling) pluralSuffix = this.pluralResolver.getSuffix(code, opt.count, opt);
						const zeroSuffix = `${this.options.pluralSeparator}zero`;
						const ordinalPrefix = `${this.options.pluralSeparator}ordinal${this.options.pluralSeparator}`;
						if (needsPluralHandling) {
							if (opt.ordinal && pluralSuffix.startsWith(ordinalPrefix)) finalKeys.push(key + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
							finalKeys.push(key + pluralSuffix);
							if (needsZeroSuffixLookup) finalKeys.push(key + zeroSuffix);
						}
						if (needsContextHandling) {
							const contextKey = `${key}${this.options.contextSeparator || "_"}${opt.context}`;
							finalKeys.push(contextKey);
							if (needsPluralHandling) {
								if (opt.ordinal && pluralSuffix.startsWith(ordinalPrefix)) finalKeys.push(contextKey + pluralSuffix.replace(ordinalPrefix, this.options.pluralSeparator));
								finalKeys.push(contextKey + pluralSuffix);
								if (needsZeroSuffixLookup) finalKeys.push(contextKey + zeroSuffix);
							}
						}
					}
					let possibleKey;
					while (possibleKey = finalKeys.pop()) if (!this.isValidLookup(found)) {
						exactUsedKey = possibleKey;
						found = this.getResource(code, ns, possibleKey, opt);
					}
				});
			});
		});
		return {
			res: found,
			usedKey,
			exactUsedKey,
			usedLng,
			usedNS
		};
	}
	isValidLookup(res) {
		return res !== void 0 && !(!this.options.returnNull && res === null) && !(!this.options.returnEmptyString && res === "");
	}
	getResource(code, ns, key, options = {}) {
		if (this.i18nFormat?.getResource) return this.i18nFormat.getResource(code, ns, key, options);
		return this.resourceStore.getResource(code, ns, key, options);
	}
	getUsedParamsDetails(options = {}) {
		const optionsKeys = [
			"defaultValue",
			"ordinal",
			"context",
			"replace",
			"lng",
			"lngs",
			"fallbackLng",
			"ns",
			"keySeparator",
			"nsSeparator",
			"returnObjects",
			"returnDetails",
			"joinArrays",
			"postProcess",
			"interpolation"
		];
		const useOptionsReplaceForData = options.replace && !isString(options.replace);
		let data = useOptionsReplaceForData ? options.replace : options;
		if (useOptionsReplaceForData && typeof options.count !== "undefined") data = {
			...data,
			count: options.count
		};
		if (this.options.interpolation.defaultVariables) data = {
			...this.options.interpolation.defaultVariables,
			...data
		};
		if (!useOptionsReplaceForData) {
			data = { ...data };
			for (const key of optionsKeys) delete data[key];
		}
		return data;
	}
	static hasDefaultValue(options) {
		const prefix = "defaultValue";
		for (const option in options) if (Object.prototype.hasOwnProperty.call(options, option) && option.startsWith(prefix) && void 0 !== options[option]) return true;
		return false;
	}
};
var LanguageUtil = class {
	constructor(options) {
		this.options = options;
		this.supportedLngs = this.options.supportedLngs || false;
		this.logger = baseLogger.create("languageUtils");
		this.resolveHierarchyCache = {};
	}
	clearCache() {
		this.resolveHierarchyCache = {};
	}
	getScriptPartFromCode(code) {
		code = getCleanedCode(code);
		if (!code || !code.includes("-")) return null;
		const p = code.split("-");
		if (p.length === 2) return null;
		p.pop();
		if (p[p.length - 1].toLowerCase() === "x") return null;
		return this.formatLanguageCode(p.join("-"));
	}
	getLanguagePartFromCode(code) {
		code = getCleanedCode(code);
		if (!code || !code.includes("-")) return code;
		const p = code.split("-");
		return this.formatLanguageCode(p[0]);
	}
	formatLanguageCode(code) {
		if (isString(code) && code.includes("-")) {
			let formattedCode;
			try {
				formattedCode = Intl.getCanonicalLocales(code)[0];
			} catch (e) {}
			if (formattedCode && this.options.lowerCaseLng) formattedCode = formattedCode.toLowerCase();
			if (formattedCode) return formattedCode;
			if (this.options.lowerCaseLng) return code.toLowerCase();
			return code;
		}
		return this.options.cleanCode || this.options.lowerCaseLng ? code.toLowerCase() : code;
	}
	isSupportedCode(code) {
		if (this.options.load === "languageOnly" || this.options.nonExplicitSupportedLngs) code = this.getLanguagePartFromCode(code);
		return !this.supportedLngs || !this.supportedLngs.length || this.supportedLngs.includes(code);
	}
	getBestMatchFromCodes(codes) {
		if (!codes) return null;
		let found;
		codes.forEach((code) => {
			if (found) return;
			const cleanedLng = this.formatLanguageCode(code);
			if (!this.options.supportedLngs || this.isSupportedCode(cleanedLng)) found = cleanedLng;
		});
		if (!found && this.options.supportedLngs) codes.forEach((code) => {
			if (found) return;
			const lngScOnly = this.getScriptPartFromCode(code);
			if (this.isSupportedCode(lngScOnly)) return found = lngScOnly;
			const lngOnly = this.getLanguagePartFromCode(code);
			if (this.isSupportedCode(lngOnly)) return found = lngOnly;
			found = this.options.supportedLngs.find((supportedLng) => {
				if (supportedLng === lngOnly) return true;
				if (!supportedLng.includes("-") && !lngOnly.includes("-")) return false;
				if (supportedLng.includes("-") && !lngOnly.includes("-") && supportedLng.slice(0, supportedLng.indexOf("-")) === lngOnly) return true;
				return false;
			});
		});
		if (!found) found = this.getFallbackCodes(this.options.fallbackLng)[0];
		return found;
	}
	getFallbackCodes(fallbacks, code) {
		if (!fallbacks) return [];
		if (typeof fallbacks === "function") fallbacks = fallbacks(code);
		if (isString(fallbacks)) fallbacks = [fallbacks];
		if (Array.isArray(fallbacks)) return fallbacks;
		if (!code) return fallbacks.default || [];
		let found = fallbacks[code];
		if (!found) found = fallbacks[this.getScriptPartFromCode(code)];
		if (!found) found = fallbacks[this.formatLanguageCode(code)];
		if (!found) found = fallbacks[this.getLanguagePartFromCode(code)];
		if (!found) found = fallbacks.default;
		return found || [];
	}
	toResolveHierarchy(code, fallbackCode) {
		const fallbackLng = this.options.fallbackLng;
		const fallbackLngKey = Array.isArray(fallbackLng) ? fallbackLng.join("|") : fallbackLng;
		if (fallbackLngKey !== this._cachedFallbackLng) {
			this.resolveHierarchyCache = {};
			this._cachedFallbackLng = fallbackLngKey;
		}
		const hasCacheableFallback = fallbackCode === void 0 || fallbackCode === false || isString(fallbackCode);
		const usesUncacheableOptionsFallback = fallbackCode === void 0 && typeof this.options.fallbackLng === "function";
		const cacheable = isString(code) && hasCacheableFallback && !usesUncacheableOptionsFallback;
		let cacheKey = null;
		if (cacheable) {
			let fallbackCacheKey;
			if (fallbackCode === void 0) fallbackCacheKey = "undefined";
			else if (fallbackCode === false) fallbackCacheKey = "boolean:false";
			else fallbackCacheKey = `string:${fallbackCode}`;
			cacheKey = `${code.length}:${code}|${fallbackCacheKey}`;
		}
		if (cacheKey !== null) {
			const cached = this.resolveHierarchyCache[cacheKey];
			if (cached !== void 0) return cached.slice();
		}
		const fallbackCodes = this.getFallbackCodes((fallbackCode === false ? [] : fallbackCode) || this.options.fallbackLng || [], code);
		const codes = [];
		const addCode = (c) => {
			if (!c) return;
			if (this.isSupportedCode(c)) codes.push(c);
			else this.logger.warn(`rejecting language code not found in supportedLngs: ${c}`);
		};
		if (isString(code) && (code.includes("-") || code.includes("_"))) {
			if (this.options.load !== "languageOnly") addCode(this.formatLanguageCode(code));
			if (this.options.load !== "languageOnly" && this.options.load !== "currentOnly") addCode(this.getScriptPartFromCode(code));
			if (this.options.load !== "currentOnly") addCode(this.getLanguagePartFromCode(code));
		} else if (isString(code)) addCode(this.formatLanguageCode(code));
		fallbackCodes.forEach((fc) => {
			const formattedFc = this.formatLanguageCode(fc);
			if (!codes.includes(formattedFc)) addCode(formattedFc);
		});
		if (cacheKey !== null) {
			this.resolveHierarchyCache[cacheKey] = codes;
			return codes.slice();
		}
		return codes;
	}
};
var suffixesOrder = {
	zero: 0,
	one: 1,
	two: 2,
	few: 3,
	many: 4,
	other: 5
};
var dummyRule = {
	select: (count) => count === 1 ? "one" : "other",
	resolvedOptions: () => ({ pluralCategories: ["one", "other"] })
};
var PluralResolver = class {
	constructor(languageUtils, options = {}) {
		this.languageUtils = languageUtils;
		this.options = options;
		this.logger = baseLogger.create("pluralResolver");
		this.pluralRulesCache = {};
	}
	clearCache() {
		this.pluralRulesCache = {};
	}
	getRule(code, options = {}) {
		const cleanedCode = getCleanedCode(code === "dev" ? "en" : code);
		const type = options.ordinal ? "ordinal" : "cardinal";
		const cacheKey = JSON.stringify({
			cleanedCode,
			type
		});
		if (cacheKey in this.pluralRulesCache) return this.pluralRulesCache[cacheKey];
		let rule;
		try {
			rule = new Intl.PluralRules(cleanedCode, { type });
		} catch (err) {
			if (typeof Intl === "undefined") {
				this.logger.error("No Intl support, please use an Intl polyfill!");
				return dummyRule;
			}
			if (!code.match(/-|_/)) return dummyRule;
			const lngPart = this.languageUtils.getLanguagePartFromCode(code);
			rule = this.getRule(lngPart, options);
		}
		this.pluralRulesCache[cacheKey] = rule;
		return rule;
	}
	needsPlural(code, options = {}) {
		let rule = this.getRule(code, options);
		if (!rule) rule = this.getRule("dev", options);
		return rule?.resolvedOptions().pluralCategories.length > 1;
	}
	getPluralFormsOfKey(code, key, options = {}) {
		return this.getSuffixes(code, options).map((suffix) => `${key}${suffix}`);
	}
	getSuffixes(code, options = {}) {
		let rule = this.getRule(code, options);
		if (!rule) rule = this.getRule("dev", options);
		if (!rule) return [];
		return rule.resolvedOptions().pluralCategories.sort((pluralCategory1, pluralCategory2) => suffixesOrder[pluralCategory1] - suffixesOrder[pluralCategory2]).map((pluralCategory) => `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${pluralCategory}`);
	}
	getSuffix(code, count, options = {}) {
		const rule = this.getRule(code, options);
		if (rule) return `${this.options.prepend}${options.ordinal ? `ordinal${this.options.prepend}` : ""}${rule.select(count)}`;
		this.logger.warn(`no plural rule found for: ${code}`);
		return this.getSuffix("dev", count, options);
	}
};
var deepFindWithDefaults = (data, defaultData, key, keySeparator = ".", ignoreJSONStructure = true) => {
	let path = getPathWithDefaults(data, defaultData, key);
	if (path == null && ignoreJSONStructure && isString(key)) {
		path = deepFind(data, key, keySeparator);
		if (path === void 0) path = deepFind(defaultData, key, keySeparator);
	}
	return path;
};
var Interpolator = class {
	constructor(options = {}) {
		this.logger = baseLogger.create("interpolator");
		this.options = options;
		this.format = options?.interpolation?.format || ((value) => value);
		this.init(options);
	}
	init(options = {}) {
		if (!options.interpolation) options.interpolation = { escapeValue: true };
		const { escape: escape$1, escapeValue, useRawValueToEscape, prefix, prefixEscaped, suffix, suffixEscaped, formatSeparator, unescapeSuffix, unescapePrefix, nestingPrefix, nestingPrefixEscaped, nestingSuffix, nestingSuffixEscaped, nestingOptionsSeparator, maxReplaces, alwaysFormat } = options.interpolation;
		this.escape = escape$1 !== void 0 ? escape$1 : escape;
		this.escapeValue = escapeValue !== void 0 ? escapeValue : true;
		this.useRawValueToEscape = useRawValueToEscape !== void 0 ? useRawValueToEscape : false;
		this.prefix = prefix ? regexEscape(prefix) : prefixEscaped || "{{";
		this.suffix = suffix ? regexEscape(suffix) : suffixEscaped || "}}";
		this.formatSeparator = formatSeparator || ",";
		this.unescapePrefix = unescapeSuffix ? "" : unescapePrefix ? regexEscape(unescapePrefix) : "-";
		this.unescapeSuffix = this.unescapePrefix ? "" : unescapeSuffix ? regexEscape(unescapeSuffix) : "";
		this.nestingPrefix = nestingPrefix ? regexEscape(nestingPrefix) : nestingPrefixEscaped || regexEscape("$t(");
		this.nestingSuffix = nestingSuffix ? regexEscape(nestingSuffix) : nestingSuffixEscaped || regexEscape(")");
		this.nestingOptionsSeparator = nestingOptionsSeparator || ",";
		this.maxReplaces = maxReplaces || 1e3;
		this.alwaysFormat = alwaysFormat !== void 0 ? alwaysFormat : false;
		this.resetRegExp();
	}
	reset() {
		if (this.options) this.init(this.options);
	}
	resetRegExp() {
		const getOrResetRegExp = (existingRegExp, pattern) => {
			if (existingRegExp?.source === pattern) {
				existingRegExp.lastIndex = 0;
				return existingRegExp;
			}
			return new RegExp(pattern, "g");
		};
		this.regexp = getOrResetRegExp(this.regexp, `${this.prefix}(.+?)${this.suffix}`);
		this.regexpUnescape = getOrResetRegExp(this.regexpUnescape, `${this.prefix}${this.unescapePrefix}(.+?)${this.unescapeSuffix}${this.suffix}`);
		this.nestingRegexp = getOrResetRegExp(this.nestingRegexp, `${this.nestingPrefix}((?:[^()"']|"[^"]*"|'[^']*'|\\((?:[^()"']|"[^"]*"|'[^']*')*\\))*?)${this.nestingSuffix}`);
	}
	interpolate(str, data, lng, options) {
		let match;
		let value;
		let replaces;
		const defaultData = this.options && this.options.interpolation && this.options.interpolation.defaultVariables || {};
		const handleFormat = (key) => {
			if (!key.includes(this.formatSeparator)) {
				const path = deepFindWithDefaults(data, defaultData, key, this.options.keySeparator, this.options.ignoreJSONStructure);
				return this.alwaysFormat ? this.format(path, void 0, lng, {
					...options,
					...data,
					interpolationkey: key
				}) : path;
			}
			const p = key.split(this.formatSeparator);
			const k = p.shift().trim();
			const f = p.join(this.formatSeparator).trim();
			return this.format(deepFindWithDefaults(data, defaultData, k, this.options.keySeparator, this.options.ignoreJSONStructure), f, lng, {
				...options,
				...data,
				interpolationkey: k
			});
		};
		this.resetRegExp();
		if (!this.escapeValue && typeof str === "string" && /\$t\([^)]*\{[^}]*\{\{/.test(str)) this.logger.warn("nesting options string contains interpolated variables with escapeValue: false — if any of those values are attacker-controlled they can inject additional nesting options (e.g. redirect lng/ns). Sanitise untrusted input before passing it to t(), or keep escapeValue: true.");
		const missingInterpolationHandler = options?.missingInterpolationHandler || this.options.missingInterpolationHandler;
		const skipOnVariables = options?.interpolation?.skipOnVariables !== void 0 ? options.interpolation.skipOnVariables : this.options.interpolation.skipOnVariables;
		const todos = [{
			regex: this.regexpUnescape,
			safeValue: (val) => val
		}, {
			regex: this.regexp,
			safeValue: (val) => this.escapeValue ? this.escape(val) : val
		}];
		const unescapedValues = [];
		let shift = 0;
		todos.forEach((todo) => {
			replaces = 0;
			while (match = todo.regex.exec(str)) {
				const at = match.index - shift;
				const written = unescapedValues.find(([start, end]) => at >= start && at < end);
				if (written) {
					todo.regex.lastIndex = written[1] + shift;
					continue;
				}
				const matchedVar = match[1].trim();
				value = handleFormat(matchedVar);
				if (value === void 0) {
					if (typeof missingInterpolationHandler === "function") {
						const temp = missingInterpolationHandler(str, match, options);
						value = isString(temp) ? temp : "";
					} else if (options && Object.prototype.hasOwnProperty.call(options, matchedVar)) value = "";
					else if (skipOnVariables) {
						value = match[0];
						continue;
					} else {
						this.logger.warn(`missed to pass in variable ${matchedVar} for interpolating ${str}`);
						value = "";
					}
				} else if (!isString(value) && !this.useRawValueToEscape) value = makeString(value);
				const safeValue = makeString(todo.safeValue(value));
				str = str.slice(0, match.index) + safeValue + str.slice(match.index + match[0].length);
				if (skipOnVariables) {
					if (todo.regex === this.regexpUnescape) unescapedValues.push([match.index, match.index + safeValue.length]);
					else shift += safeValue.length - match[0].length;
					todo.regex.lastIndex += safeValue.length;
					todo.regex.lastIndex -= match[0].length;
				} else todo.regex.lastIndex = 0;
				replaces++;
				if (replaces >= this.maxReplaces) break;
			}
		});
		return str;
	}
	nest(str, fc, options = {}) {
		let match;
		let value;
		let clonedOptions;
		const handleHasOptions = (key, inheritedOptions) => {
			const sep = this.nestingOptionsSeparator;
			if (!key.includes(sep)) return key;
			const c = key.split(new RegExp(`${regexEscape(sep)}[ ]*{`));
			let optionsString = `{${c[1]}`;
			key = c[0];
			optionsString = this.interpolate(optionsString, clonedOptions);
			const matchedSingleQuotes = optionsString.match(/'/g);
			const matchedDoubleQuotes = optionsString.match(/"/g);
			if ((matchedSingleQuotes?.length ?? 0) % 2 === 0 && !matchedDoubleQuotes || (matchedDoubleQuotes?.length ?? 0) % 2 !== 0) optionsString = optionsString.replace(/'/g, "\"");
			try {
				clonedOptions = JSON.parse(optionsString);
				if (inheritedOptions) clonedOptions = {
					...inheritedOptions,
					...clonedOptions
				};
			} catch (e) {
				this.logger.warn(`failed parsing options string in nesting for key ${key}`, e);
				return `${key}${sep}${optionsString}`;
			}
			if (clonedOptions.defaultValue && clonedOptions.defaultValue.includes(this.prefix)) delete clonedOptions.defaultValue;
			return key;
		};
		const nestingRegexp = new RegExp(this.nestingRegexp);
		let out = "";
		let lastEnd = 0;
		while (match = nestingRegexp.exec(str)) {
			let formatters = [];
			clonedOptions = { ...options };
			clonedOptions = clonedOptions.replace && !isString(clonedOptions.replace) ? clonedOptions.replace : clonedOptions;
			clonedOptions.applyPostProcessor = false;
			delete clonedOptions.defaultValue;
			const keyEndIndex = /{.*}/s.test(match[1]) ? match[1].lastIndexOf("}") + 1 : match[1].indexOf(this.formatSeparator);
			if (keyEndIndex !== -1) {
				formatters = match[1].slice(keyEndIndex).split(this.formatSeparator).map((elem) => elem.trim()).filter(Boolean);
				match[1] = match[1].slice(0, keyEndIndex);
			}
			value = fc(handleHasOptions.call(this, match[1].trim(), clonedOptions), clonedOptions);
			if (value && match[0] === str && !isString(value)) return value;
			if (!isString(value)) value = makeString(value);
			if (!value) {
				this.logger.warn(`missed to resolve ${match[1]} for nesting ${str}`);
				value = "";
			}
			if (formatters.length) value = formatters.reduce((v, f) => this.format(v, f, options.lng, {
				...options,
				interpolationkey: match[1].trim()
			}), value.trim());
			out += str.slice(lastEnd, match.index) + makeString(value);
			lastEnd = nestingRegexp.lastIndex;
			this.regexp.lastIndex = 0;
		}
		return lastEnd ? out + str.slice(lastEnd) : str;
	}
};
var parseFormatStr = (formatStr) => {
	let formatName = formatStr.toLowerCase().trim();
	const formatOptions = {};
	if (formatStr.includes("(")) {
		const p = formatStr.split("(");
		formatName = p[0].toLowerCase().trim();
		const optStr = p[1].slice(0, -1);
		if (formatName === "currency" && !optStr.includes(":")) {
			if (!formatOptions.currency) formatOptions.currency = optStr.trim();
		} else if (formatName === "relativetime" && !optStr.includes(":")) {
			if (!formatOptions.range) formatOptions.range = optStr.trim();
		} else optStr.split(";").forEach((opt) => {
			if (opt) {
				const [key, ...rest] = opt.split(":");
				const val = rest.join(":").trim().replace(/^'+|'+$/g, "");
				const trimmedKey = key.trim();
				if (!formatOptions[trimmedKey]) formatOptions[trimmedKey] = val;
				if (val === "false") formatOptions[trimmedKey] = false;
				if (val === "true") formatOptions[trimmedKey] = true;
				if (!isNaN(val)) formatOptions[trimmedKey] = parseInt(val, 10);
			}
		});
	}
	return {
		formatName,
		formatOptions
	};
};
var createCachedFormatter = (fn) => {
	const cache = {};
	return (v, l, o) => {
		let optForCache = o;
		if (o && o.interpolationkey && o.formatParams && o.formatParams[o.interpolationkey] && o[o.interpolationkey]) optForCache = {
			...optForCache,
			[o.interpolationkey]: void 0
		};
		let key;
		try {
			key = l + JSON.stringify(optForCache);
		} catch (e) {
			return fn(getCleanedCode(l), o)(v);
		}
		let frm = cache[key];
		if (!frm) {
			frm = fn(getCleanedCode(l), o);
			cache[key] = frm;
		}
		return frm(v);
	};
};
var createNonCachedFormatter = (fn) => (v, l, o) => fn(getCleanedCode(l), o)(v);
var Formatter = class {
	constructor(options = {}) {
		this.logger = baseLogger.create("formatter");
		this.options = options;
		this.init(options);
	}
	init(services, options = { interpolation: {} }) {
		this.formatSeparator = options.interpolation.formatSeparator || ",";
		const cf = options.cacheInBuiltFormats ? createCachedFormatter : createNonCachedFormatter;
		this.formats = {
			number: cf((lng, opt) => {
				const formatter = new Intl.NumberFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			}),
			currency: cf((lng, opt) => {
				const formatter = new Intl.NumberFormat(lng, {
					...opt,
					style: "currency"
				});
				return (val) => formatter.format(val);
			}),
			datetime: cf((lng, opt) => {
				const formatter = new Intl.DateTimeFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			}),
			relativetime: cf((lng, opt) => {
				const formatter = new Intl.RelativeTimeFormat(lng, { ...opt });
				return (val) => formatter.format(val, opt.range || "day");
			}),
			list: cf((lng, opt) => {
				const formatter = new Intl.ListFormat(lng, { ...opt });
				return (val) => formatter.format(val);
			})
		};
	}
	add(name, fc) {
		this.formats[name.toLowerCase().trim()] = fc;
	}
	addCached(name, fc) {
		this.formats[name.toLowerCase().trim()] = createCachedFormatter(fc);
	}
	format(value, format, lng, options = {}) {
		if (!format) return value;
		if (value == null) return value;
		const rawFormats = format.split(this.formatSeparator);
		const formats = [];
		for (let i = 0; i < rawFormats.length; i++) {
			let f = rawFormats[i];
			while (f.indexOf("(") > -1 && !f.includes(")") && i + 1 < rawFormats.length) f = `${f}${this.formatSeparator}${rawFormats[++i]}`;
			formats.push(f);
		}
		return formats.reduce((mem, f) => {
			const { formatName, formatOptions } = parseFormatStr(f);
			if (this.formats[formatName]) {
				let formatted = mem;
				try {
					const valOptions = options?.formatParams?.[options.interpolationkey] || {};
					const l = valOptions.locale || valOptions.lng || options.locale || options.lng || lng;
					formatted = this.formats[formatName](mem, l, {
						...formatOptions,
						...options,
						...valOptions
					});
				} catch (error) {
					this.logger.warn(error);
				}
				return formatted;
			} else this.logger.warn(`there was no format function for ${formatName}`);
			return mem;
		}, value);
	}
};
var removePending = (q, name) => {
	if (q.pending[name] !== void 0) {
		delete q.pending[name];
		q.pendingCount--;
	}
};
var Connector = class extends EventEmitter {
	constructor(backend, store, services, options = {}) {
		super();
		this.backend = backend;
		this.store = store;
		this.services = services;
		this.languageUtils = services.languageUtils;
		this.options = options;
		this.logger = baseLogger.create("backendConnector");
		this.waitingReads = [];
		this.maxParallelReads = options.maxParallelReads || 10;
		this.readingCalls = 0;
		this.maxRetries = options.maxRetries >= 0 ? options.maxRetries : 5;
		this.retryTimeout = options.retryTimeout >= 1 ? options.retryTimeout : 350;
		this.state = {};
		this.queue = [];
		this.backend?.init?.(services, options.backend, options);
	}
	queueLoad(languages, namespaces, options, callback) {
		const toLoad = {};
		const pending = {};
		const toLoadLanguages = {};
		const toLoadNamespaces = {};
		languages.forEach((lng) => {
			let hasAllNamespaces = true;
			namespaces.forEach((ns) => {
				const name = `${lng}|${ns}`;
				if (!options.reload && this.store.hasResourceBundle(lng, ns)) this.state[name] = 2;
				else if (this.state[name] < 0);
				else if (this.state[name] === 1) {
					if (pending[name] === void 0) pending[name] = true;
				} else {
					this.state[name] = 1;
					hasAllNamespaces = false;
					if (pending[name] === void 0) pending[name] = true;
					if (toLoad[name] === void 0) toLoad[name] = true;
					if (toLoadNamespaces[ns] === void 0) toLoadNamespaces[ns] = true;
				}
			});
			if (!hasAllNamespaces) toLoadLanguages[lng] = true;
		});
		if (Object.keys(toLoad).length || Object.keys(pending).length) this.queue.push({
			pending,
			pendingCount: Object.keys(pending).length,
			loaded: {},
			errors: [],
			callback
		});
		return {
			toLoad: Object.keys(toLoad),
			pending: Object.keys(pending),
			toLoadLanguages: Object.keys(toLoadLanguages),
			toLoadNamespaces: Object.keys(toLoadNamespaces)
		};
	}
	loaded(name, err, data) {
		const s = name.split("|");
		const lng = s[0];
		const ns = s[1];
		if (err) this.emit("failedLoading", lng, ns, err);
		if (!err && data) this.store.addResourceBundle(lng, ns, data, void 0, void 0, { skipCopy: true });
		this.state[name] = err ? -1 : 2;
		if (err && data) this.state[name] = 0;
		const loaded = {};
		this.queue.forEach((q) => {
			pushPath(q.loaded, [lng], ns);
			removePending(q, name);
			if (err) q.errors.push(err);
			if (q.pendingCount === 0 && !q.done) {
				Object.keys(q.loaded).forEach((l) => {
					if (!loaded[l]) loaded[l] = {};
					const loadedKeys = q.loaded[l];
					if (loadedKeys.length) loadedKeys.forEach((n) => {
						if (loaded[l][n] === void 0) loaded[l][n] = true;
					});
				});
				q.done = true;
				if (q.errors.length) q.callback(q.errors);
				else q.callback();
			}
		});
		this.emit("loaded", loaded);
		this.queue = this.queue.filter((q) => !q.done);
	}
	read(lng, ns, fcName, tried = 0, wait = this.retryTimeout, callback) {
		if (!lng.length) return callback(null, {});
		if (this.readingCalls >= this.maxParallelReads) {
			this.waitingReads.push({
				lng,
				ns,
				fcName,
				tried,
				wait,
				callback
			});
			return;
		}
		this.readingCalls++;
		const resolver = (err, data) => {
			this.readingCalls--;
			if (this.waitingReads.length > 0) {
				const next = this.waitingReads.shift();
				this.read(next.lng, next.ns, next.fcName, next.tried, next.wait, next.callback);
			}
			if (err && data && tried < this.maxRetries) {
				setTimeout(() => {
					this.read(lng, ns, fcName, tried + 1, wait * 2, callback);
				}, wait);
				return;
			}
			callback(err, data);
		};
		const fc = this.backend[fcName].bind(this.backend);
		if (fc.length === 2) {
			try {
				const r = fc(lng, ns);
				if (r && typeof r.then === "function") r.then((data) => resolver(null, data)).catch(resolver);
				else resolver(null, r);
			} catch (err) {
				resolver(err);
			}
			return;
		}
		return fc(lng, ns, resolver);
	}
	prepareLoading(languages, namespaces, options = {}, callback) {
		if (!this.backend) {
			this.logger.warn("No backend was added via i18next.use. Will not load resources.");
			return callback && callback();
		}
		if (isString(languages)) languages = this.languageUtils.toResolveHierarchy(languages);
		if (isString(namespaces)) namespaces = [namespaces];
		const toLoad = this.queueLoad(languages, namespaces, options, callback);
		if (!toLoad.toLoad.length) {
			if (!toLoad.pending.length) callback();
			return null;
		}
		toLoad.toLoad.forEach((name) => {
			this.loadOne(name);
		});
	}
	load(languages, namespaces, callback) {
		this.prepareLoading(languages, namespaces, {}, callback);
	}
	reload(languages, namespaces, callback) {
		this.prepareLoading(languages, namespaces, { reload: true }, callback);
	}
	loadOne(name, prefix = "") {
		const s = name.split("|");
		const lng = s[0];
		const ns = s[1];
		this.read(lng, ns, "read", void 0, void 0, (err, data) => {
			if (err) this.logger.warn(`${prefix}loading namespace ${ns} for language ${lng} failed`, err);
			if (!err && data) this.logger.log(`${prefix}loaded namespace ${ns} for language ${lng}`, data);
			this.loaded(name, err, data);
		});
	}
	saveMissing(languages, namespace, key, fallbackValue, isUpdate, options = {}, clb = () => {}) {
		if (this.services?.utils?.hasLoadedNamespace && !this.services?.utils?.hasLoadedNamespace(namespace)) {
			this.logger.warn(`did not save key "${key}" as the namespace "${namespace}" was not yet loaded`, "This means something IS WRONG in your setup. You access the t function before i18next.init / i18next.loadNamespace / i18next.changeLanguage was done. Wait for the callback or Promise to resolve before accessing it!!!");
			return;
		}
		if (key === void 0 || key === null || key === "") return;
		if (this.backend?.create) {
			const opts = {
				...options,
				isUpdate
			};
			const fc = this.backend.create.bind(this.backend);
			if (fc.length < 6) try {
				let r;
				if (fc.length === 5) r = fc(languages, namespace, key, fallbackValue, opts);
				else r = fc(languages, namespace, key, fallbackValue);
				if (r && typeof r.then === "function") r.then((data) => clb(null, data)).catch(clb);
				else clb(null, r);
			} catch (err) {
				clb(err);
			}
			else fc(languages, namespace, key, fallbackValue, clb, opts);
		}
		if (!languages || !languages[0]) return;
		this.store.addResource(languages[0], namespace, key, fallbackValue);
	}
};
var get = () => ({
	debug: false,
	initAsync: true,
	ns: ["translation"],
	defaultNS: ["translation"],
	fallbackLng: ["dev"],
	fallbackNS: false,
	supportedLngs: false,
	nonExplicitSupportedLngs: false,
	load: "all",
	preload: false,
	keySeparator: ".",
	nsSeparator: ":",
	pluralSeparator: "_",
	contextSeparator: "_",
	enableSelector: false,
	partialBundledLanguages: false,
	saveMissing: false,
	updateMissing: false,
	saveMissingTo: "fallback",
	saveMissingPlurals: true,
	missingKeyHandler: false,
	missingInterpolationHandler: false,
	postProcess: false,
	postProcessPassResolved: false,
	returnNull: false,
	returnEmptyString: true,
	returnObjects: false,
	joinArrays: false,
	returnedObjectHandler: false,
	parseMissingKeyHandler: false,
	appendNamespaceToMissingKey: false,
	appendNamespaceToCIMode: false,
	overloadTranslationOptionHandler: (args) => {
		let ret = {};
		if (typeof args[1] === "object") ret = args[1];
		if (isString(args[1])) ret.defaultValue = args[1];
		if (isString(args[2])) ret.tDescription = args[2];
		if (typeof args[2] === "object" || typeof args[3] === "object") {
			const options = args[3] || args[2];
			Object.keys(options).forEach((key) => {
				ret[key] = options[key];
			});
		}
		return ret;
	},
	interpolation: {
		escapeValue: true,
		prefix: "{{",
		suffix: "}}",
		formatSeparator: ",",
		unescapePrefix: "-",
		nestingPrefix: "$t(",
		nestingSuffix: ")",
		nestingOptionsSeparator: ",",
		maxReplaces: 1e3,
		skipOnVariables: true
	},
	cacheInBuiltFormats: true
});
var transformOptions = (options) => {
	if (isString(options.ns)) options.ns = [options.ns];
	if (isString(options.fallbackLng)) options.fallbackLng = [options.fallbackLng];
	if (isString(options.fallbackNS)) options.fallbackNS = [options.fallbackNS];
	if (options.supportedLngs && !options.supportedLngs.includes("cimode")) options.supportedLngs = options.supportedLngs.concat(["cimode"]);
	return options;
};
var noop = () => {};
var bindMemberFunctions = (inst) => {
	Object.getOwnPropertyNames(Object.getPrototypeOf(inst)).forEach((mem) => {
		if (typeof inst[mem] === "function") inst[mem] = inst[mem].bind(inst);
	});
};
var instance = class I18n extends EventEmitter {
	constructor(options = {}, callback) {
		super();
		this.options = transformOptions(options);
		this.services = {};
		this.logger = baseLogger;
		this.modules = { external: [] };
		bindMemberFunctions(this);
		if (callback && !this.isInitialized && !options.isClone) {
			if (!this.options.initAsync) {
				this.init(options, callback);
				return this;
			}
			setTimeout(() => {
				this.init(options, callback);
			}, 0);
		}
	}
	init(options = {}, callback) {
		this.isInitializing = true;
		if (typeof options === "function") {
			callback = options;
			options = {};
		}
		if (options.defaultNS == null && options.ns) {
			if (isString(options.ns)) options.defaultNS = options.ns;
			else if (!options.ns.includes("translation")) options.defaultNS = options.ns[0];
		}
		const defOpts = get();
		this.options = {
			...defOpts,
			...this.options,
			...transformOptions(options)
		};
		this.options.interpolation = {
			...defOpts.interpolation,
			...this.options.interpolation
		};
		if (options.keySeparator !== void 0) this.options.userDefinedKeySeparator = options.keySeparator;
		if (options.nsSeparator !== void 0) this.options.userDefinedNsSeparator = options.nsSeparator;
		if (typeof this.options.overloadTranslationOptionHandler !== "function") this.options.overloadTranslationOptionHandler = defOpts.overloadTranslationOptionHandler;
		const createClassOnDemand = (ClassOrObject) => {
			if (!ClassOrObject) return null;
			if (typeof ClassOrObject === "function") return new ClassOrObject();
			return ClassOrObject;
		};
		if (!this.options.isClone) {
			if (this.modules.logger) baseLogger.init(createClassOnDemand(this.modules.logger), this.options);
			else baseLogger.init(null, this.options);
			let formatter;
			if (this.modules.formatter) formatter = this.modules.formatter;
			else formatter = Formatter;
			const lu = new LanguageUtil(this.options);
			this.store = new ResourceStore(this.options.resources, this.options);
			const s = this.services;
			s.logger = baseLogger;
			s.resourceStore = this.store;
			s.languageUtils = lu;
			s.pluralResolver = new PluralResolver(lu, { prepend: this.options.pluralSeparator });
			if (formatter) {
				s.formatter = createClassOnDemand(formatter);
				if (s.formatter.init) s.formatter.init(s, this.options);
				this.options.interpolation.format = s.formatter.format.bind(s.formatter);
			}
			s.interpolator = new Interpolator(this.options);
			s.utils = { hasLoadedNamespace: this.hasLoadedNamespace.bind(this) };
			s.backendConnector = new Connector(createClassOnDemand(this.modules.backend), s.resourceStore, s, this.options);
			s.backendConnector.on("*", (event, ...args) => {
				this.emit(event, ...args);
			});
			if (this.modules.languageDetector) {
				s.languageDetector = createClassOnDemand(this.modules.languageDetector);
				if (s.languageDetector.init) s.languageDetector.init(s, this.options.detection, this.options);
			}
			if (this.modules.i18nFormat) {
				s.i18nFormat = createClassOnDemand(this.modules.i18nFormat);
				if (s.i18nFormat.init) s.i18nFormat.init(this);
			}
			this.translator = new Translator(this.services, this.options);
			this.translator.on("*", (event, ...args) => {
				this.emit(event, ...args);
			});
			this.modules.external.forEach((m) => {
				if (m.init) m.init(this);
			});
		}
		this.format = this.options.interpolation.format;
		if (!callback) callback = noop;
		if (this.options.fallbackLng && !this.services.languageDetector && !this.options.lng) {
			const codes = this.services.languageUtils.getFallbackCodes(this.options.fallbackLng);
			if (codes.length > 0 && codes[0] !== "dev") this.options.lng = codes[0];
		}
		if (!this.services.languageDetector && !this.options.lng) this.logger.warn("init: no languageDetector is used and no lng is defined");
		[
			"getResource",
			"hasResourceBundle",
			"getResourceBundle",
			"getDataByLanguage"
		].forEach((fcName) => {
			this[fcName] = (...args) => this.store[fcName](...args);
		});
		[
			"addResource",
			"addResources",
			"addResourceBundle",
			"removeResourceBundle"
		].forEach((fcName) => {
			this[fcName] = (...args) => {
				this.store[fcName](...args);
				return this;
			};
		});
		const deferred = defer();
		const load = () => {
			const finish = (err, t) => {
				this.isInitializing = false;
				if (this.isInitialized && !this.initializedStoreOnce) this.logger.warn("init: i18next is already initialized. You should call init just once!");
				this.isInitialized = true;
				if (!this.options.isClone) this.logger.log("initialized", this.options);
				this.emit("initialized", this.options);
				deferred.resolve(t);
				callback(err, t);
			};
			if ((this.languages || this.isLanguageChangingTo) && !this.isInitialized) return finish(null, this.t.bind(this));
			this.changeLanguage(this.options.lng, finish);
		};
		if (this.options.resources || !this.options.initAsync) load();
		else setTimeout(load, 0);
		return deferred;
	}
	loadResources(language, callback = noop) {
		let usedCallback = callback;
		const usedLng = isString(language) ? language : this.language;
		if (typeof language === "function") usedCallback = language;
		if (!this.options.resources || this.options.partialBundledLanguages) {
			if (usedLng?.toLowerCase() === "cimode" && (!this.options.preload || this.options.preload.length === 0)) return usedCallback();
			const toLoad = [];
			const append = (lng) => {
				if (!lng) return;
				if (lng === "cimode") return;
				this.services.languageUtils.toResolveHierarchy(lng).forEach((l) => {
					if (l === "cimode") return;
					if (!toLoad.includes(l)) toLoad.push(l);
				});
			};
			if (!usedLng) this.services.languageUtils.getFallbackCodes(this.options.fallbackLng).forEach((l) => append(l));
			else append(usedLng);
			this.options.preload?.forEach?.((l) => append(l));
			this.services.backendConnector.load(toLoad, this.options.ns, (e) => {
				if (!e && !this.resolvedLanguage && this.language) this.setResolvedLanguage(this.language);
				usedCallback(e);
			});
		} else usedCallback(null);
	}
	reloadResources(lngs, ns, callback) {
		const deferred = defer();
		if (typeof lngs === "function") {
			callback = lngs;
			lngs = void 0;
		}
		if (typeof ns === "function") {
			callback = ns;
			ns = void 0;
		}
		if (!lngs) lngs = this.languages;
		if (!ns) ns = this.options.ns;
		if (!callback) callback = noop;
		this.services.backendConnector.reload(lngs, ns, (err) => {
			deferred.resolve();
			callback(err);
		});
		return deferred;
	}
	use(module) {
		if (!module) throw new Error("You are passing an undefined module! Please check the object you are passing to i18next.use()");
		if (!module.type) throw new Error("You are passing a wrong module! Please check the object you are passing to i18next.use()");
		if (module.type === "backend") this.modules.backend = module;
		if (module.type === "logger" || module.log && module.warn && module.error) this.modules.logger = module;
		if (module.type === "languageDetector") this.modules.languageDetector = module;
		if (module.type === "i18nFormat") this.modules.i18nFormat = module;
		if (module.type === "postProcessor") postProcessor.addPostProcessor(module);
		if (module.type === "formatter") this.modules.formatter = module;
		if (module.type === "3rdParty") this.modules.external.push(module);
		return this;
	}
	setResolvedLanguage(l) {
		if (!l || !this.languages) return;
		if (["cimode", "dev"].includes(l)) return;
		for (let li = 0; li < this.languages.length; li++) {
			const lngInLngs = this.languages[li];
			if (["cimode", "dev"].includes(lngInLngs)) continue;
			if (this.store.hasLanguageSomeTranslations(lngInLngs)) {
				this.resolvedLanguage = lngInLngs;
				break;
			}
		}
		if (!this.resolvedLanguage && !this.languages.includes(l) && this.store.hasLanguageSomeTranslations(l)) {
			this.resolvedLanguage = l;
			this.languages.unshift(l);
		}
	}
	changeLanguage(lng, callback) {
		this.isLanguageChangingTo = lng;
		const deferred = defer();
		this.emit("languageChanging", lng);
		const setLngProps = (l) => {
			this.language = l;
			this.languages = this.services.languageUtils.toResolveHierarchy(l);
			this.resolvedLanguage = void 0;
			this.setResolvedLanguage(l);
		};
		const done = (err, l) => {
			if (l) {
				if (this.isLanguageChangingTo === lng) {
					setLngProps(l);
					this.translator.changeLanguage(l);
					this.isLanguageChangingTo = void 0;
					this.emit("languageChanged", l);
					this.logger.log("languageChanged", l);
				}
			} else this.isLanguageChangingTo = void 0;
			deferred.resolve((...args) => this.t(...args));
			if (callback) callback(err, (...args) => this.t(...args));
		};
		const setLng = (lngs) => {
			if (!lng && !lngs && this.services.languageDetector) lngs = [];
			const fl = isString(lngs) ? lngs : lngs && lngs[0];
			const l = this.store.hasLanguageSomeTranslations(fl) ? fl : this.services.languageUtils.getBestMatchFromCodes(isString(lngs) ? [lngs] : lngs);
			if (l) {
				if (!this.language) setLngProps(l);
				if (!this.translator.language) this.translator.changeLanguage(l);
				this.services.languageDetector?.cacheUserLanguage?.(l);
			}
			this.loadResources(l, (err) => {
				done(err, l);
			});
		};
		if (!lng && this.services.languageDetector && !this.services.languageDetector.async) setLng(this.services.languageDetector.detect());
		else if (!lng && this.services.languageDetector && this.services.languageDetector.async) {
			if (this.services.languageDetector.detect.length === 0) this.services.languageDetector.detect().then(setLng);
			else this.services.languageDetector.detect(setLng);
		} else setLng(lng);
		return deferred;
	}
	getFixedT(lng, ns, keyPrefix, fixedOpts) {
		const scopeNs = fixedOpts?.scopeNs;
		const fixedT = (key, opts, ...rest) => {
			let o;
			if (typeof opts !== "object") o = this.options.overloadTranslationOptionHandler([key, opts].concat(rest));
			else o = { ...opts };
			o.lng = o.lng || fixedT.lng;
			o.lngs = o.lngs || fixedT.lngs;
			const explicitCallNs = o.ns !== void 0 && o.ns !== null;
			o.ns = o.ns || fixedT.ns;
			if (o.keyPrefix !== "") o.keyPrefix = o.keyPrefix || keyPrefix || fixedT.keyPrefix;
			const selectorOpts = {
				...this.options,
				...o
			};
			if (Array.isArray(scopeNs) && !explicitCallNs) selectorOpts.ns = scopeNs;
			if (typeof o.keyPrefix === "function") o.keyPrefix = keysFromSelector(o.keyPrefix, selectorOpts);
			const keySeparator = this.options.keySeparator || ".";
			let resultKey;
			if (o.keyPrefix && Array.isArray(key)) resultKey = key.map((k) => {
				if (typeof k === "function") k = keysFromSelector(k, selectorOpts);
				return `${o.keyPrefix}${keySeparator}${k}`;
			});
			else {
				if (typeof key === "function") key = keysFromSelector(key, selectorOpts);
				resultKey = o.keyPrefix ? `${o.keyPrefix}${keySeparator}${key}` : key;
			}
			return this.t(resultKey, o);
		};
		if (isString(lng)) fixedT.lng = lng;
		else fixedT.lngs = lng;
		fixedT.ns = ns;
		fixedT.keyPrefix = keyPrefix;
		return fixedT;
	}
	t(...args) {
		return this.translator?.translate(...args);
	}
	exists(...args) {
		return this.translator?.exists(...args);
	}
	setDefaultNamespace(ns) {
		this.options.defaultNS = ns;
	}
	hasLoadedNamespace(ns, options = {}) {
		if (!this.isInitialized) {
			this.logger.warn("hasLoadedNamespace: i18next was not initialized", this.languages);
			return false;
		}
		if (!this.languages || !this.languages.length) {
			this.logger.warn("hasLoadedNamespace: i18n.languages were undefined or empty", this.languages);
			return false;
		}
		const lng = options.lng || this.resolvedLanguage || this.languages[0];
		const fallbackLng = this.options ? this.options.fallbackLng : false;
		const lastLng = this.languages[this.languages.length - 1];
		if (lng.toLowerCase() === "cimode") return true;
		const loadNotPending = (l, n) => {
			const loadState = this.services.backendConnector.state[`${l}|${n}`];
			return loadState === -1 || loadState === 0 || loadState === 2;
		};
		if (options.precheck) {
			const preResult = options.precheck(this, loadNotPending);
			if (preResult !== void 0) return preResult;
		}
		if (this.hasResourceBundle(lng, ns)) return true;
		if (!this.services.backendConnector.backend || this.options.resources && !this.options.partialBundledLanguages) return true;
		const { languageUtils } = this.services;
		const loadLng = !options.lng ? lng : languageUtils.isSupportedCode(lng) && languageUtils.toResolveHierarchy(lng, false)[0];
		if ((!loadLng || loadNotPending(loadLng, ns)) && (!fallbackLng || loadNotPending(lastLng, ns))) return true;
		return false;
	}
	loadNamespaces(ns, callback) {
		const deferred = defer();
		if (!this.options.ns) {
			if (callback) callback();
			return Promise.resolve();
		}
		if (isString(ns)) ns = [ns];
		ns.forEach((n) => {
			if (!this.options.ns.includes(n)) this.options.ns.push(n);
		});
		this.loadResources((err) => {
			deferred.resolve();
			if (callback) callback(err);
		});
		return deferred;
	}
	loadLanguages(lngs, callback) {
		const deferred = defer();
		if (isString(lngs)) lngs = [lngs];
		const preloaded = this.options.preload || [];
		const newLngs = lngs.filter((lng) => !preloaded.includes(lng) && this.services.languageUtils.isSupportedCode(lng));
		if (!newLngs.length) {
			if (callback) callback();
			return Promise.resolve();
		}
		this.options.preload = preloaded.concat(newLngs);
		this.loadResources((err) => {
			deferred.resolve();
			if (callback) callback(err);
		});
		return deferred;
	}
	dir(lng) {
		if (!lng) lng = this.resolvedLanguage || (this.languages?.length > 0 ? this.languages[0] : this.language);
		if (!lng) return "rtl";
		try {
			const l = new Intl.Locale(lng);
			if (l && l.getTextInfo) {
				const ti = l.getTextInfo();
				if (ti && ti.direction) return ti.direction;
			}
		} catch (e) {}
		const rtlLngs = [
			"ar",
			"shu",
			"sqr",
			"ssh",
			"xaa",
			"yhd",
			"yud",
			"aao",
			"abh",
			"abv",
			"acm",
			"acq",
			"acw",
			"acx",
			"acy",
			"adf",
			"ads",
			"aeb",
			"aec",
			"afb",
			"ajp",
			"apc",
			"apd",
			"arb",
			"arq",
			"ars",
			"ary",
			"arz",
			"auz",
			"avl",
			"ayh",
			"ayl",
			"ayn",
			"ayp",
			"bbz",
			"pga",
			"he",
			"iw",
			"ps",
			"pbt",
			"pbu",
			"pst",
			"prp",
			"prd",
			"ug",
			"ur",
			"ydd",
			"yds",
			"yih",
			"ji",
			"yi",
			"hbo",
			"men",
			"xmn",
			"fa",
			"jpr",
			"peo",
			"pes",
			"prs",
			"dv",
			"sam",
			"ckb"
		];
		const languageUtils = this.services?.languageUtils || new LanguageUtil(get());
		if (lng.toLowerCase().indexOf("-latn") > 1) return "ltr";
		return rtlLngs.includes(languageUtils.getLanguagePartFromCode(lng)) || lng.toLowerCase().indexOf("-arab") > 1 ? "rtl" : "ltr";
	}
	static createInstance(options = {}, callback) {
		const instance = new I18n(options, callback);
		instance.createInstance = I18n.createInstance;
		return instance;
	}
	cloneInstance(options = {}, callback = noop) {
		const forkResourceStore = options.forkResourceStore;
		if (forkResourceStore) {
			options = { ...options };
			delete options.forkResourceStore;
		}
		const mergedOptions = {
			...this.options,
			preload: false,
			...options,
			isClone: true
		};
		const clone = new I18n(mergedOptions);
		if (options.debug !== void 0 || options.prefix !== void 0) clone.logger = clone.logger.clone(options);
		[
			"store",
			"services",
			"language"
		].forEach((m) => {
			clone[m] = this[m];
		});
		clone.services = { ...this.services };
		clone.services.utils = { hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone) };
		if (forkResourceStore) {
			const copyData = (obj) => {
				const copied = Array.isArray(obj) ? [...obj] : { ...obj };
				Object.keys(copied).forEach((k) => {
					if (copied[k] && typeof copied[k] === "object") copied[k] = copyData(copied[k]);
				});
				return copied;
			};
			clone.store = new ResourceStore(copyData(this.store.data), mergedOptions);
			clone.services.resourceStore = clone.store;
		}
		if (options.interpolation) {
			const mergedInterpolation = {
				...get().interpolation,
				...this.options.interpolation,
				...options.interpolation
			};
			const mergedForInterpolator = {
				...mergedOptions,
				interpolation: mergedInterpolation
			};
			clone.services.interpolator = new Interpolator(mergedForInterpolator);
		}
		clone.translator = new Translator(clone.services, mergedOptions);
		clone.translator.on("*", (event, ...args) => {
			clone.emit(event, ...args);
		});
		clone.init(mergedOptions, callback);
		clone.translator.options = mergedOptions;
		clone.translator.backendConnector.services.utils = { hasLoadedNamespace: clone.hasLoadedNamespace.bind(clone) };
		return clone;
	}
	toJSON() {
		return {
			options: this.options,
			store: this.store,
			language: this.language,
			languages: this.languages,
			resolvedLanguage: this.resolvedLanguage
		};
	}
}.createInstance();
var createInstance = instance.createInstance;
var dir = instance.dir;
var init = instance.init;
var loadResources = instance.loadResources;
var reloadResources = instance.reloadResources;
var use = instance.use;
var changeLanguage = instance.changeLanguage;
var getFixedT = instance.getFixedT;
var t = instance.t;
var exists = instance.exists;
var setDefaultNamespace = instance.setDefaultNamespace;
var hasLoadedNamespace = instance.hasLoadedNamespace;
var loadNamespaces = instance.loadNamespaces;
var loadLanguages = instance.loadLanguages;
//#endregion
export { changeLanguage, createInstance, instance as default, dir, exists, getFixedT, hasLoadedNamespace, init, keysFromSelector as keyFromSelector, loadLanguages, loadNamespaces, loadResources, reloadResources, setDefaultNamespace, t, use };

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaTE4bmV4dC5qcyIsIm5hbWVzIjpbXSwic291cmNlcyI6WyIuLi8uLi8ucG5wbS9pMThuZXh0QDI2LjYuMF90eXBlc2NyaXB0QDYuMC4zL25vZGVfbW9kdWxlcy9pMThuZXh0L2Rpc3QvZXNtL2kxOG5leHQuanMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgaXNTdHJpbmcgPSBvYmogPT4gdHlwZW9mIG9iaiA9PT0gJ3N0cmluZyc7XG5jb25zdCBkZWZlciA9ICgpID0+IHtcbiAgbGV0IHJlcztcbiAgbGV0IHJlajtcbiAgY29uc3QgcHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICByZXMgPSByZXNvbHZlO1xuICAgIHJlaiA9IHJlamVjdDtcbiAgfSk7XG4gIHByb21pc2UucmVzb2x2ZSA9IHJlcztcbiAgcHJvbWlzZS5yZWplY3QgPSByZWo7XG4gIHJldHVybiBwcm9taXNlO1xufTtcbmNvbnN0IG1ha2VTdHJpbmcgPSBvYmplY3QgPT4ge1xuICBpZiAob2JqZWN0ID09IG51bGwpIHJldHVybiAnJztcbiAgcmV0dXJuIFN0cmluZyhvYmplY3QpO1xufTtcbmNvbnN0IGNvcHkgPSAoYSwgcywgdCkgPT4ge1xuICBhLmZvckVhY2gobSA9PiB7XG4gICAgaWYgKHNbbV0pIHRbbV0gPSBzW21dO1xuICB9KTtcbn07XG5jb25zdCBsYXN0T2ZQYXRoU2VwYXJhdG9yUmVnRXhwID0gLyMjIy9nO1xuY29uc3QgY2xlYW5LZXkgPSBrZXkgPT4ga2V5ICYmIGtleS5pbmNsdWRlcygnIyMjJykgPyBrZXkucmVwbGFjZShsYXN0T2ZQYXRoU2VwYXJhdG9yUmVnRXhwLCAnLicpIDoga2V5O1xuY29uc3QgY2FuTm90VHJhdmVyc2VEZWVwZXIgPSBvYmplY3QgPT4gIW9iamVjdCB8fCBpc1N0cmluZyhvYmplY3QpO1xuY29uc3QgZ2V0TGFzdE9mUGF0aCA9IChvYmplY3QsIHBhdGgsIEVtcHR5KSA9PiB7XG4gIGNvbnN0IHN0YWNrID0gIWlzU3RyaW5nKHBhdGgpID8gcGF0aCA6IHBhdGguc3BsaXQoJy4nKTtcbiAgbGV0IHN0YWNrSW5kZXggPSAwO1xuICB3aGlsZSAoc3RhY2tJbmRleCA8IHN0YWNrLmxlbmd0aCAtIDEpIHtcbiAgICBpZiAoY2FuTm90VHJhdmVyc2VEZWVwZXIob2JqZWN0KSkgcmV0dXJuIHt9O1xuICAgIGNvbnN0IGtleSA9IGNsZWFuS2V5KHN0YWNrW3N0YWNrSW5kZXhdKTtcbiAgICBpZiAoIW9iamVjdFtrZXldICYmIEVtcHR5KSBvYmplY3Rba2V5XSA9IG5ldyBFbXB0eSgpO1xuICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBrZXkpKSB7XG4gICAgICBvYmplY3QgPSBvYmplY3Rba2V5XTtcbiAgICB9IGVsc2Uge1xuICAgICAgb2JqZWN0ID0ge307XG4gICAgfVxuICAgICsrc3RhY2tJbmRleDtcbiAgfVxuICBpZiAoY2FuTm90VHJhdmVyc2VEZWVwZXIob2JqZWN0KSkgcmV0dXJuIHt9O1xuICByZXR1cm4ge1xuICAgIG9iajogb2JqZWN0LFxuICAgIGs6IGNsZWFuS2V5KHN0YWNrW3N0YWNrSW5kZXhdKVxuICB9O1xufTtcbmNvbnN0IHNldFBhdGggPSAob2JqZWN0LCBwYXRoLCBuZXdWYWx1ZSkgPT4ge1xuICBjb25zdCB7XG4gICAgb2JqLFxuICAgIGtcbiAgfSA9IGdldExhc3RPZlBhdGgob2JqZWN0LCBwYXRoLCBPYmplY3QpO1xuICBpZiAob2JqICE9PSB1bmRlZmluZWQgfHwgcGF0aC5sZW5ndGggPT09IDEpIHtcbiAgICBvYmpba10gPSBuZXdWYWx1ZTtcbiAgICByZXR1cm47XG4gIH1cbiAgbGV0IGUgPSBwYXRoW3BhdGgubGVuZ3RoIC0gMV07XG4gIGxldCBwID0gcGF0aC5zbGljZSgwLCBwYXRoLmxlbmd0aCAtIDEpO1xuICBsZXQgbGFzdCA9IGdldExhc3RPZlBhdGgob2JqZWN0LCBwLCBPYmplY3QpO1xuICB3aGlsZSAobGFzdC5vYmogPT09IHVuZGVmaW5lZCAmJiBwLmxlbmd0aCkge1xuICAgIGUgPSBgJHtwW3AubGVuZ3RoIC0gMV19LiR7ZX1gO1xuICAgIHAgPSBwLnNsaWNlKDAsIHAubGVuZ3RoIC0gMSk7XG4gICAgbGFzdCA9IGdldExhc3RPZlBhdGgob2JqZWN0LCBwLCBPYmplY3QpO1xuICAgIGlmIChsYXN0Py5vYmogJiYgdHlwZW9mIGxhc3Qub2JqW2Ake2xhc3Qua30uJHtlfWBdICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgbGFzdC5vYmogPSB1bmRlZmluZWQ7XG4gICAgfVxuICB9XG4gIGxhc3Qub2JqW2Ake2xhc3Qua30uJHtlfWBdID0gbmV3VmFsdWU7XG59O1xuY29uc3QgcHVzaFBhdGggPSAob2JqZWN0LCBwYXRoLCBuZXdWYWx1ZSwgY29uY2F0KSA9PiB7XG4gIGNvbnN0IHtcbiAgICBvYmosXG4gICAga1xuICB9ID0gZ2V0TGFzdE9mUGF0aChvYmplY3QsIHBhdGgsIE9iamVjdCk7XG4gIG9ialtrXSA9IG9ialtrXSB8fCBbXTtcbiAgb2JqW2tdLnB1c2gobmV3VmFsdWUpO1xufTtcbmNvbnN0IGdldFBhdGggPSAob2JqZWN0LCBwYXRoKSA9PiB7XG4gIGNvbnN0IHtcbiAgICBvYmosXG4gICAga1xuICB9ID0gZ2V0TGFzdE9mUGF0aChvYmplY3QsIHBhdGgpO1xuICBpZiAoIW9iaikgcmV0dXJuIHVuZGVmaW5lZDtcbiAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBrKSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgcmV0dXJuIG9ialtrXTtcbn07XG5jb25zdCBnZXRQYXRoV2l0aERlZmF1bHRzID0gKGRhdGEsIGRlZmF1bHREYXRhLCBrZXkpID0+IHtcbiAgY29uc3QgdmFsdWUgPSBnZXRQYXRoKGRhdGEsIGtleSk7XG4gIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG4gIHJldHVybiBnZXRQYXRoKGRlZmF1bHREYXRhLCBrZXkpO1xufTtcbmNvbnN0IGRlZXBFeHRlbmQgPSAodGFyZ2V0LCBzb3VyY2UsIG92ZXJ3cml0ZSkgPT4ge1xuICBmb3IgKGNvbnN0IHByb3AgaW4gc291cmNlKSB7XG4gICAgaWYgKHByb3AgIT09ICdfX3Byb3RvX18nICYmIHByb3AgIT09ICdjb25zdHJ1Y3RvcicpIHtcbiAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwodGFyZ2V0LCBwcm9wKSkge1xuICAgICAgICBpZiAoaXNTdHJpbmcodGFyZ2V0W3Byb3BdKSB8fCB0YXJnZXRbcHJvcF0gaW5zdGFuY2VvZiBTdHJpbmcgfHwgaXNTdHJpbmcoc291cmNlW3Byb3BdKSB8fCBzb3VyY2VbcHJvcF0gaW5zdGFuY2VvZiBTdHJpbmcpIHtcbiAgICAgICAgICBpZiAob3ZlcndyaXRlKSB0YXJnZXRbcHJvcF0gPSBzb3VyY2VbcHJvcF07XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgZGVlcEV4dGVuZCh0YXJnZXRbcHJvcF0sIHNvdXJjZVtwcm9wXSwgb3ZlcndyaXRlKTtcbiAgICAgICAgfVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGFyZ2V0W3Byb3BdID0gc291cmNlW3Byb3BdO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gdGFyZ2V0O1xufTtcbmNvbnN0IHJlZ2V4RXNjYXBlID0gc3RyID0+IHN0ci5yZXBsYWNlKC9bXFwtXFxbXFxdXFwvXFx7XFx9XFwoXFwpXFwqXFwrXFw/XFwuXFxcXFxcXlxcJFxcfF0vZywgJ1xcXFwkJicpO1xuY29uc3QgX2VudGl0eU1hcCA9IHtcbiAgJyYnOiAnJmFtcDsnLFxuICAnPCc6ICcmbHQ7JyxcbiAgJz4nOiAnJmd0OycsXG4gICdcIic6ICcmcXVvdDsnLFxuICBcIidcIjogJyYjMzk7JyxcbiAgJy8nOiAnJiN4MkY7J1xufTtcbmNvbnN0IGVzY2FwZSA9IGRhdGEgPT4ge1xuICBpZiAoaXNTdHJpbmcoZGF0YSkpIHtcbiAgICByZXR1cm4gZGF0YS5yZXBsYWNlKC9bJjw+XCInXFwvXS9nLCBzID0+IF9lbnRpdHlNYXBbc10pO1xuICB9XG4gIHJldHVybiBkYXRhO1xufTtcbmNsYXNzIFJlZ0V4cENhY2hlIHtcbiAgY29uc3RydWN0b3IoY2FwYWNpdHkpIHtcbiAgICB0aGlzLmNhcGFjaXR5ID0gY2FwYWNpdHk7XG4gICAgdGhpcy5yZWdFeHBNYXAgPSBuZXcgTWFwKCk7XG4gICAgdGhpcy5yZWdFeHBRdWV1ZSA9IFtdO1xuICB9XG4gIGdldFJlZ0V4cChwYXR0ZXJuKSB7XG4gICAgY29uc3QgcmVnRXhwRnJvbUNhY2hlID0gdGhpcy5yZWdFeHBNYXAuZ2V0KHBhdHRlcm4pO1xuICAgIGlmIChyZWdFeHBGcm9tQ2FjaGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgcmV0dXJuIHJlZ0V4cEZyb21DYWNoZTtcbiAgICB9XG4gICAgY29uc3QgcmVnRXhwTmV3ID0gbmV3IFJlZ0V4cChwYXR0ZXJuKTtcbiAgICBpZiAodGhpcy5yZWdFeHBRdWV1ZS5sZW5ndGggPT09IHRoaXMuY2FwYWNpdHkpIHtcbiAgICAgIHRoaXMucmVnRXhwTWFwLmRlbGV0ZSh0aGlzLnJlZ0V4cFF1ZXVlLnNoaWZ0KCkpO1xuICAgIH1cbiAgICB0aGlzLnJlZ0V4cE1hcC5zZXQocGF0dGVybiwgcmVnRXhwTmV3KTtcbiAgICB0aGlzLnJlZ0V4cFF1ZXVlLnB1c2gocGF0dGVybik7XG4gICAgcmV0dXJuIHJlZ0V4cE5ldztcbiAgfVxufVxuY29uc3QgY2hhcnMgPSBbJyAnLCAnLCcsICc/JywgJyEnLCAnOyddO1xuY29uc3QgbG9va3NMaWtlT2JqZWN0UGF0aFJlZ0V4cENhY2hlID0gbmV3IFJlZ0V4cENhY2hlKDIwKTtcbmNvbnN0IGxvb2tzTGlrZU9iamVjdFBhdGggPSAoa2V5LCBuc1NlcGFyYXRvciwga2V5U2VwYXJhdG9yKSA9PiB7XG4gIG5zU2VwYXJhdG9yID0gbnNTZXBhcmF0b3IgfHwgJyc7XG4gIGtleVNlcGFyYXRvciA9IGtleVNlcGFyYXRvciB8fCAnJztcbiAgY29uc3QgcG9zc2libGVDaGFycyA9IGNoYXJzLmZpbHRlcihjID0+ICFuc1NlcGFyYXRvci5pbmNsdWRlcyhjKSAmJiAha2V5U2VwYXJhdG9yLmluY2x1ZGVzKGMpKTtcbiAgaWYgKHBvc3NpYmxlQ2hhcnMubGVuZ3RoID09PSAwKSByZXR1cm4gdHJ1ZTtcbiAgY29uc3QgciA9IGxvb2tzTGlrZU9iamVjdFBhdGhSZWdFeHBDYWNoZS5nZXRSZWdFeHAoYCgke3Bvc3NpYmxlQ2hhcnMubWFwKGMgPT4gYyA9PT0gJz8nID8gJ1xcXFw/JyA6IGMpLmpvaW4oJ3wnKX0pYCk7XG4gIGxldCBtYXRjaGVkID0gIXIudGVzdChrZXkpO1xuICBpZiAoIW1hdGNoZWQpIHtcbiAgICBjb25zdCBraSA9IGtleS5pbmRleE9mKGtleVNlcGFyYXRvcik7XG4gICAgaWYgKGtpID4gMCAmJiAhci50ZXN0KGtleS5zdWJzdHJpbmcoMCwga2kpKSkge1xuICAgICAgbWF0Y2hlZCA9IHRydWU7XG4gICAgfVxuICB9XG4gIHJldHVybiBtYXRjaGVkO1xufTtcbmNvbnN0IGRlZXBGaW5kID0gKG9iaiwgcGF0aCwga2V5U2VwYXJhdG9yID0gJy4nKSA9PiB7XG4gIGlmICghb2JqKSByZXR1cm4gdW5kZWZpbmVkO1xuICBpZiAob2JqW3BhdGhdKSB7XG4gICAgaWYgKCFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwYXRoKSkgcmV0dXJuIHVuZGVmaW5lZDtcbiAgICByZXR1cm4gb2JqW3BhdGhdO1xuICB9XG4gIGNvbnN0IHRva2VucyA9IHBhdGguc3BsaXQoa2V5U2VwYXJhdG9yKTtcbiAgbGV0IGN1cnJlbnQgPSBvYmo7XG4gIGZvciAobGV0IGkgPSAwOyBpIDwgdG9rZW5zLmxlbmd0aDspIHtcbiAgICBpZiAoIWN1cnJlbnQgfHwgdHlwZW9mIGN1cnJlbnQgIT09ICdvYmplY3QnKSB7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBsZXQgbmV4dDtcbiAgICBsZXQgbmV4dFBhdGggPSAnJztcbiAgICBmb3IgKGxldCBqID0gaTsgaiA8IHRva2Vucy5sZW5ndGg7ICsraikge1xuICAgICAgaWYgKGogIT09IGkpIHtcbiAgICAgICAgbmV4dFBhdGggKz0ga2V5U2VwYXJhdG9yO1xuICAgICAgfVxuICAgICAgbmV4dFBhdGggKz0gdG9rZW5zW2pdO1xuICAgICAgbmV4dCA9IGN1cnJlbnRbbmV4dFBhdGhdO1xuICAgICAgaWYgKCh0eXBlb2YgbmV4dCA9PT0gJ2Z1bmN0aW9uJyB8fCBuZXh0UGF0aCA9PT0gJ19fcHJvdG9fXycpICYmICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoY3VycmVudCwgbmV4dFBhdGgpKSB7XG4gICAgICAgIG5leHQgPSB1bmRlZmluZWQ7XG4gICAgICB9XG4gICAgICBpZiAobmV4dCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIGlmIChbJ3N0cmluZycsICdudW1iZXInLCAnYm9vbGVhbiddLmluY2x1ZGVzKHR5cGVvZiBuZXh0KSAmJiBqIDwgdG9rZW5zLmxlbmd0aCAtIDEpIHtcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpICs9IGogLSBpICsgMTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGN1cnJlbnQgPSBuZXh0O1xuICB9XG4gIHJldHVybiBjdXJyZW50O1xufTtcbmNvbnN0IGdldENsZWFuZWRDb2RlID0gY29kZSA9PiBjb2RlPy5yZXBsYWNlKC9fL2csICctJyk7XG5cbmNvbnN0IGNvbnNvbGVMb2dnZXIgPSB7XG4gIHR5cGU6ICdsb2dnZXInLFxuICBsb2coYXJncykge1xuICAgIHRoaXMub3V0cHV0KCdsb2cnLCBhcmdzKTtcbiAgfSxcbiAgd2FybihhcmdzKSB7XG4gICAgdGhpcy5vdXRwdXQoJ3dhcm4nLCBhcmdzKTtcbiAgfSxcbiAgZXJyb3IoYXJncykge1xuICAgIHRoaXMub3V0cHV0KCdlcnJvcicsIGFyZ3MpO1xuICB9LFxuICBvdXRwdXQodHlwZSwgYXJncykge1xuICAgIGNvbnNvbGU/Llt0eXBlXT8uYXBwbHk/Lihjb25zb2xlLCBhcmdzKTtcbiAgfVxufTtcbmNsYXNzIExvZ2dlciB7XG4gIGNvbnN0cnVjdG9yKGNvbmNyZXRlTG9nZ2VyLCBvcHRpb25zID0ge30pIHtcbiAgICB0aGlzLmluaXQoY29uY3JldGVMb2dnZXIsIG9wdGlvbnMpO1xuICB9XG4gIGluaXQoY29uY3JldGVMb2dnZXIsIG9wdGlvbnMgPSB7fSkge1xuICAgIHRoaXMucHJlZml4ID0gb3B0aW9ucy5wcmVmaXggfHwgJ2kxOG5leHQ6JztcbiAgICB0aGlzLmxvZ2dlciA9IGNvbmNyZXRlTG9nZ2VyIHx8IGNvbnNvbGVMb2dnZXI7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLmRlYnVnID0gb3B0aW9ucy5kZWJ1ZztcbiAgfVxuICBsb2coLi4uYXJncykge1xuICAgIHJldHVybiB0aGlzLmZvcndhcmQoYXJncywgJ2xvZycsICcnLCB0cnVlKTtcbiAgfVxuICB3YXJuKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy5mb3J3YXJkKGFyZ3MsICd3YXJuJywgJycsIHRydWUpO1xuICB9XG4gIGVycm9yKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy5mb3J3YXJkKGFyZ3MsICdlcnJvcicsICcnKTtcbiAgfVxuICBkZXByZWNhdGUoLi4uYXJncykge1xuICAgIHJldHVybiB0aGlzLmZvcndhcmQoYXJncywgJ3dhcm4nLCAnV0FSTklORyBERVBSRUNBVEVEOiAnLCB0cnVlKTtcbiAgfVxuICBmb3J3YXJkKGFyZ3MsIGx2bCwgcHJlZml4LCBkZWJ1Z09ubHkpIHtcbiAgICBpZiAoZGVidWdPbmx5ICYmICF0aGlzLmRlYnVnKSByZXR1cm4gbnVsbDtcbiAgICBhcmdzID0gYXJncy5tYXAoYSA9PiBpc1N0cmluZyhhKSA/IGEucmVwbGFjZSgvW1xcclxcblxceDAwLVxceDFGXFx4N0ZdL2csICcgJykgOiBhKTtcbiAgICBpZiAoaXNTdHJpbmcoYXJnc1swXSkpIGFyZ3NbMF0gPSBgJHtwcmVmaXh9JHt0aGlzLnByZWZpeH0gJHthcmdzWzBdfWA7XG4gICAgcmV0dXJuIHRoaXMubG9nZ2VyW2x2bF0oYXJncyk7XG4gIH1cbiAgY3JlYXRlKG1vZHVsZU5hbWUpIHtcbiAgICByZXR1cm4gbmV3IExvZ2dlcih0aGlzLmxvZ2dlciwge1xuICAgICAgLi4ue1xuICAgICAgICBwcmVmaXg6IGAke3RoaXMucHJlZml4fToke21vZHVsZU5hbWV9OmBcbiAgICAgIH0sXG4gICAgICAuLi50aGlzLm9wdGlvbnNcbiAgICB9KTtcbiAgfVxuICBjbG9uZShvcHRpb25zKSB7XG4gICAgb3B0aW9ucyA9IG9wdGlvbnMgfHwgdGhpcy5vcHRpb25zO1xuICAgIG9wdGlvbnMucHJlZml4ID0gb3B0aW9ucy5wcmVmaXggfHwgdGhpcy5wcmVmaXg7XG4gICAgcmV0dXJuIG5ldyBMb2dnZXIodGhpcy5sb2dnZXIsIG9wdGlvbnMpO1xuICB9XG59XG52YXIgYmFzZUxvZ2dlciA9IG5ldyBMb2dnZXIoKTtcblxuY2xhc3MgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5vYnNlcnZlcnMgPSB7fTtcbiAgfVxuICBvbihldmVudHMsIGxpc3RlbmVyKSB7XG4gICAgZXZlbnRzLnNwbGl0KCcgJykuZm9yRWFjaChldmVudCA9PiB7XG4gICAgICBpZiAoIXRoaXMub2JzZXJ2ZXJzW2V2ZW50XSkgdGhpcy5vYnNlcnZlcnNbZXZlbnRdID0gbmV3IE1hcCgpO1xuICAgICAgY29uc3QgbnVtTGlzdGVuZXJzID0gdGhpcy5vYnNlcnZlcnNbZXZlbnRdLmdldChsaXN0ZW5lcikgfHwgMDtcbiAgICAgIHRoaXMub2JzZXJ2ZXJzW2V2ZW50XS5zZXQobGlzdGVuZXIsIG51bUxpc3RlbmVycyArIDEpO1xuICAgIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIG9mZihldmVudCwgbGlzdGVuZXIpIHtcbiAgICBpZiAoIXRoaXMub2JzZXJ2ZXJzW2V2ZW50XSkgcmV0dXJuO1xuICAgIGlmICghbGlzdGVuZXIpIHtcbiAgICAgIGRlbGV0ZSB0aGlzLm9ic2VydmVyc1tldmVudF07XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIHRoaXMub2JzZXJ2ZXJzW2V2ZW50XS5kZWxldGUobGlzdGVuZXIpO1xuICB9XG4gIG9uY2UoZXZlbnQsIGxpc3RlbmVyKSB7XG4gICAgY29uc3Qgd3JhcHBlciA9ICguLi5hcmdzKSA9PiB7XG4gICAgICBsaXN0ZW5lciguLi5hcmdzKTtcbiAgICAgIHRoaXMub2ZmKGV2ZW50LCB3cmFwcGVyKTtcbiAgICB9O1xuICAgIHRoaXMub24oZXZlbnQsIHdyYXBwZXIpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG4gIGVtaXQoZXZlbnQsIC4uLmFyZ3MpIHtcbiAgICBpZiAodGhpcy5vYnNlcnZlcnNbZXZlbnRdKSB7XG4gICAgICBjb25zdCBjbG9uZWQgPSBBcnJheS5mcm9tKHRoaXMub2JzZXJ2ZXJzW2V2ZW50XS5lbnRyaWVzKCkpO1xuICAgICAgY2xvbmVkLmZvckVhY2goKFtvYnNlcnZlciwgbnVtVGltZXNBZGRlZF0pID0+IHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBudW1UaW1lc0FkZGVkOyBpKyspIHtcbiAgICAgICAgICBvYnNlcnZlciguLi5hcmdzKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICAgIGlmICh0aGlzLm9ic2VydmVyc1snKiddKSB7XG4gICAgICBjb25zdCBjbG9uZWQgPSBBcnJheS5mcm9tKHRoaXMub2JzZXJ2ZXJzWycqJ10uZW50cmllcygpKTtcbiAgICAgIGNsb25lZC5mb3JFYWNoKChbb2JzZXJ2ZXIsIG51bVRpbWVzQWRkZWRdKSA9PiB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgbnVtVGltZXNBZGRlZDsgaSsrKSB7XG4gICAgICAgICAgb2JzZXJ2ZXIoZXZlbnQsIC4uLmFyZ3MpO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG4gIH1cbn1cblxuY29uc3Qgbm9uRW1wdHlCdW5kbGVzID0gbmV3IFdlYWtTZXQoKTtcbmNsYXNzIFJlc291cmNlU3RvcmUgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3RvcihkYXRhLCBvcHRpb25zID0ge1xuICAgIG5zOiBbJ3RyYW5zbGF0aW9uJ10sXG4gICAgZGVmYXVsdE5TOiAndHJhbnNsYXRpb24nXG4gIH0pIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuZGF0YSA9IGRhdGEgfHwge307XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICBpZiAodGhpcy5vcHRpb25zLmtleVNlcGFyYXRvciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLm9wdGlvbnMua2V5U2VwYXJhdG9yID0gJy4nO1xuICAgIH1cbiAgICBpZiAodGhpcy5vcHRpb25zLmlnbm9yZUpTT05TdHJ1Y3R1cmUgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5vcHRpb25zLmlnbm9yZUpTT05TdHJ1Y3R1cmUgPSB0cnVlO1xuICAgIH1cbiAgfVxuICBhZGROYW1lc3BhY2VzKG5zKSB7XG4gICAgaWYgKCF0aGlzLm9wdGlvbnMubnMuaW5jbHVkZXMobnMpKSB7XG4gICAgICB0aGlzLm9wdGlvbnMubnMucHVzaChucyk7XG4gICAgfVxuICB9XG4gIHJlbW92ZU5hbWVzcGFjZXMobnMpIHtcbiAgICBjb25zdCBpbmRleCA9IHRoaXMub3B0aW9ucy5ucy5pbmRleE9mKG5zKTtcbiAgICBpZiAoaW5kZXggPiAtMSkge1xuICAgICAgdGhpcy5vcHRpb25zLm5zLnNwbGljZShpbmRleCwgMSk7XG4gICAgfVxuICB9XG4gIGdldFJlc291cmNlKGxuZywgbnMsIGtleSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3Qga2V5U2VwYXJhdG9yID0gb3B0aW9ucy5rZXlTZXBhcmF0b3IgIT09IHVuZGVmaW5lZCA/IG9wdGlvbnMua2V5U2VwYXJhdG9yIDogdGhpcy5vcHRpb25zLmtleVNlcGFyYXRvcjtcbiAgICBjb25zdCBpZ25vcmVKU09OU3RydWN0dXJlID0gb3B0aW9ucy5pZ25vcmVKU09OU3RydWN0dXJlICE9PSB1bmRlZmluZWQgPyBvcHRpb25zLmlnbm9yZUpTT05TdHJ1Y3R1cmUgOiB0aGlzLm9wdGlvbnMuaWdub3JlSlNPTlN0cnVjdHVyZTtcbiAgICBsZXQgcGF0aDtcbiAgICBpZiAobG5nLmluY2x1ZGVzKCcuJykpIHtcbiAgICAgIHBhdGggPSBsbmcuc3BsaXQoJy4nKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcGF0aCA9IFtsbmcsIG5zXTtcbiAgICAgIGlmIChrZXkpIHtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoa2V5KSkge1xuICAgICAgICAgIHBhdGgucHVzaCguLi5rZXkpO1xuICAgICAgICB9IGVsc2UgaWYgKGlzU3RyaW5nKGtleSkgJiYga2V5U2VwYXJhdG9yKSB7XG4gICAgICAgICAgcGF0aC5wdXNoKC4uLmtleS5zcGxpdChrZXlTZXBhcmF0b3IpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBwYXRoLnB1c2goa2V5KTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cbiAgICBjb25zdCByZXN1bHQgPSBnZXRQYXRoKHRoaXMuZGF0YSwgcGF0aCk7XG4gICAgaWYgKHJlc3VsdCA9PSBudWxsICYmICFucyAmJiAha2V5ICYmIGxuZy5pbmNsdWRlcygnLicpKSB7XG4gICAgICBsbmcgPSBwYXRoWzBdO1xuICAgICAgbnMgPSBwYXRoWzFdO1xuICAgICAga2V5ID0gcGF0aC5zbGljZSgyKS5qb2luKCcuJyk7XG4gICAgfVxuICAgIGlmIChyZXN1bHQgIT0gbnVsbCB8fCAhaWdub3JlSlNPTlN0cnVjdHVyZSB8fCAhaXNTdHJpbmcoa2V5KSkgcmV0dXJuIHJlc3VsdDtcbiAgICByZXR1cm4gZGVlcEZpbmQodGhpcy5kYXRhPy5bbG5nXT8uW25zXSwga2V5LCBrZXlTZXBhcmF0b3IpO1xuICB9XG4gIGFkZFJlc291cmNlKGxuZywgbnMsIGtleSwgdmFsdWUsIG9wdGlvbnMgPSB7XG4gICAgc2lsZW50OiBmYWxzZVxuICB9KSB7XG4gICAgY29uc3Qga2V5U2VwYXJhdG9yID0gb3B0aW9ucy5rZXlTZXBhcmF0b3IgIT09IHVuZGVmaW5lZCA/IG9wdGlvbnMua2V5U2VwYXJhdG9yIDogdGhpcy5vcHRpb25zLmtleVNlcGFyYXRvcjtcbiAgICBsZXQgcGF0aCA9IFtsbmcsIG5zXTtcbiAgICBpZiAoa2V5KSBwYXRoID0gcGF0aC5jb25jYXQoa2V5U2VwYXJhdG9yID8ga2V5LnNwbGl0KGtleVNlcGFyYXRvcikgOiBrZXkpO1xuICAgIGlmIChsbmcuaW5jbHVkZXMoJy4nKSkge1xuICAgICAgcGF0aCA9IGxuZy5zcGxpdCgnLicpO1xuICAgICAgdmFsdWUgPSBucztcbiAgICAgIG5zID0gcGF0aFsxXTtcbiAgICB9XG4gICAgdGhpcy5hZGROYW1lc3BhY2VzKG5zKTtcbiAgICBzZXRQYXRoKHRoaXMuZGF0YSwgcGF0aCwgdmFsdWUpO1xuICAgIGlmICghb3B0aW9ucy5zaWxlbnQpIHRoaXMuZW1pdCgnYWRkZWQnLCBsbmcsIG5zLCBrZXksIHZhbHVlKTtcbiAgfVxuICBhZGRSZXNvdXJjZXMobG5nLCBucywgcmVzb3VyY2VzLCBvcHRpb25zID0ge1xuICAgIHNpbGVudDogZmFsc2VcbiAgfSkge1xuICAgIGZvciAoY29uc3QgbSBpbiByZXNvdXJjZXMpIHtcbiAgICAgIGlmIChpc1N0cmluZyhyZXNvdXJjZXNbbV0pIHx8IEFycmF5LmlzQXJyYXkocmVzb3VyY2VzW21dKSkgdGhpcy5hZGRSZXNvdXJjZShsbmcsIG5zLCBtLCByZXNvdXJjZXNbbV0sIHtcbiAgICAgICAgc2lsZW50OiB0cnVlXG4gICAgICB9KTtcbiAgICB9XG4gICAgaWYgKCFvcHRpb25zLnNpbGVudCkgdGhpcy5lbWl0KCdhZGRlZCcsIGxuZywgbnMsIHJlc291cmNlcyk7XG4gIH1cbiAgYWRkUmVzb3VyY2VCdW5kbGUobG5nLCBucywgcmVzb3VyY2VzLCBkZWVwLCBvdmVyd3JpdGUsIG9wdGlvbnMgPSB7XG4gICAgc2lsZW50OiBmYWxzZSxcbiAgICBza2lwQ29weTogZmFsc2VcbiAgfSkge1xuICAgIGxldCBwYXRoID0gW2xuZywgbnNdO1xuICAgIGlmIChsbmcuaW5jbHVkZXMoJy4nKSkge1xuICAgICAgcGF0aCA9IGxuZy5zcGxpdCgnLicpO1xuICAgICAgZGVlcCA9IHJlc291cmNlcztcbiAgICAgIHJlc291cmNlcyA9IG5zO1xuICAgICAgbnMgPSBwYXRoWzFdO1xuICAgIH1cbiAgICB0aGlzLmFkZE5hbWVzcGFjZXMobnMpO1xuICAgIGxldCBwYWNrID0gZ2V0UGF0aCh0aGlzLmRhdGEsIHBhdGgpIHx8IHt9O1xuICAgIGlmICghb3B0aW9ucy5za2lwQ29weSkgcmVzb3VyY2VzID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShyZXNvdXJjZXMpKTtcbiAgICBpZiAoZGVlcCkge1xuICAgICAgZGVlcEV4dGVuZChwYWNrLCByZXNvdXJjZXMsIG92ZXJ3cml0ZSk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBhY2sgPSB7XG4gICAgICAgIC4uLnBhY2ssXG4gICAgICAgIC4uLnJlc291cmNlc1xuICAgICAgfTtcbiAgICB9XG4gICAgc2V0UGF0aCh0aGlzLmRhdGEsIHBhdGgsIHBhY2spO1xuICAgIGlmICghb3B0aW9ucy5zaWxlbnQpIHRoaXMuZW1pdCgnYWRkZWQnLCBsbmcsIG5zLCByZXNvdXJjZXMpO1xuICB9XG4gIHJlbW92ZVJlc291cmNlQnVuZGxlKGxuZywgbnMpIHtcbiAgICBpZiAodGhpcy5oYXNSZXNvdXJjZUJ1bmRsZShsbmcsIG5zKSkge1xuICAgICAgZGVsZXRlIHRoaXMuZGF0YVtsbmddW25zXTtcbiAgICB9XG4gICAgdGhpcy5yZW1vdmVOYW1lc3BhY2VzKG5zKTtcbiAgICB0aGlzLmVtaXQoJ3JlbW92ZWQnLCBsbmcsIG5zKTtcbiAgfVxuICBoYXNSZXNvdXJjZUJ1bmRsZShsbmcsIG5zKSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0UmVzb3VyY2UobG5nLCBucykgIT09IHVuZGVmaW5lZDtcbiAgfVxuICBnZXRSZXNvdXJjZUJ1bmRsZShsbmcsIG5zKSB7XG4gICAgaWYgKCFucykgbnMgPSB0aGlzLm9wdGlvbnMuZGVmYXVsdE5TO1xuICAgIHJldHVybiB0aGlzLmdldFJlc291cmNlKGxuZywgbnMpO1xuICB9XG4gIGdldERhdGFCeUxhbmd1YWdlKGxuZykge1xuICAgIHJldHVybiB0aGlzLmRhdGFbbG5nXTtcbiAgfVxuICBoYXNMYW5ndWFnZVNvbWVUcmFuc2xhdGlvbnMobG5nKSB7XG4gICAgY29uc3QgZGF0YSA9IHRoaXMuZ2V0RGF0YUJ5TGFuZ3VhZ2UobG5nKTtcbiAgICBjb25zdCBuID0gZGF0YSAmJiBPYmplY3Qua2V5cyhkYXRhKSB8fCBbXTtcbiAgICByZXR1cm4gISFuLmZpbmQodiA9PiB7XG4gICAgICBjb25zdCBidW5kbGUgPSBkYXRhW3ZdO1xuICAgICAgaWYgKG5vbkVtcHR5QnVuZGxlcy5oYXMoYnVuZGxlKSkgcmV0dXJuIHRydWU7XG4gICAgICBpZiAoIWJ1bmRsZSB8fCBPYmplY3Qua2V5cyhidW5kbGUpLmxlbmd0aCA9PT0gMCkgcmV0dXJuIGZhbHNlO1xuICAgICAgaWYgKHR5cGVvZiBidW5kbGUgPT09ICdvYmplY3QnKSBub25FbXB0eUJ1bmRsZXMuYWRkKGJ1bmRsZSk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9KTtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHRoaXMuZGF0YTtcbiAgfVxufVxuXG52YXIgcG9zdFByb2Nlc3NvciA9IHtcbiAgcHJvY2Vzc29yczoge30sXG4gIGFkZFBvc3RQcm9jZXNzb3IobW9kdWxlKSB7XG4gICAgdGhpcy5wcm9jZXNzb3JzW21vZHVsZS5uYW1lXSA9IG1vZHVsZTtcbiAgfSxcbiAgaGFuZGxlKHByb2Nlc3NvcnMsIHZhbHVlLCBrZXksIG9wdGlvbnMsIHRyYW5zbGF0b3IpIHtcbiAgICBwcm9jZXNzb3JzLmZvckVhY2gocHJvY2Vzc29yID0+IHtcbiAgICAgIHZhbHVlID0gdGhpcy5wcm9jZXNzb3JzW3Byb2Nlc3Nvcl0/LnByb2Nlc3ModmFsdWUsIGtleSwgb3B0aW9ucywgdHJhbnNsYXRvcikgPz8gdmFsdWU7XG4gICAgfSk7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG59O1xuXG5jb25zdCBQQVRIX0tFWSA9IFN5bWJvbCgnaTE4bmV4dC9QQVRIX0tFWScpO1xuZnVuY3Rpb24gY3JlYXRlUHJveHkoKSB7XG4gIGNvbnN0IHN0YXRlID0gW107XG4gIGNvbnN0IGhhbmRsZXIgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICBsZXQgcHJveHk7XG4gIGhhbmRsZXIuZ2V0ID0gKHRhcmdldCwga2V5KSA9PiB7XG4gICAgcHJveHk/LnJldm9rZT8uKCk7XG4gICAgaWYgKGtleSA9PT0gUEFUSF9LRVkpIHJldHVybiBzdGF0ZTtcbiAgICBzdGF0ZS5wdXNoKGtleSk7XG4gICAgcHJveHkgPSBQcm94eS5yZXZvY2FibGUodGFyZ2V0LCBoYW5kbGVyKTtcbiAgICByZXR1cm4gcHJveHkucHJveHk7XG4gIH07XG4gIHJldHVybiBQcm94eS5yZXZvY2FibGUoT2JqZWN0LmNyZWF0ZShudWxsKSwgaGFuZGxlcikucHJveHk7XG59XG5mdW5jdGlvbiBrZXlzRnJvbVNlbGVjdG9yKHNlbGVjdG9yLCBvcHRzKSB7XG4gIGNvbnN0IHtcbiAgICBbUEFUSF9LRVldOiBwYXRoXG4gIH0gPSBzZWxlY3RvcihjcmVhdGVQcm94eSgpKTtcbiAgY29uc3Qga2V5U2VwYXJhdG9yID0gb3B0cz8ua2V5U2VwYXJhdG9yID8/ICcuJztcbiAgY29uc3QgbnNTZXBhcmF0b3IgPSBvcHRzPy5uc1NlcGFyYXRvciA/PyAnOic7XG4gIGNvbnN0IHN0cmljdCA9IG9wdHM/LmVuYWJsZVNlbGVjdG9yID09PSAnc3RyaWN0JztcbiAgaWYgKHBhdGgubGVuZ3RoID4gMSAmJiBuc1NlcGFyYXRvcikge1xuICAgIGNvbnN0IG5zID0gb3B0cz8ubnM7XG4gICAgY29uc3QgbnNMaXN0ID0gc3RyaWN0ID8gQXJyYXkuaXNBcnJheShucykgPyBucyA6IG5zID8gW25zXSA6IG51bGwgOiBBcnJheS5pc0FycmF5KG5zKSA/IG5zIDogbnVsbDtcbiAgICBpZiAobnNMaXN0KSB7XG4gICAgICBjb25zdCBjYW5kaWRhdGVzID0gc3RyaWN0ID8gbnNMaXN0IDogbnNMaXN0Lmxlbmd0aCA+IDEgPyBuc0xpc3Quc2xpY2UoMSkgOiBbXTtcbiAgICAgIGlmIChjYW5kaWRhdGVzLmluY2x1ZGVzKHBhdGhbMF0pKSB7XG4gICAgICAgIHJldHVybiBgJHtwYXRoWzBdfSR7bnNTZXBhcmF0b3J9JHtwYXRoLnNsaWNlKDEpLmpvaW4oa2V5U2VwYXJhdG9yKX1gO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICByZXR1cm4gcGF0aC5qb2luKGtleVNlcGFyYXRvcik7XG59XG5cbmNvbnN0IHNob3VsZEhhbmRsZUFzT2JqZWN0ID0gcmVzID0+ICFpc1N0cmluZyhyZXMpICYmIHR5cGVvZiByZXMgIT09ICdib29sZWFuJyAmJiB0eXBlb2YgcmVzICE9PSAnbnVtYmVyJztcbmNsYXNzIFRyYW5zbGF0b3IgZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3RvcihzZXJ2aWNlcywgb3B0aW9ucyA9IHt9KSB7XG4gICAgc3VwZXIoKTtcbiAgICBjb3B5KFsncmVzb3VyY2VTdG9yZScsICdsYW5ndWFnZVV0aWxzJywgJ3BsdXJhbFJlc29sdmVyJywgJ2ludGVycG9sYXRvcicsICdiYWNrZW5kQ29ubmVjdG9yJywgJ2kxOG5Gb3JtYXQnLCAndXRpbHMnXSwgc2VydmljZXMsIHRoaXMpO1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgaWYgKHRoaXMub3B0aW9ucy5rZXlTZXBhcmF0b3IgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhpcy5vcHRpb25zLmtleVNlcGFyYXRvciA9ICcuJztcbiAgICB9XG4gICAgdGhpcy5sb2dnZXIgPSBiYXNlTG9nZ2VyLmNyZWF0ZSgndHJhbnNsYXRvcicpO1xuICAgIHRoaXMuY2hlY2tlZExvYWRlZEZvciA9IHt9O1xuICB9XG4gIGNoYW5nZUxhbmd1YWdlKGxuZykge1xuICAgIGlmIChsbmcpIHRoaXMubGFuZ3VhZ2UgPSBsbmc7XG4gIH1cbiAgZXhpc3RzKGtleSwgbyA9IHtcbiAgICBpbnRlcnBvbGF0aW9uOiB7fVxuICB9KSB7XG4gICAgY29uc3Qgb3B0ID0ge1xuICAgICAgLi4ub1xuICAgIH07XG4gICAgaWYgKGtleSA9PSBudWxsKSByZXR1cm4gZmFsc2U7XG4gICAgY29uc3QgcmVzb2x2ZWQgPSB0aGlzLnJlc29sdmUoa2V5LCBvcHQpO1xuICAgIGlmIChyZXNvbHZlZD8ucmVzID09PSB1bmRlZmluZWQpIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBpc09iamVjdCA9IHNob3VsZEhhbmRsZUFzT2JqZWN0KHJlc29sdmVkLnJlcyk7XG4gICAgaWYgKG9wdC5yZXR1cm5PYmplY3RzID09PSBmYWxzZSAmJiBpc09iamVjdCkge1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbiAgfVxuICBleHRyYWN0RnJvbUtleShrZXksIG9wdCkge1xuICAgIGxldCBuc1NlcGFyYXRvciA9IG9wdC5uc1NlcGFyYXRvciAhPT0gdW5kZWZpbmVkID8gb3B0Lm5zU2VwYXJhdG9yIDogdGhpcy5vcHRpb25zLm5zU2VwYXJhdG9yO1xuICAgIGlmIChuc1NlcGFyYXRvciA9PT0gdW5kZWZpbmVkKSBuc1NlcGFyYXRvciA9ICc6JztcbiAgICBjb25zdCBrZXlTZXBhcmF0b3IgPSBvcHQua2V5U2VwYXJhdG9yICE9PSB1bmRlZmluZWQgPyBvcHQua2V5U2VwYXJhdG9yIDogdGhpcy5vcHRpb25zLmtleVNlcGFyYXRvcjtcbiAgICBsZXQgbmFtZXNwYWNlcyA9IG9wdC5ucyB8fCB0aGlzLm9wdGlvbnMuZGVmYXVsdE5TIHx8IFtdO1xuICAgIGNvbnN0IHdvdWxkQ2hlY2tGb3JOc0luS2V5ID0gbnNTZXBhcmF0b3IgJiYga2V5LmluY2x1ZGVzKG5zU2VwYXJhdG9yKTtcbiAgICBjb25zdCBzZWVtc05hdHVyYWxMYW5ndWFnZSA9ICF0aGlzLm9wdGlvbnMudXNlckRlZmluZWRLZXlTZXBhcmF0b3IgJiYgIW9wdC5rZXlTZXBhcmF0b3IgJiYgIXRoaXMub3B0aW9ucy51c2VyRGVmaW5lZE5zU2VwYXJhdG9yICYmICFvcHQubnNTZXBhcmF0b3IgJiYgIWxvb2tzTGlrZU9iamVjdFBhdGgoa2V5LCBuc1NlcGFyYXRvciwga2V5U2VwYXJhdG9yKTtcbiAgICBpZiAod291bGRDaGVja0Zvck5zSW5LZXkgJiYgIXNlZW1zTmF0dXJhbExhbmd1YWdlKSB7XG4gICAgICBjb25zdCBtID0ga2V5Lm1hdGNoKHRoaXMuaW50ZXJwb2xhdG9yLm5lc3RpbmdSZWdleHApO1xuICAgICAgaWYgKG0gJiYgbS5sZW5ndGggPiAwKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAga2V5LFxuICAgICAgICAgIG5hbWVzcGFjZXM6IGlzU3RyaW5nKG5hbWVzcGFjZXMpID8gW25hbWVzcGFjZXNdIDogbmFtZXNwYWNlc1xuICAgICAgICB9O1xuICAgICAgfVxuICAgICAgY29uc3QgcGFydHMgPSBrZXkuc3BsaXQobnNTZXBhcmF0b3IpO1xuICAgICAgaWYgKG5zU2VwYXJhdG9yICE9PSBrZXlTZXBhcmF0b3IgfHwgbnNTZXBhcmF0b3IgPT09IGtleVNlcGFyYXRvciAmJiB0aGlzLm9wdGlvbnMubnMuaW5jbHVkZXMocGFydHNbMF0pKSBuYW1lc3BhY2VzID0gcGFydHMuc2hpZnQoKTtcbiAgICAgIGtleSA9IHBhcnRzLmpvaW4oa2V5U2VwYXJhdG9yKTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgIGtleSxcbiAgICAgIG5hbWVzcGFjZXM6IGlzU3RyaW5nKG5hbWVzcGFjZXMpID8gW25hbWVzcGFjZXNdIDogbmFtZXNwYWNlc1xuICAgIH07XG4gIH1cbiAgdHJhbnNsYXRlKGtleXMsIG8sIGxhc3RLZXkpIHtcbiAgICBsZXQgb3B0ID0gdHlwZW9mIG8gPT09ICdvYmplY3QnID8ge1xuICAgICAgLi4ub1xuICAgIH0gOiBvO1xuICAgIGlmICh0eXBlb2Ygb3B0ICE9PSAnb2JqZWN0JyAmJiB0aGlzLm9wdGlvbnMub3ZlcmxvYWRUcmFuc2xhdGlvbk9wdGlvbkhhbmRsZXIpIHtcbiAgICAgIG9wdCA9IHRoaXMub3B0aW9ucy5vdmVybG9hZFRyYW5zbGF0aW9uT3B0aW9uSGFuZGxlcihhcmd1bWVudHMpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIG9wdCA9PT0gJ29iamVjdCcpIG9wdCA9IHtcbiAgICAgIC4uLm9wdFxuICAgIH07XG4gICAgaWYgKCFvcHQpIG9wdCA9IHt9O1xuICAgIGlmIChrZXlzID09IG51bGwpIHJldHVybiAnJztcbiAgICBpZiAodHlwZW9mIGtleXMgPT09ICdmdW5jdGlvbicpIGtleXMgPSBrZXlzRnJvbVNlbGVjdG9yKGtleXMsIHtcbiAgICAgIC4uLnRoaXMub3B0aW9ucyxcbiAgICAgIC4uLm9wdFxuICAgIH0pO1xuICAgIGlmICghQXJyYXkuaXNBcnJheShrZXlzKSkga2V5cyA9IFtTdHJpbmcoa2V5cyldO1xuICAgIGtleXMgPSBrZXlzLm1hcChrID0+IHR5cGVvZiBrID09PSAnZnVuY3Rpb24nID8ga2V5c0Zyb21TZWxlY3RvcihrLCB7XG4gICAgICAuLi50aGlzLm9wdGlvbnMsXG4gICAgICAuLi5vcHRcbiAgICB9KSA6IFN0cmluZyhrKSk7XG4gICAgY29uc3QgcmV0dXJuRGV0YWlscyA9IG9wdC5yZXR1cm5EZXRhaWxzICE9PSB1bmRlZmluZWQgPyBvcHQucmV0dXJuRGV0YWlscyA6IHRoaXMub3B0aW9ucy5yZXR1cm5EZXRhaWxzO1xuICAgIGNvbnN0IGtleVNlcGFyYXRvciA9IG9wdC5rZXlTZXBhcmF0b3IgIT09IHVuZGVmaW5lZCA/IG9wdC5rZXlTZXBhcmF0b3IgOiB0aGlzLm9wdGlvbnMua2V5U2VwYXJhdG9yO1xuICAgIGNvbnN0IHtcbiAgICAgIGtleSxcbiAgICAgIG5hbWVzcGFjZXNcbiAgICB9ID0gdGhpcy5leHRyYWN0RnJvbUtleShrZXlzW2tleXMubGVuZ3RoIC0gMV0sIG9wdCk7XG4gICAgY29uc3QgbmFtZXNwYWNlID0gbmFtZXNwYWNlc1tuYW1lc3BhY2VzLmxlbmd0aCAtIDFdO1xuICAgIGxldCBuc1NlcGFyYXRvciA9IG9wdC5uc1NlcGFyYXRvciAhPT0gdW5kZWZpbmVkID8gb3B0Lm5zU2VwYXJhdG9yIDogdGhpcy5vcHRpb25zLm5zU2VwYXJhdG9yO1xuICAgIGlmIChuc1NlcGFyYXRvciA9PT0gdW5kZWZpbmVkKSBuc1NlcGFyYXRvciA9ICc6JztcbiAgICBjb25zdCBsbmcgPSBvcHQubG5nIHx8IHRoaXMubGFuZ3VhZ2U7XG4gICAgY29uc3QgYXBwZW5kTmFtZXNwYWNlVG9DSU1vZGUgPSBvcHQuYXBwZW5kTmFtZXNwYWNlVG9DSU1vZGUgfHwgdGhpcy5vcHRpb25zLmFwcGVuZE5hbWVzcGFjZVRvQ0lNb2RlO1xuICAgIGlmIChsbmc/LnRvTG93ZXJDYXNlKCkgPT09ICdjaW1vZGUnKSB7XG4gICAgICBpZiAoYXBwZW5kTmFtZXNwYWNlVG9DSU1vZGUpIHtcbiAgICAgICAgaWYgKHJldHVybkRldGFpbHMpIHtcbiAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcmVzOiBgJHtuYW1lc3BhY2V9JHtuc1NlcGFyYXRvcn0ke2tleX1gLFxuICAgICAgICAgICAgdXNlZEtleToga2V5LFxuICAgICAgICAgICAgZXhhY3RVc2VkS2V5OiBrZXksXG4gICAgICAgICAgICB1c2VkTG5nOiBsbmcsXG4gICAgICAgICAgICB1c2VkTlM6IG5hbWVzcGFjZSxcbiAgICAgICAgICAgIHVzZWRQYXJhbXM6IHRoaXMuZ2V0VXNlZFBhcmFtc0RldGFpbHMob3B0KVxuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGAke25hbWVzcGFjZX0ke25zU2VwYXJhdG9yfSR7a2V5fWA7XG4gICAgICB9XG4gICAgICBpZiAocmV0dXJuRGV0YWlscykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgIHJlczoga2V5LFxuICAgICAgICAgIHVzZWRLZXk6IGtleSxcbiAgICAgICAgICBleGFjdFVzZWRLZXk6IGtleSxcbiAgICAgICAgICB1c2VkTG5nOiBsbmcsXG4gICAgICAgICAgdXNlZE5TOiBuYW1lc3BhY2UsXG4gICAgICAgICAgdXNlZFBhcmFtczogdGhpcy5nZXRVc2VkUGFyYW1zRGV0YWlscyhvcHQpXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICByZXR1cm4ga2V5O1xuICAgIH1cbiAgICBjb25zdCByZXNvbHZlZCA9IHRoaXMucmVzb2x2ZShrZXlzLCBvcHQpO1xuICAgIGxldCByZXMgPSByZXNvbHZlZD8ucmVzO1xuICAgIGNvbnN0IHJlc1VzZWRLZXkgPSByZXNvbHZlZD8udXNlZEtleSB8fCBrZXk7XG4gICAgY29uc3QgcmVzRXhhY3RVc2VkS2V5ID0gcmVzb2x2ZWQ/LmV4YWN0VXNlZEtleSB8fCBrZXk7XG4gICAgY29uc3Qgbm9PYmplY3QgPSBbJ1tvYmplY3QgTnVtYmVyXScsICdbb2JqZWN0IEZ1bmN0aW9uXScsICdbb2JqZWN0IFJlZ0V4cF0nXTtcbiAgICBjb25zdCBqb2luQXJyYXlzID0gb3B0LmpvaW5BcnJheXMgIT09IHVuZGVmaW5lZCA/IG9wdC5qb2luQXJyYXlzIDogdGhpcy5vcHRpb25zLmpvaW5BcnJheXM7XG4gICAgY29uc3QgaGFuZGxlQXNPYmplY3RJbkkxOG5Gb3JtYXQgPSAhdGhpcy5pMThuRm9ybWF0IHx8IHRoaXMuaTE4bkZvcm1hdC5oYW5kbGVBc09iamVjdDtcbiAgICBjb25zdCBuZWVkc1BsdXJhbEhhbmRsaW5nID0gb3B0LmNvdW50ICE9PSB1bmRlZmluZWQgJiYgIWlzU3RyaW5nKG9wdC5jb3VudCk7XG4gICAgY29uc3QgaGFzRGVmYXVsdFZhbHVlID0gVHJhbnNsYXRvci5oYXNEZWZhdWx0VmFsdWUob3B0KTtcbiAgICBjb25zdCBkZWZhdWx0VmFsdWVTdWZmaXggPSBuZWVkc1BsdXJhbEhhbmRsaW5nID8gdGhpcy5wbHVyYWxSZXNvbHZlci5nZXRTdWZmaXgobG5nLCBvcHQuY291bnQsIG9wdCkgOiAnJztcbiAgICBjb25zdCBkZWZhdWx0VmFsdWVTdWZmaXhPcmRpbmFsRmFsbGJhY2sgPSBvcHQub3JkaW5hbCAmJiBuZWVkc1BsdXJhbEhhbmRsaW5nID8gdGhpcy5wbHVyYWxSZXNvbHZlci5nZXRTdWZmaXgobG5nLCBvcHQuY291bnQsIHtcbiAgICAgIG9yZGluYWw6IGZhbHNlXG4gICAgfSkgOiAnJztcbiAgICBjb25zdCBuZWVkc1plcm9TdWZmaXhMb29rdXAgPSBuZWVkc1BsdXJhbEhhbmRsaW5nICYmICFvcHQub3JkaW5hbCAmJiBvcHQuY291bnQgPT09IDA7XG4gICAgY29uc3QgZGVmYXVsdFZhbHVlID0gbmVlZHNaZXJvU3VmZml4TG9va3VwICYmIG9wdFtgZGVmYXVsdFZhbHVlJHt0aGlzLm9wdGlvbnMucGx1cmFsU2VwYXJhdG9yfXplcm9gXSB8fCBvcHRbYGRlZmF1bHRWYWx1ZSR7ZGVmYXVsdFZhbHVlU3VmZml4fWBdIHx8IG9wdFtgZGVmYXVsdFZhbHVlJHtkZWZhdWx0VmFsdWVTdWZmaXhPcmRpbmFsRmFsbGJhY2t9YF0gfHwgb3B0LmRlZmF1bHRWYWx1ZTtcbiAgICBsZXQgcmVzRm9yT2JqSG5kbCA9IHJlcztcbiAgICBpZiAoaGFuZGxlQXNPYmplY3RJbkkxOG5Gb3JtYXQgJiYgIXJlcyAmJiBoYXNEZWZhdWx0VmFsdWUpIHtcbiAgICAgIHJlc0Zvck9iakhuZGwgPSBkZWZhdWx0VmFsdWU7XG4gICAgfVxuICAgIGNvbnN0IGhhbmRsZUFzT2JqZWN0ID0gc2hvdWxkSGFuZGxlQXNPYmplY3QocmVzRm9yT2JqSG5kbCk7XG4gICAgY29uc3QgcmVzVHlwZSA9IE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuYXBwbHkocmVzRm9yT2JqSG5kbCk7XG4gICAgaWYgKGhhbmRsZUFzT2JqZWN0SW5JMThuRm9ybWF0ICYmIHJlc0Zvck9iakhuZGwgJiYgaGFuZGxlQXNPYmplY3QgJiYgIW5vT2JqZWN0LmluY2x1ZGVzKHJlc1R5cGUpICYmICEoaXNTdHJpbmcoam9pbkFycmF5cykgJiYgQXJyYXkuaXNBcnJheShyZXNGb3JPYmpIbmRsKSkpIHtcbiAgICAgIGlmICghb3B0LnJldHVybk9iamVjdHMgJiYgIXRoaXMub3B0aW9ucy5yZXR1cm5PYmplY3RzKSB7XG4gICAgICAgIGlmICghdGhpcy5vcHRpb25zLnJldHVybmVkT2JqZWN0SGFuZGxlcikge1xuICAgICAgICAgIHRoaXMubG9nZ2VyLndhcm4oJ2FjY2Vzc2luZyBhbiBvYmplY3QgLSBidXQgcmV0dXJuT2JqZWN0cyBvcHRpb25zIGlzIG5vdCBlbmFibGVkIScpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHIgPSB0aGlzLm9wdGlvbnMucmV0dXJuZWRPYmplY3RIYW5kbGVyID8gdGhpcy5vcHRpb25zLnJldHVybmVkT2JqZWN0SGFuZGxlcihyZXNVc2VkS2V5LCByZXNGb3JPYmpIbmRsLCB7XG4gICAgICAgICAgLi4ub3B0LFxuICAgICAgICAgIG5zOiBuYW1lc3BhY2VzXG4gICAgICAgIH0pIDogYGtleSAnJHtrZXl9ICgke3RoaXMubGFuZ3VhZ2V9KScgcmV0dXJuZWQgYW4gb2JqZWN0IGluc3RlYWQgb2Ygc3RyaW5nLmA7XG4gICAgICAgIGlmIChyZXR1cm5EZXRhaWxzKSB7XG4gICAgICAgICAgcmVzb2x2ZWQucmVzID0gcjtcbiAgICAgICAgICByZXNvbHZlZC51c2VkUGFyYW1zID0gdGhpcy5nZXRVc2VkUGFyYW1zRGV0YWlscyhvcHQpO1xuICAgICAgICAgIHJldHVybiByZXNvbHZlZDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcjtcbiAgICAgIH1cbiAgICAgIGlmIChrZXlTZXBhcmF0b3IpIHtcbiAgICAgICAgY29uc3QgcmVzVHlwZUlzQXJyYXkgPSBBcnJheS5pc0FycmF5KHJlc0Zvck9iakhuZGwpO1xuICAgICAgICBjb25zdCBjb3B5ID0gcmVzVHlwZUlzQXJyYXkgPyBbXSA6IHt9O1xuICAgICAgICBjb25zdCBuZXdLZXlUb1VzZSA9IHJlc1R5cGVJc0FycmF5ID8gcmVzRXhhY3RVc2VkS2V5IDogcmVzVXNlZEtleTtcbiAgICAgICAgZm9yIChjb25zdCBtIGluIHJlc0Zvck9iakhuZGwpIHtcbiAgICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHJlc0Zvck9iakhuZGwsIG0pKSB7XG4gICAgICAgICAgICBjb25zdCBkZWVwS2V5ID0gYCR7bmV3S2V5VG9Vc2V9JHtrZXlTZXBhcmF0b3J9JHttfWA7XG4gICAgICAgICAgICBpZiAoaGFzRGVmYXVsdFZhbHVlICYmICFyZXMpIHtcbiAgICAgICAgICAgICAgY29weVttXSA9IHRoaXMudHJhbnNsYXRlKGRlZXBLZXksIHtcbiAgICAgICAgICAgICAgICAuLi5vcHQsXG4gICAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlOiBzaG91bGRIYW5kbGVBc09iamVjdChkZWZhdWx0VmFsdWUpID8gZGVmYXVsdFZhbHVlW21dIDogdW5kZWZpbmVkLFxuICAgICAgICAgICAgICAgIC4uLntcbiAgICAgICAgICAgICAgICAgIGpvaW5BcnJheXM6IGZhbHNlLFxuICAgICAgICAgICAgICAgICAgbnM6IG5hbWVzcGFjZXNcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgY29weVttXSA9IHRoaXMudHJhbnNsYXRlKGRlZXBLZXksIHtcbiAgICAgICAgICAgICAgICAuLi5vcHQsXG4gICAgICAgICAgICAgICAgLi4ue1xuICAgICAgICAgICAgICAgICAgam9pbkFycmF5czogZmFsc2UsXG4gICAgICAgICAgICAgICAgICBuczogbmFtZXNwYWNlc1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY29weVttXSA9PT0gZGVlcEtleSkgY29weVttXSA9IHJlc0Zvck9iakhuZGxbbV07XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJlcyA9IGNvcHk7XG4gICAgICB9XG4gICAgfSBlbHNlIGlmIChoYW5kbGVBc09iamVjdEluSTE4bkZvcm1hdCAmJiBpc1N0cmluZyhqb2luQXJyYXlzKSAmJiBBcnJheS5pc0FycmF5KHJlcykpIHtcbiAgICAgIHJlcyA9IHJlcy5qb2luKGpvaW5BcnJheXMpO1xuICAgICAgaWYgKHJlcykgcmVzID0gdGhpcy5leHRlbmRUcmFuc2xhdGlvbihyZXMsIGtleXMsIG9wdCwgcmVzb2x2ZWQsIGxhc3RLZXkpO1xuICAgIH0gZWxzZSB7XG4gICAgICBsZXQgdXNlZERlZmF1bHQgPSBmYWxzZTtcbiAgICAgIGxldCB1c2VkS2V5ID0gZmFsc2U7XG4gICAgICBpZiAoIXRoaXMuaXNWYWxpZExvb2t1cChyZXMpICYmIGhhc0RlZmF1bHRWYWx1ZSkge1xuICAgICAgICB1c2VkRGVmYXVsdCA9IHRydWU7XG4gICAgICAgIHJlcyA9IGRlZmF1bHRWYWx1ZTtcbiAgICAgIH1cbiAgICAgIGlmICghdGhpcy5pc1ZhbGlkTG9va3VwKHJlcykpIHtcbiAgICAgICAgdXNlZEtleSA9IHRydWU7XG4gICAgICAgIHJlcyA9IGtleTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IG1pc3NpbmdLZXlOb1ZhbHVlRmFsbGJhY2tUb0tleSA9IG9wdC5taXNzaW5nS2V5Tm9WYWx1ZUZhbGxiYWNrVG9LZXkgfHwgdGhpcy5vcHRpb25zLm1pc3NpbmdLZXlOb1ZhbHVlRmFsbGJhY2tUb0tleTtcbiAgICAgIGNvbnN0IHJlc0Zvck1pc3NpbmcgPSBtaXNzaW5nS2V5Tm9WYWx1ZUZhbGxiYWNrVG9LZXkgJiYgdXNlZEtleSA/IHVuZGVmaW5lZCA6IHJlcztcbiAgICAgIGNvbnN0IHVwZGF0ZU1pc3NpbmcgPSBoYXNEZWZhdWx0VmFsdWUgJiYgZGVmYXVsdFZhbHVlICE9PSByZXMgJiYgdGhpcy5vcHRpb25zLnVwZGF0ZU1pc3Npbmc7XG4gICAgICBpZiAodXNlZEtleSB8fCB1c2VkRGVmYXVsdCB8fCB1cGRhdGVNaXNzaW5nKSB7XG4gICAgICAgIHRoaXMubG9nZ2VyLmxvZyh1cGRhdGVNaXNzaW5nID8gJ3VwZGF0ZUtleScgOiAnbWlzc2luZ0tleScsIGxuZywgbmFtZXNwYWNlLCBuZWVkc1BsdXJhbEhhbmRsaW5nICYmICF1cGRhdGVNaXNzaW5nID8gYCR7a2V5fSR7dGhpcy5wbHVyYWxSZXNvbHZlci5nZXRTdWZmaXgobG5nLCBvcHQuY291bnQsIG9wdCl9YCA6IGtleSwgdXBkYXRlTWlzc2luZyA/IGRlZmF1bHRWYWx1ZSA6IHJlcyk7XG4gICAgICAgIGlmIChrZXlTZXBhcmF0b3IpIHtcbiAgICAgICAgICBjb25zdCBmayA9IHRoaXMucmVzb2x2ZShrZXksIHtcbiAgICAgICAgICAgIC4uLm9wdCxcbiAgICAgICAgICAgIGtleVNlcGFyYXRvcjogZmFsc2VcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBpZiAoZmsgJiYgZmsucmVzKSB0aGlzLmxvZ2dlci53YXJuKCdTZWVtcyB0aGUgbG9hZGVkIHRyYW5zbGF0aW9ucyB3ZXJlIGluIGZsYXQgSlNPTiBmb3JtYXQgaW5zdGVhZCBvZiBuZXN0ZWQuIEVpdGhlciBzZXQga2V5U2VwYXJhdG9yOiBmYWxzZSBvbiBpbml0IG9yIG1ha2Ugc3VyZSB5b3VyIHRyYW5zbGF0aW9ucyBhcmUgcHVibGlzaGVkIGluIG5lc3RlZCBmb3JtYXQuJyk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IGxuZ3MgPSBbXTtcbiAgICAgICAgY29uc3QgZmFsbGJhY2tMbmdzID0gdGhpcy5sYW5ndWFnZVV0aWxzLmdldEZhbGxiYWNrQ29kZXModGhpcy5vcHRpb25zLmZhbGxiYWNrTG5nLCBvcHQubG5nIHx8IHRoaXMubGFuZ3VhZ2UpO1xuICAgICAgICBpZiAodGhpcy5vcHRpb25zLnNhdmVNaXNzaW5nVG8gPT09ICdmYWxsYmFjaycgJiYgZmFsbGJhY2tMbmdzICYmIGZhbGxiYWNrTG5nc1swXSkge1xuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZmFsbGJhY2tMbmdzLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBsbmdzLnB1c2goZmFsbGJhY2tMbmdzW2ldKTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5vcHRpb25zLnNhdmVNaXNzaW5nVG8gPT09ICdhbGwnKSB7XG4gICAgICAgICAgbG5ncyA9IHRoaXMubGFuZ3VhZ2VVdGlscy50b1Jlc29sdmVIaWVyYXJjaHkob3B0LmxuZyB8fCB0aGlzLmxhbmd1YWdlKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBsbmdzLnB1c2gob3B0LmxuZyB8fCB0aGlzLmxhbmd1YWdlKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBzZW5kID0gKGwsIGssIHNwZWNpZmljRGVmYXVsdFZhbHVlKSA9PiB7XG4gICAgICAgICAgY29uc3QgZGVmYXVsdEZvck1pc3NpbmcgPSBoYXNEZWZhdWx0VmFsdWUgJiYgc3BlY2lmaWNEZWZhdWx0VmFsdWUgIT09IHJlcyA/IHNwZWNpZmljRGVmYXVsdFZhbHVlIDogcmVzRm9yTWlzc2luZztcbiAgICAgICAgICBpZiAodGhpcy5vcHRpb25zLm1pc3NpbmdLZXlIYW5kbGVyKSB7XG4gICAgICAgICAgICB0aGlzLm9wdGlvbnMubWlzc2luZ0tleUhhbmRsZXIobCwgbmFtZXNwYWNlLCBrLCBkZWZhdWx0Rm9yTWlzc2luZywgdXBkYXRlTWlzc2luZywgb3B0KTtcbiAgICAgICAgICB9IGVsc2UgaWYgKHRoaXMuYmFja2VuZENvbm5lY3Rvcj8uc2F2ZU1pc3NpbmcpIHtcbiAgICAgICAgICAgIHRoaXMuYmFja2VuZENvbm5lY3Rvci5zYXZlTWlzc2luZyhsLCBuYW1lc3BhY2UsIGssIGRlZmF1bHRGb3JNaXNzaW5nLCB1cGRhdGVNaXNzaW5nLCBvcHQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0aGlzLmVtaXQoJ21pc3NpbmdLZXknLCBsLCBuYW1lc3BhY2UsIGssIHJlcyk7XG4gICAgICAgIH07XG4gICAgICAgIGlmICh0aGlzLm9wdGlvbnMuc2F2ZU1pc3NpbmcpIHtcbiAgICAgICAgICBpZiAodGhpcy5vcHRpb25zLnNhdmVNaXNzaW5nUGx1cmFscyAmJiBuZWVkc1BsdXJhbEhhbmRsaW5nKSB7XG4gICAgICAgICAgICBsbmdzLmZvckVhY2gobGFuZ3VhZ2UgPT4ge1xuICAgICAgICAgICAgICBjb25zdCBzdWZmaXhlcyA9IHRoaXMucGx1cmFsUmVzb2x2ZXIuZ2V0U3VmZml4ZXMobGFuZ3VhZ2UsIG9wdCk7XG4gICAgICAgICAgICAgIGlmIChuZWVkc1plcm9TdWZmaXhMb29rdXAgJiYgb3B0W2BkZWZhdWx0VmFsdWUke3RoaXMub3B0aW9ucy5wbHVyYWxTZXBhcmF0b3J9emVyb2BdICYmICFzdWZmaXhlcy5pbmNsdWRlcyhgJHt0aGlzLm9wdGlvbnMucGx1cmFsU2VwYXJhdG9yfXplcm9gKSkge1xuICAgICAgICAgICAgICAgIHN1ZmZpeGVzLnB1c2goYCR7dGhpcy5vcHRpb25zLnBsdXJhbFNlcGFyYXRvcn16ZXJvYCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgc3VmZml4ZXMuZm9yRWFjaChzdWZmaXggPT4ge1xuICAgICAgICAgICAgICAgIHNlbmQoW2xhbmd1YWdlXSwga2V5ICsgc3VmZml4LCBvcHRbYGRlZmF1bHRWYWx1ZSR7c3VmZml4fWBdIHx8IGRlZmF1bHRWYWx1ZSk7XG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNlbmQobG5ncywga2V5LCBkZWZhdWx0VmFsdWUpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgcmVzID0gdGhpcy5leHRlbmRUcmFuc2xhdGlvbihyZXMsIGtleXMsIG9wdCwgcmVzb2x2ZWQsIGxhc3RLZXkpO1xuICAgICAgaWYgKHVzZWRLZXkgJiYgcmVzID09PSBrZXkgJiYgdGhpcy5vcHRpb25zLmFwcGVuZE5hbWVzcGFjZVRvTWlzc2luZ0tleSkge1xuICAgICAgICByZXMgPSBgJHtuYW1lc3BhY2V9JHtuc1NlcGFyYXRvcn0ke2tleX1gO1xuICAgICAgfVxuICAgICAgaWYgKCh1c2VkS2V5IHx8IHVzZWREZWZhdWx0KSAmJiB0aGlzLm9wdGlvbnMucGFyc2VNaXNzaW5nS2V5SGFuZGxlcikge1xuICAgICAgICByZXMgPSB0aGlzLm9wdGlvbnMucGFyc2VNaXNzaW5nS2V5SGFuZGxlcih0aGlzLm9wdGlvbnMuYXBwZW5kTmFtZXNwYWNlVG9NaXNzaW5nS2V5ID8gYCR7bmFtZXNwYWNlfSR7bnNTZXBhcmF0b3J9JHtrZXl9YCA6IGtleSwgdXNlZERlZmF1bHQgPyByZXMgOiB1bmRlZmluZWQsIG9wdCk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmIChyZXR1cm5EZXRhaWxzKSB7XG4gICAgICByZXNvbHZlZC5yZXMgPSByZXM7XG4gICAgICByZXNvbHZlZC51c2VkUGFyYW1zID0gdGhpcy5nZXRVc2VkUGFyYW1zRGV0YWlscyhvcHQpO1xuICAgICAgcmV0dXJuIHJlc29sdmVkO1xuICAgIH1cbiAgICByZXR1cm4gcmVzO1xuICB9XG4gIGV4dGVuZFRyYW5zbGF0aW9uKHJlcywga2V5LCBvcHQsIHJlc29sdmVkLCBsYXN0S2V5KSB7XG4gICAgaWYgKHRoaXMuaTE4bkZvcm1hdD8ucGFyc2UpIHtcbiAgICAgIHJlcyA9IHRoaXMuaTE4bkZvcm1hdC5wYXJzZShyZXMsIHtcbiAgICAgICAgLi4udGhpcy5vcHRpb25zLmludGVycG9sYXRpb24uZGVmYXVsdFZhcmlhYmxlcyxcbiAgICAgICAgLi4ub3B0XG4gICAgICB9LCBvcHQubG5nIHx8IHRoaXMubGFuZ3VhZ2UgfHwgcmVzb2x2ZWQudXNlZExuZywgcmVzb2x2ZWQudXNlZE5TLCByZXNvbHZlZC51c2VkS2V5LCB7XG4gICAgICAgIHJlc29sdmVkXG4gICAgICB9KTtcbiAgICB9IGVsc2UgaWYgKCFvcHQuc2tpcEludGVycG9sYXRpb24pIHtcbiAgICAgIGlmIChvcHQuaW50ZXJwb2xhdGlvbikgdGhpcy5pbnRlcnBvbGF0b3IuaW5pdCh7XG4gICAgICAgIC4uLm9wdCxcbiAgICAgICAgLi4ue1xuICAgICAgICAgIGludGVycG9sYXRpb246IHtcbiAgICAgICAgICAgIC4uLnRoaXMub3B0aW9ucy5pbnRlcnBvbGF0aW9uLFxuICAgICAgICAgICAgLi4ub3B0LmludGVycG9sYXRpb25cbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH0pO1xuICAgICAgY29uc3Qgc2tpcE9uVmFyaWFibGVzID0gaXNTdHJpbmcocmVzKSAmJiAob3B0Py5pbnRlcnBvbGF0aW9uPy5za2lwT25WYXJpYWJsZXMgIT09IHVuZGVmaW5lZCA/IG9wdC5pbnRlcnBvbGF0aW9uLnNraXBPblZhcmlhYmxlcyA6IHRoaXMub3B0aW9ucy5pbnRlcnBvbGF0aW9uLnNraXBPblZhcmlhYmxlcyk7XG4gICAgICBsZXQgbmVzdEJlZjtcbiAgICAgIGlmIChza2lwT25WYXJpYWJsZXMpIHtcbiAgICAgICAgY29uc3QgbmIgPSByZXMubWF0Y2godGhpcy5pbnRlcnBvbGF0b3IubmVzdGluZ1JlZ2V4cCk7XG4gICAgICAgIG5lc3RCZWYgPSBuYiAmJiBuYi5sZW5ndGg7XG4gICAgICB9XG4gICAgICBsZXQgZGF0YSA9IG9wdC5yZXBsYWNlICYmICFpc1N0cmluZyhvcHQucmVwbGFjZSkgPyBvcHQucmVwbGFjZSA6IG9wdDtcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbi5kZWZhdWx0VmFyaWFibGVzKSBkYXRhID0ge1xuICAgICAgICAuLi50aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbi5kZWZhdWx0VmFyaWFibGVzLFxuICAgICAgICAuLi5kYXRhXG4gICAgICB9O1xuICAgICAgcmVzID0gdGhpcy5pbnRlcnBvbGF0b3IuaW50ZXJwb2xhdGUocmVzLCBkYXRhLCBvcHQubG5nIHx8IHRoaXMubGFuZ3VhZ2UgfHwgcmVzb2x2ZWQudXNlZExuZywgb3B0KTtcbiAgICAgIGlmIChza2lwT25WYXJpYWJsZXMpIHtcbiAgICAgICAgY29uc3QgbmEgPSByZXMubWF0Y2godGhpcy5pbnRlcnBvbGF0b3IubmVzdGluZ1JlZ2V4cCk7XG4gICAgICAgIGNvbnN0IG5lc3RBZnQgPSBuYSAmJiBuYS5sZW5ndGg7XG4gICAgICAgIGlmIChuZXN0QmVmIDwgbmVzdEFmdCkgb3B0Lm5lc3QgPSBmYWxzZTtcbiAgICAgIH1cbiAgICAgIGlmICghb3B0LmxuZyAmJiByZXNvbHZlZCAmJiByZXNvbHZlZC5yZXMpIG9wdC5sbmcgPSB0aGlzLmxhbmd1YWdlIHx8IHJlc29sdmVkLnVzZWRMbmc7XG4gICAgICBpZiAob3B0Lm5lc3QgIT09IGZhbHNlKSByZXMgPSB0aGlzLmludGVycG9sYXRvci5uZXN0KHJlcywgKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgaWYgKGxhc3RLZXk/LlswXSA9PT0gYXJnc1swXSAmJiAhb3B0LmNvbnRleHQpIHtcbiAgICAgICAgICB0aGlzLmxvZ2dlci53YXJuKGBJdCBzZWVtcyB5b3UgYXJlIG5lc3RpbmcgcmVjdXJzaXZlbHkga2V5OiAke2FyZ3NbMF19IGluIGtleTogJHtrZXlbMF19YCk7XG4gICAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMudHJhbnNsYXRlKC4uLmFyZ3MsIGtleSk7XG4gICAgICB9LCBvcHQpO1xuICAgICAgaWYgKG9wdC5pbnRlcnBvbGF0aW9uKSB0aGlzLmludGVycG9sYXRvci5yZXNldCgpO1xuICAgIH1cbiAgICBjb25zdCBwb3N0UHJvY2VzcyA9IG9wdC5wb3N0UHJvY2VzcyB8fCB0aGlzLm9wdGlvbnMucG9zdFByb2Nlc3M7XG4gICAgY29uc3QgcG9zdFByb2Nlc3Nvck5hbWVzID0gaXNTdHJpbmcocG9zdFByb2Nlc3MpID8gW3Bvc3RQcm9jZXNzXSA6IHBvc3RQcm9jZXNzO1xuICAgIGlmIChyZXMgIT0gbnVsbCAmJiBwb3N0UHJvY2Vzc29yTmFtZXM/Lmxlbmd0aCAmJiBvcHQuYXBwbHlQb3N0UHJvY2Vzc29yICE9PSBmYWxzZSkge1xuICAgICAgcmVzID0gcG9zdFByb2Nlc3Nvci5oYW5kbGUocG9zdFByb2Nlc3Nvck5hbWVzLCByZXMsIGtleSwgdGhpcy5vcHRpb25zICYmIHRoaXMub3B0aW9ucy5wb3N0UHJvY2Vzc1Bhc3NSZXNvbHZlZCA/IHtcbiAgICAgICAgaTE4blJlc29sdmVkOiB7XG4gICAgICAgICAgLi4ucmVzb2x2ZWQsXG4gICAgICAgICAgdXNlZFBhcmFtczogdGhpcy5nZXRVc2VkUGFyYW1zRGV0YWlscyhvcHQpXG4gICAgICAgIH0sXG4gICAgICAgIC4uLm9wdFxuICAgICAgfSA6IG9wdCwgdGhpcyk7XG4gICAgfVxuICAgIHJldHVybiByZXM7XG4gIH1cbiAgcmVzb2x2ZShrZXlzLCBvcHQgPSB7fSkge1xuICAgIGxldCBmb3VuZDtcbiAgICBsZXQgdXNlZEtleTtcbiAgICBsZXQgZXhhY3RVc2VkS2V5O1xuICAgIGxldCB1c2VkTG5nO1xuICAgIGxldCB1c2VkTlM7XG4gICAgaWYgKGlzU3RyaW5nKGtleXMpKSBrZXlzID0gW2tleXNdO1xuICAgIGlmIChBcnJheS5pc0FycmF5KGtleXMpKSBrZXlzID0ga2V5cy5tYXAoayA9PiB0eXBlb2YgayA9PT0gJ2Z1bmN0aW9uJyA/IGtleXNGcm9tU2VsZWN0b3Ioaywge1xuICAgICAgLi4udGhpcy5vcHRpb25zLFxuICAgICAgLi4ub3B0XG4gICAgfSkgOiBrKTtcbiAgICBrZXlzLmZvckVhY2goayA9PiB7XG4gICAgICBpZiAodGhpcy5pc1ZhbGlkTG9va3VwKGZvdW5kKSkgcmV0dXJuO1xuICAgICAgY29uc3QgZXh0cmFjdGVkID0gdGhpcy5leHRyYWN0RnJvbUtleShrLCBvcHQpO1xuICAgICAgY29uc3Qga2V5ID0gZXh0cmFjdGVkLmtleTtcbiAgICAgIHVzZWRLZXkgPSBrZXk7XG4gICAgICBsZXQgbmFtZXNwYWNlcyA9IGV4dHJhY3RlZC5uYW1lc3BhY2VzO1xuICAgICAgaWYgKHRoaXMub3B0aW9ucy5mYWxsYmFja05TKSBuYW1lc3BhY2VzID0gbmFtZXNwYWNlcy5jb25jYXQodGhpcy5vcHRpb25zLmZhbGxiYWNrTlMpO1xuICAgICAgY29uc3QgbmVlZHNQbHVyYWxIYW5kbGluZyA9IG9wdC5jb3VudCAhPT0gdW5kZWZpbmVkICYmICFpc1N0cmluZyhvcHQuY291bnQpO1xuICAgICAgY29uc3QgbmVlZHNaZXJvU3VmZml4TG9va3VwID0gbmVlZHNQbHVyYWxIYW5kbGluZyAmJiAhb3B0Lm9yZGluYWwgJiYgb3B0LmNvdW50ID09PSAwO1xuICAgICAgY29uc3QgbmVlZHNDb250ZXh0SGFuZGxpbmcgPSBvcHQuY29udGV4dCAhPT0gdW5kZWZpbmVkICYmIChpc1N0cmluZyhvcHQuY29udGV4dCkgfHwgdHlwZW9mIG9wdC5jb250ZXh0ID09PSAnbnVtYmVyJykgJiYgb3B0LmNvbnRleHQgIT09ICcnO1xuICAgICAgY29uc3QgY29kZXMgPSBvcHQubG5ncyA/IG9wdC5sbmdzIDogdGhpcy5sYW5ndWFnZVV0aWxzLnRvUmVzb2x2ZUhpZXJhcmNoeShvcHQubG5nIHx8IHRoaXMubGFuZ3VhZ2UsIG9wdC5mYWxsYmFja0xuZyk7XG4gICAgICBuYW1lc3BhY2VzLmZvckVhY2gobnMgPT4ge1xuICAgICAgICBpZiAodGhpcy5pc1ZhbGlkTG9va3VwKGZvdW5kKSkgcmV0dXJuO1xuICAgICAgICB1c2VkTlMgPSBucztcbiAgICAgICAgaWYgKCF0aGlzLmNoZWNrZWRMb2FkZWRGb3JbYCR7Y29kZXNbMF19LSR7bnN9YF0gJiYgdGhpcy51dGlscz8uaGFzTG9hZGVkTmFtZXNwYWNlICYmICF0aGlzLnV0aWxzPy5oYXNMb2FkZWROYW1lc3BhY2UodXNlZE5TKSkge1xuICAgICAgICAgIHRoaXMuY2hlY2tlZExvYWRlZEZvcltgJHtjb2Rlc1swXX0tJHtuc31gXSA9IHRydWU7XG4gICAgICAgICAgdGhpcy5sb2dnZXIud2Fybihga2V5IFwiJHt1c2VkS2V5fVwiIGZvciBsYW5ndWFnZXMgXCIke2NvZGVzLmpvaW4oJywgJyl9XCIgd29uJ3QgZ2V0IHJlc29sdmVkIGFzIG5hbWVzcGFjZSBcIiR7dXNlZE5TfVwiIHdhcyBub3QgeWV0IGxvYWRlZGAsICdUaGlzIG1lYW5zIHNvbWV0aGluZyBJUyBXUk9ORyBpbiB5b3VyIHNldHVwLiBZb3UgYWNjZXNzIHRoZSB0IGZ1bmN0aW9uIGJlZm9yZSBpMThuZXh0LmluaXQgLyBpMThuZXh0LmxvYWROYW1lc3BhY2UgLyBpMThuZXh0LmNoYW5nZUxhbmd1YWdlIHdhcyBkb25lLiBXYWl0IGZvciB0aGUgY2FsbGJhY2sgb3IgUHJvbWlzZSB0byByZXNvbHZlIGJlZm9yZSBhY2Nlc3NpbmcgaXQhISEnKTtcbiAgICAgICAgfVxuICAgICAgICBjb2Rlcy5mb3JFYWNoKGNvZGUgPT4ge1xuICAgICAgICAgIGlmICh0aGlzLmlzVmFsaWRMb29rdXAoZm91bmQpKSByZXR1cm47XG4gICAgICAgICAgdXNlZExuZyA9IGNvZGU7XG4gICAgICAgICAgY29uc3QgZmluYWxLZXlzID0gW2tleV07XG4gICAgICAgICAgaWYgKHRoaXMuaTE4bkZvcm1hdD8uYWRkTG9va3VwS2V5cykge1xuICAgICAgICAgICAgdGhpcy5pMThuRm9ybWF0LmFkZExvb2t1cEtleXMoZmluYWxLZXlzLCBrZXksIGNvZGUsIG5zLCBvcHQpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBsZXQgcGx1cmFsU3VmZml4O1xuICAgICAgICAgICAgaWYgKG5lZWRzUGx1cmFsSGFuZGxpbmcpIHBsdXJhbFN1ZmZpeCA9IHRoaXMucGx1cmFsUmVzb2x2ZXIuZ2V0U3VmZml4KGNvZGUsIG9wdC5jb3VudCwgb3B0KTtcbiAgICAgICAgICAgIGNvbnN0IHplcm9TdWZmaXggPSBgJHt0aGlzLm9wdGlvbnMucGx1cmFsU2VwYXJhdG9yfXplcm9gO1xuICAgICAgICAgICAgY29uc3Qgb3JkaW5hbFByZWZpeCA9IGAke3RoaXMub3B0aW9ucy5wbHVyYWxTZXBhcmF0b3J9b3JkaW5hbCR7dGhpcy5vcHRpb25zLnBsdXJhbFNlcGFyYXRvcn1gO1xuICAgICAgICAgICAgaWYgKG5lZWRzUGx1cmFsSGFuZGxpbmcpIHtcbiAgICAgICAgICAgICAgaWYgKG9wdC5vcmRpbmFsICYmIHBsdXJhbFN1ZmZpeC5zdGFydHNXaXRoKG9yZGluYWxQcmVmaXgpKSB7XG4gICAgICAgICAgICAgICAgZmluYWxLZXlzLnB1c2goa2V5ICsgcGx1cmFsU3VmZml4LnJlcGxhY2Uob3JkaW5hbFByZWZpeCwgdGhpcy5vcHRpb25zLnBsdXJhbFNlcGFyYXRvcikpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGZpbmFsS2V5cy5wdXNoKGtleSArIHBsdXJhbFN1ZmZpeCk7XG4gICAgICAgICAgICAgIGlmIChuZWVkc1plcm9TdWZmaXhMb29rdXApIHtcbiAgICAgICAgICAgICAgICBmaW5hbEtleXMucHVzaChrZXkgKyB6ZXJvU3VmZml4KTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG5lZWRzQ29udGV4dEhhbmRsaW5nKSB7XG4gICAgICAgICAgICAgIGNvbnN0IGNvbnRleHRLZXkgPSBgJHtrZXl9JHt0aGlzLm9wdGlvbnMuY29udGV4dFNlcGFyYXRvciB8fCAnXyd9JHtvcHQuY29udGV4dH1gO1xuICAgICAgICAgICAgICBmaW5hbEtleXMucHVzaChjb250ZXh0S2V5KTtcbiAgICAgICAgICAgICAgaWYgKG5lZWRzUGx1cmFsSGFuZGxpbmcpIHtcbiAgICAgICAgICAgICAgICBpZiAob3B0Lm9yZGluYWwgJiYgcGx1cmFsU3VmZml4LnN0YXJ0c1dpdGgob3JkaW5hbFByZWZpeCkpIHtcbiAgICAgICAgICAgICAgICAgIGZpbmFsS2V5cy5wdXNoKGNvbnRleHRLZXkgKyBwbHVyYWxTdWZmaXgucmVwbGFjZShvcmRpbmFsUHJlZml4LCB0aGlzLm9wdGlvbnMucGx1cmFsU2VwYXJhdG9yKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGZpbmFsS2V5cy5wdXNoKGNvbnRleHRLZXkgKyBwbHVyYWxTdWZmaXgpO1xuICAgICAgICAgICAgICAgIGlmIChuZWVkc1plcm9TdWZmaXhMb29rdXApIHtcbiAgICAgICAgICAgICAgICAgIGZpbmFsS2V5cy5wdXNoKGNvbnRleHRLZXkgKyB6ZXJvU3VmZml4KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgICAgbGV0IHBvc3NpYmxlS2V5O1xuICAgICAgICAgIHdoaWxlIChwb3NzaWJsZUtleSA9IGZpbmFsS2V5cy5wb3AoKSkge1xuICAgICAgICAgICAgaWYgKCF0aGlzLmlzVmFsaWRMb29rdXAoZm91bmQpKSB7XG4gICAgICAgICAgICAgIGV4YWN0VXNlZEtleSA9IHBvc3NpYmxlS2V5O1xuICAgICAgICAgICAgICBmb3VuZCA9IHRoaXMuZ2V0UmVzb3VyY2UoY29kZSwgbnMsIHBvc3NpYmxlS2V5LCBvcHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9KTtcbiAgICB9KTtcbiAgICByZXR1cm4ge1xuICAgICAgcmVzOiBmb3VuZCxcbiAgICAgIHVzZWRLZXksXG4gICAgICBleGFjdFVzZWRLZXksXG4gICAgICB1c2VkTG5nLFxuICAgICAgdXNlZE5TXG4gICAgfTtcbiAgfVxuICBpc1ZhbGlkTG9va3VwKHJlcykge1xuICAgIHJldHVybiByZXMgIT09IHVuZGVmaW5lZCAmJiAhKCF0aGlzLm9wdGlvbnMucmV0dXJuTnVsbCAmJiByZXMgPT09IG51bGwpICYmICEoIXRoaXMub3B0aW9ucy5yZXR1cm5FbXB0eVN0cmluZyAmJiByZXMgPT09ICcnKTtcbiAgfVxuICBnZXRSZXNvdXJjZShjb2RlLCBucywga2V5LCBvcHRpb25zID0ge30pIHtcbiAgICBpZiAodGhpcy5pMThuRm9ybWF0Py5nZXRSZXNvdXJjZSkgcmV0dXJuIHRoaXMuaTE4bkZvcm1hdC5nZXRSZXNvdXJjZShjb2RlLCBucywga2V5LCBvcHRpb25zKTtcbiAgICByZXR1cm4gdGhpcy5yZXNvdXJjZVN0b3JlLmdldFJlc291cmNlKGNvZGUsIG5zLCBrZXksIG9wdGlvbnMpO1xuICB9XG4gIGdldFVzZWRQYXJhbXNEZXRhaWxzKG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IG9wdGlvbnNLZXlzID0gWydkZWZhdWx0VmFsdWUnLCAnb3JkaW5hbCcsICdjb250ZXh0JywgJ3JlcGxhY2UnLCAnbG5nJywgJ2xuZ3MnLCAnZmFsbGJhY2tMbmcnLCAnbnMnLCAna2V5U2VwYXJhdG9yJywgJ25zU2VwYXJhdG9yJywgJ3JldHVybk9iamVjdHMnLCAncmV0dXJuRGV0YWlscycsICdqb2luQXJyYXlzJywgJ3Bvc3RQcm9jZXNzJywgJ2ludGVycG9sYXRpb24nXTtcbiAgICBjb25zdCB1c2VPcHRpb25zUmVwbGFjZUZvckRhdGEgPSBvcHRpb25zLnJlcGxhY2UgJiYgIWlzU3RyaW5nKG9wdGlvbnMucmVwbGFjZSk7XG4gICAgbGV0IGRhdGEgPSB1c2VPcHRpb25zUmVwbGFjZUZvckRhdGEgPyBvcHRpb25zLnJlcGxhY2UgOiBvcHRpb25zO1xuICAgIGlmICh1c2VPcHRpb25zUmVwbGFjZUZvckRhdGEgJiYgdHlwZW9mIG9wdGlvbnMuY291bnQgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBkYXRhID0ge1xuICAgICAgICAuLi5kYXRhLFxuICAgICAgICBjb3VudDogb3B0aW9ucy5jb3VudFxuICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHRoaXMub3B0aW9ucy5pbnRlcnBvbGF0aW9uLmRlZmF1bHRWYXJpYWJsZXMpIHtcbiAgICAgIGRhdGEgPSB7XG4gICAgICAgIC4uLnRoaXMub3B0aW9ucy5pbnRlcnBvbGF0aW9uLmRlZmF1bHRWYXJpYWJsZXMsXG4gICAgICAgIC4uLmRhdGFcbiAgICAgIH07XG4gICAgfVxuICAgIGlmICghdXNlT3B0aW9uc1JlcGxhY2VGb3JEYXRhKSB7XG4gICAgICBkYXRhID0ge1xuICAgICAgICAuLi5kYXRhXG4gICAgICB9O1xuICAgICAgZm9yIChjb25zdCBrZXkgb2Ygb3B0aW9uc0tleXMpIHtcbiAgICAgICAgZGVsZXRlIGRhdGFba2V5XTtcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGRhdGE7XG4gIH1cbiAgc3RhdGljIGhhc0RlZmF1bHRWYWx1ZShvcHRpb25zKSB7XG4gICAgY29uc3QgcHJlZml4ID0gJ2RlZmF1bHRWYWx1ZSc7XG4gICAgZm9yIChjb25zdCBvcHRpb24gaW4gb3B0aW9ucykge1xuICAgICAgaWYgKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvcHRpb25zLCBvcHRpb24pICYmIG9wdGlvbi5zdGFydHNXaXRoKHByZWZpeCkgJiYgdW5kZWZpbmVkICE9PSBvcHRpb25zW29wdGlvbl0pIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG5jbGFzcyBMYW5ndWFnZVV0aWwge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zKSB7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLnN1cHBvcnRlZExuZ3MgPSB0aGlzLm9wdGlvbnMuc3VwcG9ydGVkTG5ncyB8fCBmYWxzZTtcbiAgICB0aGlzLmxvZ2dlciA9IGJhc2VMb2dnZXIuY3JlYXRlKCdsYW5ndWFnZVV0aWxzJyk7XG4gICAgdGhpcy5yZXNvbHZlSGllcmFyY2h5Q2FjaGUgPSB7fTtcbiAgfVxuICBjbGVhckNhY2hlKCkge1xuICAgIHRoaXMucmVzb2x2ZUhpZXJhcmNoeUNhY2hlID0ge307XG4gIH1cbiAgZ2V0U2NyaXB0UGFydEZyb21Db2RlKGNvZGUpIHtcbiAgICBjb2RlID0gZ2V0Q2xlYW5lZENvZGUoY29kZSk7XG4gICAgaWYgKCFjb2RlIHx8ICFjb2RlLmluY2x1ZGVzKCctJykpIHJldHVybiBudWxsO1xuICAgIGNvbnN0IHAgPSBjb2RlLnNwbGl0KCctJyk7XG4gICAgaWYgKHAubGVuZ3RoID09PSAyKSByZXR1cm4gbnVsbDtcbiAgICBwLnBvcCgpO1xuICAgIGlmIChwW3AubGVuZ3RoIC0gMV0udG9Mb3dlckNhc2UoKSA9PT0gJ3gnKSByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gdGhpcy5mb3JtYXRMYW5ndWFnZUNvZGUocC5qb2luKCctJykpO1xuICB9XG4gIGdldExhbmd1YWdlUGFydEZyb21Db2RlKGNvZGUpIHtcbiAgICBjb2RlID0gZ2V0Q2xlYW5lZENvZGUoY29kZSk7XG4gICAgaWYgKCFjb2RlIHx8ICFjb2RlLmluY2x1ZGVzKCctJykpIHJldHVybiBjb2RlO1xuICAgIGNvbnN0IHAgPSBjb2RlLnNwbGl0KCctJyk7XG4gICAgcmV0dXJuIHRoaXMuZm9ybWF0TGFuZ3VhZ2VDb2RlKHBbMF0pO1xuICB9XG4gIGZvcm1hdExhbmd1YWdlQ29kZShjb2RlKSB7XG4gICAgaWYgKGlzU3RyaW5nKGNvZGUpICYmIGNvZGUuaW5jbHVkZXMoJy0nKSkge1xuICAgICAgbGV0IGZvcm1hdHRlZENvZGU7XG4gICAgICB0cnkge1xuICAgICAgICBmb3JtYXR0ZWRDb2RlID0gSW50bC5nZXRDYW5vbmljYWxMb2NhbGVzKGNvZGUpWzBdO1xuICAgICAgfSBjYXRjaCAoZSkge31cbiAgICAgIGlmIChmb3JtYXR0ZWRDb2RlICYmIHRoaXMub3B0aW9ucy5sb3dlckNhc2VMbmcpIHtcbiAgICAgICAgZm9ybWF0dGVkQ29kZSA9IGZvcm1hdHRlZENvZGUudG9Mb3dlckNhc2UoKTtcbiAgICAgIH1cbiAgICAgIGlmIChmb3JtYXR0ZWRDb2RlKSByZXR1cm4gZm9ybWF0dGVkQ29kZTtcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMubG93ZXJDYXNlTG5nKSB7XG4gICAgICAgIHJldHVybiBjb2RlLnRvTG93ZXJDYXNlKCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gY29kZTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMub3B0aW9ucy5jbGVhbkNvZGUgfHwgdGhpcy5vcHRpb25zLmxvd2VyQ2FzZUxuZyA/IGNvZGUudG9Mb3dlckNhc2UoKSA6IGNvZGU7XG4gIH1cbiAgaXNTdXBwb3J0ZWRDb2RlKGNvZGUpIHtcbiAgICBpZiAodGhpcy5vcHRpb25zLmxvYWQgPT09ICdsYW5ndWFnZU9ubHknIHx8IHRoaXMub3B0aW9ucy5ub25FeHBsaWNpdFN1cHBvcnRlZExuZ3MpIHtcbiAgICAgIGNvZGUgPSB0aGlzLmdldExhbmd1YWdlUGFydEZyb21Db2RlKGNvZGUpO1xuICAgIH1cbiAgICByZXR1cm4gIXRoaXMuc3VwcG9ydGVkTG5ncyB8fCAhdGhpcy5zdXBwb3J0ZWRMbmdzLmxlbmd0aCB8fCB0aGlzLnN1cHBvcnRlZExuZ3MuaW5jbHVkZXMoY29kZSk7XG4gIH1cbiAgZ2V0QmVzdE1hdGNoRnJvbUNvZGVzKGNvZGVzKSB7XG4gICAgaWYgKCFjb2RlcykgcmV0dXJuIG51bGw7XG4gICAgbGV0IGZvdW5kO1xuICAgIGNvZGVzLmZvckVhY2goY29kZSA9PiB7XG4gICAgICBpZiAoZm91bmQpIHJldHVybjtcbiAgICAgIGNvbnN0IGNsZWFuZWRMbmcgPSB0aGlzLmZvcm1hdExhbmd1YWdlQ29kZShjb2RlKTtcbiAgICAgIGlmICghdGhpcy5vcHRpb25zLnN1cHBvcnRlZExuZ3MgfHwgdGhpcy5pc1N1cHBvcnRlZENvZGUoY2xlYW5lZExuZykpIGZvdW5kID0gY2xlYW5lZExuZztcbiAgICB9KTtcbiAgICBpZiAoIWZvdW5kICYmIHRoaXMub3B0aW9ucy5zdXBwb3J0ZWRMbmdzKSB7XG4gICAgICBjb2Rlcy5mb3JFYWNoKGNvZGUgPT4ge1xuICAgICAgICBpZiAoZm91bmQpIHJldHVybjtcbiAgICAgICAgY29uc3QgbG5nU2NPbmx5ID0gdGhpcy5nZXRTY3JpcHRQYXJ0RnJvbUNvZGUoY29kZSk7XG4gICAgICAgIGlmICh0aGlzLmlzU3VwcG9ydGVkQ29kZShsbmdTY09ubHkpKSByZXR1cm4gZm91bmQgPSBsbmdTY09ubHk7XG4gICAgICAgIGNvbnN0IGxuZ09ubHkgPSB0aGlzLmdldExhbmd1YWdlUGFydEZyb21Db2RlKGNvZGUpO1xuICAgICAgICBpZiAodGhpcy5pc1N1cHBvcnRlZENvZGUobG5nT25seSkpIHJldHVybiBmb3VuZCA9IGxuZ09ubHk7XG4gICAgICAgIGZvdW5kID0gdGhpcy5vcHRpb25zLnN1cHBvcnRlZExuZ3MuZmluZChzdXBwb3J0ZWRMbmcgPT4ge1xuICAgICAgICAgIGlmIChzdXBwb3J0ZWRMbmcgPT09IGxuZ09ubHkpIHJldHVybiB0cnVlO1xuICAgICAgICAgIGlmICghc3VwcG9ydGVkTG5nLmluY2x1ZGVzKCctJykgJiYgIWxuZ09ubHkuaW5jbHVkZXMoJy0nKSkgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIGlmIChzdXBwb3J0ZWRMbmcuaW5jbHVkZXMoJy0nKSAmJiAhbG5nT25seS5pbmNsdWRlcygnLScpICYmIHN1cHBvcnRlZExuZy5zbGljZSgwLCBzdXBwb3J0ZWRMbmcuaW5kZXhPZignLScpKSA9PT0gbG5nT25seSkgcmV0dXJuIHRydWU7XG4gICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9KTtcbiAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoIWZvdW5kKSBmb3VuZCA9IHRoaXMuZ2V0RmFsbGJhY2tDb2Rlcyh0aGlzLm9wdGlvbnMuZmFsbGJhY2tMbmcpWzBdO1xuICAgIHJldHVybiBmb3VuZDtcbiAgfVxuICBnZXRGYWxsYmFja0NvZGVzKGZhbGxiYWNrcywgY29kZSkge1xuICAgIGlmICghZmFsbGJhY2tzKSByZXR1cm4gW107XG4gICAgaWYgKHR5cGVvZiBmYWxsYmFja3MgPT09ICdmdW5jdGlvbicpIGZhbGxiYWNrcyA9IGZhbGxiYWNrcyhjb2RlKTtcbiAgICBpZiAoaXNTdHJpbmcoZmFsbGJhY2tzKSkgZmFsbGJhY2tzID0gW2ZhbGxiYWNrc107XG4gICAgaWYgKEFycmF5LmlzQXJyYXkoZmFsbGJhY2tzKSkgcmV0dXJuIGZhbGxiYWNrcztcbiAgICBpZiAoIWNvZGUpIHJldHVybiBmYWxsYmFja3MuZGVmYXVsdCB8fCBbXTtcbiAgICBsZXQgZm91bmQgPSBmYWxsYmFja3NbY29kZV07XG4gICAgaWYgKCFmb3VuZCkgZm91bmQgPSBmYWxsYmFja3NbdGhpcy5nZXRTY3JpcHRQYXJ0RnJvbUNvZGUoY29kZSldO1xuICAgIGlmICghZm91bmQpIGZvdW5kID0gZmFsbGJhY2tzW3RoaXMuZm9ybWF0TGFuZ3VhZ2VDb2RlKGNvZGUpXTtcbiAgICBpZiAoIWZvdW5kKSBmb3VuZCA9IGZhbGxiYWNrc1t0aGlzLmdldExhbmd1YWdlUGFydEZyb21Db2RlKGNvZGUpXTtcbiAgICBpZiAoIWZvdW5kKSBmb3VuZCA9IGZhbGxiYWNrcy5kZWZhdWx0O1xuICAgIHJldHVybiBmb3VuZCB8fCBbXTtcbiAgfVxuICB0b1Jlc29sdmVIaWVyYXJjaHkoY29kZSwgZmFsbGJhY2tDb2RlKSB7XG4gICAgY29uc3QgZmFsbGJhY2tMbmcgPSB0aGlzLm9wdGlvbnMuZmFsbGJhY2tMbmc7XG4gICAgY29uc3QgZmFsbGJhY2tMbmdLZXkgPSBBcnJheS5pc0FycmF5KGZhbGxiYWNrTG5nKSA/IGZhbGxiYWNrTG5nLmpvaW4oJ3wnKSA6IGZhbGxiYWNrTG5nO1xuICAgIGlmIChmYWxsYmFja0xuZ0tleSAhPT0gdGhpcy5fY2FjaGVkRmFsbGJhY2tMbmcpIHtcbiAgICAgIHRoaXMucmVzb2x2ZUhpZXJhcmNoeUNhY2hlID0ge307XG4gICAgICB0aGlzLl9jYWNoZWRGYWxsYmFja0xuZyA9IGZhbGxiYWNrTG5nS2V5O1xuICAgIH1cbiAgICBjb25zdCBoYXNDYWNoZWFibGVGYWxsYmFjayA9IGZhbGxiYWNrQ29kZSA9PT0gdW5kZWZpbmVkIHx8IGZhbGxiYWNrQ29kZSA9PT0gZmFsc2UgfHwgaXNTdHJpbmcoZmFsbGJhY2tDb2RlKTtcbiAgICBjb25zdCB1c2VzVW5jYWNoZWFibGVPcHRpb25zRmFsbGJhY2sgPSBmYWxsYmFja0NvZGUgPT09IHVuZGVmaW5lZCAmJiB0eXBlb2YgdGhpcy5vcHRpb25zLmZhbGxiYWNrTG5nID09PSAnZnVuY3Rpb24nO1xuICAgIGNvbnN0IGNhY2hlYWJsZSA9IGlzU3RyaW5nKGNvZGUpICYmIGhhc0NhY2hlYWJsZUZhbGxiYWNrICYmICF1c2VzVW5jYWNoZWFibGVPcHRpb25zRmFsbGJhY2s7XG4gICAgbGV0IGNhY2hlS2V5ID0gbnVsbDtcbiAgICBpZiAoY2FjaGVhYmxlKSB7XG4gICAgICBsZXQgZmFsbGJhY2tDYWNoZUtleTtcbiAgICAgIGlmIChmYWxsYmFja0NvZGUgPT09IHVuZGVmaW5lZCkgZmFsbGJhY2tDYWNoZUtleSA9ICd1bmRlZmluZWQnO2Vsc2UgaWYgKGZhbGxiYWNrQ29kZSA9PT0gZmFsc2UpIGZhbGxiYWNrQ2FjaGVLZXkgPSAnYm9vbGVhbjpmYWxzZSc7ZWxzZSBmYWxsYmFja0NhY2hlS2V5ID0gYHN0cmluZzoke2ZhbGxiYWNrQ29kZX1gO1xuICAgICAgY2FjaGVLZXkgPSBgJHtjb2RlLmxlbmd0aH06JHtjb2RlfXwke2ZhbGxiYWNrQ2FjaGVLZXl9YDtcbiAgICB9XG4gICAgaWYgKGNhY2hlS2V5ICE9PSBudWxsKSB7XG4gICAgICBjb25zdCBjYWNoZWQgPSB0aGlzLnJlc29sdmVIaWVyYXJjaHlDYWNoZVtjYWNoZUtleV07XG4gICAgICBpZiAoY2FjaGVkICE9PSB1bmRlZmluZWQpIHJldHVybiBjYWNoZWQuc2xpY2UoKTtcbiAgICB9XG4gICAgY29uc3QgZmFsbGJhY2tDb2RlcyA9IHRoaXMuZ2V0RmFsbGJhY2tDb2RlcygoZmFsbGJhY2tDb2RlID09PSBmYWxzZSA/IFtdIDogZmFsbGJhY2tDb2RlKSB8fCB0aGlzLm9wdGlvbnMuZmFsbGJhY2tMbmcgfHwgW10sIGNvZGUpO1xuICAgIGNvbnN0IGNvZGVzID0gW107XG4gICAgY29uc3QgYWRkQ29kZSA9IGMgPT4ge1xuICAgICAgaWYgKCFjKSByZXR1cm47XG4gICAgICBpZiAodGhpcy5pc1N1cHBvcnRlZENvZGUoYykpIHtcbiAgICAgICAgY29kZXMucHVzaChjKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHRoaXMubG9nZ2VyLndhcm4oYHJlamVjdGluZyBsYW5ndWFnZSBjb2RlIG5vdCBmb3VuZCBpbiBzdXBwb3J0ZWRMbmdzOiAke2N9YCk7XG4gICAgICB9XG4gICAgfTtcbiAgICBpZiAoaXNTdHJpbmcoY29kZSkgJiYgKGNvZGUuaW5jbHVkZXMoJy0nKSB8fCBjb2RlLmluY2x1ZGVzKCdfJykpKSB7XG4gICAgICBpZiAodGhpcy5vcHRpb25zLmxvYWQgIT09ICdsYW5ndWFnZU9ubHknKSBhZGRDb2RlKHRoaXMuZm9ybWF0TGFuZ3VhZ2VDb2RlKGNvZGUpKTtcbiAgICAgIGlmICh0aGlzLm9wdGlvbnMubG9hZCAhPT0gJ2xhbmd1YWdlT25seScgJiYgdGhpcy5vcHRpb25zLmxvYWQgIT09ICdjdXJyZW50T25seScpIGFkZENvZGUodGhpcy5nZXRTY3JpcHRQYXJ0RnJvbUNvZGUoY29kZSkpO1xuICAgICAgaWYgKHRoaXMub3B0aW9ucy5sb2FkICE9PSAnY3VycmVudE9ubHknKSBhZGRDb2RlKHRoaXMuZ2V0TGFuZ3VhZ2VQYXJ0RnJvbUNvZGUoY29kZSkpO1xuICAgIH0gZWxzZSBpZiAoaXNTdHJpbmcoY29kZSkpIHtcbiAgICAgIGFkZENvZGUodGhpcy5mb3JtYXRMYW5ndWFnZUNvZGUoY29kZSkpO1xuICAgIH1cbiAgICBmYWxsYmFja0NvZGVzLmZvckVhY2goZmMgPT4ge1xuICAgICAgY29uc3QgZm9ybWF0dGVkRmMgPSB0aGlzLmZvcm1hdExhbmd1YWdlQ29kZShmYyk7XG4gICAgICBpZiAoIWNvZGVzLmluY2x1ZGVzKGZvcm1hdHRlZEZjKSkgYWRkQ29kZShmb3JtYXR0ZWRGYyk7XG4gICAgfSk7XG4gICAgaWYgKGNhY2hlS2V5ICE9PSBudWxsKSB7XG4gICAgICB0aGlzLnJlc29sdmVIaWVyYXJjaHlDYWNoZVtjYWNoZUtleV0gPSBjb2RlcztcbiAgICAgIHJldHVybiBjb2Rlcy5zbGljZSgpO1xuICAgIH1cbiAgICByZXR1cm4gY29kZXM7XG4gIH1cbn1cblxuY29uc3Qgc3VmZml4ZXNPcmRlciA9IHtcbiAgemVybzogMCxcbiAgb25lOiAxLFxuICB0d286IDIsXG4gIGZldzogMyxcbiAgbWFueTogNCxcbiAgb3RoZXI6IDVcbn07XG5jb25zdCBkdW1teVJ1bGUgPSB7XG4gIHNlbGVjdDogY291bnQgPT4gY291bnQgPT09IDEgPyAnb25lJyA6ICdvdGhlcicsXG4gIHJlc29sdmVkT3B0aW9uczogKCkgPT4gKHtcbiAgICBwbHVyYWxDYXRlZ29yaWVzOiBbJ29uZScsICdvdGhlciddXG4gIH0pXG59O1xuY2xhc3MgUGx1cmFsUmVzb2x2ZXIge1xuICBjb25zdHJ1Y3RvcihsYW5ndWFnZVV0aWxzLCBvcHRpb25zID0ge30pIHtcbiAgICB0aGlzLmxhbmd1YWdlVXRpbHMgPSBsYW5ndWFnZVV0aWxzO1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy5sb2dnZXIgPSBiYXNlTG9nZ2VyLmNyZWF0ZSgncGx1cmFsUmVzb2x2ZXInKTtcbiAgICB0aGlzLnBsdXJhbFJ1bGVzQ2FjaGUgPSB7fTtcbiAgfVxuICBjbGVhckNhY2hlKCkge1xuICAgIHRoaXMucGx1cmFsUnVsZXNDYWNoZSA9IHt9O1xuICB9XG4gIGdldFJ1bGUoY29kZSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3QgY2xlYW5lZENvZGUgPSBnZXRDbGVhbmVkQ29kZShjb2RlID09PSAnZGV2JyA/ICdlbicgOiBjb2RlKTtcbiAgICBjb25zdCB0eXBlID0gb3B0aW9ucy5vcmRpbmFsID8gJ29yZGluYWwnIDogJ2NhcmRpbmFsJztcbiAgICBjb25zdCBjYWNoZUtleSA9IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgIGNsZWFuZWRDb2RlLFxuICAgICAgdHlwZVxuICAgIH0pO1xuICAgIGlmIChjYWNoZUtleSBpbiB0aGlzLnBsdXJhbFJ1bGVzQ2FjaGUpIHtcbiAgICAgIHJldHVybiB0aGlzLnBsdXJhbFJ1bGVzQ2FjaGVbY2FjaGVLZXldO1xuICAgIH1cbiAgICBsZXQgcnVsZTtcbiAgICB0cnkge1xuICAgICAgcnVsZSA9IG5ldyBJbnRsLlBsdXJhbFJ1bGVzKGNsZWFuZWRDb2RlLCB7XG4gICAgICAgIHR5cGVcbiAgICAgIH0pO1xuICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgaWYgKHR5cGVvZiBJbnRsID09PSAndW5kZWZpbmVkJykge1xuICAgICAgICB0aGlzLmxvZ2dlci5lcnJvcignTm8gSW50bCBzdXBwb3J0LCBwbGVhc2UgdXNlIGFuIEludGwgcG9seWZpbGwhJyk7XG4gICAgICAgIHJldHVybiBkdW1teVJ1bGU7XG4gICAgICB9XG4gICAgICBpZiAoIWNvZGUubWF0Y2goLy18Xy8pKSByZXR1cm4gZHVtbXlSdWxlO1xuICAgICAgY29uc3QgbG5nUGFydCA9IHRoaXMubGFuZ3VhZ2VVdGlscy5nZXRMYW5ndWFnZVBhcnRGcm9tQ29kZShjb2RlKTtcbiAgICAgIHJ1bGUgPSB0aGlzLmdldFJ1bGUobG5nUGFydCwgb3B0aW9ucyk7XG4gICAgfVxuICAgIHRoaXMucGx1cmFsUnVsZXNDYWNoZVtjYWNoZUtleV0gPSBydWxlO1xuICAgIHJldHVybiBydWxlO1xuICB9XG4gIG5lZWRzUGx1cmFsKGNvZGUsIG9wdGlvbnMgPSB7fSkge1xuICAgIGxldCBydWxlID0gdGhpcy5nZXRSdWxlKGNvZGUsIG9wdGlvbnMpO1xuICAgIGlmICghcnVsZSkgcnVsZSA9IHRoaXMuZ2V0UnVsZSgnZGV2Jywgb3B0aW9ucyk7XG4gICAgcmV0dXJuIHJ1bGU/LnJlc29sdmVkT3B0aW9ucygpLnBsdXJhbENhdGVnb3JpZXMubGVuZ3RoID4gMTtcbiAgfVxuICBnZXRQbHVyYWxGb3Jtc09mS2V5KGNvZGUsIGtleSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3VmZml4ZXMoY29kZSwgb3B0aW9ucykubWFwKHN1ZmZpeCA9PiBgJHtrZXl9JHtzdWZmaXh9YCk7XG4gIH1cbiAgZ2V0U3VmZml4ZXMoY29kZSwgb3B0aW9ucyA9IHt9KSB7XG4gICAgbGV0IHJ1bGUgPSB0aGlzLmdldFJ1bGUoY29kZSwgb3B0aW9ucyk7XG4gICAgaWYgKCFydWxlKSBydWxlID0gdGhpcy5nZXRSdWxlKCdkZXYnLCBvcHRpb25zKTtcbiAgICBpZiAoIXJ1bGUpIHJldHVybiBbXTtcbiAgICByZXR1cm4gcnVsZS5yZXNvbHZlZE9wdGlvbnMoKS5wbHVyYWxDYXRlZ29yaWVzLnNvcnQoKHBsdXJhbENhdGVnb3J5MSwgcGx1cmFsQ2F0ZWdvcnkyKSA9PiBzdWZmaXhlc09yZGVyW3BsdXJhbENhdGVnb3J5MV0gLSBzdWZmaXhlc09yZGVyW3BsdXJhbENhdGVnb3J5Ml0pLm1hcChwbHVyYWxDYXRlZ29yeSA9PiBgJHt0aGlzLm9wdGlvbnMucHJlcGVuZH0ke29wdGlvbnMub3JkaW5hbCA/IGBvcmRpbmFsJHt0aGlzLm9wdGlvbnMucHJlcGVuZH1gIDogJyd9JHtwbHVyYWxDYXRlZ29yeX1gKTtcbiAgfVxuICBnZXRTdWZmaXgoY29kZSwgY291bnQsIG9wdGlvbnMgPSB7fSkge1xuICAgIGNvbnN0IHJ1bGUgPSB0aGlzLmdldFJ1bGUoY29kZSwgb3B0aW9ucyk7XG4gICAgaWYgKHJ1bGUpIHtcbiAgICAgIHJldHVybiBgJHt0aGlzLm9wdGlvbnMucHJlcGVuZH0ke29wdGlvbnMub3JkaW5hbCA/IGBvcmRpbmFsJHt0aGlzLm9wdGlvbnMucHJlcGVuZH1gIDogJyd9JHtydWxlLnNlbGVjdChjb3VudCl9YDtcbiAgICB9XG4gICAgdGhpcy5sb2dnZXIud2Fybihgbm8gcGx1cmFsIHJ1bGUgZm91bmQgZm9yOiAke2NvZGV9YCk7XG4gICAgcmV0dXJuIHRoaXMuZ2V0U3VmZml4KCdkZXYnLCBjb3VudCwgb3B0aW9ucyk7XG4gIH1cbn1cblxuY29uc3QgZGVlcEZpbmRXaXRoRGVmYXVsdHMgPSAoZGF0YSwgZGVmYXVsdERhdGEsIGtleSwga2V5U2VwYXJhdG9yID0gJy4nLCBpZ25vcmVKU09OU3RydWN0dXJlID0gdHJ1ZSkgPT4ge1xuICBsZXQgcGF0aCA9IGdldFBhdGhXaXRoRGVmYXVsdHMoZGF0YSwgZGVmYXVsdERhdGEsIGtleSk7XG4gIGlmIChwYXRoID09IG51bGwgJiYgaWdub3JlSlNPTlN0cnVjdHVyZSAmJiBpc1N0cmluZyhrZXkpKSB7XG4gICAgcGF0aCA9IGRlZXBGaW5kKGRhdGEsIGtleSwga2V5U2VwYXJhdG9yKTtcbiAgICBpZiAocGF0aCA9PT0gdW5kZWZpbmVkKSBwYXRoID0gZGVlcEZpbmQoZGVmYXVsdERhdGEsIGtleSwga2V5U2VwYXJhdG9yKTtcbiAgfVxuICByZXR1cm4gcGF0aDtcbn07XG5jbGFzcyBJbnRlcnBvbGF0b3Ige1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30pIHtcbiAgICB0aGlzLmxvZ2dlciA9IGJhc2VMb2dnZXIuY3JlYXRlKCdpbnRlcnBvbGF0b3InKTtcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMuZm9ybWF0ID0gb3B0aW9ucz8uaW50ZXJwb2xhdGlvbj8uZm9ybWF0IHx8ICh2YWx1ZSA9PiB2YWx1ZSk7XG4gICAgdGhpcy5pbml0KG9wdGlvbnMpO1xuICB9XG4gIGluaXQob3B0aW9ucyA9IHt9KSB7XG4gICAgaWYgKCFvcHRpb25zLmludGVycG9sYXRpb24pIG9wdGlvbnMuaW50ZXJwb2xhdGlvbiA9IHtcbiAgICAgIGVzY2FwZVZhbHVlOiB0cnVlXG4gICAgfTtcbiAgICBjb25zdCB7XG4gICAgICBlc2NhcGU6IGVzY2FwZSQxLFxuICAgICAgZXNjYXBlVmFsdWUsXG4gICAgICB1c2VSYXdWYWx1ZVRvRXNjYXBlLFxuICAgICAgcHJlZml4LFxuICAgICAgcHJlZml4RXNjYXBlZCxcbiAgICAgIHN1ZmZpeCxcbiAgICAgIHN1ZmZpeEVzY2FwZWQsXG4gICAgICBmb3JtYXRTZXBhcmF0b3IsXG4gICAgICB1bmVzY2FwZVN1ZmZpeCxcbiAgICAgIHVuZXNjYXBlUHJlZml4LFxuICAgICAgbmVzdGluZ1ByZWZpeCxcbiAgICAgIG5lc3RpbmdQcmVmaXhFc2NhcGVkLFxuICAgICAgbmVzdGluZ1N1ZmZpeCxcbiAgICAgIG5lc3RpbmdTdWZmaXhFc2NhcGVkLFxuICAgICAgbmVzdGluZ09wdGlvbnNTZXBhcmF0b3IsXG4gICAgICBtYXhSZXBsYWNlcyxcbiAgICAgIGFsd2F5c0Zvcm1hdFxuICAgIH0gPSBvcHRpb25zLmludGVycG9sYXRpb247XG4gICAgdGhpcy5lc2NhcGUgPSBlc2NhcGUkMSAhPT0gdW5kZWZpbmVkID8gZXNjYXBlJDEgOiBlc2NhcGU7XG4gICAgdGhpcy5lc2NhcGVWYWx1ZSA9IGVzY2FwZVZhbHVlICE9PSB1bmRlZmluZWQgPyBlc2NhcGVWYWx1ZSA6IHRydWU7XG4gICAgdGhpcy51c2VSYXdWYWx1ZVRvRXNjYXBlID0gdXNlUmF3VmFsdWVUb0VzY2FwZSAhPT0gdW5kZWZpbmVkID8gdXNlUmF3VmFsdWVUb0VzY2FwZSA6IGZhbHNlO1xuICAgIHRoaXMucHJlZml4ID0gcHJlZml4ID8gcmVnZXhFc2NhcGUocHJlZml4KSA6IHByZWZpeEVzY2FwZWQgfHwgJ3t7JztcbiAgICB0aGlzLnN1ZmZpeCA9IHN1ZmZpeCA/IHJlZ2V4RXNjYXBlKHN1ZmZpeCkgOiBzdWZmaXhFc2NhcGVkIHx8ICd9fSc7XG4gICAgdGhpcy5mb3JtYXRTZXBhcmF0b3IgPSBmb3JtYXRTZXBhcmF0b3IgfHwgJywnO1xuICAgIHRoaXMudW5lc2NhcGVQcmVmaXggPSB1bmVzY2FwZVN1ZmZpeCA/ICcnIDogdW5lc2NhcGVQcmVmaXggPyByZWdleEVzY2FwZSh1bmVzY2FwZVByZWZpeCkgOiAnLSc7XG4gICAgdGhpcy51bmVzY2FwZVN1ZmZpeCA9IHRoaXMudW5lc2NhcGVQcmVmaXggPyAnJyA6IHVuZXNjYXBlU3VmZml4ID8gcmVnZXhFc2NhcGUodW5lc2NhcGVTdWZmaXgpIDogJyc7XG4gICAgdGhpcy5uZXN0aW5nUHJlZml4ID0gbmVzdGluZ1ByZWZpeCA/IHJlZ2V4RXNjYXBlKG5lc3RpbmdQcmVmaXgpIDogbmVzdGluZ1ByZWZpeEVzY2FwZWQgfHwgcmVnZXhFc2NhcGUoJyR0KCcpO1xuICAgIHRoaXMubmVzdGluZ1N1ZmZpeCA9IG5lc3RpbmdTdWZmaXggPyByZWdleEVzY2FwZShuZXN0aW5nU3VmZml4KSA6IG5lc3RpbmdTdWZmaXhFc2NhcGVkIHx8IHJlZ2V4RXNjYXBlKCcpJyk7XG4gICAgdGhpcy5uZXN0aW5nT3B0aW9uc1NlcGFyYXRvciA9IG5lc3RpbmdPcHRpb25zU2VwYXJhdG9yIHx8ICcsJztcbiAgICB0aGlzLm1heFJlcGxhY2VzID0gbWF4UmVwbGFjZXMgfHwgMTAwMDtcbiAgICB0aGlzLmFsd2F5c0Zvcm1hdCA9IGFsd2F5c0Zvcm1hdCAhPT0gdW5kZWZpbmVkID8gYWx3YXlzRm9ybWF0IDogZmFsc2U7XG4gICAgdGhpcy5yZXNldFJlZ0V4cCgpO1xuICB9XG4gIHJlc2V0KCkge1xuICAgIGlmICh0aGlzLm9wdGlvbnMpIHRoaXMuaW5pdCh0aGlzLm9wdGlvbnMpO1xuICB9XG4gIHJlc2V0UmVnRXhwKCkge1xuICAgIGNvbnN0IGdldE9yUmVzZXRSZWdFeHAgPSAoZXhpc3RpbmdSZWdFeHAsIHBhdHRlcm4pID0+IHtcbiAgICAgIGlmIChleGlzdGluZ1JlZ0V4cD8uc291cmNlID09PSBwYXR0ZXJuKSB7XG4gICAgICAgIGV4aXN0aW5nUmVnRXhwLmxhc3RJbmRleCA9IDA7XG4gICAgICAgIHJldHVybiBleGlzdGluZ1JlZ0V4cDtcbiAgICAgIH1cbiAgICAgIHJldHVybiBuZXcgUmVnRXhwKHBhdHRlcm4sICdnJyk7XG4gICAgfTtcbiAgICB0aGlzLnJlZ2V4cCA9IGdldE9yUmVzZXRSZWdFeHAodGhpcy5yZWdleHAsIGAke3RoaXMucHJlZml4fSguKz8pJHt0aGlzLnN1ZmZpeH1gKTtcbiAgICB0aGlzLnJlZ2V4cFVuZXNjYXBlID0gZ2V0T3JSZXNldFJlZ0V4cCh0aGlzLnJlZ2V4cFVuZXNjYXBlLCBgJHt0aGlzLnByZWZpeH0ke3RoaXMudW5lc2NhcGVQcmVmaXh9KC4rPykke3RoaXMudW5lc2NhcGVTdWZmaXh9JHt0aGlzLnN1ZmZpeH1gKTtcbiAgICB0aGlzLm5lc3RpbmdSZWdleHAgPSBnZXRPclJlc2V0UmVnRXhwKHRoaXMubmVzdGluZ1JlZ2V4cCwgYCR7dGhpcy5uZXN0aW5nUHJlZml4fSgoPzpbXigpXCInXXxcIlteXCJdKlwifCdbXiddKid8XFxcXCgoPzpbXigpXCInXXxcIlteXCJdKlwifCdbXiddKicpKlxcXFwpKSo/KSR7dGhpcy5uZXN0aW5nU3VmZml4fWApO1xuICB9XG4gIGludGVycG9sYXRlKHN0ciwgZGF0YSwgbG5nLCBvcHRpb25zKSB7XG4gICAgbGV0IG1hdGNoO1xuICAgIGxldCB2YWx1ZTtcbiAgICBsZXQgcmVwbGFjZXM7XG4gICAgY29uc3QgZGVmYXVsdERhdGEgPSB0aGlzLm9wdGlvbnMgJiYgdGhpcy5vcHRpb25zLmludGVycG9sYXRpb24gJiYgdGhpcy5vcHRpb25zLmludGVycG9sYXRpb24uZGVmYXVsdFZhcmlhYmxlcyB8fCB7fTtcbiAgICBjb25zdCBoYW5kbGVGb3JtYXQgPSBrZXkgPT4ge1xuICAgICAgaWYgKCFrZXkuaW5jbHVkZXModGhpcy5mb3JtYXRTZXBhcmF0b3IpKSB7XG4gICAgICAgIGNvbnN0IHBhdGggPSBkZWVwRmluZFdpdGhEZWZhdWx0cyhkYXRhLCBkZWZhdWx0RGF0YSwga2V5LCB0aGlzLm9wdGlvbnMua2V5U2VwYXJhdG9yLCB0aGlzLm9wdGlvbnMuaWdub3JlSlNPTlN0cnVjdHVyZSk7XG4gICAgICAgIHJldHVybiB0aGlzLmFsd2F5c0Zvcm1hdCA/IHRoaXMuZm9ybWF0KHBhdGgsIHVuZGVmaW5lZCwgbG5nLCB7XG4gICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAuLi5kYXRhLFxuICAgICAgICAgIGludGVycG9sYXRpb25rZXk6IGtleVxuICAgICAgICB9KSA6IHBhdGg7XG4gICAgICB9XG4gICAgICBjb25zdCBwID0ga2V5LnNwbGl0KHRoaXMuZm9ybWF0U2VwYXJhdG9yKTtcbiAgICAgIGNvbnN0IGsgPSBwLnNoaWZ0KCkudHJpbSgpO1xuICAgICAgY29uc3QgZiA9IHAuam9pbih0aGlzLmZvcm1hdFNlcGFyYXRvcikudHJpbSgpO1xuICAgICAgcmV0dXJuIHRoaXMuZm9ybWF0KGRlZXBGaW5kV2l0aERlZmF1bHRzKGRhdGEsIGRlZmF1bHREYXRhLCBrLCB0aGlzLm9wdGlvbnMua2V5U2VwYXJhdG9yLCB0aGlzLm9wdGlvbnMuaWdub3JlSlNPTlN0cnVjdHVyZSksIGYsIGxuZywge1xuICAgICAgICAuLi5vcHRpb25zLFxuICAgICAgICAuLi5kYXRhLFxuICAgICAgICBpbnRlcnBvbGF0aW9ua2V5OiBrXG4gICAgICB9KTtcbiAgICB9O1xuICAgIHRoaXMucmVzZXRSZWdFeHAoKTtcbiAgICBpZiAoIXRoaXMuZXNjYXBlVmFsdWUgJiYgdHlwZW9mIHN0ciA9PT0gJ3N0cmluZycgJiYgL1xcJHRcXChbXildKlxce1tefV0qXFx7XFx7Ly50ZXN0KHN0cikpIHtcbiAgICAgIHRoaXMubG9nZ2VyLndhcm4oJ25lc3Rpbmcgb3B0aW9ucyBzdHJpbmcgY29udGFpbnMgaW50ZXJwb2xhdGVkIHZhcmlhYmxlcyB3aXRoIGVzY2FwZVZhbHVlOiBmYWxzZSDigJQgJyArICdpZiBhbnkgb2YgdGhvc2UgdmFsdWVzIGFyZSBhdHRhY2tlci1jb250cm9sbGVkIHRoZXkgY2FuIGluamVjdCBhZGRpdGlvbmFsICcgKyAnbmVzdGluZyBvcHRpb25zIChlLmcuIHJlZGlyZWN0IGxuZy9ucykuIFNhbml0aXNlIHVudHJ1c3RlZCBpbnB1dCBiZWZvcmUgcGFzc2luZyAnICsgJ2l0IHRvIHQoKSwgb3Iga2VlcCBlc2NhcGVWYWx1ZTogdHJ1ZS4nKTtcbiAgICB9XG4gICAgY29uc3QgbWlzc2luZ0ludGVycG9sYXRpb25IYW5kbGVyID0gb3B0aW9ucz8ubWlzc2luZ0ludGVycG9sYXRpb25IYW5kbGVyIHx8IHRoaXMub3B0aW9ucy5taXNzaW5nSW50ZXJwb2xhdGlvbkhhbmRsZXI7XG4gICAgY29uc3Qgc2tpcE9uVmFyaWFibGVzID0gb3B0aW9ucz8uaW50ZXJwb2xhdGlvbj8uc2tpcE9uVmFyaWFibGVzICE9PSB1bmRlZmluZWQgPyBvcHRpb25zLmludGVycG9sYXRpb24uc2tpcE9uVmFyaWFibGVzIDogdGhpcy5vcHRpb25zLmludGVycG9sYXRpb24uc2tpcE9uVmFyaWFibGVzO1xuICAgIGNvbnN0IHRvZG9zID0gW3tcbiAgICAgIHJlZ2V4OiB0aGlzLnJlZ2V4cFVuZXNjYXBlLFxuICAgICAgc2FmZVZhbHVlOiB2YWwgPT4gdmFsXG4gICAgfSwge1xuICAgICAgcmVnZXg6IHRoaXMucmVnZXhwLFxuICAgICAgc2FmZVZhbHVlOiB2YWwgPT4gdGhpcy5lc2NhcGVWYWx1ZSA/IHRoaXMuZXNjYXBlKHZhbCkgOiB2YWxcbiAgICB9XTtcbiAgICBjb25zdCB1bmVzY2FwZWRWYWx1ZXMgPSBbXTtcbiAgICBsZXQgc2hpZnQgPSAwO1xuICAgIHRvZG9zLmZvckVhY2godG9kbyA9PiB7XG4gICAgICByZXBsYWNlcyA9IDA7XG4gICAgICB3aGlsZSAobWF0Y2ggPSB0b2RvLnJlZ2V4LmV4ZWMoc3RyKSkge1xuICAgICAgICBjb25zdCBhdCA9IG1hdGNoLmluZGV4IC0gc2hpZnQ7XG4gICAgICAgIGNvbnN0IHdyaXR0ZW4gPSB1bmVzY2FwZWRWYWx1ZXMuZmluZCgoW3N0YXJ0LCBlbmRdKSA9PiBhdCA+PSBzdGFydCAmJiBhdCA8IGVuZCk7XG4gICAgICAgIGlmICh3cml0dGVuKSB7XG4gICAgICAgICAgdG9kby5yZWdleC5sYXN0SW5kZXggPSB3cml0dGVuWzFdICsgc2hpZnQ7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbWF0Y2hlZFZhciA9IG1hdGNoWzFdLnRyaW0oKTtcbiAgICAgICAgdmFsdWUgPSBoYW5kbGVGb3JtYXQobWF0Y2hlZFZhcik7XG4gICAgICAgIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgaWYgKHR5cGVvZiBtaXNzaW5nSW50ZXJwb2xhdGlvbkhhbmRsZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGNvbnN0IHRlbXAgPSBtaXNzaW5nSW50ZXJwb2xhdGlvbkhhbmRsZXIoc3RyLCBtYXRjaCwgb3B0aW9ucyk7XG4gICAgICAgICAgICB2YWx1ZSA9IGlzU3RyaW5nKHRlbXApID8gdGVtcCA6ICcnO1xuICAgICAgICAgIH0gZWxzZSBpZiAob3B0aW9ucyAmJiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob3B0aW9ucywgbWF0Y2hlZFZhcikpIHtcbiAgICAgICAgICAgIHZhbHVlID0gJyc7XG4gICAgICAgICAgfSBlbHNlIGlmIChza2lwT25WYXJpYWJsZXMpIHtcbiAgICAgICAgICAgIHZhbHVlID0gbWF0Y2hbMF07XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdGhpcy5sb2dnZXIud2FybihgbWlzc2VkIHRvIHBhc3MgaW4gdmFyaWFibGUgJHttYXRjaGVkVmFyfSBmb3IgaW50ZXJwb2xhdGluZyAke3N0cn1gKTtcbiAgICAgICAgICAgIHZhbHVlID0gJyc7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKCFpc1N0cmluZyh2YWx1ZSkgJiYgIXRoaXMudXNlUmF3VmFsdWVUb0VzY2FwZSkge1xuICAgICAgICAgIHZhbHVlID0gbWFrZVN0cmluZyh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc2FmZVZhbHVlID0gbWFrZVN0cmluZyh0b2RvLnNhZmVWYWx1ZSh2YWx1ZSkpO1xuICAgICAgICBzdHIgPSBzdHIuc2xpY2UoMCwgbWF0Y2guaW5kZXgpICsgc2FmZVZhbHVlICsgc3RyLnNsaWNlKG1hdGNoLmluZGV4ICsgbWF0Y2hbMF0ubGVuZ3RoKTtcbiAgICAgICAgaWYgKHNraXBPblZhcmlhYmxlcykge1xuICAgICAgICAgIGlmICh0b2RvLnJlZ2V4ID09PSB0aGlzLnJlZ2V4cFVuZXNjYXBlKSB7XG4gICAgICAgICAgICB1bmVzY2FwZWRWYWx1ZXMucHVzaChbbWF0Y2guaW5kZXgsIG1hdGNoLmluZGV4ICsgc2FmZVZhbHVlLmxlbmd0aF0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzaGlmdCArPSBzYWZlVmFsdWUubGVuZ3RoIC0gbWF0Y2hbMF0ubGVuZ3RoO1xuICAgICAgICAgIH1cbiAgICAgICAgICB0b2RvLnJlZ2V4Lmxhc3RJbmRleCArPSBzYWZlVmFsdWUubGVuZ3RoO1xuICAgICAgICAgIHRvZG8ucmVnZXgubGFzdEluZGV4IC09IG1hdGNoWzBdLmxlbmd0aDtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0b2RvLnJlZ2V4Lmxhc3RJbmRleCA9IDA7XG4gICAgICAgIH1cbiAgICAgICAgcmVwbGFjZXMrKztcbiAgICAgICAgaWYgKHJlcGxhY2VzID49IHRoaXMubWF4UmVwbGFjZXMpIHtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBzdHI7XG4gIH1cbiAgbmVzdChzdHIsIGZjLCBvcHRpb25zID0ge30pIHtcbiAgICBsZXQgbWF0Y2g7XG4gICAgbGV0IHZhbHVlO1xuICAgIGxldCBjbG9uZWRPcHRpb25zO1xuICAgIGNvbnN0IGhhbmRsZUhhc09wdGlvbnMgPSAoa2V5LCBpbmhlcml0ZWRPcHRpb25zKSA9PiB7XG4gICAgICBjb25zdCBzZXAgPSB0aGlzLm5lc3RpbmdPcHRpb25zU2VwYXJhdG9yO1xuICAgICAgaWYgKCFrZXkuaW5jbHVkZXMoc2VwKSkgcmV0dXJuIGtleTtcbiAgICAgIGNvbnN0IGMgPSBrZXkuc3BsaXQobmV3IFJlZ0V4cChgJHtyZWdleEVzY2FwZShzZXApfVsgXSp7YCkpO1xuICAgICAgbGV0IG9wdGlvbnNTdHJpbmcgPSBgeyR7Y1sxXX1gO1xuICAgICAga2V5ID0gY1swXTtcbiAgICAgIG9wdGlvbnNTdHJpbmcgPSB0aGlzLmludGVycG9sYXRlKG9wdGlvbnNTdHJpbmcsIGNsb25lZE9wdGlvbnMpO1xuICAgICAgY29uc3QgbWF0Y2hlZFNpbmdsZVF1b3RlcyA9IG9wdGlvbnNTdHJpbmcubWF0Y2goLycvZyk7XG4gICAgICBjb25zdCBtYXRjaGVkRG91YmxlUXVvdGVzID0gb3B0aW9uc1N0cmluZy5tYXRjaCgvXCIvZyk7XG4gICAgICBpZiAoKG1hdGNoZWRTaW5nbGVRdW90ZXM/Lmxlbmd0aCA/PyAwKSAlIDIgPT09IDAgJiYgIW1hdGNoZWREb3VibGVRdW90ZXMgfHwgKG1hdGNoZWREb3VibGVRdW90ZXM/Lmxlbmd0aCA/PyAwKSAlIDIgIT09IDApIHtcbiAgICAgICAgb3B0aW9uc1N0cmluZyA9IG9wdGlvbnNTdHJpbmcucmVwbGFjZSgvJy9nLCAnXCInKTtcbiAgICAgIH1cbiAgICAgIHRyeSB7XG4gICAgICAgIGNsb25lZE9wdGlvbnMgPSBKU09OLnBhcnNlKG9wdGlvbnNTdHJpbmcpO1xuICAgICAgICBpZiAoaW5oZXJpdGVkT3B0aW9ucykgY2xvbmVkT3B0aW9ucyA9IHtcbiAgICAgICAgICAuLi5pbmhlcml0ZWRPcHRpb25zLFxuICAgICAgICAgIC4uLmNsb25lZE9wdGlvbnNcbiAgICAgICAgfTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgdGhpcy5sb2dnZXIud2FybihgZmFpbGVkIHBhcnNpbmcgb3B0aW9ucyBzdHJpbmcgaW4gbmVzdGluZyBmb3Iga2V5ICR7a2V5fWAsIGUpO1xuICAgICAgICByZXR1cm4gYCR7a2V5fSR7c2VwfSR7b3B0aW9uc1N0cmluZ31gO1xuICAgICAgfVxuICAgICAgaWYgKGNsb25lZE9wdGlvbnMuZGVmYXVsdFZhbHVlICYmIGNsb25lZE9wdGlvbnMuZGVmYXVsdFZhbHVlLmluY2x1ZGVzKHRoaXMucHJlZml4KSkgZGVsZXRlIGNsb25lZE9wdGlvbnMuZGVmYXVsdFZhbHVlO1xuICAgICAgcmV0dXJuIGtleTtcbiAgICB9O1xuICAgIGNvbnN0IG5lc3RpbmdSZWdleHAgPSBuZXcgUmVnRXhwKHRoaXMubmVzdGluZ1JlZ2V4cCk7XG4gICAgbGV0IG91dCA9ICcnO1xuICAgIGxldCBsYXN0RW5kID0gMDtcbiAgICB3aGlsZSAobWF0Y2ggPSBuZXN0aW5nUmVnZXhwLmV4ZWMoc3RyKSkge1xuICAgICAgbGV0IGZvcm1hdHRlcnMgPSBbXTtcbiAgICAgIGNsb25lZE9wdGlvbnMgPSB7XG4gICAgICAgIC4uLm9wdGlvbnNcbiAgICAgIH07XG4gICAgICBjbG9uZWRPcHRpb25zID0gY2xvbmVkT3B0aW9ucy5yZXBsYWNlICYmICFpc1N0cmluZyhjbG9uZWRPcHRpb25zLnJlcGxhY2UpID8gY2xvbmVkT3B0aW9ucy5yZXBsYWNlIDogY2xvbmVkT3B0aW9ucztcbiAgICAgIGNsb25lZE9wdGlvbnMuYXBwbHlQb3N0UHJvY2Vzc29yID0gZmFsc2U7XG4gICAgICBkZWxldGUgY2xvbmVkT3B0aW9ucy5kZWZhdWx0VmFsdWU7XG4gICAgICBjb25zdCBrZXlFbmRJbmRleCA9IC97Lip9L3MudGVzdChtYXRjaFsxXSkgPyBtYXRjaFsxXS5sYXN0SW5kZXhPZignfScpICsgMSA6IG1hdGNoWzFdLmluZGV4T2YodGhpcy5mb3JtYXRTZXBhcmF0b3IpO1xuICAgICAgaWYgKGtleUVuZEluZGV4ICE9PSAtMSkge1xuICAgICAgICBmb3JtYXR0ZXJzID0gbWF0Y2hbMV0uc2xpY2Uoa2V5RW5kSW5kZXgpLnNwbGl0KHRoaXMuZm9ybWF0U2VwYXJhdG9yKS5tYXAoZWxlbSA9PiBlbGVtLnRyaW0oKSkuZmlsdGVyKEJvb2xlYW4pO1xuICAgICAgICBtYXRjaFsxXSA9IG1hdGNoWzFdLnNsaWNlKDAsIGtleUVuZEluZGV4KTtcbiAgICAgIH1cbiAgICAgIHZhbHVlID0gZmMoaGFuZGxlSGFzT3B0aW9ucy5jYWxsKHRoaXMsIG1hdGNoWzFdLnRyaW0oKSwgY2xvbmVkT3B0aW9ucyksIGNsb25lZE9wdGlvbnMpO1xuICAgICAgaWYgKHZhbHVlICYmIG1hdGNoWzBdID09PSBzdHIgJiYgIWlzU3RyaW5nKHZhbHVlKSkgcmV0dXJuIHZhbHVlO1xuICAgICAgaWYgKCFpc1N0cmluZyh2YWx1ZSkpIHZhbHVlID0gbWFrZVN0cmluZyh2YWx1ZSk7XG4gICAgICBpZiAoIXZhbHVlKSB7XG4gICAgICAgIHRoaXMubG9nZ2VyLndhcm4oYG1pc3NlZCB0byByZXNvbHZlICR7bWF0Y2hbMV19IGZvciBuZXN0aW5nICR7c3RyfWApO1xuICAgICAgICB2YWx1ZSA9ICcnO1xuICAgICAgfVxuICAgICAgaWYgKGZvcm1hdHRlcnMubGVuZ3RoKSB7XG4gICAgICAgIHZhbHVlID0gZm9ybWF0dGVycy5yZWR1Y2UoKHYsIGYpID0+IHRoaXMuZm9ybWF0KHYsIGYsIG9wdGlvbnMubG5nLCB7XG4gICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICBpbnRlcnBvbGF0aW9ua2V5OiBtYXRjaFsxXS50cmltKClcbiAgICAgICAgfSksIHZhbHVlLnRyaW0oKSk7XG4gICAgICB9XG4gICAgICBvdXQgKz0gc3RyLnNsaWNlKGxhc3RFbmQsIG1hdGNoLmluZGV4KSArIG1ha2VTdHJpbmcodmFsdWUpO1xuICAgICAgbGFzdEVuZCA9IG5lc3RpbmdSZWdleHAubGFzdEluZGV4O1xuICAgICAgdGhpcy5yZWdleHAubGFzdEluZGV4ID0gMDtcbiAgICB9XG4gICAgcmV0dXJuIGxhc3RFbmQgPyBvdXQgKyBzdHIuc2xpY2UobGFzdEVuZCkgOiBzdHI7XG4gIH1cbn1cblxuY29uc3QgcGFyc2VGb3JtYXRTdHIgPSBmb3JtYXRTdHIgPT4ge1xuICBsZXQgZm9ybWF0TmFtZSA9IGZvcm1hdFN0ci50b0xvd2VyQ2FzZSgpLnRyaW0oKTtcbiAgY29uc3QgZm9ybWF0T3B0aW9ucyA9IHt9O1xuICBpZiAoZm9ybWF0U3RyLmluY2x1ZGVzKCcoJykpIHtcbiAgICBjb25zdCBwID0gZm9ybWF0U3RyLnNwbGl0KCcoJyk7XG4gICAgZm9ybWF0TmFtZSA9IHBbMF0udG9Mb3dlckNhc2UoKS50cmltKCk7XG4gICAgY29uc3Qgb3B0U3RyID0gcFsxXS5zbGljZSgwLCAtMSk7XG4gICAgaWYgKGZvcm1hdE5hbWUgPT09ICdjdXJyZW5jeScgJiYgIW9wdFN0ci5pbmNsdWRlcygnOicpKSB7XG4gICAgICBpZiAoIWZvcm1hdE9wdGlvbnMuY3VycmVuY3kpIGZvcm1hdE9wdGlvbnMuY3VycmVuY3kgPSBvcHRTdHIudHJpbSgpO1xuICAgIH0gZWxzZSBpZiAoZm9ybWF0TmFtZSA9PT0gJ3JlbGF0aXZldGltZScgJiYgIW9wdFN0ci5pbmNsdWRlcygnOicpKSB7XG4gICAgICBpZiAoIWZvcm1hdE9wdGlvbnMucmFuZ2UpIGZvcm1hdE9wdGlvbnMucmFuZ2UgPSBvcHRTdHIudHJpbSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBjb25zdCBvcHRzID0gb3B0U3RyLnNwbGl0KCc7Jyk7XG4gICAgICBvcHRzLmZvckVhY2gob3B0ID0+IHtcbiAgICAgICAgaWYgKG9wdCkge1xuICAgICAgICAgIGNvbnN0IFtrZXksIC4uLnJlc3RdID0gb3B0LnNwbGl0KCc6Jyk7XG4gICAgICAgICAgY29uc3QgdmFsID0gcmVzdC5qb2luKCc6JykudHJpbSgpLnJlcGxhY2UoL14nK3wnKyQvZywgJycpO1xuICAgICAgICAgIGNvbnN0IHRyaW1tZWRLZXkgPSBrZXkudHJpbSgpO1xuICAgICAgICAgIGlmICghZm9ybWF0T3B0aW9uc1t0cmltbWVkS2V5XSkgZm9ybWF0T3B0aW9uc1t0cmltbWVkS2V5XSA9IHZhbDtcbiAgICAgICAgICBpZiAodmFsID09PSAnZmFsc2UnKSBmb3JtYXRPcHRpb25zW3RyaW1tZWRLZXldID0gZmFsc2U7XG4gICAgICAgICAgaWYgKHZhbCA9PT0gJ3RydWUnKSBmb3JtYXRPcHRpb25zW3RyaW1tZWRLZXldID0gdHJ1ZTtcbiAgICAgICAgICBpZiAoIWlzTmFOKHZhbCkpIGZvcm1hdE9wdGlvbnNbdHJpbW1lZEtleV0gPSBwYXJzZUludCh2YWwsIDEwKTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuICB9XG4gIHJldHVybiB7XG4gICAgZm9ybWF0TmFtZSxcbiAgICBmb3JtYXRPcHRpb25zXG4gIH07XG59O1xuY29uc3QgY3JlYXRlQ2FjaGVkRm9ybWF0dGVyID0gZm4gPT4ge1xuICBjb25zdCBjYWNoZSA9IHt9O1xuICByZXR1cm4gKHYsIGwsIG8pID0+IHtcbiAgICBsZXQgb3B0Rm9yQ2FjaGUgPSBvO1xuICAgIGlmIChvICYmIG8uaW50ZXJwb2xhdGlvbmtleSAmJiBvLmZvcm1hdFBhcmFtcyAmJiBvLmZvcm1hdFBhcmFtc1tvLmludGVycG9sYXRpb25rZXldICYmIG9bby5pbnRlcnBvbGF0aW9ua2V5XSkge1xuICAgICAgb3B0Rm9yQ2FjaGUgPSB7XG4gICAgICAgIC4uLm9wdEZvckNhY2hlLFxuICAgICAgICBbby5pbnRlcnBvbGF0aW9ua2V5XTogdW5kZWZpbmVkXG4gICAgICB9O1xuICAgIH1cbiAgICBsZXQga2V5O1xuICAgIHRyeSB7XG4gICAgICBrZXkgPSBsICsgSlNPTi5zdHJpbmdpZnkob3B0Rm9yQ2FjaGUpO1xuICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgIHJldHVybiBmbihnZXRDbGVhbmVkQ29kZShsKSwgbykodik7XG4gICAgfVxuICAgIGxldCBmcm0gPSBjYWNoZVtrZXldO1xuICAgIGlmICghZnJtKSB7XG4gICAgICBmcm0gPSBmbihnZXRDbGVhbmVkQ29kZShsKSwgbyk7XG4gICAgICBjYWNoZVtrZXldID0gZnJtO1xuICAgIH1cbiAgICByZXR1cm4gZnJtKHYpO1xuICB9O1xufTtcbmNvbnN0IGNyZWF0ZU5vbkNhY2hlZEZvcm1hdHRlciA9IGZuID0+ICh2LCBsLCBvKSA9PiBmbihnZXRDbGVhbmVkQ29kZShsKSwgbykodik7XG5jbGFzcyBGb3JtYXR0ZXIge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30pIHtcbiAgICB0aGlzLmxvZ2dlciA9IGJhc2VMb2dnZXIuY3JlYXRlKCdmb3JtYXR0ZXInKTtcbiAgICB0aGlzLm9wdGlvbnMgPSBvcHRpb25zO1xuICAgIHRoaXMuaW5pdChvcHRpb25zKTtcbiAgfVxuICBpbml0KHNlcnZpY2VzLCBvcHRpb25zID0ge1xuICAgIGludGVycG9sYXRpb246IHt9XG4gIH0pIHtcbiAgICB0aGlzLmZvcm1hdFNlcGFyYXRvciA9IG9wdGlvbnMuaW50ZXJwb2xhdGlvbi5mb3JtYXRTZXBhcmF0b3IgfHwgJywnO1xuICAgIGNvbnN0IGNmID0gb3B0aW9ucy5jYWNoZUluQnVpbHRGb3JtYXRzID8gY3JlYXRlQ2FjaGVkRm9ybWF0dGVyIDogY3JlYXRlTm9uQ2FjaGVkRm9ybWF0dGVyO1xuICAgIHRoaXMuZm9ybWF0cyA9IHtcbiAgICAgIG51bWJlcjogY2YoKGxuZywgb3B0KSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IG5ldyBJbnRsLk51bWJlckZvcm1hdChsbmcsIHtcbiAgICAgICAgICAuLi5vcHRcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB2YWwgPT4gZm9ybWF0dGVyLmZvcm1hdCh2YWwpO1xuICAgICAgfSksXG4gICAgICBjdXJyZW5jeTogY2YoKGxuZywgb3B0KSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IG5ldyBJbnRsLk51bWJlckZvcm1hdChsbmcsIHtcbiAgICAgICAgICAuLi5vcHQsXG4gICAgICAgICAgc3R5bGU6ICdjdXJyZW5jeSdcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB2YWwgPT4gZm9ybWF0dGVyLmZvcm1hdCh2YWwpO1xuICAgICAgfSksXG4gICAgICBkYXRldGltZTogY2YoKGxuZywgb3B0KSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IG5ldyBJbnRsLkRhdGVUaW1lRm9ybWF0KGxuZywge1xuICAgICAgICAgIC4uLm9wdFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHZhbCA9PiBmb3JtYXR0ZXIuZm9ybWF0KHZhbCk7XG4gICAgICB9KSxcbiAgICAgIHJlbGF0aXZldGltZTogY2YoKGxuZywgb3B0KSA9PiB7XG4gICAgICAgIGNvbnN0IGZvcm1hdHRlciA9IG5ldyBJbnRsLlJlbGF0aXZlVGltZUZvcm1hdChsbmcsIHtcbiAgICAgICAgICAuLi5vcHRcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiB2YWwgPT4gZm9ybWF0dGVyLmZvcm1hdCh2YWwsIG9wdC5yYW5nZSB8fCAnZGF5Jyk7XG4gICAgICB9KSxcbiAgICAgIGxpc3Q6IGNmKChsbmcsIG9wdCkgPT4ge1xuICAgICAgICBjb25zdCBmb3JtYXR0ZXIgPSBuZXcgSW50bC5MaXN0Rm9ybWF0KGxuZywge1xuICAgICAgICAgIC4uLm9wdFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHZhbCA9PiBmb3JtYXR0ZXIuZm9ybWF0KHZhbCk7XG4gICAgICB9KVxuICAgIH07XG4gIH1cbiAgYWRkKG5hbWUsIGZjKSB7XG4gICAgdGhpcy5mb3JtYXRzW25hbWUudG9Mb3dlckNhc2UoKS50cmltKCldID0gZmM7XG4gIH1cbiAgYWRkQ2FjaGVkKG5hbWUsIGZjKSB7XG4gICAgdGhpcy5mb3JtYXRzW25hbWUudG9Mb3dlckNhc2UoKS50cmltKCldID0gY3JlYXRlQ2FjaGVkRm9ybWF0dGVyKGZjKTtcbiAgfVxuICBmb3JtYXQodmFsdWUsIGZvcm1hdCwgbG5nLCBvcHRpb25zID0ge30pIHtcbiAgICBpZiAoIWZvcm1hdCkgcmV0dXJuIHZhbHVlO1xuICAgIGlmICh2YWx1ZSA9PSBudWxsKSByZXR1cm4gdmFsdWU7XG4gICAgY29uc3QgcmF3Rm9ybWF0cyA9IGZvcm1hdC5zcGxpdCh0aGlzLmZvcm1hdFNlcGFyYXRvcik7XG4gICAgY29uc3QgZm9ybWF0cyA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmF3Rm9ybWF0cy5sZW5ndGg7IGkrKykge1xuICAgICAgbGV0IGYgPSByYXdGb3JtYXRzW2ldO1xuICAgICAgd2hpbGUgKGYuaW5kZXhPZignKCcpID4gLTEgJiYgIWYuaW5jbHVkZXMoJyknKSAmJiBpICsgMSA8IHJhd0Zvcm1hdHMubGVuZ3RoKSB7XG4gICAgICAgIGYgPSBgJHtmfSR7dGhpcy5mb3JtYXRTZXBhcmF0b3J9JHtyYXdGb3JtYXRzWysraV19YDtcbiAgICAgIH1cbiAgICAgIGZvcm1hdHMucHVzaChmKTtcbiAgICB9XG4gICAgY29uc3QgcmVzdWx0ID0gZm9ybWF0cy5yZWR1Y2UoKG1lbSwgZikgPT4ge1xuICAgICAgY29uc3Qge1xuICAgICAgICBmb3JtYXROYW1lLFxuICAgICAgICBmb3JtYXRPcHRpb25zXG4gICAgICB9ID0gcGFyc2VGb3JtYXRTdHIoZik7XG4gICAgICBpZiAodGhpcy5mb3JtYXRzW2Zvcm1hdE5hbWVdKSB7XG4gICAgICAgIGxldCBmb3JtYXR0ZWQgPSBtZW07XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgY29uc3QgdmFsT3B0aW9ucyA9IG9wdGlvbnM/LmZvcm1hdFBhcmFtcz8uW29wdGlvbnMuaW50ZXJwb2xhdGlvbmtleV0gfHwge307XG4gICAgICAgICAgY29uc3QgbCA9IHZhbE9wdGlvbnMubG9jYWxlIHx8IHZhbE9wdGlvbnMubG5nIHx8IG9wdGlvbnMubG9jYWxlIHx8IG9wdGlvbnMubG5nIHx8IGxuZztcbiAgICAgICAgICBmb3JtYXR0ZWQgPSB0aGlzLmZvcm1hdHNbZm9ybWF0TmFtZV0obWVtLCBsLCB7XG4gICAgICAgICAgICAuLi5mb3JtYXRPcHRpb25zLFxuICAgICAgICAgICAgLi4ub3B0aW9ucyxcbiAgICAgICAgICAgIC4uLnZhbE9wdGlvbnNcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICB0aGlzLmxvZ2dlci53YXJuKGVycm9yKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZm9ybWF0dGVkO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGhpcy5sb2dnZXIud2FybihgdGhlcmUgd2FzIG5vIGZvcm1hdCBmdW5jdGlvbiBmb3IgJHtmb3JtYXROYW1lfWApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIG1lbTtcbiAgICB9LCB2YWx1ZSk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbiAgfVxufVxuXG5jb25zdCByZW1vdmVQZW5kaW5nID0gKHEsIG5hbWUpID0+IHtcbiAgaWYgKHEucGVuZGluZ1tuYW1lXSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgZGVsZXRlIHEucGVuZGluZ1tuYW1lXTtcbiAgICBxLnBlbmRpbmdDb3VudC0tO1xuICB9XG59O1xuY2xhc3MgQ29ubmVjdG9yIGV4dGVuZHMgRXZlbnRFbWl0dGVyIHtcbiAgY29uc3RydWN0b3IoYmFja2VuZCwgc3RvcmUsIHNlcnZpY2VzLCBvcHRpb25zID0ge30pIHtcbiAgICBzdXBlcigpO1xuICAgIHRoaXMuYmFja2VuZCA9IGJhY2tlbmQ7XG4gICAgdGhpcy5zdG9yZSA9IHN0b3JlO1xuICAgIHRoaXMuc2VydmljZXMgPSBzZXJ2aWNlcztcbiAgICB0aGlzLmxhbmd1YWdlVXRpbHMgPSBzZXJ2aWNlcy5sYW5ndWFnZVV0aWxzO1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy5sb2dnZXIgPSBiYXNlTG9nZ2VyLmNyZWF0ZSgnYmFja2VuZENvbm5lY3RvcicpO1xuICAgIHRoaXMud2FpdGluZ1JlYWRzID0gW107XG4gICAgdGhpcy5tYXhQYXJhbGxlbFJlYWRzID0gb3B0aW9ucy5tYXhQYXJhbGxlbFJlYWRzIHx8IDEwO1xuICAgIHRoaXMucmVhZGluZ0NhbGxzID0gMDtcbiAgICB0aGlzLm1heFJldHJpZXMgPSBvcHRpb25zLm1heFJldHJpZXMgPj0gMCA/IG9wdGlvbnMubWF4UmV0cmllcyA6IDU7XG4gICAgdGhpcy5yZXRyeVRpbWVvdXQgPSBvcHRpb25zLnJldHJ5VGltZW91dCA+PSAxID8gb3B0aW9ucy5yZXRyeVRpbWVvdXQgOiAzNTA7XG4gICAgdGhpcy5zdGF0ZSA9IHt9O1xuICAgIHRoaXMucXVldWUgPSBbXTtcbiAgICB0aGlzLmJhY2tlbmQ/LmluaXQ/LihzZXJ2aWNlcywgb3B0aW9ucy5iYWNrZW5kLCBvcHRpb25zKTtcbiAgfVxuICBxdWV1ZUxvYWQobGFuZ3VhZ2VzLCBuYW1lc3BhY2VzLCBvcHRpb25zLCBjYWxsYmFjaykge1xuICAgIGNvbnN0IHRvTG9hZCA9IHt9O1xuICAgIGNvbnN0IHBlbmRpbmcgPSB7fTtcbiAgICBjb25zdCB0b0xvYWRMYW5ndWFnZXMgPSB7fTtcbiAgICBjb25zdCB0b0xvYWROYW1lc3BhY2VzID0ge307XG4gICAgbGFuZ3VhZ2VzLmZvckVhY2gobG5nID0+IHtcbiAgICAgIGxldCBoYXNBbGxOYW1lc3BhY2VzID0gdHJ1ZTtcbiAgICAgIG5hbWVzcGFjZXMuZm9yRWFjaChucyA9PiB7XG4gICAgICAgIGNvbnN0IG5hbWUgPSBgJHtsbmd9fCR7bnN9YDtcbiAgICAgICAgaWYgKCFvcHRpb25zLnJlbG9hZCAmJiB0aGlzLnN0b3JlLmhhc1Jlc291cmNlQnVuZGxlKGxuZywgbnMpKSB7XG4gICAgICAgICAgdGhpcy5zdGF0ZVtuYW1lXSA9IDI7XG4gICAgICAgIH0gZWxzZSBpZiAodGhpcy5zdGF0ZVtuYW1lXSA8IDApIDsgZWxzZSBpZiAodGhpcy5zdGF0ZVtuYW1lXSA9PT0gMSkge1xuICAgICAgICAgIGlmIChwZW5kaW5nW25hbWVdID09PSB1bmRlZmluZWQpIHBlbmRpbmdbbmFtZV0gPSB0cnVlO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRoaXMuc3RhdGVbbmFtZV0gPSAxO1xuICAgICAgICAgIGhhc0FsbE5hbWVzcGFjZXMgPSBmYWxzZTtcbiAgICAgICAgICBpZiAocGVuZGluZ1tuYW1lXSA9PT0gdW5kZWZpbmVkKSBwZW5kaW5nW25hbWVdID0gdHJ1ZTtcbiAgICAgICAgICBpZiAodG9Mb2FkW25hbWVdID09PSB1bmRlZmluZWQpIHRvTG9hZFtuYW1lXSA9IHRydWU7XG4gICAgICAgICAgaWYgKHRvTG9hZE5hbWVzcGFjZXNbbnNdID09PSB1bmRlZmluZWQpIHRvTG9hZE5hbWVzcGFjZXNbbnNdID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgICBpZiAoIWhhc0FsbE5hbWVzcGFjZXMpIHRvTG9hZExhbmd1YWdlc1tsbmddID0gdHJ1ZTtcbiAgICB9KTtcbiAgICBpZiAoT2JqZWN0LmtleXModG9Mb2FkKS5sZW5ndGggfHwgT2JqZWN0LmtleXMocGVuZGluZykubGVuZ3RoKSB7XG4gICAgICB0aGlzLnF1ZXVlLnB1c2goe1xuICAgICAgICBwZW5kaW5nLFxuICAgICAgICBwZW5kaW5nQ291bnQ6IE9iamVjdC5rZXlzKHBlbmRpbmcpLmxlbmd0aCxcbiAgICAgICAgbG9hZGVkOiB7fSxcbiAgICAgICAgZXJyb3JzOiBbXSxcbiAgICAgICAgY2FsbGJhY2tcbiAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgdG9Mb2FkOiBPYmplY3Qua2V5cyh0b0xvYWQpLFxuICAgICAgcGVuZGluZzogT2JqZWN0LmtleXMocGVuZGluZyksXG4gICAgICB0b0xvYWRMYW5ndWFnZXM6IE9iamVjdC5rZXlzKHRvTG9hZExhbmd1YWdlcyksXG4gICAgICB0b0xvYWROYW1lc3BhY2VzOiBPYmplY3Qua2V5cyh0b0xvYWROYW1lc3BhY2VzKVxuICAgIH07XG4gIH1cbiAgbG9hZGVkKG5hbWUsIGVyciwgZGF0YSkge1xuICAgIGNvbnN0IHMgPSBuYW1lLnNwbGl0KCd8Jyk7XG4gICAgY29uc3QgbG5nID0gc1swXTtcbiAgICBjb25zdCBucyA9IHNbMV07XG4gICAgaWYgKGVycikgdGhpcy5lbWl0KCdmYWlsZWRMb2FkaW5nJywgbG5nLCBucywgZXJyKTtcbiAgICBpZiAoIWVyciAmJiBkYXRhKSB7XG4gICAgICB0aGlzLnN0b3JlLmFkZFJlc291cmNlQnVuZGxlKGxuZywgbnMsIGRhdGEsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCB7XG4gICAgICAgIHNraXBDb3B5OiB0cnVlXG4gICAgICB9KTtcbiAgICB9XG4gICAgdGhpcy5zdGF0ZVtuYW1lXSA9IGVyciA/IC0xIDogMjtcbiAgICBpZiAoZXJyICYmIGRhdGEpIHRoaXMuc3RhdGVbbmFtZV0gPSAwO1xuICAgIGNvbnN0IGxvYWRlZCA9IHt9O1xuICAgIHRoaXMucXVldWUuZm9yRWFjaChxID0+IHtcbiAgICAgIHB1c2hQYXRoKHEubG9hZGVkLCBbbG5nXSwgbnMpO1xuICAgICAgcmVtb3ZlUGVuZGluZyhxLCBuYW1lKTtcbiAgICAgIGlmIChlcnIpIHEuZXJyb3JzLnB1c2goZXJyKTtcbiAgICAgIGlmIChxLnBlbmRpbmdDb3VudCA9PT0gMCAmJiAhcS5kb25lKSB7XG4gICAgICAgIE9iamVjdC5rZXlzKHEubG9hZGVkKS5mb3JFYWNoKGwgPT4ge1xuICAgICAgICAgIGlmICghbG9hZGVkW2xdKSBsb2FkZWRbbF0gPSB7fTtcbiAgICAgICAgICBjb25zdCBsb2FkZWRLZXlzID0gcS5sb2FkZWRbbF07XG4gICAgICAgICAgaWYgKGxvYWRlZEtleXMubGVuZ3RoKSB7XG4gICAgICAgICAgICBsb2FkZWRLZXlzLmZvckVhY2gobiA9PiB7XG4gICAgICAgICAgICAgIGlmIChsb2FkZWRbbF1bbl0gPT09IHVuZGVmaW5lZCkgbG9hZGVkW2xdW25dID0gdHJ1ZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHEuZG9uZSA9IHRydWU7XG4gICAgICAgIGlmIChxLmVycm9ycy5sZW5ndGgpIHtcbiAgICAgICAgICBxLmNhbGxiYWNrKHEuZXJyb3JzKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBxLmNhbGxiYWNrKCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KTtcbiAgICB0aGlzLmVtaXQoJ2xvYWRlZCcsIGxvYWRlZCk7XG4gICAgdGhpcy5xdWV1ZSA9IHRoaXMucXVldWUuZmlsdGVyKHEgPT4gIXEuZG9uZSk7XG4gIH1cbiAgcmVhZChsbmcsIG5zLCBmY05hbWUsIHRyaWVkID0gMCwgd2FpdCA9IHRoaXMucmV0cnlUaW1lb3V0LCBjYWxsYmFjaykge1xuICAgIGlmICghbG5nLmxlbmd0aCkgcmV0dXJuIGNhbGxiYWNrKG51bGwsIHt9KTtcbiAgICBpZiAodGhpcy5yZWFkaW5nQ2FsbHMgPj0gdGhpcy5tYXhQYXJhbGxlbFJlYWRzKSB7XG4gICAgICB0aGlzLndhaXRpbmdSZWFkcy5wdXNoKHtcbiAgICAgICAgbG5nLFxuICAgICAgICBucyxcbiAgICAgICAgZmNOYW1lLFxuICAgICAgICB0cmllZCxcbiAgICAgICAgd2FpdCxcbiAgICAgICAgY2FsbGJhY2tcbiAgICAgIH0pO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB0aGlzLnJlYWRpbmdDYWxscysrO1xuICAgIGNvbnN0IHJlc29sdmVyID0gKGVyciwgZGF0YSkgPT4ge1xuICAgICAgdGhpcy5yZWFkaW5nQ2FsbHMtLTtcbiAgICAgIGlmICh0aGlzLndhaXRpbmdSZWFkcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIGNvbnN0IG5leHQgPSB0aGlzLndhaXRpbmdSZWFkcy5zaGlmdCgpO1xuICAgICAgICB0aGlzLnJlYWQobmV4dC5sbmcsIG5leHQubnMsIG5leHQuZmNOYW1lLCBuZXh0LnRyaWVkLCBuZXh0LndhaXQsIG5leHQuY2FsbGJhY2spO1xuICAgICAgfVxuICAgICAgaWYgKGVyciAmJiBkYXRhICYmIHRyaWVkIDwgdGhpcy5tYXhSZXRyaWVzKSB7XG4gICAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICAgIHRoaXMucmVhZChsbmcsIG5zLCBmY05hbWUsIHRyaWVkICsgMSwgd2FpdCAqIDIsIGNhbGxiYWNrKTtcbiAgICAgICAgfSwgd2FpdCk7XG4gICAgICAgIHJldHVybjtcbiAgICAgIH1cbiAgICAgIGNhbGxiYWNrKGVyciwgZGF0YSk7XG4gICAgfTtcbiAgICBjb25zdCBmYyA9IHRoaXMuYmFja2VuZFtmY05hbWVdLmJpbmQodGhpcy5iYWNrZW5kKTtcbiAgICBpZiAoZmMubGVuZ3RoID09PSAyKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByID0gZmMobG5nLCBucyk7XG4gICAgICAgIGlmIChyICYmIHR5cGVvZiByLnRoZW4gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICByLnRoZW4oZGF0YSA9PiByZXNvbHZlcihudWxsLCBkYXRhKSkuY2F0Y2gocmVzb2x2ZXIpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmVyKG51bGwsIHIpO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgcmVzb2x2ZXIoZXJyKTtcbiAgICAgIH1cbiAgICAgIHJldHVybjtcbiAgICB9XG4gICAgcmV0dXJuIGZjKGxuZywgbnMsIHJlc29sdmVyKTtcbiAgfVxuICBwcmVwYXJlTG9hZGluZyhsYW5ndWFnZXMsIG5hbWVzcGFjZXMsIG9wdGlvbnMgPSB7fSwgY2FsbGJhY2spIHtcbiAgICBpZiAoIXRoaXMuYmFja2VuZCkge1xuICAgICAgdGhpcy5sb2dnZXIud2FybignTm8gYmFja2VuZCB3YXMgYWRkZWQgdmlhIGkxOG5leHQudXNlLiBXaWxsIG5vdCBsb2FkIHJlc291cmNlcy4nKTtcbiAgICAgIHJldHVybiBjYWxsYmFjayAmJiBjYWxsYmFjaygpO1xuICAgIH1cbiAgICBpZiAoaXNTdHJpbmcobGFuZ3VhZ2VzKSkgbGFuZ3VhZ2VzID0gdGhpcy5sYW5ndWFnZVV0aWxzLnRvUmVzb2x2ZUhpZXJhcmNoeShsYW5ndWFnZXMpO1xuICAgIGlmIChpc1N0cmluZyhuYW1lc3BhY2VzKSkgbmFtZXNwYWNlcyA9IFtuYW1lc3BhY2VzXTtcbiAgICBjb25zdCB0b0xvYWQgPSB0aGlzLnF1ZXVlTG9hZChsYW5ndWFnZXMsIG5hbWVzcGFjZXMsIG9wdGlvbnMsIGNhbGxiYWNrKTtcbiAgICBpZiAoIXRvTG9hZC50b0xvYWQubGVuZ3RoKSB7XG4gICAgICBpZiAoIXRvTG9hZC5wZW5kaW5nLmxlbmd0aCkgY2FsbGJhY2soKTtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICB0b0xvYWQudG9Mb2FkLmZvckVhY2gobmFtZSA9PiB7XG4gICAgICB0aGlzLmxvYWRPbmUobmFtZSk7XG4gICAgfSk7XG4gIH1cbiAgbG9hZChsYW5ndWFnZXMsIG5hbWVzcGFjZXMsIGNhbGxiYWNrKSB7XG4gICAgdGhpcy5wcmVwYXJlTG9hZGluZyhsYW5ndWFnZXMsIG5hbWVzcGFjZXMsIHt9LCBjYWxsYmFjayk7XG4gIH1cbiAgcmVsb2FkKGxhbmd1YWdlcywgbmFtZXNwYWNlcywgY2FsbGJhY2spIHtcbiAgICB0aGlzLnByZXBhcmVMb2FkaW5nKGxhbmd1YWdlcywgbmFtZXNwYWNlcywge1xuICAgICAgcmVsb2FkOiB0cnVlXG4gICAgfSwgY2FsbGJhY2spO1xuICB9XG4gIGxvYWRPbmUobmFtZSwgcHJlZml4ID0gJycpIHtcbiAgICBjb25zdCBzID0gbmFtZS5zcGxpdCgnfCcpO1xuICAgIGNvbnN0IGxuZyA9IHNbMF07XG4gICAgY29uc3QgbnMgPSBzWzFdO1xuICAgIHRoaXMucmVhZChsbmcsIG5zLCAncmVhZCcsIHVuZGVmaW5lZCwgdW5kZWZpbmVkLCAoZXJyLCBkYXRhKSA9PiB7XG4gICAgICBpZiAoZXJyKSB0aGlzLmxvZ2dlci53YXJuKGAke3ByZWZpeH1sb2FkaW5nIG5hbWVzcGFjZSAke25zfSBmb3IgbGFuZ3VhZ2UgJHtsbmd9IGZhaWxlZGAsIGVycik7XG4gICAgICBpZiAoIWVyciAmJiBkYXRhKSB0aGlzLmxvZ2dlci5sb2coYCR7cHJlZml4fWxvYWRlZCBuYW1lc3BhY2UgJHtuc30gZm9yIGxhbmd1YWdlICR7bG5nfWAsIGRhdGEpO1xuICAgICAgdGhpcy5sb2FkZWQobmFtZSwgZXJyLCBkYXRhKTtcbiAgICB9KTtcbiAgfVxuICBzYXZlTWlzc2luZyhsYW5ndWFnZXMsIG5hbWVzcGFjZSwga2V5LCBmYWxsYmFja1ZhbHVlLCBpc1VwZGF0ZSwgb3B0aW9ucyA9IHt9LCBjbGIgPSAoKSA9PiB7fSkge1xuICAgIGlmICh0aGlzLnNlcnZpY2VzPy51dGlscz8uaGFzTG9hZGVkTmFtZXNwYWNlICYmICF0aGlzLnNlcnZpY2VzPy51dGlscz8uaGFzTG9hZGVkTmFtZXNwYWNlKG5hbWVzcGFjZSkpIHtcbiAgICAgIHRoaXMubG9nZ2VyLndhcm4oYGRpZCBub3Qgc2F2ZSBrZXkgXCIke2tleX1cIiBhcyB0aGUgbmFtZXNwYWNlIFwiJHtuYW1lc3BhY2V9XCIgd2FzIG5vdCB5ZXQgbG9hZGVkYCwgJ1RoaXMgbWVhbnMgc29tZXRoaW5nIElTIFdST05HIGluIHlvdXIgc2V0dXAuIFlvdSBhY2Nlc3MgdGhlIHQgZnVuY3Rpb24gYmVmb3JlIGkxOG5leHQuaW5pdCAvIGkxOG5leHQubG9hZE5hbWVzcGFjZSAvIGkxOG5leHQuY2hhbmdlTGFuZ3VhZ2Ugd2FzIGRvbmUuIFdhaXQgZm9yIHRoZSBjYWxsYmFjayBvciBQcm9taXNlIHRvIHJlc29sdmUgYmVmb3JlIGFjY2Vzc2luZyBpdCEhIScpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoa2V5ID09PSB1bmRlZmluZWQgfHwga2V5ID09PSBudWxsIHx8IGtleSA9PT0gJycpIHJldHVybjtcbiAgICBpZiAodGhpcy5iYWNrZW5kPy5jcmVhdGUpIHtcbiAgICAgIGNvbnN0IG9wdHMgPSB7XG4gICAgICAgIC4uLm9wdGlvbnMsXG4gICAgICAgIGlzVXBkYXRlXG4gICAgICB9O1xuICAgICAgY29uc3QgZmMgPSB0aGlzLmJhY2tlbmQuY3JlYXRlLmJpbmQodGhpcy5iYWNrZW5kKTtcbiAgICAgIGlmIChmYy5sZW5ndGggPCA2KSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgbGV0IHI7XG4gICAgICAgICAgaWYgKGZjLmxlbmd0aCA9PT0gNSkge1xuICAgICAgICAgICAgciA9IGZjKGxhbmd1YWdlcywgbmFtZXNwYWNlLCBrZXksIGZhbGxiYWNrVmFsdWUsIG9wdHMpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByID0gZmMobGFuZ3VhZ2VzLCBuYW1lc3BhY2UsIGtleSwgZmFsbGJhY2tWYWx1ZSk7XG4gICAgICAgICAgfVxuICAgICAgICAgIGlmIChyICYmIHR5cGVvZiByLnRoZW4gPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHIudGhlbihkYXRhID0+IGNsYihudWxsLCBkYXRhKSkuY2F0Y2goY2xiKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgY2xiKG51bGwsIHIpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgY2xiKGVycik7XG4gICAgICAgIH1cbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIGZjKGxhbmd1YWdlcywgbmFtZXNwYWNlLCBrZXksIGZhbGxiYWNrVmFsdWUsIGNsYiwgb3B0cyk7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghbGFuZ3VhZ2VzIHx8ICFsYW5ndWFnZXNbMF0pIHJldHVybjtcbiAgICB0aGlzLnN0b3JlLmFkZFJlc291cmNlKGxhbmd1YWdlc1swXSwgbmFtZXNwYWNlLCBrZXksIGZhbGxiYWNrVmFsdWUpO1xuICB9XG59XG5cbmNvbnN0IGdldCA9ICgpID0+ICh7XG4gIGRlYnVnOiBmYWxzZSxcbiAgaW5pdEFzeW5jOiB0cnVlLFxuICBuczogWyd0cmFuc2xhdGlvbiddLFxuICBkZWZhdWx0TlM6IFsndHJhbnNsYXRpb24nXSxcbiAgZmFsbGJhY2tMbmc6IFsnZGV2J10sXG4gIGZhbGxiYWNrTlM6IGZhbHNlLFxuICBzdXBwb3J0ZWRMbmdzOiBmYWxzZSxcbiAgbm9uRXhwbGljaXRTdXBwb3J0ZWRMbmdzOiBmYWxzZSxcbiAgbG9hZDogJ2FsbCcsXG4gIHByZWxvYWQ6IGZhbHNlLFxuICBrZXlTZXBhcmF0b3I6ICcuJyxcbiAgbnNTZXBhcmF0b3I6ICc6JyxcbiAgcGx1cmFsU2VwYXJhdG9yOiAnXycsXG4gIGNvbnRleHRTZXBhcmF0b3I6ICdfJyxcbiAgZW5hYmxlU2VsZWN0b3I6IGZhbHNlLFxuICBwYXJ0aWFsQnVuZGxlZExhbmd1YWdlczogZmFsc2UsXG4gIHNhdmVNaXNzaW5nOiBmYWxzZSxcbiAgdXBkYXRlTWlzc2luZzogZmFsc2UsXG4gIHNhdmVNaXNzaW5nVG86ICdmYWxsYmFjaycsXG4gIHNhdmVNaXNzaW5nUGx1cmFsczogdHJ1ZSxcbiAgbWlzc2luZ0tleUhhbmRsZXI6IGZhbHNlLFxuICBtaXNzaW5nSW50ZXJwb2xhdGlvbkhhbmRsZXI6IGZhbHNlLFxuICBwb3N0UHJvY2VzczogZmFsc2UsXG4gIHBvc3RQcm9jZXNzUGFzc1Jlc29sdmVkOiBmYWxzZSxcbiAgcmV0dXJuTnVsbDogZmFsc2UsXG4gIHJldHVybkVtcHR5U3RyaW5nOiB0cnVlLFxuICByZXR1cm5PYmplY3RzOiBmYWxzZSxcbiAgam9pbkFycmF5czogZmFsc2UsXG4gIHJldHVybmVkT2JqZWN0SGFuZGxlcjogZmFsc2UsXG4gIHBhcnNlTWlzc2luZ0tleUhhbmRsZXI6IGZhbHNlLFxuICBhcHBlbmROYW1lc3BhY2VUb01pc3NpbmdLZXk6IGZhbHNlLFxuICBhcHBlbmROYW1lc3BhY2VUb0NJTW9kZTogZmFsc2UsXG4gIG92ZXJsb2FkVHJhbnNsYXRpb25PcHRpb25IYW5kbGVyOiBhcmdzID0+IHtcbiAgICBsZXQgcmV0ID0ge307XG4gICAgaWYgKHR5cGVvZiBhcmdzWzFdID09PSAnb2JqZWN0JykgcmV0ID0gYXJnc1sxXTtcbiAgICBpZiAoaXNTdHJpbmcoYXJnc1sxXSkpIHJldC5kZWZhdWx0VmFsdWUgPSBhcmdzWzFdO1xuICAgIGlmIChpc1N0cmluZyhhcmdzWzJdKSkgcmV0LnREZXNjcmlwdGlvbiA9IGFyZ3NbMl07XG4gICAgaWYgKHR5cGVvZiBhcmdzWzJdID09PSAnb2JqZWN0JyB8fCB0eXBlb2YgYXJnc1szXSA9PT0gJ29iamVjdCcpIHtcbiAgICAgIGNvbnN0IG9wdGlvbnMgPSBhcmdzWzNdIHx8IGFyZ3NbMl07XG4gICAgICBPYmplY3Qua2V5cyhvcHRpb25zKS5mb3JFYWNoKGtleSA9PiB7XG4gICAgICAgIHJldFtrZXldID0gb3B0aW9uc1trZXldO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiByZXQ7XG4gIH0sXG4gIGludGVycG9sYXRpb246IHtcbiAgICBlc2NhcGVWYWx1ZTogdHJ1ZSxcbiAgICBwcmVmaXg6ICd7eycsXG4gICAgc3VmZml4OiAnfX0nLFxuICAgIGZvcm1hdFNlcGFyYXRvcjogJywnLFxuICAgIHVuZXNjYXBlUHJlZml4OiAnLScsXG4gICAgbmVzdGluZ1ByZWZpeDogJyR0KCcsXG4gICAgbmVzdGluZ1N1ZmZpeDogJyknLFxuICAgIG5lc3RpbmdPcHRpb25zU2VwYXJhdG9yOiAnLCcsXG4gICAgbWF4UmVwbGFjZXM6IDEwMDAsXG4gICAgc2tpcE9uVmFyaWFibGVzOiB0cnVlXG4gIH0sXG4gIGNhY2hlSW5CdWlsdEZvcm1hdHM6IHRydWVcbn0pO1xuY29uc3QgdHJhbnNmb3JtT3B0aW9ucyA9IG9wdGlvbnMgPT4ge1xuICBpZiAoaXNTdHJpbmcob3B0aW9ucy5ucykpIG9wdGlvbnMubnMgPSBbb3B0aW9ucy5uc107XG4gIGlmIChpc1N0cmluZyhvcHRpb25zLmZhbGxiYWNrTG5nKSkgb3B0aW9ucy5mYWxsYmFja0xuZyA9IFtvcHRpb25zLmZhbGxiYWNrTG5nXTtcbiAgaWYgKGlzU3RyaW5nKG9wdGlvbnMuZmFsbGJhY2tOUykpIG9wdGlvbnMuZmFsbGJhY2tOUyA9IFtvcHRpb25zLmZhbGxiYWNrTlNdO1xuICBpZiAob3B0aW9ucy5zdXBwb3J0ZWRMbmdzICYmICFvcHRpb25zLnN1cHBvcnRlZExuZ3MuaW5jbHVkZXMoJ2NpbW9kZScpKSB7XG4gICAgb3B0aW9ucy5zdXBwb3J0ZWRMbmdzID0gb3B0aW9ucy5zdXBwb3J0ZWRMbmdzLmNvbmNhdChbJ2NpbW9kZSddKTtcbiAgfVxuICByZXR1cm4gb3B0aW9ucztcbn07XG5cbmNvbnN0IG5vb3AgPSAoKSA9PiB7fTtcbmNvbnN0IGJpbmRNZW1iZXJGdW5jdGlvbnMgPSBpbnN0ID0+IHtcbiAgY29uc3QgbWVtcyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKE9iamVjdC5nZXRQcm90b3R5cGVPZihpbnN0KSk7XG4gIG1lbXMuZm9yRWFjaChtZW0gPT4ge1xuICAgIGlmICh0eXBlb2YgaW5zdFttZW1dID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICBpbnN0W21lbV0gPSBpbnN0W21lbV0uYmluZChpbnN0KTtcbiAgICB9XG4gIH0pO1xufTtcbmNsYXNzIEkxOG4gZXh0ZW5kcyBFdmVudEVtaXR0ZXIge1xuICBjb25zdHJ1Y3RvcihvcHRpb25zID0ge30sIGNhbGxiYWNrKSB7XG4gICAgc3VwZXIoKTtcbiAgICB0aGlzLm9wdGlvbnMgPSB0cmFuc2Zvcm1PcHRpb25zKG9wdGlvbnMpO1xuICAgIHRoaXMuc2VydmljZXMgPSB7fTtcbiAgICB0aGlzLmxvZ2dlciA9IGJhc2VMb2dnZXI7XG4gICAgdGhpcy5tb2R1bGVzID0ge1xuICAgICAgZXh0ZXJuYWw6IFtdXG4gICAgfTtcbiAgICBiaW5kTWVtYmVyRnVuY3Rpb25zKHRoaXMpO1xuICAgIGlmIChjYWxsYmFjayAmJiAhdGhpcy5pc0luaXRpYWxpemVkICYmICFvcHRpb25zLmlzQ2xvbmUpIHtcbiAgICAgIGlmICghdGhpcy5vcHRpb25zLmluaXRBc3luYykge1xuICAgICAgICB0aGlzLmluaXQob3B0aW9ucywgY2FsbGJhY2spO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgIH1cbiAgICAgIHNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICB0aGlzLmluaXQob3B0aW9ucywgY2FsbGJhY2spO1xuICAgICAgfSwgMCk7XG4gICAgfVxuICB9XG4gIGluaXQob3B0aW9ucyA9IHt9LCBjYWxsYmFjaykge1xuICAgIHRoaXMuaXNJbml0aWFsaXppbmcgPSB0cnVlO1xuICAgIGlmICh0eXBlb2Ygb3B0aW9ucyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY2FsbGJhY2sgPSBvcHRpb25zO1xuICAgICAgb3B0aW9ucyA9IHt9O1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5kZWZhdWx0TlMgPT0gbnVsbCAmJiBvcHRpb25zLm5zKSB7XG4gICAgICBpZiAoaXNTdHJpbmcob3B0aW9ucy5ucykpIHtcbiAgICAgICAgb3B0aW9ucy5kZWZhdWx0TlMgPSBvcHRpb25zLm5zO1xuICAgICAgfSBlbHNlIGlmICghb3B0aW9ucy5ucy5pbmNsdWRlcygndHJhbnNsYXRpb24nKSkge1xuICAgICAgICBvcHRpb25zLmRlZmF1bHROUyA9IG9wdGlvbnMubnNbMF07XG4gICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGRlZk9wdHMgPSBnZXQoKTtcbiAgICB0aGlzLm9wdGlvbnMgPSB7XG4gICAgICAuLi5kZWZPcHRzLFxuICAgICAgLi4udGhpcy5vcHRpb25zLFxuICAgICAgLi4udHJhbnNmb3JtT3B0aW9ucyhvcHRpb25zKVxuICAgIH07XG4gICAgdGhpcy5vcHRpb25zLmludGVycG9sYXRpb24gPSB7XG4gICAgICAuLi5kZWZPcHRzLmludGVycG9sYXRpb24sXG4gICAgICAuLi50aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvblxuICAgIH07XG4gICAgaWYgKG9wdGlvbnMua2V5U2VwYXJhdG9yICE9PSB1bmRlZmluZWQpIHtcbiAgICAgIHRoaXMub3B0aW9ucy51c2VyRGVmaW5lZEtleVNlcGFyYXRvciA9IG9wdGlvbnMua2V5U2VwYXJhdG9yO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5uc1NlcGFyYXRvciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aGlzLm9wdGlvbnMudXNlckRlZmluZWROc1NlcGFyYXRvciA9IG9wdGlvbnMubnNTZXBhcmF0b3I7XG4gICAgfVxuICAgIGlmICh0eXBlb2YgdGhpcy5vcHRpb25zLm92ZXJsb2FkVHJhbnNsYXRpb25PcHRpb25IYW5kbGVyICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICB0aGlzLm9wdGlvbnMub3ZlcmxvYWRUcmFuc2xhdGlvbk9wdGlvbkhhbmRsZXIgPSBkZWZPcHRzLm92ZXJsb2FkVHJhbnNsYXRpb25PcHRpb25IYW5kbGVyO1xuICAgIH1cbiAgICBjb25zdCBjcmVhdGVDbGFzc09uRGVtYW5kID0gQ2xhc3NPck9iamVjdCA9PiB7XG4gICAgICBpZiAoIUNsYXNzT3JPYmplY3QpIHJldHVybiBudWxsO1xuICAgICAgaWYgKHR5cGVvZiBDbGFzc09yT2JqZWN0ID09PSAnZnVuY3Rpb24nKSByZXR1cm4gbmV3IENsYXNzT3JPYmplY3QoKTtcbiAgICAgIHJldHVybiBDbGFzc09yT2JqZWN0O1xuICAgIH07XG4gICAgaWYgKCF0aGlzLm9wdGlvbnMuaXNDbG9uZSkge1xuICAgICAgaWYgKHRoaXMubW9kdWxlcy5sb2dnZXIpIHtcbiAgICAgICAgYmFzZUxvZ2dlci5pbml0KGNyZWF0ZUNsYXNzT25EZW1hbmQodGhpcy5tb2R1bGVzLmxvZ2dlciksIHRoaXMub3B0aW9ucyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBiYXNlTG9nZ2VyLmluaXQobnVsbCwgdGhpcy5vcHRpb25zKTtcbiAgICAgIH1cbiAgICAgIGxldCBmb3JtYXR0ZXI7XG4gICAgICBpZiAodGhpcy5tb2R1bGVzLmZvcm1hdHRlcikge1xuICAgICAgICBmb3JtYXR0ZXIgPSB0aGlzLm1vZHVsZXMuZm9ybWF0dGVyO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgZm9ybWF0dGVyID0gRm9ybWF0dGVyO1xuICAgICAgfVxuICAgICAgY29uc3QgbHUgPSBuZXcgTGFuZ3VhZ2VVdGlsKHRoaXMub3B0aW9ucyk7XG4gICAgICB0aGlzLnN0b3JlID0gbmV3IFJlc291cmNlU3RvcmUodGhpcy5vcHRpb25zLnJlc291cmNlcywgdGhpcy5vcHRpb25zKTtcbiAgICAgIGNvbnN0IHMgPSB0aGlzLnNlcnZpY2VzO1xuICAgICAgcy5sb2dnZXIgPSBiYXNlTG9nZ2VyO1xuICAgICAgcy5yZXNvdXJjZVN0b3JlID0gdGhpcy5zdG9yZTtcbiAgICAgIHMubGFuZ3VhZ2VVdGlscyA9IGx1O1xuICAgICAgcy5wbHVyYWxSZXNvbHZlciA9IG5ldyBQbHVyYWxSZXNvbHZlcihsdSwge1xuICAgICAgICBwcmVwZW5kOiB0aGlzLm9wdGlvbnMucGx1cmFsU2VwYXJhdG9yXG4gICAgICB9KTtcbiAgICAgIGlmIChmb3JtYXR0ZXIpIHtcbiAgICAgICAgcy5mb3JtYXR0ZXIgPSBjcmVhdGVDbGFzc09uRGVtYW5kKGZvcm1hdHRlcik7XG4gICAgICAgIGlmIChzLmZvcm1hdHRlci5pbml0KSBzLmZvcm1hdHRlci5pbml0KHMsIHRoaXMub3B0aW9ucyk7XG4gICAgICAgIHRoaXMub3B0aW9ucy5pbnRlcnBvbGF0aW9uLmZvcm1hdCA9IHMuZm9ybWF0dGVyLmZvcm1hdC5iaW5kKHMuZm9ybWF0dGVyKTtcbiAgICAgIH1cbiAgICAgIHMuaW50ZXJwb2xhdG9yID0gbmV3IEludGVycG9sYXRvcih0aGlzLm9wdGlvbnMpO1xuICAgICAgcy51dGlscyA9IHtcbiAgICAgICAgaGFzTG9hZGVkTmFtZXNwYWNlOiB0aGlzLmhhc0xvYWRlZE5hbWVzcGFjZS5iaW5kKHRoaXMpXG4gICAgICB9O1xuICAgICAgcy5iYWNrZW5kQ29ubmVjdG9yID0gbmV3IENvbm5lY3RvcihjcmVhdGVDbGFzc09uRGVtYW5kKHRoaXMubW9kdWxlcy5iYWNrZW5kKSwgcy5yZXNvdXJjZVN0b3JlLCBzLCB0aGlzLm9wdGlvbnMpO1xuICAgICAgcy5iYWNrZW5kQ29ubmVjdG9yLm9uKCcqJywgKGV2ZW50LCAuLi5hcmdzKSA9PiB7XG4gICAgICAgIHRoaXMuZW1pdChldmVudCwgLi4uYXJncyk7XG4gICAgICB9KTtcbiAgICAgIGlmICh0aGlzLm1vZHVsZXMubGFuZ3VhZ2VEZXRlY3Rvcikge1xuICAgICAgICBzLmxhbmd1YWdlRGV0ZWN0b3IgPSBjcmVhdGVDbGFzc09uRGVtYW5kKHRoaXMubW9kdWxlcy5sYW5ndWFnZURldGVjdG9yKTtcbiAgICAgICAgaWYgKHMubGFuZ3VhZ2VEZXRlY3Rvci5pbml0KSBzLmxhbmd1YWdlRGV0ZWN0b3IuaW5pdChzLCB0aGlzLm9wdGlvbnMuZGV0ZWN0aW9uLCB0aGlzLm9wdGlvbnMpO1xuICAgICAgfVxuICAgICAgaWYgKHRoaXMubW9kdWxlcy5pMThuRm9ybWF0KSB7XG4gICAgICAgIHMuaTE4bkZvcm1hdCA9IGNyZWF0ZUNsYXNzT25EZW1hbmQodGhpcy5tb2R1bGVzLmkxOG5Gb3JtYXQpO1xuICAgICAgICBpZiAocy5pMThuRm9ybWF0LmluaXQpIHMuaTE4bkZvcm1hdC5pbml0KHRoaXMpO1xuICAgICAgfVxuICAgICAgdGhpcy50cmFuc2xhdG9yID0gbmV3IFRyYW5zbGF0b3IodGhpcy5zZXJ2aWNlcywgdGhpcy5vcHRpb25zKTtcbiAgICAgIHRoaXMudHJhbnNsYXRvci5vbignKicsIChldmVudCwgLi4uYXJncykgPT4ge1xuICAgICAgICB0aGlzLmVtaXQoZXZlbnQsIC4uLmFyZ3MpO1xuICAgICAgfSk7XG4gICAgICB0aGlzLm1vZHVsZXMuZXh0ZXJuYWwuZm9yRWFjaChtID0+IHtcbiAgICAgICAgaWYgKG0uaW5pdCkgbS5pbml0KHRoaXMpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHRoaXMuZm9ybWF0ID0gdGhpcy5vcHRpb25zLmludGVycG9sYXRpb24uZm9ybWF0O1xuICAgIGlmICghY2FsbGJhY2spIGNhbGxiYWNrID0gbm9vcDtcbiAgICBpZiAodGhpcy5vcHRpb25zLmZhbGxiYWNrTG5nICYmICF0aGlzLnNlcnZpY2VzLmxhbmd1YWdlRGV0ZWN0b3IgJiYgIXRoaXMub3B0aW9ucy5sbmcpIHtcbiAgICAgIGNvbnN0IGNvZGVzID0gdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZVV0aWxzLmdldEZhbGxiYWNrQ29kZXModGhpcy5vcHRpb25zLmZhbGxiYWNrTG5nKTtcbiAgICAgIGlmIChjb2Rlcy5sZW5ndGggPiAwICYmIGNvZGVzWzBdICE9PSAnZGV2JykgdGhpcy5vcHRpb25zLmxuZyA9IGNvZGVzWzBdO1xuICAgIH1cbiAgICBpZiAoIXRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3RvciAmJiAhdGhpcy5vcHRpb25zLmxuZykge1xuICAgICAgdGhpcy5sb2dnZXIud2FybignaW5pdDogbm8gbGFuZ3VhZ2VEZXRlY3RvciBpcyB1c2VkIGFuZCBubyBsbmcgaXMgZGVmaW5lZCcpO1xuICAgIH1cbiAgICBjb25zdCBzdG9yZUFwaSA9IFsnZ2V0UmVzb3VyY2UnLCAnaGFzUmVzb3VyY2VCdW5kbGUnLCAnZ2V0UmVzb3VyY2VCdW5kbGUnLCAnZ2V0RGF0YUJ5TGFuZ3VhZ2UnXTtcbiAgICBzdG9yZUFwaS5mb3JFYWNoKGZjTmFtZSA9PiB7XG4gICAgICB0aGlzW2ZjTmFtZV0gPSAoLi4uYXJncykgPT4gdGhpcy5zdG9yZVtmY05hbWVdKC4uLmFyZ3MpO1xuICAgIH0pO1xuICAgIGNvbnN0IHN0b3JlQXBpQ2hhaW5lZCA9IFsnYWRkUmVzb3VyY2UnLCAnYWRkUmVzb3VyY2VzJywgJ2FkZFJlc291cmNlQnVuZGxlJywgJ3JlbW92ZVJlc291cmNlQnVuZGxlJ107XG4gICAgc3RvcmVBcGlDaGFpbmVkLmZvckVhY2goZmNOYW1lID0+IHtcbiAgICAgIHRoaXNbZmNOYW1lXSA9ICguLi5hcmdzKSA9PiB7XG4gICAgICAgIHRoaXMuc3RvcmVbZmNOYW1lXSguLi5hcmdzKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICB9O1xuICAgIH0pO1xuICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXIoKTtcbiAgICBjb25zdCBsb2FkID0gKCkgPT4ge1xuICAgICAgY29uc3QgZmluaXNoID0gKGVyciwgdCkgPT4ge1xuICAgICAgICB0aGlzLmlzSW5pdGlhbGl6aW5nID0gZmFsc2U7XG4gICAgICAgIGlmICh0aGlzLmlzSW5pdGlhbGl6ZWQgJiYgIXRoaXMuaW5pdGlhbGl6ZWRTdG9yZU9uY2UpIHRoaXMubG9nZ2VyLndhcm4oJ2luaXQ6IGkxOG5leHQgaXMgYWxyZWFkeSBpbml0aWFsaXplZC4gWW91IHNob3VsZCBjYWxsIGluaXQganVzdCBvbmNlIScpO1xuICAgICAgICB0aGlzLmlzSW5pdGlhbGl6ZWQgPSB0cnVlO1xuICAgICAgICBpZiAoIXRoaXMub3B0aW9ucy5pc0Nsb25lKSB0aGlzLmxvZ2dlci5sb2coJ2luaXRpYWxpemVkJywgdGhpcy5vcHRpb25zKTtcbiAgICAgICAgdGhpcy5lbWl0KCdpbml0aWFsaXplZCcsIHRoaXMub3B0aW9ucyk7XG4gICAgICAgIGRlZmVycmVkLnJlc29sdmUodCk7XG4gICAgICAgIGNhbGxiYWNrKGVyciwgdCk7XG4gICAgICB9O1xuICAgICAgaWYgKCh0aGlzLmxhbmd1YWdlcyB8fCB0aGlzLmlzTGFuZ3VhZ2VDaGFuZ2luZ1RvKSAmJiAhdGhpcy5pc0luaXRpYWxpemVkKSByZXR1cm4gZmluaXNoKG51bGwsIHRoaXMudC5iaW5kKHRoaXMpKTtcbiAgICAgIHRoaXMuY2hhbmdlTGFuZ3VhZ2UodGhpcy5vcHRpb25zLmxuZywgZmluaXNoKTtcbiAgICB9O1xuICAgIGlmICh0aGlzLm9wdGlvbnMucmVzb3VyY2VzIHx8ICF0aGlzLm9wdGlvbnMuaW5pdEFzeW5jKSB7XG4gICAgICBsb2FkKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldFRpbWVvdXQobG9hZCwgMCk7XG4gICAgfVxuICAgIHJldHVybiBkZWZlcnJlZDtcbiAgfVxuICBsb2FkUmVzb3VyY2VzKGxhbmd1YWdlLCBjYWxsYmFjayA9IG5vb3ApIHtcbiAgICBsZXQgdXNlZENhbGxiYWNrID0gY2FsbGJhY2s7XG4gICAgY29uc3QgdXNlZExuZyA9IGlzU3RyaW5nKGxhbmd1YWdlKSA/IGxhbmd1YWdlIDogdGhpcy5sYW5ndWFnZTtcbiAgICBpZiAodHlwZW9mIGxhbmd1YWdlID09PSAnZnVuY3Rpb24nKSB1c2VkQ2FsbGJhY2sgPSBsYW5ndWFnZTtcbiAgICBpZiAoIXRoaXMub3B0aW9ucy5yZXNvdXJjZXMgfHwgdGhpcy5vcHRpb25zLnBhcnRpYWxCdW5kbGVkTGFuZ3VhZ2VzKSB7XG4gICAgICBpZiAodXNlZExuZz8udG9Mb3dlckNhc2UoKSA9PT0gJ2NpbW9kZScgJiYgKCF0aGlzLm9wdGlvbnMucHJlbG9hZCB8fCB0aGlzLm9wdGlvbnMucHJlbG9hZC5sZW5ndGggPT09IDApKSByZXR1cm4gdXNlZENhbGxiYWNrKCk7XG4gICAgICBjb25zdCB0b0xvYWQgPSBbXTtcbiAgICAgIGNvbnN0IGFwcGVuZCA9IGxuZyA9PiB7XG4gICAgICAgIGlmICghbG5nKSByZXR1cm47XG4gICAgICAgIGlmIChsbmcgPT09ICdjaW1vZGUnKSByZXR1cm47XG4gICAgICAgIGNvbnN0IGxuZ3MgPSB0aGlzLnNlcnZpY2VzLmxhbmd1YWdlVXRpbHMudG9SZXNvbHZlSGllcmFyY2h5KGxuZyk7XG4gICAgICAgIGxuZ3MuZm9yRWFjaChsID0+IHtcbiAgICAgICAgICBpZiAobCA9PT0gJ2NpbW9kZScpIHJldHVybjtcbiAgICAgICAgICBpZiAoIXRvTG9hZC5pbmNsdWRlcyhsKSkgdG9Mb2FkLnB1c2gobCk7XG4gICAgICAgIH0pO1xuICAgICAgfTtcbiAgICAgIGlmICghdXNlZExuZykge1xuICAgICAgICBjb25zdCBmYWxsYmFja3MgPSB0aGlzLnNlcnZpY2VzLmxhbmd1YWdlVXRpbHMuZ2V0RmFsbGJhY2tDb2Rlcyh0aGlzLm9wdGlvbnMuZmFsbGJhY2tMbmcpO1xuICAgICAgICBmYWxsYmFja3MuZm9yRWFjaChsID0+IGFwcGVuZChsKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBhcHBlbmQodXNlZExuZyk7XG4gICAgICB9XG4gICAgICB0aGlzLm9wdGlvbnMucHJlbG9hZD8uZm9yRWFjaD8uKGwgPT4gYXBwZW5kKGwpKTtcbiAgICAgIHRoaXMuc2VydmljZXMuYmFja2VuZENvbm5lY3Rvci5sb2FkKHRvTG9hZCwgdGhpcy5vcHRpb25zLm5zLCBlID0+IHtcbiAgICAgICAgaWYgKCFlICYmICF0aGlzLnJlc29sdmVkTGFuZ3VhZ2UgJiYgdGhpcy5sYW5ndWFnZSkgdGhpcy5zZXRSZXNvbHZlZExhbmd1YWdlKHRoaXMubGFuZ3VhZ2UpO1xuICAgICAgICB1c2VkQ2FsbGJhY2soZSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgdXNlZENhbGxiYWNrKG51bGwpO1xuICAgIH1cbiAgfVxuICByZWxvYWRSZXNvdXJjZXMobG5ncywgbnMsIGNhbGxiYWNrKSB7XG4gICAgY29uc3QgZGVmZXJyZWQgPSBkZWZlcigpO1xuICAgIGlmICh0eXBlb2YgbG5ncyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY2FsbGJhY2sgPSBsbmdzO1xuICAgICAgbG5ncyA9IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBucyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgY2FsbGJhY2sgPSBucztcbiAgICAgIG5zID0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBpZiAoIWxuZ3MpIGxuZ3MgPSB0aGlzLmxhbmd1YWdlcztcbiAgICBpZiAoIW5zKSBucyA9IHRoaXMub3B0aW9ucy5ucztcbiAgICBpZiAoIWNhbGxiYWNrKSBjYWxsYmFjayA9IG5vb3A7XG4gICAgdGhpcy5zZXJ2aWNlcy5iYWNrZW5kQ29ubmVjdG9yLnJlbG9hZChsbmdzLCBucywgZXJyID0+IHtcbiAgICAgIGRlZmVycmVkLnJlc29sdmUoKTtcbiAgICAgIGNhbGxiYWNrKGVycik7XG4gICAgfSk7XG4gICAgcmV0dXJuIGRlZmVycmVkO1xuICB9XG4gIHVzZShtb2R1bGUpIHtcbiAgICBpZiAoIW1vZHVsZSkgdGhyb3cgbmV3IEVycm9yKCdZb3UgYXJlIHBhc3NpbmcgYW4gdW5kZWZpbmVkIG1vZHVsZSEgUGxlYXNlIGNoZWNrIHRoZSBvYmplY3QgeW91IGFyZSBwYXNzaW5nIHRvIGkxOG5leHQudXNlKCknKTtcbiAgICBpZiAoIW1vZHVsZS50eXBlKSB0aHJvdyBuZXcgRXJyb3IoJ1lvdSBhcmUgcGFzc2luZyBhIHdyb25nIG1vZHVsZSEgUGxlYXNlIGNoZWNrIHRoZSBvYmplY3QgeW91IGFyZSBwYXNzaW5nIHRvIGkxOG5leHQudXNlKCknKTtcbiAgICBpZiAobW9kdWxlLnR5cGUgPT09ICdiYWNrZW5kJykge1xuICAgICAgdGhpcy5tb2R1bGVzLmJhY2tlbmQgPSBtb2R1bGU7XG4gICAgfVxuICAgIGlmIChtb2R1bGUudHlwZSA9PT0gJ2xvZ2dlcicgfHwgbW9kdWxlLmxvZyAmJiBtb2R1bGUud2FybiAmJiBtb2R1bGUuZXJyb3IpIHtcbiAgICAgIHRoaXMubW9kdWxlcy5sb2dnZXIgPSBtb2R1bGU7XG4gICAgfVxuICAgIGlmIChtb2R1bGUudHlwZSA9PT0gJ2xhbmd1YWdlRGV0ZWN0b3InKSB7XG4gICAgICB0aGlzLm1vZHVsZXMubGFuZ3VhZ2VEZXRlY3RvciA9IG1vZHVsZTtcbiAgICB9XG4gICAgaWYgKG1vZHVsZS50eXBlID09PSAnaTE4bkZvcm1hdCcpIHtcbiAgICAgIHRoaXMubW9kdWxlcy5pMThuRm9ybWF0ID0gbW9kdWxlO1xuICAgIH1cbiAgICBpZiAobW9kdWxlLnR5cGUgPT09ICdwb3N0UHJvY2Vzc29yJykge1xuICAgICAgcG9zdFByb2Nlc3Nvci5hZGRQb3N0UHJvY2Vzc29yKG1vZHVsZSk7XG4gICAgfVxuICAgIGlmIChtb2R1bGUudHlwZSA9PT0gJ2Zvcm1hdHRlcicpIHtcbiAgICAgIHRoaXMubW9kdWxlcy5mb3JtYXR0ZXIgPSBtb2R1bGU7XG4gICAgfVxuICAgIGlmIChtb2R1bGUudHlwZSA9PT0gJzNyZFBhcnR5Jykge1xuICAgICAgdGhpcy5tb2R1bGVzLmV4dGVybmFsLnB1c2gobW9kdWxlKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cbiAgc2V0UmVzb2x2ZWRMYW5ndWFnZShsKSB7XG4gICAgaWYgKCFsIHx8ICF0aGlzLmxhbmd1YWdlcykgcmV0dXJuO1xuICAgIGlmIChbJ2NpbW9kZScsICdkZXYnXS5pbmNsdWRlcyhsKSkgcmV0dXJuO1xuICAgIGZvciAobGV0IGxpID0gMDsgbGkgPCB0aGlzLmxhbmd1YWdlcy5sZW5ndGg7IGxpKyspIHtcbiAgICAgIGNvbnN0IGxuZ0luTG5ncyA9IHRoaXMubGFuZ3VhZ2VzW2xpXTtcbiAgICAgIGlmIChbJ2NpbW9kZScsICdkZXYnXS5pbmNsdWRlcyhsbmdJbkxuZ3MpKSBjb250aW51ZTtcbiAgICAgIGlmICh0aGlzLnN0b3JlLmhhc0xhbmd1YWdlU29tZVRyYW5zbGF0aW9ucyhsbmdJbkxuZ3MpKSB7XG4gICAgICAgIHRoaXMucmVzb2x2ZWRMYW5ndWFnZSA9IGxuZ0luTG5ncztcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuICAgIGlmICghdGhpcy5yZXNvbHZlZExhbmd1YWdlICYmICF0aGlzLmxhbmd1YWdlcy5pbmNsdWRlcyhsKSAmJiB0aGlzLnN0b3JlLmhhc0xhbmd1YWdlU29tZVRyYW5zbGF0aW9ucyhsKSkge1xuICAgICAgdGhpcy5yZXNvbHZlZExhbmd1YWdlID0gbDtcbiAgICAgIHRoaXMubGFuZ3VhZ2VzLnVuc2hpZnQobCk7XG4gICAgfVxuICB9XG4gIGNoYW5nZUxhbmd1YWdlKGxuZywgY2FsbGJhY2spIHtcbiAgICB0aGlzLmlzTGFuZ3VhZ2VDaGFuZ2luZ1RvID0gbG5nO1xuICAgIGNvbnN0IGRlZmVycmVkID0gZGVmZXIoKTtcbiAgICB0aGlzLmVtaXQoJ2xhbmd1YWdlQ2hhbmdpbmcnLCBsbmcpO1xuICAgIGNvbnN0IHNldExuZ1Byb3BzID0gbCA9PiB7XG4gICAgICB0aGlzLmxhbmd1YWdlID0gbDtcbiAgICAgIHRoaXMubGFuZ3VhZ2VzID0gdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZVV0aWxzLnRvUmVzb2x2ZUhpZXJhcmNoeShsKTtcbiAgICAgIHRoaXMucmVzb2x2ZWRMYW5ndWFnZSA9IHVuZGVmaW5lZDtcbiAgICAgIHRoaXMuc2V0UmVzb2x2ZWRMYW5ndWFnZShsKTtcbiAgICB9O1xuICAgIGNvbnN0IGRvbmUgPSAoZXJyLCBsKSA9PiB7XG4gICAgICBpZiAobCkge1xuICAgICAgICBpZiAodGhpcy5pc0xhbmd1YWdlQ2hhbmdpbmdUbyA9PT0gbG5nKSB7XG4gICAgICAgICAgc2V0TG5nUHJvcHMobCk7XG4gICAgICAgICAgdGhpcy50cmFuc2xhdG9yLmNoYW5nZUxhbmd1YWdlKGwpO1xuICAgICAgICAgIHRoaXMuaXNMYW5ndWFnZUNoYW5naW5nVG8gPSB1bmRlZmluZWQ7XG4gICAgICAgICAgdGhpcy5lbWl0KCdsYW5ndWFnZUNoYW5nZWQnLCBsKTtcbiAgICAgICAgICB0aGlzLmxvZ2dlci5sb2coJ2xhbmd1YWdlQ2hhbmdlZCcsIGwpO1xuICAgICAgICB9XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLmlzTGFuZ3VhZ2VDaGFuZ2luZ1RvID0gdW5kZWZpbmVkO1xuICAgICAgfVxuICAgICAgZGVmZXJyZWQucmVzb2x2ZSgoLi4uYXJncykgPT4gdGhpcy50KC4uLmFyZ3MpKTtcbiAgICAgIGlmIChjYWxsYmFjaykgY2FsbGJhY2soZXJyLCAoLi4uYXJncykgPT4gdGhpcy50KC4uLmFyZ3MpKTtcbiAgICB9O1xuICAgIGNvbnN0IHNldExuZyA9IGxuZ3MgPT4ge1xuICAgICAgaWYgKCFsbmcgJiYgIWxuZ3MgJiYgdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZURldGVjdG9yKSBsbmdzID0gW107XG4gICAgICBjb25zdCBmbCA9IGlzU3RyaW5nKGxuZ3MpID8gbG5ncyA6IGxuZ3MgJiYgbG5nc1swXTtcbiAgICAgIGNvbnN0IGwgPSB0aGlzLnN0b3JlLmhhc0xhbmd1YWdlU29tZVRyYW5zbGF0aW9ucyhmbCkgPyBmbCA6IHRoaXMuc2VydmljZXMubGFuZ3VhZ2VVdGlscy5nZXRCZXN0TWF0Y2hGcm9tQ29kZXMoaXNTdHJpbmcobG5ncykgPyBbbG5nc10gOiBsbmdzKTtcbiAgICAgIGlmIChsKSB7XG4gICAgICAgIGlmICghdGhpcy5sYW5ndWFnZSkge1xuICAgICAgICAgIHNldExuZ1Byb3BzKGwpO1xuICAgICAgICB9XG4gICAgICAgIGlmICghdGhpcy50cmFuc2xhdG9yLmxhbmd1YWdlKSB0aGlzLnRyYW5zbGF0b3IuY2hhbmdlTGFuZ3VhZ2UobCk7XG4gICAgICAgIHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3Rvcj8uY2FjaGVVc2VyTGFuZ3VhZ2U/LihsKTtcbiAgICAgIH1cbiAgICAgIHRoaXMubG9hZFJlc291cmNlcyhsLCBlcnIgPT4ge1xuICAgICAgICBkb25lKGVyciwgbCk7XG4gICAgICB9KTtcbiAgICB9O1xuICAgIGlmICghbG5nICYmIHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3RvciAmJiAhdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZURldGVjdG9yLmFzeW5jKSB7XG4gICAgICBzZXRMbmcodGhpcy5zZXJ2aWNlcy5sYW5ndWFnZURldGVjdG9yLmRldGVjdCgpKTtcbiAgICB9IGVsc2UgaWYgKCFsbmcgJiYgdGhpcy5zZXJ2aWNlcy5sYW5ndWFnZURldGVjdG9yICYmIHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3Rvci5hc3luYykge1xuICAgICAgaWYgKHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3Rvci5kZXRlY3QubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHRoaXMuc2VydmljZXMubGFuZ3VhZ2VEZXRlY3Rvci5kZXRlY3QoKS50aGVuKHNldExuZyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aGlzLnNlcnZpY2VzLmxhbmd1YWdlRGV0ZWN0b3IuZGV0ZWN0KHNldExuZyk7XG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHNldExuZyhsbmcpO1xuICAgIH1cbiAgICByZXR1cm4gZGVmZXJyZWQ7XG4gIH1cbiAgZ2V0Rml4ZWRUKGxuZywgbnMsIGtleVByZWZpeCwgZml4ZWRPcHRzKSB7XG4gICAgY29uc3Qgc2NvcGVOcyA9IGZpeGVkT3B0cz8uc2NvcGVOcztcbiAgICBjb25zdCBmaXhlZFQgPSAoa2V5LCBvcHRzLCAuLi5yZXN0KSA9PiB7XG4gICAgICBsZXQgbztcbiAgICAgIGlmICh0eXBlb2Ygb3B0cyAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgbyA9IHRoaXMub3B0aW9ucy5vdmVybG9hZFRyYW5zbGF0aW9uT3B0aW9uSGFuZGxlcihba2V5LCBvcHRzXS5jb25jYXQocmVzdCkpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbyA9IHtcbiAgICAgICAgICAuLi5vcHRzXG4gICAgICAgIH07XG4gICAgICB9XG4gICAgICBvLmxuZyA9IG8ubG5nIHx8IGZpeGVkVC5sbmc7XG4gICAgICBvLmxuZ3MgPSBvLmxuZ3MgfHwgZml4ZWRULmxuZ3M7XG4gICAgICBjb25zdCBleHBsaWNpdENhbGxOcyA9IG8ubnMgIT09IHVuZGVmaW5lZCAmJiBvLm5zICE9PSBudWxsO1xuICAgICAgby5ucyA9IG8ubnMgfHwgZml4ZWRULm5zO1xuICAgICAgaWYgKG8ua2V5UHJlZml4ICE9PSAnJykgby5rZXlQcmVmaXggPSBvLmtleVByZWZpeCB8fCBrZXlQcmVmaXggfHwgZml4ZWRULmtleVByZWZpeDtcbiAgICAgIGNvbnN0IHNlbGVjdG9yT3B0cyA9IHtcbiAgICAgICAgLi4udGhpcy5vcHRpb25zLFxuICAgICAgICAuLi5vXG4gICAgICB9O1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkoc2NvcGVOcykgJiYgIWV4cGxpY2l0Q2FsbE5zKSBzZWxlY3Rvck9wdHMubnMgPSBzY29wZU5zO1xuICAgICAgaWYgKHR5cGVvZiBvLmtleVByZWZpeCA9PT0gJ2Z1bmN0aW9uJykgby5rZXlQcmVmaXggPSBrZXlzRnJvbVNlbGVjdG9yKG8ua2V5UHJlZml4LCBzZWxlY3Rvck9wdHMpO1xuICAgICAgY29uc3Qga2V5U2VwYXJhdG9yID0gdGhpcy5vcHRpb25zLmtleVNlcGFyYXRvciB8fCAnLic7XG4gICAgICBsZXQgcmVzdWx0S2V5O1xuICAgICAgaWYgKG8ua2V5UHJlZml4ICYmIEFycmF5LmlzQXJyYXkoa2V5KSkge1xuICAgICAgICByZXN1bHRLZXkgPSBrZXkubWFwKGsgPT4ge1xuICAgICAgICAgIGlmICh0eXBlb2YgayA9PT0gJ2Z1bmN0aW9uJykgayA9IGtleXNGcm9tU2VsZWN0b3Ioaywgc2VsZWN0b3JPcHRzKTtcbiAgICAgICAgICByZXR1cm4gYCR7by5rZXlQcmVmaXh9JHtrZXlTZXBhcmF0b3J9JHtrfWA7XG4gICAgICAgIH0pO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgaWYgKHR5cGVvZiBrZXkgPT09ICdmdW5jdGlvbicpIGtleSA9IGtleXNGcm9tU2VsZWN0b3Ioa2V5LCBzZWxlY3Rvck9wdHMpO1xuICAgICAgICByZXN1bHRLZXkgPSBvLmtleVByZWZpeCA/IGAke28ua2V5UHJlZml4fSR7a2V5U2VwYXJhdG9yfSR7a2V5fWAgOiBrZXk7XG4gICAgICB9XG4gICAgICByZXR1cm4gdGhpcy50KHJlc3VsdEtleSwgbyk7XG4gICAgfTtcbiAgICBpZiAoaXNTdHJpbmcobG5nKSkge1xuICAgICAgZml4ZWRULmxuZyA9IGxuZztcbiAgICB9IGVsc2Uge1xuICAgICAgZml4ZWRULmxuZ3MgPSBsbmc7XG4gICAgfVxuICAgIGZpeGVkVC5ucyA9IG5zO1xuICAgIGZpeGVkVC5rZXlQcmVmaXggPSBrZXlQcmVmaXg7XG4gICAgcmV0dXJuIGZpeGVkVDtcbiAgfVxuICB0KC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2xhdG9yPy50cmFuc2xhdGUoLi4uYXJncyk7XG4gIH1cbiAgZXhpc3RzKC4uLmFyZ3MpIHtcbiAgICByZXR1cm4gdGhpcy50cmFuc2xhdG9yPy5leGlzdHMoLi4uYXJncyk7XG4gIH1cbiAgc2V0RGVmYXVsdE5hbWVzcGFjZShucykge1xuICAgIHRoaXMub3B0aW9ucy5kZWZhdWx0TlMgPSBucztcbiAgfVxuICBoYXNMb2FkZWROYW1lc3BhY2UobnMsIG9wdGlvbnMgPSB7fSkge1xuICAgIGlmICghdGhpcy5pc0luaXRpYWxpemVkKSB7XG4gICAgICB0aGlzLmxvZ2dlci53YXJuKCdoYXNMb2FkZWROYW1lc3BhY2U6IGkxOG5leHQgd2FzIG5vdCBpbml0aWFsaXplZCcsIHRoaXMubGFuZ3VhZ2VzKTtcbiAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaWYgKCF0aGlzLmxhbmd1YWdlcyB8fCAhdGhpcy5sYW5ndWFnZXMubGVuZ3RoKSB7XG4gICAgICB0aGlzLmxvZ2dlci53YXJuKCdoYXNMb2FkZWROYW1lc3BhY2U6IGkxOG4ubGFuZ3VhZ2VzIHdlcmUgdW5kZWZpbmVkIG9yIGVtcHR5JywgdGhpcy5sYW5ndWFnZXMpO1xuICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBsbmcgPSBvcHRpb25zLmxuZyB8fCB0aGlzLnJlc29sdmVkTGFuZ3VhZ2UgfHwgdGhpcy5sYW5ndWFnZXNbMF07XG4gICAgY29uc3QgZmFsbGJhY2tMbmcgPSB0aGlzLm9wdGlvbnMgPyB0aGlzLm9wdGlvbnMuZmFsbGJhY2tMbmcgOiBmYWxzZTtcbiAgICBjb25zdCBsYXN0TG5nID0gdGhpcy5sYW5ndWFnZXNbdGhpcy5sYW5ndWFnZXMubGVuZ3RoIC0gMV07XG4gICAgaWYgKGxuZy50b0xvd2VyQ2FzZSgpID09PSAnY2ltb2RlJykgcmV0dXJuIHRydWU7XG4gICAgY29uc3QgbG9hZE5vdFBlbmRpbmcgPSAobCwgbikgPT4ge1xuICAgICAgY29uc3QgbG9hZFN0YXRlID0gdGhpcy5zZXJ2aWNlcy5iYWNrZW5kQ29ubmVjdG9yLnN0YXRlW2Ake2x9fCR7bn1gXTtcbiAgICAgIHJldHVybiBsb2FkU3RhdGUgPT09IC0xIHx8IGxvYWRTdGF0ZSA9PT0gMCB8fCBsb2FkU3RhdGUgPT09IDI7XG4gICAgfTtcbiAgICBpZiAob3B0aW9ucy5wcmVjaGVjaykge1xuICAgICAgY29uc3QgcHJlUmVzdWx0ID0gb3B0aW9ucy5wcmVjaGVjayh0aGlzLCBsb2FkTm90UGVuZGluZyk7XG4gICAgICBpZiAocHJlUmVzdWx0ICE9PSB1bmRlZmluZWQpIHJldHVybiBwcmVSZXN1bHQ7XG4gICAgfVxuICAgIGlmICh0aGlzLmhhc1Jlc291cmNlQnVuZGxlKGxuZywgbnMpKSByZXR1cm4gdHJ1ZTtcbiAgICBpZiAoIXRoaXMuc2VydmljZXMuYmFja2VuZENvbm5lY3Rvci5iYWNrZW5kIHx8IHRoaXMub3B0aW9ucy5yZXNvdXJjZXMgJiYgIXRoaXMub3B0aW9ucy5wYXJ0aWFsQnVuZGxlZExhbmd1YWdlcykgcmV0dXJuIHRydWU7XG4gICAgY29uc3Qge1xuICAgICAgbGFuZ3VhZ2VVdGlsc1xuICAgIH0gPSB0aGlzLnNlcnZpY2VzO1xuICAgIGNvbnN0IGxvYWRMbmcgPSAhb3B0aW9ucy5sbmcgPyBsbmcgOiBsYW5ndWFnZVV0aWxzLmlzU3VwcG9ydGVkQ29kZShsbmcpICYmIGxhbmd1YWdlVXRpbHMudG9SZXNvbHZlSGllcmFyY2h5KGxuZywgZmFsc2UpWzBdO1xuICAgIGlmICgoIWxvYWRMbmcgfHwgbG9hZE5vdFBlbmRpbmcobG9hZExuZywgbnMpKSAmJiAoIWZhbGxiYWNrTG5nIHx8IGxvYWROb3RQZW5kaW5nKGxhc3RMbmcsIG5zKSkpIHJldHVybiB0cnVlO1xuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuICBsb2FkTmFtZXNwYWNlcyhucywgY2FsbGJhY2spIHtcbiAgICBjb25zdCBkZWZlcnJlZCA9IGRlZmVyKCk7XG4gICAgaWYgKCF0aGlzLm9wdGlvbnMubnMpIHtcbiAgICAgIGlmIChjYWxsYmFjaykgY2FsbGJhY2soKTtcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgaWYgKGlzU3RyaW5nKG5zKSkgbnMgPSBbbnNdO1xuICAgIG5zLmZvckVhY2gobiA9PiB7XG4gICAgICBpZiAoIXRoaXMub3B0aW9ucy5ucy5pbmNsdWRlcyhuKSkgdGhpcy5vcHRpb25zLm5zLnB1c2gobik7XG4gICAgfSk7XG4gICAgdGhpcy5sb2FkUmVzb3VyY2VzKGVyciA9PiB7XG4gICAgICBkZWZlcnJlZC5yZXNvbHZlKCk7XG4gICAgICBpZiAoY2FsbGJhY2spIGNhbGxiYWNrKGVycik7XG4gICAgfSk7XG4gICAgcmV0dXJuIGRlZmVycmVkO1xuICB9XG4gIGxvYWRMYW5ndWFnZXMobG5ncywgY2FsbGJhY2spIHtcbiAgICBjb25zdCBkZWZlcnJlZCA9IGRlZmVyKCk7XG4gICAgaWYgKGlzU3RyaW5nKGxuZ3MpKSBsbmdzID0gW2xuZ3NdO1xuICAgIGNvbnN0IHByZWxvYWRlZCA9IHRoaXMub3B0aW9ucy5wcmVsb2FkIHx8IFtdO1xuICAgIGNvbnN0IG5ld0xuZ3MgPSBsbmdzLmZpbHRlcihsbmcgPT4gIXByZWxvYWRlZC5pbmNsdWRlcyhsbmcpICYmIHRoaXMuc2VydmljZXMubGFuZ3VhZ2VVdGlscy5pc1N1cHBvcnRlZENvZGUobG5nKSk7XG4gICAgaWYgKCFuZXdMbmdzLmxlbmd0aCkge1xuICAgICAgaWYgKGNhbGxiYWNrKSBjYWxsYmFjaygpO1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICB0aGlzLm9wdGlvbnMucHJlbG9hZCA9IHByZWxvYWRlZC5jb25jYXQobmV3TG5ncyk7XG4gICAgdGhpcy5sb2FkUmVzb3VyY2VzKGVyciA9PiB7XG4gICAgICBkZWZlcnJlZC5yZXNvbHZlKCk7XG4gICAgICBpZiAoY2FsbGJhY2spIGNhbGxiYWNrKGVycik7XG4gICAgfSk7XG4gICAgcmV0dXJuIGRlZmVycmVkO1xuICB9XG4gIGRpcihsbmcpIHtcbiAgICBpZiAoIWxuZykgbG5nID0gdGhpcy5yZXNvbHZlZExhbmd1YWdlIHx8ICh0aGlzLmxhbmd1YWdlcz8ubGVuZ3RoID4gMCA/IHRoaXMubGFuZ3VhZ2VzWzBdIDogdGhpcy5sYW5ndWFnZSk7XG4gICAgaWYgKCFsbmcpIHJldHVybiAncnRsJztcbiAgICB0cnkge1xuICAgICAgY29uc3QgbCA9IG5ldyBJbnRsLkxvY2FsZShsbmcpO1xuICAgICAgaWYgKGwgJiYgbC5nZXRUZXh0SW5mbykge1xuICAgICAgICBjb25zdCB0aSA9IGwuZ2V0VGV4dEluZm8oKTtcbiAgICAgICAgaWYgKHRpICYmIHRpLmRpcmVjdGlvbikgcmV0dXJuIHRpLmRpcmVjdGlvbjtcbiAgICAgIH1cbiAgICB9IGNhdGNoIChlKSB7fVxuICAgIGNvbnN0IHJ0bExuZ3MgPSBbJ2FyJywgJ3NodScsICdzcXInLCAnc3NoJywgJ3hhYScsICd5aGQnLCAneXVkJywgJ2FhbycsICdhYmgnLCAnYWJ2JywgJ2FjbScsICdhY3EnLCAnYWN3JywgJ2FjeCcsICdhY3knLCAnYWRmJywgJ2FkcycsICdhZWInLCAnYWVjJywgJ2FmYicsICdhanAnLCAnYXBjJywgJ2FwZCcsICdhcmInLCAnYXJxJywgJ2FycycsICdhcnknLCAnYXJ6JywgJ2F1eicsICdhdmwnLCAnYXloJywgJ2F5bCcsICdheW4nLCAnYXlwJywgJ2JieicsICdwZ2EnLCAnaGUnLCAnaXcnLCAncHMnLCAncGJ0JywgJ3BidScsICdwc3QnLCAncHJwJywgJ3ByZCcsICd1ZycsICd1cicsICd5ZGQnLCAneWRzJywgJ3lpaCcsICdqaScsICd5aScsICdoYm8nLCAnbWVuJywgJ3htbicsICdmYScsICdqcHInLCAncGVvJywgJ3BlcycsICdwcnMnLCAnZHYnLCAnc2FtJywgJ2NrYiddO1xuICAgIGNvbnN0IGxhbmd1YWdlVXRpbHMgPSB0aGlzLnNlcnZpY2VzPy5sYW5ndWFnZVV0aWxzIHx8IG5ldyBMYW5ndWFnZVV0aWwoZ2V0KCkpO1xuICAgIGlmIChsbmcudG9Mb3dlckNhc2UoKS5pbmRleE9mKCctbGF0bicpID4gMSkgcmV0dXJuICdsdHInO1xuICAgIHJldHVybiBydGxMbmdzLmluY2x1ZGVzKGxhbmd1YWdlVXRpbHMuZ2V0TGFuZ3VhZ2VQYXJ0RnJvbUNvZGUobG5nKSkgfHwgbG5nLnRvTG93ZXJDYXNlKCkuaW5kZXhPZignLWFyYWInKSA+IDEgPyAncnRsJyA6ICdsdHInO1xuICB9XG4gIHN0YXRpYyBjcmVhdGVJbnN0YW5jZShvcHRpb25zID0ge30sIGNhbGxiYWNrKSB7XG4gICAgY29uc3QgaW5zdGFuY2UgPSBuZXcgSTE4bihvcHRpb25zLCBjYWxsYmFjayk7XG4gICAgaW5zdGFuY2UuY3JlYXRlSW5zdGFuY2UgPSBJMThuLmNyZWF0ZUluc3RhbmNlO1xuICAgIHJldHVybiBpbnN0YW5jZTtcbiAgfVxuICBjbG9uZUluc3RhbmNlKG9wdGlvbnMgPSB7fSwgY2FsbGJhY2sgPSBub29wKSB7XG4gICAgY29uc3QgZm9ya1Jlc291cmNlU3RvcmUgPSBvcHRpb25zLmZvcmtSZXNvdXJjZVN0b3JlO1xuICAgIGlmIChmb3JrUmVzb3VyY2VTdG9yZSkge1xuICAgICAgb3B0aW9ucyA9IHtcbiAgICAgICAgLi4ub3B0aW9uc1xuICAgICAgfTtcbiAgICAgIGRlbGV0ZSBvcHRpb25zLmZvcmtSZXNvdXJjZVN0b3JlO1xuICAgIH1cbiAgICBjb25zdCBtZXJnZWRPcHRpb25zID0ge1xuICAgICAgLi4udGhpcy5vcHRpb25zLFxuICAgICAgcHJlbG9hZDogZmFsc2UsXG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgLi4ue1xuICAgICAgICBpc0Nsb25lOiB0cnVlXG4gICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBjbG9uZSA9IG5ldyBJMThuKG1lcmdlZE9wdGlvbnMpO1xuICAgIGlmIChvcHRpb25zLmRlYnVnICE9PSB1bmRlZmluZWQgfHwgb3B0aW9ucy5wcmVmaXggIT09IHVuZGVmaW5lZCkge1xuICAgICAgY2xvbmUubG9nZ2VyID0gY2xvbmUubG9nZ2VyLmNsb25lKG9wdGlvbnMpO1xuICAgIH1cbiAgICBjb25zdCBtZW1iZXJzVG9Db3B5ID0gWydzdG9yZScsICdzZXJ2aWNlcycsICdsYW5ndWFnZSddO1xuICAgIG1lbWJlcnNUb0NvcHkuZm9yRWFjaChtID0+IHtcbiAgICAgIGNsb25lW21dID0gdGhpc1ttXTtcbiAgICB9KTtcbiAgICBjbG9uZS5zZXJ2aWNlcyA9IHtcbiAgICAgIC4uLnRoaXMuc2VydmljZXNcbiAgICB9O1xuICAgIGNsb25lLnNlcnZpY2VzLnV0aWxzID0ge1xuICAgICAgaGFzTG9hZGVkTmFtZXNwYWNlOiBjbG9uZS5oYXNMb2FkZWROYW1lc3BhY2UuYmluZChjbG9uZSlcbiAgICB9O1xuICAgIGlmIChmb3JrUmVzb3VyY2VTdG9yZSkge1xuICAgICAgY29uc3QgY29weURhdGEgPSBvYmogPT4ge1xuICAgICAgICBjb25zdCBjb3BpZWQgPSBBcnJheS5pc0FycmF5KG9iaikgPyBbLi4ub2JqXSA6IHtcbiAgICAgICAgICAuLi5vYmpcbiAgICAgICAgfTtcbiAgICAgICAgT2JqZWN0LmtleXMoY29waWVkKS5mb3JFYWNoKGsgPT4ge1xuICAgICAgICAgIGlmIChjb3BpZWRba10gJiYgdHlwZW9mIGNvcGllZFtrXSA9PT0gJ29iamVjdCcpIGNvcGllZFtrXSA9IGNvcHlEYXRhKGNvcGllZFtrXSk7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gY29waWVkO1xuICAgICAgfTtcbiAgICAgIGNvbnN0IGNsb25lZERhdGEgPSBjb3B5RGF0YSh0aGlzLnN0b3JlLmRhdGEpO1xuICAgICAgY2xvbmUuc3RvcmUgPSBuZXcgUmVzb3VyY2VTdG9yZShjbG9uZWREYXRhLCBtZXJnZWRPcHRpb25zKTtcbiAgICAgIGNsb25lLnNlcnZpY2VzLnJlc291cmNlU3RvcmUgPSBjbG9uZS5zdG9yZTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMuaW50ZXJwb2xhdGlvbikge1xuICAgICAgY29uc3QgZGVmT3B0cyA9IGdldCgpO1xuICAgICAgY29uc3QgbWVyZ2VkSW50ZXJwb2xhdGlvbiA9IHtcbiAgICAgICAgLi4uZGVmT3B0cy5pbnRlcnBvbGF0aW9uLFxuICAgICAgICAuLi50aGlzLm9wdGlvbnMuaW50ZXJwb2xhdGlvbixcbiAgICAgICAgLi4ub3B0aW9ucy5pbnRlcnBvbGF0aW9uXG4gICAgICB9O1xuICAgICAgY29uc3QgbWVyZ2VkRm9ySW50ZXJwb2xhdG9yID0ge1xuICAgICAgICAuLi5tZXJnZWRPcHRpb25zLFxuICAgICAgICBpbnRlcnBvbGF0aW9uOiBtZXJnZWRJbnRlcnBvbGF0aW9uXG4gICAgICB9O1xuICAgICAgY2xvbmUuc2VydmljZXMuaW50ZXJwb2xhdG9yID0gbmV3IEludGVycG9sYXRvcihtZXJnZWRGb3JJbnRlcnBvbGF0b3IpO1xuICAgIH1cbiAgICBjbG9uZS50cmFuc2xhdG9yID0gbmV3IFRyYW5zbGF0b3IoY2xvbmUuc2VydmljZXMsIG1lcmdlZE9wdGlvbnMpO1xuICAgIGNsb25lLnRyYW5zbGF0b3Iub24oJyonLCAoZXZlbnQsIC4uLmFyZ3MpID0+IHtcbiAgICAgIGNsb25lLmVtaXQoZXZlbnQsIC4uLmFyZ3MpO1xuICAgIH0pO1xuICAgIGNsb25lLmluaXQobWVyZ2VkT3B0aW9ucywgY2FsbGJhY2spO1xuICAgIGNsb25lLnRyYW5zbGF0b3Iub3B0aW9ucyA9IG1lcmdlZE9wdGlvbnM7XG4gICAgY2xvbmUudHJhbnNsYXRvci5iYWNrZW5kQ29ubmVjdG9yLnNlcnZpY2VzLnV0aWxzID0ge1xuICAgICAgaGFzTG9hZGVkTmFtZXNwYWNlOiBjbG9uZS5oYXNMb2FkZWROYW1lc3BhY2UuYmluZChjbG9uZSlcbiAgICB9O1xuICAgIHJldHVybiBjbG9uZTtcbiAgfVxuICB0b0pTT04oKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIG9wdGlvbnM6IHRoaXMub3B0aW9ucyxcbiAgICAgIHN0b3JlOiB0aGlzLnN0b3JlLFxuICAgICAgbGFuZ3VhZ2U6IHRoaXMubGFuZ3VhZ2UsXG4gICAgICBsYW5ndWFnZXM6IHRoaXMubGFuZ3VhZ2VzLFxuICAgICAgcmVzb2x2ZWRMYW5ndWFnZTogdGhpcy5yZXNvbHZlZExhbmd1YWdlXG4gICAgfTtcbiAgfVxufVxuY29uc3QgaW5zdGFuY2UgPSBJMThuLmNyZWF0ZUluc3RhbmNlKCk7XG5cbmNvbnN0IGNyZWF0ZUluc3RhbmNlID0gaW5zdGFuY2UuY3JlYXRlSW5zdGFuY2U7XG5jb25zdCBkaXIgPSBpbnN0YW5jZS5kaXI7XG5jb25zdCBpbml0ID0gaW5zdGFuY2UuaW5pdDtcbmNvbnN0IGxvYWRSZXNvdXJjZXMgPSBpbnN0YW5jZS5sb2FkUmVzb3VyY2VzO1xuY29uc3QgcmVsb2FkUmVzb3VyY2VzID0gaW5zdGFuY2UucmVsb2FkUmVzb3VyY2VzO1xuY29uc3QgdXNlID0gaW5zdGFuY2UudXNlO1xuY29uc3QgY2hhbmdlTGFuZ3VhZ2UgPSBpbnN0YW5jZS5jaGFuZ2VMYW5ndWFnZTtcbmNvbnN0IGdldEZpeGVkVCA9IGluc3RhbmNlLmdldEZpeGVkVDtcbmNvbnN0IHQgPSBpbnN0YW5jZS50O1xuY29uc3QgZXhpc3RzID0gaW5zdGFuY2UuZXhpc3RzO1xuY29uc3Qgc2V0RGVmYXVsdE5hbWVzcGFjZSA9IGluc3RhbmNlLnNldERlZmF1bHROYW1lc3BhY2U7XG5jb25zdCBoYXNMb2FkZWROYW1lc3BhY2UgPSBpbnN0YW5jZS5oYXNMb2FkZWROYW1lc3BhY2U7XG5jb25zdCBsb2FkTmFtZXNwYWNlcyA9IGluc3RhbmNlLmxvYWROYW1lc3BhY2VzO1xuY29uc3QgbG9hZExhbmd1YWdlcyA9IGluc3RhbmNlLmxvYWRMYW5ndWFnZXM7XG5cbmV4cG9ydCB7IGNoYW5nZUxhbmd1YWdlLCBjcmVhdGVJbnN0YW5jZSwgaW5zdGFuY2UgYXMgZGVmYXVsdCwgZGlyLCBleGlzdHMsIGdldEZpeGVkVCwgaGFzTG9hZGVkTmFtZXNwYWNlLCBpbml0LCBrZXlzRnJvbVNlbGVjdG9yIGFzIGtleUZyb21TZWxlY3RvciwgbG9hZExhbmd1YWdlcywgbG9hZE5hbWVzcGFjZXMsIGxvYWRSZXNvdXJjZXMsIHJlbG9hZFJlc291cmNlcywgc2V0RGVmYXVsdE5hbWVzcGFjZSwgdCwgdXNlIH07XG4iXSwiaWdub3JlTGlzdCI6WzBdLCJtYXBwaW5ncyI6IjtBQUFBLElBQU0sWUFBVyxRQUFPLE9BQU8sUUFBUTtBQUN2QyxJQUFNLGNBQWM7Q0FDbEIsSUFBSTtDQUNKLElBQUk7Q0FDSixNQUFNLFVBQVUsSUFBSSxTQUFTLFNBQVMsV0FBVztFQUMvQyxNQUFNO0VBQ04sTUFBTTtDQUNSLENBQUM7Q0FDRCxRQUFRLFVBQVU7Q0FDbEIsUUFBUSxTQUFTO0NBQ2pCLE9BQU87QUFDVDtBQUNBLElBQU0sY0FBYSxXQUFVO0NBQzNCLElBQUksVUFBVSxNQUFNLE9BQU87Q0FDM0IsT0FBTyxPQUFPLE1BQU07QUFDdEI7QUFDQSxJQUFNLFFBQVEsR0FBRyxHQUFHLE1BQU07Q0FDeEIsRUFBRSxTQUFRLE1BQUs7RUFDYixJQUFJLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRTtDQUNyQixDQUFDO0FBQ0g7QUFDQSxJQUFNLDRCQUE0QjtBQUNsQyxJQUFNLFlBQVcsUUFBTyxPQUFPLElBQUksU0FBUyxLQUFLLElBQUksSUFBSSxRQUFRLDJCQUEyQixHQUFHLElBQUk7QUFDbkcsSUFBTSx3QkFBdUIsV0FBVSxDQUFDLFVBQVUsU0FBUyxNQUFNO0FBQ2pFLElBQU0saUJBQWlCLFFBQVEsTUFBTSxVQUFVO0NBQzdDLE1BQU0sUUFBUSxDQUFDLFNBQVMsSUFBSSxJQUFJLE9BQU8sS0FBSyxNQUFNLEdBQUc7Q0FDckQsSUFBSSxhQUFhO0NBQ2pCLE9BQU8sYUFBYSxNQUFNLFNBQVMsR0FBRztFQUNwQyxJQUFJLHFCQUFxQixNQUFNLEdBQUcsT0FBTyxDQUFDO0VBQzFDLE1BQU0sTUFBTSxTQUFTLE1BQU0sV0FBVztFQUN0QyxJQUFJLENBQUMsT0FBTyxRQUFRLE9BQU8sT0FBTyxPQUFPLElBQUksTUFBTTtFQUNuRCxJQUFJLE9BQU8sVUFBVSxlQUFlLEtBQUssUUFBUSxHQUFHLEdBQ2xELFNBQVMsT0FBTztPQUVoQixTQUFTLENBQUM7RUFFWixFQUFFO0NBQ0o7Q0FDQSxJQUFJLHFCQUFxQixNQUFNLEdBQUcsT0FBTyxDQUFDO0NBQzFDLE9BQU87RUFDTCxLQUFLO0VBQ0wsR0FBRyxTQUFTLE1BQU0sV0FBVztDQUMvQjtBQUNGO0FBQ0EsSUFBTSxXQUFXLFFBQVEsTUFBTSxhQUFhO0NBQzFDLE1BQU0sRUFDSixLQUNBLE1BQ0UsY0FBYyxRQUFRLE1BQU0sTUFBTTtDQUN0QyxJQUFJLFFBQVEsS0FBQSxLQUFhLEtBQUssV0FBVyxHQUFHO0VBQzFDLElBQUksS0FBSztFQUNUO0NBQ0Y7Q0FDQSxJQUFJLElBQUksS0FBSyxLQUFLLFNBQVM7Q0FDM0IsSUFBSSxJQUFJLEtBQUssTUFBTSxHQUFHLEtBQUssU0FBUyxDQUFDO0NBQ3JDLElBQUksT0FBTyxjQUFjLFFBQVEsR0FBRyxNQUFNO0NBQzFDLE9BQU8sS0FBSyxRQUFRLEtBQUEsS0FBYSxFQUFFLFFBQVE7RUFDekMsSUFBSSxHQUFHLEVBQUUsRUFBRSxTQUFTLEdBQUcsR0FBRztFQUMxQixJQUFJLEVBQUUsTUFBTSxHQUFHLEVBQUUsU0FBUyxDQUFDO0VBQzNCLE9BQU8sY0FBYyxRQUFRLEdBQUcsTUFBTTtFQUN0QyxJQUFJLE1BQU0sT0FBTyxPQUFPLEtBQUssSUFBSSxHQUFHLEtBQUssRUFBRSxHQUFHLFNBQVMsYUFDckQsS0FBSyxNQUFNLEtBQUE7Q0FFZjtDQUNBLEtBQUssSUFBSSxHQUFHLEtBQUssRUFBRSxHQUFHLE9BQU87QUFDL0I7QUFDQSxJQUFNLFlBQVksUUFBUSxNQUFNLFVBQVUsV0FBVztDQUNuRCxNQUFNLEVBQ0osS0FDQSxNQUNFLGNBQWMsUUFBUSxNQUFNLE1BQU07Q0FDdEMsSUFBSSxLQUFLLElBQUksTUFBTSxDQUFDO0NBQ3BCLElBQUksRUFBRSxDQUFDLEtBQUssUUFBUTtBQUN0QjtBQUNBLElBQU0sV0FBVyxRQUFRLFNBQVM7Q0FDaEMsTUFBTSxFQUNKLEtBQ0EsTUFDRSxjQUFjLFFBQVEsSUFBSTtDQUM5QixJQUFJLENBQUMsS0FBSyxPQUFPLEtBQUE7Q0FDakIsSUFBSSxDQUFDLE9BQU8sVUFBVSxlQUFlLEtBQUssS0FBSyxDQUFDLEdBQUcsT0FBTyxLQUFBO0NBQzFELE9BQU8sSUFBSTtBQUNiO0FBQ0EsSUFBTSx1QkFBdUIsTUFBTSxhQUFhLFFBQVE7Q0FDdEQsTUFBTSxRQUFRLFFBQVEsTUFBTSxHQUFHO0NBQy9CLElBQUksVUFBVSxLQUFBLEdBQ1osT0FBTztDQUVULE9BQU8sUUFBUSxhQUFhLEdBQUc7QUFDakM7QUFDQSxJQUFNLGNBQWMsUUFBUSxRQUFRLGNBQWM7Q0FDaEQsS0FBSyxNQUFNLFFBQVEsUUFDakIsSUFBSSxTQUFTLGVBQWUsU0FBUyxlQUFlO0VBQ2xELElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxRQUFRLElBQUksR0FBRztHQUN0RCxJQUFJLFNBQVMsT0FBTyxLQUFLLEtBQUssT0FBTyxpQkFBaUIsVUFBVSxTQUFTLE9BQU8sS0FBSyxLQUFLLE9BQU8saUJBQWlCLFFBQzVHO1FBQUEsV0FBVyxPQUFPLFFBQVEsT0FBTztHQUFBLE9BRXJDLFdBQVcsT0FBTyxPQUFPLE9BQU8sT0FBTyxTQUFTO0VBRXBELE9BQ0UsT0FBTyxRQUFRLE9BQU87Q0FFMUI7Q0FFRixPQUFPO0FBQ1Q7QUFDQSxJQUFNLGVBQWMsUUFBTyxJQUFJLFFBQVEsdUNBQXVDLE1BQU07QUFDcEYsSUFBTSxhQUFhO0NBQ2pCLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztDQUNMLE1BQUs7Q0FDTCxLQUFLO0NBQ0wsS0FBSztBQUNQO0FBQ0EsSUFBTSxVQUFTLFNBQVE7Q0FDckIsSUFBSSxTQUFTLElBQUksR0FDZixPQUFPLEtBQUssUUFBUSxlQUFjLE1BQUssV0FBVyxFQUFFO0NBRXRELE9BQU87QUFDVDtBQUNBLElBQU0sY0FBTixNQUFrQjtDQUNoQixZQUFZLFVBQVU7RUFDcEIsS0FBSyxXQUFXO0VBQ2hCLEtBQUssNEJBQVksSUFBSSxJQUFJO0VBQ3pCLEtBQUssY0FBYyxDQUFDO0NBQ3RCO0NBQ0EsVUFBVSxTQUFTO0VBQ2pCLE1BQU0sa0JBQWtCLEtBQUssVUFBVSxJQUFJLE9BQU87RUFDbEQsSUFBSSxvQkFBb0IsS0FBQSxHQUN0QixPQUFPO0VBRVQsTUFBTSxZQUFZLElBQUksT0FBTyxPQUFPO0VBQ3BDLElBQUksS0FBSyxZQUFZLFdBQVcsS0FBSyxVQUNuQyxLQUFLLFVBQVUsT0FBTyxLQUFLLFlBQVksTUFBTSxDQUFDO0VBRWhELEtBQUssVUFBVSxJQUFJLFNBQVMsU0FBUztFQUNyQyxLQUFLLFlBQVksS0FBSyxPQUFPO0VBQzdCLE9BQU87Q0FDVDtBQUNGO0FBQ0EsSUFBTSxRQUFRO0NBQUM7Q0FBSztDQUFLO0NBQUs7Q0FBSztBQUFHO0FBQ3RDLElBQU0saUNBQWlDLElBQUksWUFBWSxFQUFFO0FBQ3pELElBQU0sdUJBQXVCLEtBQUssYUFBYSxpQkFBaUI7Q0FDOUQsY0FBYyxlQUFlO0NBQzdCLGVBQWUsZ0JBQWdCO0NBQy9CLE1BQU0sZ0JBQWdCLE1BQU0sUUFBTyxNQUFLLENBQUMsWUFBWSxTQUFTLENBQUMsS0FBSyxDQUFDLGFBQWEsU0FBUyxDQUFDLENBQUM7Q0FDN0YsSUFBSSxjQUFjLFdBQVcsR0FBRyxPQUFPO0NBQ3ZDLE1BQU0sSUFBSSwrQkFBK0IsVUFBVSxJQUFJLGNBQWMsS0FBSSxNQUFLLE1BQU0sTUFBTSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFLEVBQUU7Q0FDakgsSUFBSSxVQUFVLENBQUMsRUFBRSxLQUFLLEdBQUc7Q0FDekIsSUFBSSxDQUFDLFNBQVM7RUFDWixNQUFNLEtBQUssSUFBSSxRQUFRLFlBQVk7RUFDbkMsSUFBSSxLQUFLLEtBQUssQ0FBQyxFQUFFLEtBQUssSUFBSSxVQUFVLEdBQUcsRUFBRSxDQUFDLEdBQ3hDLFVBQVU7Q0FFZDtDQUNBLE9BQU87QUFDVDtBQUNBLElBQU0sWUFBWSxLQUFLLE1BQU0sZUFBZSxRQUFRO0NBQ2xELElBQUksQ0FBQyxLQUFLLE9BQU8sS0FBQTtDQUNqQixJQUFJLElBQUksT0FBTztFQUNiLElBQUksQ0FBQyxPQUFPLFVBQVUsZUFBZSxLQUFLLEtBQUssSUFBSSxHQUFHLE9BQU8sS0FBQTtFQUM3RCxPQUFPLElBQUk7Q0FDYjtDQUNBLE1BQU0sU0FBUyxLQUFLLE1BQU0sWUFBWTtDQUN0QyxJQUFJLFVBQVU7Q0FDZCxLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxTQUFTO0VBQ2xDLElBQUksQ0FBQyxXQUFXLE9BQU8sWUFBWSxVQUNqQztFQUVGLElBQUk7RUFDSixJQUFJLFdBQVc7RUFDZixLQUFLLElBQUksSUFBSSxHQUFHLElBQUksT0FBTyxRQUFRLEVBQUUsR0FBRztHQUN0QyxJQUFJLE1BQU0sR0FDUixZQUFZO0dBRWQsWUFBWSxPQUFPO0dBQ25CLE9BQU8sUUFBUTtHQUNmLEtBQUssT0FBTyxTQUFTLGNBQWMsYUFBYSxnQkFBZ0IsQ0FBQyxPQUFPLFVBQVUsZUFBZSxLQUFLLFNBQVMsUUFBUSxHQUNySCxPQUFPLEtBQUE7R0FFVCxJQUFJLFNBQVMsS0FBQSxHQUFXO0lBQ3RCLElBQUk7S0FBQztLQUFVO0tBQVU7SUFBUyxDQUFDLENBQUMsU0FBUyxPQUFPLElBQUksS0FBSyxJQUFJLE9BQU8sU0FBUyxHQUMvRTtJQUVGLEtBQUssSUFBSSxJQUFJO0lBQ2I7R0FDRjtFQUNGO0VBQ0EsVUFBVTtDQUNaO0NBQ0EsT0FBTztBQUNUO0FBQ0EsSUFBTSxrQkFBaUIsU0FBUSxNQUFNLFFBQVEsTUFBTSxHQUFHO0FBRXRELElBQU0sZ0JBQWdCO0NBQ3BCLE1BQU07Q0FDTixJQUFJLE1BQU07RUFDUixLQUFLLE9BQU8sT0FBTyxJQUFJO0NBQ3pCO0NBQ0EsS0FBSyxNQUFNO0VBQ1QsS0FBSyxPQUFPLFFBQVEsSUFBSTtDQUMxQjtDQUNBLE1BQU0sTUFBTTtFQUNWLEtBQUssT0FBTyxTQUFTLElBQUk7Q0FDM0I7Q0FDQSxPQUFPLE1BQU0sTUFBTTtFQUNqQixVQUFVLEtBQUssRUFBRSxRQUFRLFNBQVMsSUFBSTtDQUN4QztBQUNGO0FBMkNBLElBQUksYUFBYSxJQUFJLE1BMUNmLE9BQU87Q0FDWCxZQUFZLGdCQUFnQixVQUFVLENBQUMsR0FBRztFQUN4QyxLQUFLLEtBQUssZ0JBQWdCLE9BQU87Q0FDbkM7Q0FDQSxLQUFLLGdCQUFnQixVQUFVLENBQUMsR0FBRztFQUNqQyxLQUFLLFNBQVMsUUFBUSxVQUFVO0VBQ2hDLEtBQUssU0FBUyxrQkFBa0I7RUFDaEMsS0FBSyxVQUFVO0VBQ2YsS0FBSyxRQUFRLFFBQVE7Q0FDdkI7Q0FDQSxJQUFJLEdBQUcsTUFBTTtFQUNYLE9BQU8sS0FBSyxRQUFRLE1BQU0sT0FBTyxJQUFJLElBQUk7Q0FDM0M7Q0FDQSxLQUFLLEdBQUcsTUFBTTtFQUNaLE9BQU8sS0FBSyxRQUFRLE1BQU0sUUFBUSxJQUFJLElBQUk7Q0FDNUM7Q0FDQSxNQUFNLEdBQUcsTUFBTTtFQUNiLE9BQU8sS0FBSyxRQUFRLE1BQU0sU0FBUyxFQUFFO0NBQ3ZDO0NBQ0EsVUFBVSxHQUFHLE1BQU07RUFDakIsT0FBTyxLQUFLLFFBQVEsTUFBTSxRQUFRLHdCQUF3QixJQUFJO0NBQ2hFO0NBQ0EsUUFBUSxNQUFNLEtBQUssUUFBUSxXQUFXO0VBQ3BDLElBQUksYUFBYSxDQUFDLEtBQUssT0FBTyxPQUFPO0VBQ3JDLE9BQU8sS0FBSyxLQUFJLE1BQUssU0FBUyxDQUFDLElBQUksRUFBRSxRQUFRLHdCQUF3QixHQUFHLElBQUksQ0FBQztFQUM3RSxJQUFJLFNBQVMsS0FBSyxFQUFFLEdBQUcsS0FBSyxLQUFLLEdBQUcsU0FBUyxLQUFLLE9BQU8sR0FBRyxLQUFLO0VBQ2pFLE9BQU8sS0FBSyxPQUFPLElBQUksQ0FBQyxJQUFJO0NBQzlCO0NBQ0EsT0FBTyxZQUFZO0VBQ2pCLE9BQU8sSUFBSSxPQUFPLEtBQUssUUFBUTtHQUUzQixRQUFRLEdBQUcsS0FBSyxPQUFPLEdBQUcsV0FBVztHQUV2QyxHQUFHLEtBQUs7RUFDVixDQUFDO0NBQ0g7Q0FDQSxNQUFNLFNBQVM7RUFDYixVQUFVLFdBQVcsS0FBSztFQUMxQixRQUFRLFNBQVMsUUFBUSxVQUFVLEtBQUs7RUFDeEMsT0FBTyxJQUFJLE9BQU8sS0FBSyxRQUFRLE9BQU87Q0FDeEM7QUFDRixFQUM0QjtBQUU1QixJQUFNLGVBQU4sTUFBbUI7Q0FDakIsY0FBYztFQUNaLEtBQUssWUFBWSxDQUFDO0NBQ3BCO0NBQ0EsR0FBRyxRQUFRLFVBQVU7RUFDbkIsT0FBTyxNQUFNLEdBQUcsQ0FBQyxDQUFDLFNBQVEsVUFBUztHQUNqQyxJQUFJLENBQUMsS0FBSyxVQUFVLFFBQVEsS0FBSyxVQUFVLHlCQUFTLElBQUksSUFBSTtHQUM1RCxNQUFNLGVBQWUsS0FBSyxVQUFVLE1BQU0sQ0FBQyxJQUFJLFFBQVEsS0FBSztHQUM1RCxLQUFLLFVBQVUsTUFBTSxDQUFDLElBQUksVUFBVSxlQUFlLENBQUM7RUFDdEQsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLElBQUksT0FBTyxVQUFVO0VBQ25CLElBQUksQ0FBQyxLQUFLLFVBQVUsUUFBUTtFQUM1QixJQUFJLENBQUMsVUFBVTtHQUNiLE9BQU8sS0FBSyxVQUFVO0dBQ3RCO0VBQ0Y7RUFDQSxLQUFLLFVBQVUsTUFBTSxDQUFDLE9BQU8sUUFBUTtDQUN2QztDQUNBLEtBQUssT0FBTyxVQUFVO0VBQ3BCLE1BQU0sV0FBVyxHQUFHLFNBQVM7R0FDM0IsU0FBUyxHQUFHLElBQUk7R0FDaEIsS0FBSyxJQUFJLE9BQU8sT0FBTztFQUN6QjtFQUNBLEtBQUssR0FBRyxPQUFPLE9BQU87RUFDdEIsT0FBTztDQUNUO0NBQ0EsS0FBSyxPQUFPLEdBQUcsTUFBTTtFQUNuQixJQUFJLEtBQUssVUFBVSxRQUVqQixNQURxQixLQUFLLEtBQUssVUFBVSxNQUFNLENBQUMsUUFBUSxDQUNuRCxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsbUJBQW1CO0dBQzVDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLEtBQ2pDLFNBQVMsR0FBRyxJQUFJO0VBRXBCLENBQUM7RUFFSCxJQUFJLEtBQUssVUFBVSxNQUVqQixNQURxQixLQUFLLEtBQUssVUFBVSxJQUFJLENBQUMsUUFBUSxDQUNqRCxDQUFDLENBQUMsU0FBUyxDQUFDLFVBQVUsbUJBQW1CO0dBQzVDLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxlQUFlLEtBQ2pDLFNBQVMsT0FBTyxHQUFHLElBQUk7RUFFM0IsQ0FBQztDQUVMO0FBQ0Y7QUFFQSxJQUFNLGtDQUFrQixJQUFJLFFBQVE7QUFDcEMsSUFBTSxnQkFBTixjQUE0QixhQUFhO0NBQ3ZDLFlBQVksTUFBTSxVQUFVO0VBQzFCLElBQUksQ0FBQyxhQUFhO0VBQ2xCLFdBQVc7Q0FDYixHQUFHO0VBQ0QsTUFBTTtFQUNOLEtBQUssT0FBTyxRQUFRLENBQUM7RUFDckIsS0FBSyxVQUFVO0VBQ2YsSUFBSSxLQUFLLFFBQVEsaUJBQWlCLEtBQUEsR0FDaEMsS0FBSyxRQUFRLGVBQWU7RUFFOUIsSUFBSSxLQUFLLFFBQVEsd0JBQXdCLEtBQUEsR0FDdkMsS0FBSyxRQUFRLHNCQUFzQjtDQUV2QztDQUNBLGNBQWMsSUFBSTtFQUNoQixJQUFJLENBQUMsS0FBSyxRQUFRLEdBQUcsU0FBUyxFQUFFLEdBQzlCLEtBQUssUUFBUSxHQUFHLEtBQUssRUFBRTtDQUUzQjtDQUNBLGlCQUFpQixJQUFJO0VBQ25CLE1BQU0sUUFBUSxLQUFLLFFBQVEsR0FBRyxRQUFRLEVBQUU7RUFDeEMsSUFBSSxRQUFRLElBQ1YsS0FBSyxRQUFRLEdBQUcsT0FBTyxPQUFPLENBQUM7Q0FFbkM7Q0FDQSxZQUFZLEtBQUssSUFBSSxLQUFLLFVBQVUsQ0FBQyxHQUFHO0VBQ3RDLE1BQU0sZUFBZSxRQUFRLGlCQUFpQixLQUFBLElBQVksUUFBUSxlQUFlLEtBQUssUUFBUTtFQUM5RixNQUFNLHNCQUFzQixRQUFRLHdCQUF3QixLQUFBLElBQVksUUFBUSxzQkFBc0IsS0FBSyxRQUFRO0VBQ25ILElBQUk7RUFDSixJQUFJLElBQUksU0FBUyxHQUFHLEdBQ2xCLE9BQU8sSUFBSSxNQUFNLEdBQUc7T0FDZjtHQUNMLE9BQU8sQ0FBQyxLQUFLLEVBQUU7R0FDZixJQUFJLEtBQUs7SUFDUCxJQUFJLE1BQU0sUUFBUSxHQUFHLEdBQ25CLEtBQUssS0FBSyxHQUFHLEdBQUc7U0FDWCxJQUFJLFNBQVMsR0FBRyxLQUFLLGNBQzFCLEtBQUssS0FBSyxHQUFHLElBQUksTUFBTSxZQUFZLENBQUM7U0FFcEMsS0FBSyxLQUFLLEdBQUc7R0FFakI7RUFDRjtFQUNBLE1BQU0sU0FBUyxRQUFRLEtBQUssTUFBTSxJQUFJO0VBQ3RDLElBQUksVUFBVSxRQUFRLENBQUMsTUFBTSxDQUFDLE9BQU8sSUFBSSxTQUFTLEdBQUcsR0FBRztHQUN0RCxNQUFNLEtBQUs7R0FDWCxLQUFLLEtBQUs7R0FDVixNQUFNLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7RUFDOUI7RUFDQSxJQUFJLFVBQVUsUUFBUSxDQUFDLHVCQUF1QixDQUFDLFNBQVMsR0FBRyxHQUFHLE9BQU87RUFDckUsT0FBTyxTQUFTLEtBQUssT0FBTyxJQUFJLEdBQUcsS0FBSyxLQUFLLFlBQVk7Q0FDM0Q7Q0FDQSxZQUFZLEtBQUssSUFBSSxLQUFLLE9BQU8sVUFBVSxFQUN6QyxRQUFRLE1BQ1YsR0FBRztFQUNELE1BQU0sZUFBZSxRQUFRLGlCQUFpQixLQUFBLElBQVksUUFBUSxlQUFlLEtBQUssUUFBUTtFQUM5RixJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUU7RUFDbkIsSUFBSSxLQUFLLE9BQU8sS0FBSyxPQUFPLGVBQWUsSUFBSSxNQUFNLFlBQVksSUFBSSxHQUFHO0VBQ3hFLElBQUksSUFBSSxTQUFTLEdBQUcsR0FBRztHQUNyQixPQUFPLElBQUksTUFBTSxHQUFHO0dBQ3BCLFFBQVE7R0FDUixLQUFLLEtBQUs7RUFDWjtFQUNBLEtBQUssY0FBYyxFQUFFO0VBQ3JCLFFBQVEsS0FBSyxNQUFNLE1BQU0sS0FBSztFQUM5QixJQUFJLENBQUMsUUFBUSxRQUFRLEtBQUssS0FBSyxTQUFTLEtBQUssSUFBSSxLQUFLLEtBQUs7Q0FDN0Q7Q0FDQSxhQUFhLEtBQUssSUFBSSxXQUFXLFVBQVUsRUFDekMsUUFBUSxNQUNWLEdBQUc7RUFDRCxLQUFLLE1BQU0sS0FBSyxXQUNkLElBQUksU0FBUyxVQUFVLEVBQUUsS0FBSyxNQUFNLFFBQVEsVUFBVSxFQUFFLEdBQUcsS0FBSyxZQUFZLEtBQUssSUFBSSxHQUFHLFVBQVUsSUFBSSxFQUNwRyxRQUFRLEtBQ1YsQ0FBQztFQUVILElBQUksQ0FBQyxRQUFRLFFBQVEsS0FBSyxLQUFLLFNBQVMsS0FBSyxJQUFJLFNBQVM7Q0FDNUQ7Q0FDQSxrQkFBa0IsS0FBSyxJQUFJLFdBQVcsTUFBTSxXQUFXLFVBQVU7RUFDL0QsUUFBUTtFQUNSLFVBQVU7Q0FDWixHQUFHO0VBQ0QsSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFO0VBQ25CLElBQUksSUFBSSxTQUFTLEdBQUcsR0FBRztHQUNyQixPQUFPLElBQUksTUFBTSxHQUFHO0dBQ3BCLE9BQU87R0FDUCxZQUFZO0dBQ1osS0FBSyxLQUFLO0VBQ1o7RUFDQSxLQUFLLGNBQWMsRUFBRTtFQUNyQixJQUFJLE9BQU8sUUFBUSxLQUFLLE1BQU0sSUFBSSxLQUFLLENBQUM7RUFDeEMsSUFBSSxDQUFDLFFBQVEsVUFBVSxZQUFZLEtBQUssTUFBTSxLQUFLLFVBQVUsU0FBUyxDQUFDO0VBQ3ZFLElBQUksTUFDRixXQUFXLE1BQU0sV0FBVyxTQUFTO09BRXJDLE9BQU87R0FDTCxHQUFHO0dBQ0gsR0FBRztFQUNMO0VBRUYsUUFBUSxLQUFLLE1BQU0sTUFBTSxJQUFJO0VBQzdCLElBQUksQ0FBQyxRQUFRLFFBQVEsS0FBSyxLQUFLLFNBQVMsS0FBSyxJQUFJLFNBQVM7Q0FDNUQ7Q0FDQSxxQkFBcUIsS0FBSyxJQUFJO0VBQzVCLElBQUksS0FBSyxrQkFBa0IsS0FBSyxFQUFFLEdBQ2hDLE9BQU8sS0FBSyxLQUFLLElBQUksQ0FBQztFQUV4QixLQUFLLGlCQUFpQixFQUFFO0VBQ3hCLEtBQUssS0FBSyxXQUFXLEtBQUssRUFBRTtDQUM5QjtDQUNBLGtCQUFrQixLQUFLLElBQUk7RUFDekIsT0FBTyxLQUFLLFlBQVksS0FBSyxFQUFFLE1BQU0sS0FBQTtDQUN2QztDQUNBLGtCQUFrQixLQUFLLElBQUk7RUFDekIsSUFBSSxDQUFDLElBQUksS0FBSyxLQUFLLFFBQVE7RUFDM0IsT0FBTyxLQUFLLFlBQVksS0FBSyxFQUFFO0NBQ2pDO0NBQ0Esa0JBQWtCLEtBQUs7RUFDckIsT0FBTyxLQUFLLEtBQUs7Q0FDbkI7Q0FDQSw0QkFBNEIsS0FBSztFQUMvQixNQUFNLE9BQU8sS0FBSyxrQkFBa0IsR0FBRztFQUV2QyxPQUFPLENBQUMsRUFERSxRQUFRLE9BQU8sS0FBSyxJQUFJLEtBQUssQ0FBQyxFQUFBLENBQzdCLE1BQUssTUFBSztHQUNuQixNQUFNLFNBQVMsS0FBSztHQUNwQixJQUFJLGdCQUFnQixJQUFJLE1BQU0sR0FBRyxPQUFPO0dBQ3hDLElBQUksQ0FBQyxVQUFVLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxXQUFXLEdBQUcsT0FBTztHQUN4RCxJQUFJLE9BQU8sV0FBVyxVQUFVLGdCQUFnQixJQUFJLE1BQU07R0FDMUQsT0FBTztFQUNULENBQUM7Q0FDSDtDQUNBLFNBQVM7RUFDUCxPQUFPLEtBQUs7Q0FDZDtBQUNGO0FBRUEsSUFBSSxnQkFBZ0I7Q0FDbEIsWUFBWSxDQUFDO0NBQ2IsaUJBQWlCLFFBQVE7RUFDdkIsS0FBSyxXQUFXLE9BQU8sUUFBUTtDQUNqQztDQUNBLE9BQU8sWUFBWSxPQUFPLEtBQUssU0FBUyxZQUFZO0VBQ2xELFdBQVcsU0FBUSxjQUFhO0dBQzlCLFFBQVEsS0FBSyxXQUFXLFVBQVUsRUFBRSxRQUFRLE9BQU8sS0FBSyxTQUFTLFVBQVUsS0FBSztFQUNsRixDQUFDO0VBQ0QsT0FBTztDQUNUO0FBQ0Y7QUFFQSxJQUFNLFdBQVcsT0FBTyxrQkFBa0I7QUFDMUMsU0FBUyxjQUFjO0NBQ3JCLE1BQU0sUUFBUSxDQUFDO0NBQ2YsTUFBTSxVQUFVLE9BQU8sT0FBTyxJQUFJO0NBQ2xDLElBQUk7Q0FDSixRQUFRLE9BQU8sUUFBUSxRQUFRO0VBQzdCLE9BQU8sU0FBUztFQUNoQixJQUFJLFFBQVEsVUFBVSxPQUFPO0VBQzdCLE1BQU0sS0FBSyxHQUFHO0VBQ2QsUUFBUSxNQUFNLFVBQVUsUUFBUSxPQUFPO0VBQ3ZDLE9BQU8sTUFBTTtDQUNmO0NBQ0EsT0FBTyxNQUFNLFVBQVUsT0FBTyxPQUFPLElBQUksR0FBRyxPQUFPLENBQUMsQ0FBQztBQUN2RDtBQUNBLFNBQVMsaUJBQWlCLFVBQVUsTUFBTTtDQUN4QyxNQUFNLEdBQ0gsV0FBVyxTQUNWLFNBQVMsWUFBWSxDQUFDO0NBQzFCLE1BQU0sZUFBZSxNQUFNLGdCQUFnQjtDQUMzQyxNQUFNLGNBQWMsTUFBTSxlQUFlO0NBQ3pDLE1BQU0sU0FBUyxNQUFNLG1CQUFtQjtDQUN4QyxJQUFJLEtBQUssU0FBUyxLQUFLLGFBQWE7RUFDbEMsTUFBTSxLQUFLLE1BQU07RUFDakIsTUFBTSxTQUFTLFNBQVMsTUFBTSxRQUFRLEVBQUUsSUFBSSxLQUFLLEtBQUssQ0FBQyxFQUFFLElBQUksT0FBTyxNQUFNLFFBQVEsRUFBRSxJQUFJLEtBQUs7RUFDN0YsSUFBSSxRQUNpQjtRQUFBLFNBQVMsU0FBUyxPQUFPLFNBQVMsSUFBSSxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsRUFBQSxDQUM3RCxTQUFTLEtBQUssRUFBRSxHQUM3QixPQUFPLEdBQUcsS0FBSyxLQUFLLGNBQWMsS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssWUFBWTtFQUFBO0NBR3ZFO0NBQ0EsT0FBTyxLQUFLLEtBQUssWUFBWTtBQUMvQjtBQUVBLElBQU0sd0JBQXVCLFFBQU8sQ0FBQyxTQUFTLEdBQUcsS0FBSyxPQUFPLFFBQVEsYUFBYSxPQUFPLFFBQVE7QUFDakcsSUFBTSxhQUFOLE1BQU0sbUJBQW1CLGFBQWE7Q0FDcEMsWUFBWSxVQUFVLFVBQVUsQ0FBQyxHQUFHO0VBQ2xDLE1BQU07RUFDTixLQUFLO0dBQUM7R0FBaUI7R0FBaUI7R0FBa0I7R0FBZ0I7R0FBb0I7R0FBYztFQUFPLEdBQUcsVUFBVSxJQUFJO0VBQ3BJLEtBQUssVUFBVTtFQUNmLElBQUksS0FBSyxRQUFRLGlCQUFpQixLQUFBLEdBQ2hDLEtBQUssUUFBUSxlQUFlO0VBRTlCLEtBQUssU0FBUyxXQUFXLE9BQU8sWUFBWTtFQUM1QyxLQUFLLG1CQUFtQixDQUFDO0NBQzNCO0NBQ0EsZUFBZSxLQUFLO0VBQ2xCLElBQUksS0FBSyxLQUFLLFdBQVc7Q0FDM0I7Q0FDQSxPQUFPLEtBQUssSUFBSSxFQUNkLGVBQWUsQ0FBQyxFQUNsQixHQUFHO0VBQ0QsTUFBTSxNQUFNLEVBQ1YsR0FBRyxFQUNMO0VBQ0EsSUFBSSxPQUFPLE1BQU0sT0FBTztFQUN4QixNQUFNLFdBQVcsS0FBSyxRQUFRLEtBQUssR0FBRztFQUN0QyxJQUFJLFVBQVUsUUFBUSxLQUFBLEdBQVcsT0FBTztFQUN4QyxNQUFNLFdBQVcscUJBQXFCLFNBQVMsR0FBRztFQUNsRCxJQUFJLElBQUksa0JBQWtCLFNBQVMsVUFDakMsT0FBTztFQUVULE9BQU87Q0FDVDtDQUNBLGVBQWUsS0FBSyxLQUFLO0VBQ3ZCLElBQUksY0FBYyxJQUFJLGdCQUFnQixLQUFBLElBQVksSUFBSSxjQUFjLEtBQUssUUFBUTtFQUNqRixJQUFJLGdCQUFnQixLQUFBLEdBQVcsY0FBYztFQUM3QyxNQUFNLGVBQWUsSUFBSSxpQkFBaUIsS0FBQSxJQUFZLElBQUksZUFBZSxLQUFLLFFBQVE7RUFDdEYsSUFBSSxhQUFhLElBQUksTUFBTSxLQUFLLFFBQVEsYUFBYSxDQUFDO0VBQ3RELE1BQU0sdUJBQXVCLGVBQWUsSUFBSSxTQUFTLFdBQVc7RUFDcEUsTUFBTSx1QkFBdUIsQ0FBQyxLQUFLLFFBQVEsMkJBQTJCLENBQUMsSUFBSSxnQkFBZ0IsQ0FBQyxLQUFLLFFBQVEsMEJBQTBCLENBQUMsSUFBSSxlQUFlLENBQUMsb0JBQW9CLEtBQUssYUFBYSxZQUFZO0VBQzFNLElBQUksd0JBQXdCLENBQUMsc0JBQXNCO0dBQ2pELE1BQU0sSUFBSSxJQUFJLE1BQU0sS0FBSyxhQUFhLGFBQWE7R0FDbkQsSUFBSSxLQUFLLEVBQUUsU0FBUyxHQUNsQixPQUFPO0lBQ0w7SUFDQSxZQUFZLFNBQVMsVUFBVSxJQUFJLENBQUMsVUFBVSxJQUFJO0dBQ3BEO0dBRUYsTUFBTSxRQUFRLElBQUksTUFBTSxXQUFXO0dBQ25DLElBQUksZ0JBQWdCLGdCQUFnQixnQkFBZ0IsZ0JBQWdCLEtBQUssUUFBUSxHQUFHLFNBQVMsTUFBTSxFQUFFLEdBQUcsYUFBYSxNQUFNLE1BQU07R0FDakksTUFBTSxNQUFNLEtBQUssWUFBWTtFQUMvQjtFQUNBLE9BQU87R0FDTDtHQUNBLFlBQVksU0FBUyxVQUFVLElBQUksQ0FBQyxVQUFVLElBQUk7RUFDcEQ7Q0FDRjtDQUNBLFVBQVUsTUFBTSxHQUFHLFNBQVM7RUFDMUIsSUFBSSxNQUFNLE9BQU8sTUFBTSxXQUFXLEVBQ2hDLEdBQUcsRUFDTCxJQUFJO0VBQ0osSUFBSSxPQUFPLFFBQVEsWUFBWSxLQUFLLFFBQVEsa0NBQzFDLE1BQU0sS0FBSyxRQUFRLGlDQUFpQyxTQUFTO0VBRS9ELElBQUksT0FBTyxRQUFRLFVBQVUsTUFBTSxFQUNqQyxHQUFHLElBQ0w7RUFDQSxJQUFJLENBQUMsS0FBSyxNQUFNLENBQUM7RUFDakIsSUFBSSxRQUFRLE1BQU0sT0FBTztFQUN6QixJQUFJLE9BQU8sU0FBUyxZQUFZLE9BQU8saUJBQWlCLE1BQU07R0FDNUQsR0FBRyxLQUFLO0dBQ1IsR0FBRztFQUNMLENBQUM7RUFDRCxJQUFJLENBQUMsTUFBTSxRQUFRLElBQUksR0FBRyxPQUFPLENBQUMsT0FBTyxJQUFJLENBQUM7RUFDOUMsT0FBTyxLQUFLLEtBQUksTUFBSyxPQUFPLE1BQU0sYUFBYSxpQkFBaUIsR0FBRztHQUNqRSxHQUFHLEtBQUs7R0FDUixHQUFHO0VBQ0wsQ0FBQyxJQUFJLE9BQU8sQ0FBQyxDQUFDO0VBQ2QsTUFBTSxnQkFBZ0IsSUFBSSxrQkFBa0IsS0FBQSxJQUFZLElBQUksZ0JBQWdCLEtBQUssUUFBUTtFQUN6RixNQUFNLGVBQWUsSUFBSSxpQkFBaUIsS0FBQSxJQUFZLElBQUksZUFBZSxLQUFLLFFBQVE7RUFDdEYsTUFBTSxFQUNKLEtBQ0EsZUFDRSxLQUFLLGVBQWUsS0FBSyxLQUFLLFNBQVMsSUFBSSxHQUFHO0VBQ2xELE1BQU0sWUFBWSxXQUFXLFdBQVcsU0FBUztFQUNqRCxJQUFJLGNBQWMsSUFBSSxnQkFBZ0IsS0FBQSxJQUFZLElBQUksY0FBYyxLQUFLLFFBQVE7RUFDakYsSUFBSSxnQkFBZ0IsS0FBQSxHQUFXLGNBQWM7RUFDN0MsTUFBTSxNQUFNLElBQUksT0FBTyxLQUFLO0VBQzVCLE1BQU0sMEJBQTBCLElBQUksMkJBQTJCLEtBQUssUUFBUTtFQUM1RSxJQUFJLEtBQUssWUFBWSxNQUFNLFVBQVU7R0FDbkMsSUFBSSx5QkFBeUI7SUFDM0IsSUFBSSxlQUNGLE9BQU87S0FDTCxLQUFLLEdBQUcsWUFBWSxjQUFjO0tBQ2xDLFNBQVM7S0FDVCxjQUFjO0tBQ2QsU0FBUztLQUNULFFBQVE7S0FDUixZQUFZLEtBQUsscUJBQXFCLEdBQUc7SUFDM0M7SUFFRixPQUFPLEdBQUcsWUFBWSxjQUFjO0dBQ3RDO0dBQ0EsSUFBSSxlQUNGLE9BQU87SUFDTCxLQUFLO0lBQ0wsU0FBUztJQUNULGNBQWM7SUFDZCxTQUFTO0lBQ1QsUUFBUTtJQUNSLFlBQVksS0FBSyxxQkFBcUIsR0FBRztHQUMzQztHQUVGLE9BQU87RUFDVDtFQUNBLE1BQU0sV0FBVyxLQUFLLFFBQVEsTUFBTSxHQUFHO0VBQ3ZDLElBQUksTUFBTSxVQUFVO0VBQ3BCLE1BQU0sYUFBYSxVQUFVLFdBQVc7RUFDeEMsTUFBTSxrQkFBa0IsVUFBVSxnQkFBZ0I7RUFDbEQsTUFBTSxXQUFXO0dBQUM7R0FBbUI7R0FBcUI7RUFBaUI7RUFDM0UsTUFBTSxhQUFhLElBQUksZUFBZSxLQUFBLElBQVksSUFBSSxhQUFhLEtBQUssUUFBUTtFQUNoRixNQUFNLDZCQUE2QixDQUFDLEtBQUssY0FBYyxLQUFLLFdBQVc7RUFDdkUsTUFBTSxzQkFBc0IsSUFBSSxVQUFVLEtBQUEsS0FBYSxDQUFDLFNBQVMsSUFBSSxLQUFLO0VBQzFFLE1BQU0sa0JBQWtCLFdBQVcsZ0JBQWdCLEdBQUc7RUFDdEQsTUFBTSxxQkFBcUIsc0JBQXNCLEtBQUssZUFBZSxVQUFVLEtBQUssSUFBSSxPQUFPLEdBQUcsSUFBSTtFQUN0RyxNQUFNLG9DQUFvQyxJQUFJLFdBQVcsc0JBQXNCLEtBQUssZUFBZSxVQUFVLEtBQUssSUFBSSxPQUFPLEVBQzNILFNBQVMsTUFDWCxDQUFDLElBQUk7RUFDTCxNQUFNLHdCQUF3Qix1QkFBdUIsQ0FBQyxJQUFJLFdBQVcsSUFBSSxVQUFVO0VBQ25GLE1BQU0sZUFBZSx5QkFBeUIsSUFBSSxlQUFlLEtBQUssUUFBUSxnQkFBZ0IsVUFBVSxJQUFJLGVBQWUseUJBQXlCLElBQUksZUFBZSx3Q0FBd0MsSUFBSTtFQUNuTixJQUFJLGdCQUFnQjtFQUNwQixJQUFJLDhCQUE4QixDQUFDLE9BQU8saUJBQ3hDLGdCQUFnQjtFQUVsQixNQUFNLGlCQUFpQixxQkFBcUIsYUFBYTtFQUN6RCxNQUFNLFVBQVUsT0FBTyxVQUFVLFNBQVMsTUFBTSxhQUFhO0VBQzdELElBQUksOEJBQThCLGlCQUFpQixrQkFBa0IsQ0FBQyxTQUFTLFNBQVMsT0FBTyxLQUFLLEVBQUUsU0FBUyxVQUFVLEtBQUssTUFBTSxRQUFRLGFBQWEsSUFBSTtHQUMzSixJQUFJLENBQUMsSUFBSSxpQkFBaUIsQ0FBQyxLQUFLLFFBQVEsZUFBZTtJQUNyRCxJQUFJLENBQUMsS0FBSyxRQUFRLHVCQUNoQixLQUFLLE9BQU8sS0FBSyxpRUFBaUU7SUFFcEYsTUFBTSxJQUFJLEtBQUssUUFBUSx3QkFBd0IsS0FBSyxRQUFRLHNCQUFzQixZQUFZLGVBQWU7S0FDM0csR0FBRztLQUNILElBQUk7SUFDTixDQUFDLElBQUksUUFBUSxJQUFJLElBQUksS0FBSyxTQUFTO0lBQ25DLElBQUksZUFBZTtLQUNqQixTQUFTLE1BQU07S0FDZixTQUFTLGFBQWEsS0FBSyxxQkFBcUIsR0FBRztLQUNuRCxPQUFPO0lBQ1Q7SUFDQSxPQUFPO0dBQ1Q7R0FDQSxJQUFJLGNBQWM7SUFDaEIsTUFBTSxpQkFBaUIsTUFBTSxRQUFRLGFBQWE7SUFDbEQsTUFBTSxPQUFPLGlCQUFpQixDQUFDLElBQUksQ0FBQztJQUNwQyxNQUFNLGNBQWMsaUJBQWlCLGtCQUFrQjtJQUN2RCxLQUFLLE1BQU0sS0FBSyxlQUNkLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxlQUFlLENBQUMsR0FBRztLQUMxRCxNQUFNLFVBQVUsR0FBRyxjQUFjLGVBQWU7S0FDaEQsSUFBSSxtQkFBbUIsQ0FBQyxLQUN0QixLQUFLLEtBQUssS0FBSyxVQUFVLFNBQVM7TUFDaEMsR0FBRztNQUNILGNBQWMscUJBQXFCLFlBQVksSUFBSSxhQUFhLEtBQUssS0FBQTtNQUVuRSxZQUFZO01BQ1osSUFBSTtLQUVSLENBQUM7VUFFRCxLQUFLLEtBQUssS0FBSyxVQUFVLFNBQVM7TUFDaEMsR0FBRztNQUVELFlBQVk7TUFDWixJQUFJO0tBRVIsQ0FBQztLQUVILElBQUksS0FBSyxPQUFPLFNBQVMsS0FBSyxLQUFLLGNBQWM7SUFDbkQ7SUFFRixNQUFNO0dBQ1I7RUFDRixPQUFPLElBQUksOEJBQThCLFNBQVMsVUFBVSxLQUFLLE1BQU0sUUFBUSxHQUFHLEdBQUc7R0FDbkYsTUFBTSxJQUFJLEtBQUssVUFBVTtHQUN6QixJQUFJLEtBQUssTUFBTSxLQUFLLGtCQUFrQixLQUFLLE1BQU0sS0FBSyxVQUFVLE9BQU87RUFDekUsT0FBTztHQUNMLElBQUksY0FBYztHQUNsQixJQUFJLFVBQVU7R0FDZCxJQUFJLENBQUMsS0FBSyxjQUFjLEdBQUcsS0FBSyxpQkFBaUI7SUFDL0MsY0FBYztJQUNkLE1BQU07R0FDUjtHQUNBLElBQUksQ0FBQyxLQUFLLGNBQWMsR0FBRyxHQUFHO0lBQzVCLFVBQVU7SUFDVixNQUFNO0dBQ1I7R0FFQSxNQUFNLGlCQURpQyxJQUFJLGtDQUFrQyxLQUFLLFFBQVEsbUNBQ2xDLFVBQVUsS0FBQSxJQUFZO0dBQzlFLE1BQU0sZ0JBQWdCLG1CQUFtQixpQkFBaUIsT0FBTyxLQUFLLFFBQVE7R0FDOUUsSUFBSSxXQUFXLGVBQWUsZUFBZTtJQUMzQyxLQUFLLE9BQU8sSUFBSSxnQkFBZ0IsY0FBYyxjQUFjLEtBQUssV0FBVyx1QkFBdUIsQ0FBQyxnQkFBZ0IsR0FBRyxNQUFNLEtBQUssZUFBZSxVQUFVLEtBQUssSUFBSSxPQUFPLEdBQUcsTUFBTSxLQUFLLGdCQUFnQixlQUFlLEdBQUc7SUFDM04sSUFBSSxjQUFjO0tBQ2hCLE1BQU0sS0FBSyxLQUFLLFFBQVEsS0FBSztNQUMzQixHQUFHO01BQ0gsY0FBYztLQUNoQixDQUFDO0tBQ0QsSUFBSSxNQUFNLEdBQUcsS0FBSyxLQUFLLE9BQU8sS0FBSyxpTEFBaUw7SUFDdE47SUFDQSxJQUFJLE9BQU8sQ0FBQztJQUNaLE1BQU0sZUFBZSxLQUFLLGNBQWMsaUJBQWlCLEtBQUssUUFBUSxhQUFhLElBQUksT0FBTyxLQUFLLFFBQVE7SUFDM0csSUFBSSxLQUFLLFFBQVEsa0JBQWtCLGNBQWMsZ0JBQWdCLGFBQWEsSUFDNUUsS0FBSyxJQUFJLElBQUksR0FBRyxJQUFJLGFBQWEsUUFBUSxLQUN2QyxLQUFLLEtBQUssYUFBYSxFQUFFO1NBRXRCLElBQUksS0FBSyxRQUFRLGtCQUFrQixPQUN4QyxPQUFPLEtBQUssY0FBYyxtQkFBbUIsSUFBSSxPQUFPLEtBQUssUUFBUTtTQUVyRSxLQUFLLEtBQUssSUFBSSxPQUFPLEtBQUssUUFBUTtJQUVwQyxNQUFNLFFBQVEsR0FBRyxHQUFHLHlCQUF5QjtLQUMzQyxNQUFNLG9CQUFvQixtQkFBbUIseUJBQXlCLE1BQU0sdUJBQXVCO0tBQ25HLElBQUksS0FBSyxRQUFRLG1CQUNmLEtBQUssUUFBUSxrQkFBa0IsR0FBRyxXQUFXLEdBQUcsbUJBQW1CLGVBQWUsR0FBRztVQUNoRixJQUFJLEtBQUssa0JBQWtCLGFBQ2hDLEtBQUssaUJBQWlCLFlBQVksR0FBRyxXQUFXLEdBQUcsbUJBQW1CLGVBQWUsR0FBRztLQUUxRixLQUFLLEtBQUssY0FBYyxHQUFHLFdBQVcsR0FBRyxHQUFHO0lBQzlDO0lBQ0EsSUFBSSxLQUFLLFFBQVEsYUFBYTtLQUM1QixJQUFJLEtBQUssUUFBUSxzQkFBc0IscUJBQ3JDLEtBQUssU0FBUSxhQUFZO01BQ3ZCLE1BQU0sV0FBVyxLQUFLLGVBQWUsWUFBWSxVQUFVLEdBQUc7TUFDOUQsSUFBSSx5QkFBeUIsSUFBSSxlQUFlLEtBQUssUUFBUSxnQkFBZ0IsVUFBVSxDQUFDLFNBQVMsU0FBUyxHQUFHLEtBQUssUUFBUSxnQkFBZ0IsS0FBSyxHQUM3SSxTQUFTLEtBQUssR0FBRyxLQUFLLFFBQVEsZ0JBQWdCLEtBQUs7TUFFckQsU0FBUyxTQUFRLFdBQVU7T0FDekIsS0FBSyxDQUFDLFFBQVEsR0FBRyxNQUFNLFFBQVEsSUFBSSxlQUFlLGFBQWEsWUFBWTtNQUM3RSxDQUFDO0tBQ0gsQ0FBQztVQUVELEtBQUssTUFBTSxLQUFLLFlBQVk7SUFFaEM7R0FDRjtHQUNBLE1BQU0sS0FBSyxrQkFBa0IsS0FBSyxNQUFNLEtBQUssVUFBVSxPQUFPO0dBQzlELElBQUksV0FBVyxRQUFRLE9BQU8sS0FBSyxRQUFRLDZCQUN6QyxNQUFNLEdBQUcsWUFBWSxjQUFjO0dBRXJDLEtBQUssV0FBVyxnQkFBZ0IsS0FBSyxRQUFRLHdCQUMzQyxNQUFNLEtBQUssUUFBUSx1QkFBdUIsS0FBSyxRQUFRLDhCQUE4QixHQUFHLFlBQVksY0FBYyxRQUFRLEtBQUssY0FBYyxNQUFNLEtBQUEsR0FBVyxHQUFHO0VBRXJLO0VBQ0EsSUFBSSxlQUFlO0dBQ2pCLFNBQVMsTUFBTTtHQUNmLFNBQVMsYUFBYSxLQUFLLHFCQUFxQixHQUFHO0dBQ25ELE9BQU87RUFDVDtFQUNBLE9BQU87Q0FDVDtDQUNBLGtCQUFrQixLQUFLLEtBQUssS0FBSyxVQUFVLFNBQVM7RUFDbEQsSUFBSSxLQUFLLFlBQVksT0FDbkIsTUFBTSxLQUFLLFdBQVcsTUFBTSxLQUFLO0dBQy9CLEdBQUcsS0FBSyxRQUFRLGNBQWM7R0FDOUIsR0FBRztFQUNMLEdBQUcsSUFBSSxPQUFPLEtBQUssWUFBWSxTQUFTLFNBQVMsU0FBUyxRQUFRLFNBQVMsU0FBUyxFQUNsRixTQUNGLENBQUM7T0FDSSxJQUFJLENBQUMsSUFBSSxtQkFBbUI7R0FDakMsSUFBSSxJQUFJLGVBQWUsS0FBSyxhQUFhLEtBQUs7SUFDNUMsR0FBRztJQUVELGVBQWU7S0FDYixHQUFHLEtBQUssUUFBUTtLQUNoQixHQUFHLElBQUk7SUFDVDtHQUVKLENBQUM7R0FDRCxNQUFNLGtCQUFrQixTQUFTLEdBQUcsTUFBTSxLQUFLLGVBQWUsb0JBQW9CLEtBQUEsSUFBWSxJQUFJLGNBQWMsa0JBQWtCLEtBQUssUUFBUSxjQUFjO0dBQzdKLElBQUk7R0FDSixJQUFJLGlCQUFpQjtJQUNuQixNQUFNLEtBQUssSUFBSSxNQUFNLEtBQUssYUFBYSxhQUFhO0lBQ3BELFVBQVUsTUFBTSxHQUFHO0dBQ3JCO0dBQ0EsSUFBSSxPQUFPLElBQUksV0FBVyxDQUFDLFNBQVMsSUFBSSxPQUFPLElBQUksSUFBSSxVQUFVO0dBQ2pFLElBQUksS0FBSyxRQUFRLGNBQWMsa0JBQWtCLE9BQU87SUFDdEQsR0FBRyxLQUFLLFFBQVEsY0FBYztJQUM5QixHQUFHO0dBQ0w7R0FDQSxNQUFNLEtBQUssYUFBYSxZQUFZLEtBQUssTUFBTSxJQUFJLE9BQU8sS0FBSyxZQUFZLFNBQVMsU0FBUyxHQUFHO0dBQ2hHLElBQUksaUJBQWlCO0lBQ25CLE1BQU0sS0FBSyxJQUFJLE1BQU0sS0FBSyxhQUFhLGFBQWE7SUFDcEQsTUFBTSxVQUFVLE1BQU0sR0FBRztJQUN6QixJQUFJLFVBQVUsU0FBUyxJQUFJLE9BQU87R0FDcEM7R0FDQSxJQUFJLENBQUMsSUFBSSxPQUFPLFlBQVksU0FBUyxLQUFLLElBQUksTUFBTSxLQUFLLFlBQVksU0FBUztHQUM5RSxJQUFJLElBQUksU0FBUyxPQUFPLE1BQU0sS0FBSyxhQUFhLEtBQUssTUFBTSxHQUFHLFNBQVM7SUFDckUsSUFBSSxVQUFVLE9BQU8sS0FBSyxNQUFNLENBQUMsSUFBSSxTQUFTO0tBQzVDLEtBQUssT0FBTyxLQUFLLDZDQUE2QyxLQUFLLEdBQUcsV0FBVyxJQUFJLElBQUk7S0FDekYsT0FBTztJQUNUO0lBQ0EsT0FBTyxLQUFLLFVBQVUsR0FBRyxNQUFNLEdBQUc7R0FDcEMsR0FBRyxHQUFHO0dBQ04sSUFBSSxJQUFJLGVBQWUsS0FBSyxhQUFhLE1BQU07RUFDakQ7RUFDQSxNQUFNLGNBQWMsSUFBSSxlQUFlLEtBQUssUUFBUTtFQUNwRCxNQUFNLHFCQUFxQixTQUFTLFdBQVcsSUFBSSxDQUFDLFdBQVcsSUFBSTtFQUNuRSxJQUFJLE9BQU8sUUFBUSxvQkFBb0IsVUFBVSxJQUFJLHVCQUF1QixPQUMxRSxNQUFNLGNBQWMsT0FBTyxvQkFBb0IsS0FBSyxLQUFLLEtBQUssV0FBVyxLQUFLLFFBQVEsMEJBQTBCO0dBQzlHLGNBQWM7SUFDWixHQUFHO0lBQ0gsWUFBWSxLQUFLLHFCQUFxQixHQUFHO0dBQzNDO0dBQ0EsR0FBRztFQUNMLElBQUksS0FBSyxJQUFJO0VBRWYsT0FBTztDQUNUO0NBQ0EsUUFBUSxNQUFNLE1BQU0sQ0FBQyxHQUFHO0VBQ3RCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSSxTQUFTLElBQUksR0FBRyxPQUFPLENBQUMsSUFBSTtFQUNoQyxJQUFJLE1BQU0sUUFBUSxJQUFJLEdBQUcsT0FBTyxLQUFLLEtBQUksTUFBSyxPQUFPLE1BQU0sYUFBYSxpQkFBaUIsR0FBRztHQUMxRixHQUFHLEtBQUs7R0FDUixHQUFHO0VBQ0wsQ0FBQyxJQUFJLENBQUM7RUFDTixLQUFLLFNBQVEsTUFBSztHQUNoQixJQUFJLEtBQUssY0FBYyxLQUFLLEdBQUc7R0FDL0IsTUFBTSxZQUFZLEtBQUssZUFBZSxHQUFHLEdBQUc7R0FDNUMsTUFBTSxNQUFNLFVBQVU7R0FDdEIsVUFBVTtHQUNWLElBQUksYUFBYSxVQUFVO0dBQzNCLElBQUksS0FBSyxRQUFRLFlBQVksYUFBYSxXQUFXLE9BQU8sS0FBSyxRQUFRLFVBQVU7R0FDbkYsTUFBTSxzQkFBc0IsSUFBSSxVQUFVLEtBQUEsS0FBYSxDQUFDLFNBQVMsSUFBSSxLQUFLO0dBQzFFLE1BQU0sd0JBQXdCLHVCQUF1QixDQUFDLElBQUksV0FBVyxJQUFJLFVBQVU7R0FDbkYsTUFBTSx1QkFBdUIsSUFBSSxZQUFZLEtBQUEsTUFBYyxTQUFTLElBQUksT0FBTyxLQUFLLE9BQU8sSUFBSSxZQUFZLGFBQWEsSUFBSSxZQUFZO0dBQ3hJLE1BQU0sUUFBUSxJQUFJLE9BQU8sSUFBSSxPQUFPLEtBQUssY0FBYyxtQkFBbUIsSUFBSSxPQUFPLEtBQUssVUFBVSxJQUFJLFdBQVc7R0FDbkgsV0FBVyxTQUFRLE9BQU07SUFDdkIsSUFBSSxLQUFLLGNBQWMsS0FBSyxHQUFHO0lBQy9CLFNBQVM7SUFDVCxJQUFJLENBQUMsS0FBSyxpQkFBaUIsR0FBRyxNQUFNLEdBQUcsR0FBRyxTQUFTLEtBQUssT0FBTyxzQkFBc0IsQ0FBQyxLQUFLLE9BQU8sbUJBQW1CLE1BQU0sR0FBRztLQUM1SCxLQUFLLGlCQUFpQixHQUFHLE1BQU0sR0FBRyxHQUFHLFFBQVE7S0FDN0MsS0FBSyxPQUFPLEtBQUssUUFBUSxRQUFRLG1CQUFtQixNQUFNLEtBQUssSUFBSSxFQUFFLHFDQUFxQyxPQUFPLHVCQUF1QiwwTkFBME47SUFDcFc7SUFDQSxNQUFNLFNBQVEsU0FBUTtLQUNwQixJQUFJLEtBQUssY0FBYyxLQUFLLEdBQUc7S0FDL0IsVUFBVTtLQUNWLE1BQU0sWUFBWSxDQUFDLEdBQUc7S0FDdEIsSUFBSSxLQUFLLFlBQVksZUFDbkIsS0FBSyxXQUFXLGNBQWMsV0FBVyxLQUFLLE1BQU0sSUFBSSxHQUFHO1VBQ3REO01BQ0wsSUFBSTtNQUNKLElBQUkscUJBQXFCLGVBQWUsS0FBSyxlQUFlLFVBQVUsTUFBTSxJQUFJLE9BQU8sR0FBRztNQUMxRixNQUFNLGFBQWEsR0FBRyxLQUFLLFFBQVEsZ0JBQWdCO01BQ25ELE1BQU0sZ0JBQWdCLEdBQUcsS0FBSyxRQUFRLGdCQUFnQixTQUFTLEtBQUssUUFBUTtNQUM1RSxJQUFJLHFCQUFxQjtPQUN2QixJQUFJLElBQUksV0FBVyxhQUFhLFdBQVcsYUFBYSxHQUN0RCxVQUFVLEtBQUssTUFBTSxhQUFhLFFBQVEsZUFBZSxLQUFLLFFBQVEsZUFBZSxDQUFDO09BRXhGLFVBQVUsS0FBSyxNQUFNLFlBQVk7T0FDakMsSUFBSSx1QkFDRixVQUFVLEtBQUssTUFBTSxVQUFVO01BRW5DO01BQ0EsSUFBSSxzQkFBc0I7T0FDeEIsTUFBTSxhQUFhLEdBQUcsTUFBTSxLQUFLLFFBQVEsb0JBQW9CLE1BQU0sSUFBSTtPQUN2RSxVQUFVLEtBQUssVUFBVTtPQUN6QixJQUFJLHFCQUFxQjtRQUN2QixJQUFJLElBQUksV0FBVyxhQUFhLFdBQVcsYUFBYSxHQUN0RCxVQUFVLEtBQUssYUFBYSxhQUFhLFFBQVEsZUFBZSxLQUFLLFFBQVEsZUFBZSxDQUFDO1FBRS9GLFVBQVUsS0FBSyxhQUFhLFlBQVk7UUFDeEMsSUFBSSx1QkFDRixVQUFVLEtBQUssYUFBYSxVQUFVO09BRTFDO01BQ0Y7S0FDRjtLQUNBLElBQUk7S0FDSixPQUFPLGNBQWMsVUFBVSxJQUFJLEdBQ2pDLElBQUksQ0FBQyxLQUFLLGNBQWMsS0FBSyxHQUFHO01BQzlCLGVBQWU7TUFDZixRQUFRLEtBQUssWUFBWSxNQUFNLElBQUksYUFBYSxHQUFHO0tBQ3JEO0lBRUosQ0FBQztHQUNILENBQUM7RUFDSCxDQUFDO0VBQ0QsT0FBTztHQUNMLEtBQUs7R0FDTDtHQUNBO0dBQ0E7R0FDQTtFQUNGO0NBQ0Y7Q0FDQSxjQUFjLEtBQUs7RUFDakIsT0FBTyxRQUFRLEtBQUEsS0FBYSxFQUFFLENBQUMsS0FBSyxRQUFRLGNBQWMsUUFBUSxTQUFTLEVBQUUsQ0FBQyxLQUFLLFFBQVEscUJBQXFCLFFBQVE7Q0FDMUg7Q0FDQSxZQUFZLE1BQU0sSUFBSSxLQUFLLFVBQVUsQ0FBQyxHQUFHO0VBQ3ZDLElBQUksS0FBSyxZQUFZLGFBQWEsT0FBTyxLQUFLLFdBQVcsWUFBWSxNQUFNLElBQUksS0FBSyxPQUFPO0VBQzNGLE9BQU8sS0FBSyxjQUFjLFlBQVksTUFBTSxJQUFJLEtBQUssT0FBTztDQUM5RDtDQUNBLHFCQUFxQixVQUFVLENBQUMsR0FBRztFQUNqQyxNQUFNLGNBQWM7R0FBQztHQUFnQjtHQUFXO0dBQVc7R0FBVztHQUFPO0dBQVE7R0FBZTtHQUFNO0dBQWdCO0dBQWU7R0FBaUI7R0FBaUI7R0FBYztHQUFlO0VBQWU7RUFDdk4sTUFBTSwyQkFBMkIsUUFBUSxXQUFXLENBQUMsU0FBUyxRQUFRLE9BQU87RUFDN0UsSUFBSSxPQUFPLDJCQUEyQixRQUFRLFVBQVU7RUFDeEQsSUFBSSw0QkFBNEIsT0FBTyxRQUFRLFVBQVUsYUFDdkQsT0FBTztHQUNMLEdBQUc7R0FDSCxPQUFPLFFBQVE7RUFDakI7RUFFRixJQUFJLEtBQUssUUFBUSxjQUFjLGtCQUM3QixPQUFPO0dBQ0wsR0FBRyxLQUFLLFFBQVEsY0FBYztHQUM5QixHQUFHO0VBQ0w7RUFFRixJQUFJLENBQUMsMEJBQTBCO0dBQzdCLE9BQU8sRUFDTCxHQUFHLEtBQ0w7R0FDQSxLQUFLLE1BQU0sT0FBTyxhQUNoQixPQUFPLEtBQUs7RUFFaEI7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxPQUFPLGdCQUFnQixTQUFTO0VBQzlCLE1BQU0sU0FBUztFQUNmLEtBQUssTUFBTSxVQUFVLFNBQ25CLElBQUksT0FBTyxVQUFVLGVBQWUsS0FBSyxTQUFTLE1BQU0sS0FBSyxPQUFPLFdBQVcsTUFBTSxLQUFLLEtBQUEsTUFBYyxRQUFRLFNBQzlHLE9BQU87RUFHWCxPQUFPO0NBQ1Q7QUFDRjtBQUVBLElBQU0sZUFBTixNQUFtQjtDQUNqQixZQUFZLFNBQVM7RUFDbkIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxnQkFBZ0IsS0FBSyxRQUFRLGlCQUFpQjtFQUNuRCxLQUFLLFNBQVMsV0FBVyxPQUFPLGVBQWU7RUFDL0MsS0FBSyx3QkFBd0IsQ0FBQztDQUNoQztDQUNBLGFBQWE7RUFDWCxLQUFLLHdCQUF3QixDQUFDO0NBQ2hDO0NBQ0Esc0JBQXNCLE1BQU07RUFDMUIsT0FBTyxlQUFlLElBQUk7RUFDMUIsSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLFNBQVMsR0FBRyxHQUFHLE9BQU87RUFDekMsTUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHO0VBQ3hCLElBQUksRUFBRSxXQUFXLEdBQUcsT0FBTztFQUMzQixFQUFFLElBQUk7RUFDTixJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxZQUFZLE1BQU0sS0FBSyxPQUFPO0VBQ2xELE9BQU8sS0FBSyxtQkFBbUIsRUFBRSxLQUFLLEdBQUcsQ0FBQztDQUM1QztDQUNBLHdCQUF3QixNQUFNO0VBQzVCLE9BQU8sZUFBZSxJQUFJO0VBQzFCLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxTQUFTLEdBQUcsR0FBRyxPQUFPO0VBQ3pDLE1BQU0sSUFBSSxLQUFLLE1BQU0sR0FBRztFQUN4QixPQUFPLEtBQUssbUJBQW1CLEVBQUUsRUFBRTtDQUNyQztDQUNBLG1CQUFtQixNQUFNO0VBQ3ZCLElBQUksU0FBUyxJQUFJLEtBQUssS0FBSyxTQUFTLEdBQUcsR0FBRztHQUN4QyxJQUFJO0dBQ0osSUFBSTtJQUNGLGdCQUFnQixLQUFLLG9CQUFvQixJQUFJLENBQUMsQ0FBQztHQUNqRCxTQUFTLEdBQUcsQ0FBQztHQUNiLElBQUksaUJBQWlCLEtBQUssUUFBUSxjQUNoQyxnQkFBZ0IsY0FBYyxZQUFZO0dBRTVDLElBQUksZUFBZSxPQUFPO0dBQzFCLElBQUksS0FBSyxRQUFRLGNBQ2YsT0FBTyxLQUFLLFlBQVk7R0FFMUIsT0FBTztFQUNUO0VBQ0EsT0FBTyxLQUFLLFFBQVEsYUFBYSxLQUFLLFFBQVEsZUFBZSxLQUFLLFlBQVksSUFBSTtDQUNwRjtDQUNBLGdCQUFnQixNQUFNO0VBQ3BCLElBQUksS0FBSyxRQUFRLFNBQVMsa0JBQWtCLEtBQUssUUFBUSwwQkFDdkQsT0FBTyxLQUFLLHdCQUF3QixJQUFJO0VBRTFDLE9BQU8sQ0FBQyxLQUFLLGlCQUFpQixDQUFDLEtBQUssY0FBYyxVQUFVLEtBQUssY0FBYyxTQUFTLElBQUk7Q0FDOUY7Q0FDQSxzQkFBc0IsT0FBTztFQUMzQixJQUFJLENBQUMsT0FBTyxPQUFPO0VBQ25CLElBQUk7RUFDSixNQUFNLFNBQVEsU0FBUTtHQUNwQixJQUFJLE9BQU87R0FDWCxNQUFNLGFBQWEsS0FBSyxtQkFBbUIsSUFBSTtHQUMvQyxJQUFJLENBQUMsS0FBSyxRQUFRLGlCQUFpQixLQUFLLGdCQUFnQixVQUFVLEdBQUcsUUFBUTtFQUMvRSxDQUFDO0VBQ0QsSUFBSSxDQUFDLFNBQVMsS0FBSyxRQUFRLGVBQ3pCLE1BQU0sU0FBUSxTQUFRO0dBQ3BCLElBQUksT0FBTztHQUNYLE1BQU0sWUFBWSxLQUFLLHNCQUFzQixJQUFJO0dBQ2pELElBQUksS0FBSyxnQkFBZ0IsU0FBUyxHQUFHLE9BQU8sUUFBUTtHQUNwRCxNQUFNLFVBQVUsS0FBSyx3QkFBd0IsSUFBSTtHQUNqRCxJQUFJLEtBQUssZ0JBQWdCLE9BQU8sR0FBRyxPQUFPLFFBQVE7R0FDbEQsUUFBUSxLQUFLLFFBQVEsY0FBYyxNQUFLLGlCQUFnQjtJQUN0RCxJQUFJLGlCQUFpQixTQUFTLE9BQU87SUFDckMsSUFBSSxDQUFDLGFBQWEsU0FBUyxHQUFHLEtBQUssQ0FBQyxRQUFRLFNBQVMsR0FBRyxHQUFHLE9BQU87SUFDbEUsSUFBSSxhQUFhLFNBQVMsR0FBRyxLQUFLLENBQUMsUUFBUSxTQUFTLEdBQUcsS0FBSyxhQUFhLE1BQU0sR0FBRyxhQUFhLFFBQVEsR0FBRyxDQUFDLE1BQU0sU0FBUyxPQUFPO0lBQ2pJLE9BQU87R0FDVCxDQUFDO0VBQ0gsQ0FBQztFQUVILElBQUksQ0FBQyxPQUFPLFFBQVEsS0FBSyxpQkFBaUIsS0FBSyxRQUFRLFdBQVcsQ0FBQyxDQUFDO0VBQ3BFLE9BQU87Q0FDVDtDQUNBLGlCQUFpQixXQUFXLE1BQU07RUFDaEMsSUFBSSxDQUFDLFdBQVcsT0FBTyxDQUFDO0VBQ3hCLElBQUksT0FBTyxjQUFjLFlBQVksWUFBWSxVQUFVLElBQUk7RUFDL0QsSUFBSSxTQUFTLFNBQVMsR0FBRyxZQUFZLENBQUMsU0FBUztFQUMvQyxJQUFJLE1BQU0sUUFBUSxTQUFTLEdBQUcsT0FBTztFQUNyQyxJQUFJLENBQUMsTUFBTSxPQUFPLFVBQVUsV0FBVyxDQUFDO0VBQ3hDLElBQUksUUFBUSxVQUFVO0VBQ3RCLElBQUksQ0FBQyxPQUFPLFFBQVEsVUFBVSxLQUFLLHNCQUFzQixJQUFJO0VBQzdELElBQUksQ0FBQyxPQUFPLFFBQVEsVUFBVSxLQUFLLG1CQUFtQixJQUFJO0VBQzFELElBQUksQ0FBQyxPQUFPLFFBQVEsVUFBVSxLQUFLLHdCQUF3QixJQUFJO0VBQy9ELElBQUksQ0FBQyxPQUFPLFFBQVEsVUFBVTtFQUM5QixPQUFPLFNBQVMsQ0FBQztDQUNuQjtDQUNBLG1CQUFtQixNQUFNLGNBQWM7RUFDckMsTUFBTSxjQUFjLEtBQUssUUFBUTtFQUNqQyxNQUFNLGlCQUFpQixNQUFNLFFBQVEsV0FBVyxJQUFJLFlBQVksS0FBSyxHQUFHLElBQUk7RUFDNUUsSUFBSSxtQkFBbUIsS0FBSyxvQkFBb0I7R0FDOUMsS0FBSyx3QkFBd0IsQ0FBQztHQUM5QixLQUFLLHFCQUFxQjtFQUM1QjtFQUNBLE1BQU0sdUJBQXVCLGlCQUFpQixLQUFBLEtBQWEsaUJBQWlCLFNBQVMsU0FBUyxZQUFZO0VBQzFHLE1BQU0saUNBQWlDLGlCQUFpQixLQUFBLEtBQWEsT0FBTyxLQUFLLFFBQVEsZ0JBQWdCO0VBQ3pHLE1BQU0sWUFBWSxTQUFTLElBQUksS0FBSyx3QkFBd0IsQ0FBQztFQUM3RCxJQUFJLFdBQVc7RUFDZixJQUFJLFdBQVc7R0FDYixJQUFJO0dBQ0osSUFBSSxpQkFBaUIsS0FBQSxHQUFXLG1CQUFtQjtRQUFpQixJQUFJLGlCQUFpQixPQUFPLG1CQUFtQjtRQUFxQixtQkFBbUIsVUFBVTtHQUNySyxXQUFXLEdBQUcsS0FBSyxPQUFPLEdBQUcsS0FBSyxHQUFHO0VBQ3ZDO0VBQ0EsSUFBSSxhQUFhLE1BQU07R0FDckIsTUFBTSxTQUFTLEtBQUssc0JBQXNCO0dBQzFDLElBQUksV0FBVyxLQUFBLEdBQVcsT0FBTyxPQUFPLE1BQU07RUFDaEQ7RUFDQSxNQUFNLGdCQUFnQixLQUFLLGtCQUFrQixpQkFBaUIsUUFBUSxDQUFDLElBQUksaUJBQWlCLEtBQUssUUFBUSxlQUFlLENBQUMsR0FBRyxJQUFJO0VBQ2hJLE1BQU0sUUFBUSxDQUFDO0VBQ2YsTUFBTSxXQUFVLE1BQUs7R0FDbkIsSUFBSSxDQUFDLEdBQUc7R0FDUixJQUFJLEtBQUssZ0JBQWdCLENBQUMsR0FDeEIsTUFBTSxLQUFLLENBQUM7UUFFWixLQUFLLE9BQU8sS0FBSyx1REFBdUQsR0FBRztFQUUvRTtFQUNBLElBQUksU0FBUyxJQUFJLE1BQU0sS0FBSyxTQUFTLEdBQUcsS0FBSyxLQUFLLFNBQVMsR0FBRyxJQUFJO0dBQ2hFLElBQUksS0FBSyxRQUFRLFNBQVMsZ0JBQWdCLFFBQVEsS0FBSyxtQkFBbUIsSUFBSSxDQUFDO0dBQy9FLElBQUksS0FBSyxRQUFRLFNBQVMsa0JBQWtCLEtBQUssUUFBUSxTQUFTLGVBQWUsUUFBUSxLQUFLLHNCQUFzQixJQUFJLENBQUM7R0FDekgsSUFBSSxLQUFLLFFBQVEsU0FBUyxlQUFlLFFBQVEsS0FBSyx3QkFBd0IsSUFBSSxDQUFDO0VBQ3JGLE9BQU8sSUFBSSxTQUFTLElBQUksR0FDdEIsUUFBUSxLQUFLLG1CQUFtQixJQUFJLENBQUM7RUFFdkMsY0FBYyxTQUFRLE9BQU07R0FDMUIsTUFBTSxjQUFjLEtBQUssbUJBQW1CLEVBQUU7R0FDOUMsSUFBSSxDQUFDLE1BQU0sU0FBUyxXQUFXLEdBQUcsUUFBUSxXQUFXO0VBQ3ZELENBQUM7RUFDRCxJQUFJLGFBQWEsTUFBTTtHQUNyQixLQUFLLHNCQUFzQixZQUFZO0dBQ3ZDLE9BQU8sTUFBTSxNQUFNO0VBQ3JCO0VBQ0EsT0FBTztDQUNUO0FBQ0Y7QUFFQSxJQUFNLGdCQUFnQjtDQUNwQixNQUFNO0NBQ04sS0FBSztDQUNMLEtBQUs7Q0FDTCxLQUFLO0NBQ0wsTUFBTTtDQUNOLE9BQU87QUFDVDtBQUNBLElBQU0sWUFBWTtDQUNoQixTQUFRLFVBQVMsVUFBVSxJQUFJLFFBQVE7Q0FDdkMsd0JBQXdCLEVBQ3RCLGtCQUFrQixDQUFDLE9BQU8sT0FBTyxFQUNuQztBQUNGO0FBQ0EsSUFBTSxpQkFBTixNQUFxQjtDQUNuQixZQUFZLGVBQWUsVUFBVSxDQUFDLEdBQUc7RUFDdkMsS0FBSyxnQkFBZ0I7RUFDckIsS0FBSyxVQUFVO0VBQ2YsS0FBSyxTQUFTLFdBQVcsT0FBTyxnQkFBZ0I7RUFDaEQsS0FBSyxtQkFBbUIsQ0FBQztDQUMzQjtDQUNBLGFBQWE7RUFDWCxLQUFLLG1CQUFtQixDQUFDO0NBQzNCO0NBQ0EsUUFBUSxNQUFNLFVBQVUsQ0FBQyxHQUFHO0VBQzFCLE1BQU0sY0FBYyxlQUFlLFNBQVMsUUFBUSxPQUFPLElBQUk7RUFDL0QsTUFBTSxPQUFPLFFBQVEsVUFBVSxZQUFZO0VBQzNDLE1BQU0sV0FBVyxLQUFLLFVBQVU7R0FDOUI7R0FDQTtFQUNGLENBQUM7RUFDRCxJQUFJLFlBQVksS0FBSyxrQkFDbkIsT0FBTyxLQUFLLGlCQUFpQjtFQUUvQixJQUFJO0VBQ0osSUFBSTtHQUNGLE9BQU8sSUFBSSxLQUFLLFlBQVksYUFBYSxFQUN2QyxLQUNGLENBQUM7RUFDSCxTQUFTLEtBQUs7R0FDWixJQUFJLE9BQU8sU0FBUyxhQUFhO0lBQy9CLEtBQUssT0FBTyxNQUFNLCtDQUErQztJQUNqRSxPQUFPO0dBQ1Q7R0FDQSxJQUFJLENBQUMsS0FBSyxNQUFNLEtBQUssR0FBRyxPQUFPO0dBQy9CLE1BQU0sVUFBVSxLQUFLLGNBQWMsd0JBQXdCLElBQUk7R0FDL0QsT0FBTyxLQUFLLFFBQVEsU0FBUyxPQUFPO0VBQ3RDO0VBQ0EsS0FBSyxpQkFBaUIsWUFBWTtFQUNsQyxPQUFPO0NBQ1Q7Q0FDQSxZQUFZLE1BQU0sVUFBVSxDQUFDLEdBQUc7RUFDOUIsSUFBSSxPQUFPLEtBQUssUUFBUSxNQUFNLE9BQU87RUFDckMsSUFBSSxDQUFDLE1BQU0sT0FBTyxLQUFLLFFBQVEsT0FBTyxPQUFPO0VBQzdDLE9BQU8sTUFBTSxnQkFBZ0IsQ0FBQyxDQUFDLGlCQUFpQixTQUFTO0NBQzNEO0NBQ0Esb0JBQW9CLE1BQU0sS0FBSyxVQUFVLENBQUMsR0FBRztFQUMzQyxPQUFPLEtBQUssWUFBWSxNQUFNLE9BQU8sQ0FBQyxDQUFDLEtBQUksV0FBVSxHQUFHLE1BQU0sUUFBUTtDQUN4RTtDQUNBLFlBQVksTUFBTSxVQUFVLENBQUMsR0FBRztFQUM5QixJQUFJLE9BQU8sS0FBSyxRQUFRLE1BQU0sT0FBTztFQUNyQyxJQUFJLENBQUMsTUFBTSxPQUFPLEtBQUssUUFBUSxPQUFPLE9BQU87RUFDN0MsSUFBSSxDQUFDLE1BQU0sT0FBTyxDQUFDO0VBQ25CLE9BQU8sS0FBSyxnQkFBZ0IsQ0FBQyxDQUFDLGlCQUFpQixNQUFNLGlCQUFpQixvQkFBb0IsY0FBYyxtQkFBbUIsY0FBYyxnQkFBZ0IsQ0FBQyxDQUFDLEtBQUksbUJBQWtCLEdBQUcsS0FBSyxRQUFRLFVBQVUsUUFBUSxVQUFVLFVBQVUsS0FBSyxRQUFRLFlBQVksS0FBSyxnQkFBZ0I7Q0FDdlI7Q0FDQSxVQUFVLE1BQU0sT0FBTyxVQUFVLENBQUMsR0FBRztFQUNuQyxNQUFNLE9BQU8sS0FBSyxRQUFRLE1BQU0sT0FBTztFQUN2QyxJQUFJLE1BQ0YsT0FBTyxHQUFHLEtBQUssUUFBUSxVQUFVLFFBQVEsVUFBVSxVQUFVLEtBQUssUUFBUSxZQUFZLEtBQUssS0FBSyxPQUFPLEtBQUs7RUFFOUcsS0FBSyxPQUFPLEtBQUssNkJBQTZCLE1BQU07RUFDcEQsT0FBTyxLQUFLLFVBQVUsT0FBTyxPQUFPLE9BQU87Q0FDN0M7QUFDRjtBQUVBLElBQU0sd0JBQXdCLE1BQU0sYUFBYSxLQUFLLGVBQWUsS0FBSyxzQkFBc0IsU0FBUztDQUN2RyxJQUFJLE9BQU8sb0JBQW9CLE1BQU0sYUFBYSxHQUFHO0NBQ3JELElBQUksUUFBUSxRQUFRLHVCQUF1QixTQUFTLEdBQUcsR0FBRztFQUN4RCxPQUFPLFNBQVMsTUFBTSxLQUFLLFlBQVk7RUFDdkMsSUFBSSxTQUFTLEtBQUEsR0FBVyxPQUFPLFNBQVMsYUFBYSxLQUFLLFlBQVk7Q0FDeEU7Q0FDQSxPQUFPO0FBQ1Q7QUFDQSxJQUFNLGVBQU4sTUFBbUI7Q0FDakIsWUFBWSxVQUFVLENBQUMsR0FBRztFQUN4QixLQUFLLFNBQVMsV0FBVyxPQUFPLGNBQWM7RUFDOUMsS0FBSyxVQUFVO0VBQ2YsS0FBSyxTQUFTLFNBQVMsZUFBZSxZQUFXLFVBQVM7RUFDMUQsS0FBSyxLQUFLLE9BQU87Q0FDbkI7Q0FDQSxLQUFLLFVBQVUsQ0FBQyxHQUFHO0VBQ2pCLElBQUksQ0FBQyxRQUFRLGVBQWUsUUFBUSxnQkFBZ0IsRUFDbEQsYUFBYSxLQUNmO0VBQ0EsTUFBTSxFQUNKLFFBQVEsVUFDUixhQUNBLHFCQUNBLFFBQ0EsZUFDQSxRQUNBLGVBQ0EsaUJBQ0EsZ0JBQ0EsZ0JBQ0EsZUFDQSxzQkFDQSxlQUNBLHNCQUNBLHlCQUNBLGFBQ0EsaUJBQ0UsUUFBUTtFQUNaLEtBQUssU0FBUyxhQUFhLEtBQUEsSUFBWSxXQUFXO0VBQ2xELEtBQUssY0FBYyxnQkFBZ0IsS0FBQSxJQUFZLGNBQWM7RUFDN0QsS0FBSyxzQkFBc0Isd0JBQXdCLEtBQUEsSUFBWSxzQkFBc0I7RUFDckYsS0FBSyxTQUFTLFNBQVMsWUFBWSxNQUFNLElBQUksaUJBQWlCO0VBQzlELEtBQUssU0FBUyxTQUFTLFlBQVksTUFBTSxJQUFJLGlCQUFpQjtFQUM5RCxLQUFLLGtCQUFrQixtQkFBbUI7RUFDMUMsS0FBSyxpQkFBaUIsaUJBQWlCLEtBQUssaUJBQWlCLFlBQVksY0FBYyxJQUFJO0VBQzNGLEtBQUssaUJBQWlCLEtBQUssaUJBQWlCLEtBQUssaUJBQWlCLFlBQVksY0FBYyxJQUFJO0VBQ2hHLEtBQUssZ0JBQWdCLGdCQUFnQixZQUFZLGFBQWEsSUFBSSx3QkFBd0IsWUFBWSxLQUFLO0VBQzNHLEtBQUssZ0JBQWdCLGdCQUFnQixZQUFZLGFBQWEsSUFBSSx3QkFBd0IsWUFBWSxHQUFHO0VBQ3pHLEtBQUssMEJBQTBCLDJCQUEyQjtFQUMxRCxLQUFLLGNBQWMsZUFBZTtFQUNsQyxLQUFLLGVBQWUsaUJBQWlCLEtBQUEsSUFBWSxlQUFlO0VBQ2hFLEtBQUssWUFBWTtDQUNuQjtDQUNBLFFBQVE7RUFDTixJQUFJLEtBQUssU0FBUyxLQUFLLEtBQUssS0FBSyxPQUFPO0NBQzFDO0NBQ0EsY0FBYztFQUNaLE1BQU0sb0JBQW9CLGdCQUFnQixZQUFZO0dBQ3BELElBQUksZ0JBQWdCLFdBQVcsU0FBUztJQUN0QyxlQUFlLFlBQVk7SUFDM0IsT0FBTztHQUNUO0dBQ0EsT0FBTyxJQUFJLE9BQU8sU0FBUyxHQUFHO0VBQ2hDO0VBQ0EsS0FBSyxTQUFTLGlCQUFpQixLQUFLLFFBQVEsR0FBRyxLQUFLLE9BQU8sT0FBTyxLQUFLLFFBQVE7RUFDL0UsS0FBSyxpQkFBaUIsaUJBQWlCLEtBQUssZ0JBQWdCLEdBQUcsS0FBSyxTQUFTLEtBQUssZUFBZSxPQUFPLEtBQUssaUJBQWlCLEtBQUssUUFBUTtFQUMzSSxLQUFLLGdCQUFnQixpQkFBaUIsS0FBSyxlQUFlLEdBQUcsS0FBSyxjQUFjLG9FQUFvRSxLQUFLLGVBQWU7Q0FDMUs7Q0FDQSxZQUFZLEtBQUssTUFBTSxLQUFLLFNBQVM7RUFDbkMsSUFBSTtFQUNKLElBQUk7RUFDSixJQUFJO0VBQ0osTUFBTSxjQUFjLEtBQUssV0FBVyxLQUFLLFFBQVEsaUJBQWlCLEtBQUssUUFBUSxjQUFjLG9CQUFvQixDQUFDO0VBQ2xILE1BQU0sZ0JBQWUsUUFBTztHQUMxQixJQUFJLENBQUMsSUFBSSxTQUFTLEtBQUssZUFBZSxHQUFHO0lBQ3ZDLE1BQU0sT0FBTyxxQkFBcUIsTUFBTSxhQUFhLEtBQUssS0FBSyxRQUFRLGNBQWMsS0FBSyxRQUFRLG1CQUFtQjtJQUNySCxPQUFPLEtBQUssZUFBZSxLQUFLLE9BQU8sTUFBTSxLQUFBLEdBQVcsS0FBSztLQUMzRCxHQUFHO0tBQ0gsR0FBRztLQUNILGtCQUFrQjtJQUNwQixDQUFDLElBQUk7R0FDUDtHQUNBLE1BQU0sSUFBSSxJQUFJLE1BQU0sS0FBSyxlQUFlO0dBQ3hDLE1BQU0sSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDLEtBQUs7R0FDekIsTUFBTSxJQUFJLEVBQUUsS0FBSyxLQUFLLGVBQWUsQ0FBQyxDQUFDLEtBQUs7R0FDNUMsT0FBTyxLQUFLLE9BQU8scUJBQXFCLE1BQU0sYUFBYSxHQUFHLEtBQUssUUFBUSxjQUFjLEtBQUssUUFBUSxtQkFBbUIsR0FBRyxHQUFHLEtBQUs7SUFDbEksR0FBRztJQUNILEdBQUc7SUFDSCxrQkFBa0I7R0FDcEIsQ0FBQztFQUNIO0VBQ0EsS0FBSyxZQUFZO0VBQ2pCLElBQUksQ0FBQyxLQUFLLGVBQWUsT0FBTyxRQUFRLFlBQVksd0JBQXdCLEtBQUssR0FBRyxHQUNsRixLQUFLLE9BQU8sS0FBSyxrUkFBaVM7RUFFcFQsTUFBTSw4QkFBOEIsU0FBUywrQkFBK0IsS0FBSyxRQUFRO0VBQ3pGLE1BQU0sa0JBQWtCLFNBQVMsZUFBZSxvQkFBb0IsS0FBQSxJQUFZLFFBQVEsY0FBYyxrQkFBa0IsS0FBSyxRQUFRLGNBQWM7RUFDbkosTUFBTSxRQUFRLENBQUM7R0FDYixPQUFPLEtBQUs7R0FDWixZQUFXLFFBQU87RUFDcEIsR0FBRztHQUNELE9BQU8sS0FBSztHQUNaLFlBQVcsUUFBTyxLQUFLLGNBQWMsS0FBSyxPQUFPLEdBQUcsSUFBSTtFQUMxRCxDQUFDO0VBQ0QsTUFBTSxrQkFBa0IsQ0FBQztFQUN6QixJQUFJLFFBQVE7RUFDWixNQUFNLFNBQVEsU0FBUTtHQUNwQixXQUFXO0dBQ1gsT0FBTyxRQUFRLEtBQUssTUFBTSxLQUFLLEdBQUcsR0FBRztJQUNuQyxNQUFNLEtBQUssTUFBTSxRQUFRO0lBQ3pCLE1BQU0sVUFBVSxnQkFBZ0IsTUFBTSxDQUFDLE9BQU8sU0FBUyxNQUFNLFNBQVMsS0FBSyxHQUFHO0lBQzlFLElBQUksU0FBUztLQUNYLEtBQUssTUFBTSxZQUFZLFFBQVEsS0FBSztLQUNwQztJQUNGO0lBQ0EsTUFBTSxhQUFhLE1BQU0sRUFBRSxDQUFDLEtBQUs7SUFDakMsUUFBUSxhQUFhLFVBQVU7SUFDL0IsSUFBSSxVQUFVLEtBQUEsR0FBVztLQUN2QixJQUFJLE9BQU8sZ0NBQWdDLFlBQVk7TUFDckQsTUFBTSxPQUFPLDRCQUE0QixLQUFLLE9BQU8sT0FBTztNQUM1RCxRQUFRLFNBQVMsSUFBSSxJQUFJLE9BQU87S0FDbEMsT0FBTyxJQUFJLFdBQVcsT0FBTyxVQUFVLGVBQWUsS0FBSyxTQUFTLFVBQVUsR0FDNUUsUUFBUTtVQUNILElBQUksaUJBQWlCO01BQzFCLFFBQVEsTUFBTTtNQUNkO0tBQ0YsT0FBTztNQUNMLEtBQUssT0FBTyxLQUFLLDhCQUE4QixXQUFXLHFCQUFxQixLQUFLO01BQ3BGLFFBQVE7S0FDVjtJQUNGLE9BQU8sSUFBSSxDQUFDLFNBQVMsS0FBSyxLQUFLLENBQUMsS0FBSyxxQkFDbkMsUUFBUSxXQUFXLEtBQUs7SUFFMUIsTUFBTSxZQUFZLFdBQVcsS0FBSyxVQUFVLEtBQUssQ0FBQztJQUNsRCxNQUFNLElBQUksTUFBTSxHQUFHLE1BQU0sS0FBSyxJQUFJLFlBQVksSUFBSSxNQUFNLE1BQU0sUUFBUSxNQUFNLEVBQUUsQ0FBQyxNQUFNO0lBQ3JGLElBQUksaUJBQWlCO0tBQ25CLElBQUksS0FBSyxVQUFVLEtBQUssZ0JBQ3RCLGdCQUFnQixLQUFLLENBQUMsTUFBTSxPQUFPLE1BQU0sUUFBUSxVQUFVLE1BQU0sQ0FBQztVQUVsRSxTQUFTLFVBQVUsU0FBUyxNQUFNLEVBQUUsQ0FBQztLQUV2QyxLQUFLLE1BQU0sYUFBYSxVQUFVO0tBQ2xDLEtBQUssTUFBTSxhQUFhLE1BQU0sRUFBRSxDQUFDO0lBQ25DLE9BQ0UsS0FBSyxNQUFNLFlBQVk7SUFFekI7SUFDQSxJQUFJLFlBQVksS0FBSyxhQUNuQjtHQUVKO0VBQ0YsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLEtBQUssS0FBSyxJQUFJLFVBQVUsQ0FBQyxHQUFHO0VBQzFCLElBQUk7RUFDSixJQUFJO0VBQ0osSUFBSTtFQUNKLE1BQU0sb0JBQW9CLEtBQUsscUJBQXFCO0dBQ2xELE1BQU0sTUFBTSxLQUFLO0dBQ2pCLElBQUksQ0FBQyxJQUFJLFNBQVMsR0FBRyxHQUFHLE9BQU87R0FDL0IsTUFBTSxJQUFJLElBQUksTUFBTSxJQUFJLE9BQU8sR0FBRyxZQUFZLEdBQUcsRUFBRSxNQUFNLENBQUM7R0FDMUQsSUFBSSxnQkFBZ0IsSUFBSSxFQUFFO0dBQzFCLE1BQU0sRUFBRTtHQUNSLGdCQUFnQixLQUFLLFlBQVksZUFBZSxhQUFhO0dBQzdELE1BQU0sc0JBQXNCLGNBQWMsTUFBTSxJQUFJO0dBQ3BELE1BQU0sc0JBQXNCLGNBQWMsTUFBTSxJQUFJO0dBQ3BELEtBQUsscUJBQXFCLFVBQVUsS0FBSyxNQUFNLEtBQUssQ0FBQyx3QkFBd0IscUJBQXFCLFVBQVUsS0FBSyxNQUFNLEdBQ3JILGdCQUFnQixjQUFjLFFBQVEsTUFBTSxJQUFHO0dBRWpELElBQUk7SUFDRixnQkFBZ0IsS0FBSyxNQUFNLGFBQWE7SUFDeEMsSUFBSSxrQkFBa0IsZ0JBQWdCO0tBQ3BDLEdBQUc7S0FDSCxHQUFHO0lBQ0w7R0FDRixTQUFTLEdBQUc7SUFDVixLQUFLLE9BQU8sS0FBSyxvREFBb0QsT0FBTyxDQUFDO0lBQzdFLE9BQU8sR0FBRyxNQUFNLE1BQU07R0FDeEI7R0FDQSxJQUFJLGNBQWMsZ0JBQWdCLGNBQWMsYUFBYSxTQUFTLEtBQUssTUFBTSxHQUFHLE9BQU8sY0FBYztHQUN6RyxPQUFPO0VBQ1Q7RUFDQSxNQUFNLGdCQUFnQixJQUFJLE9BQU8sS0FBSyxhQUFhO0VBQ25ELElBQUksTUFBTTtFQUNWLElBQUksVUFBVTtFQUNkLE9BQU8sUUFBUSxjQUFjLEtBQUssR0FBRyxHQUFHO0dBQ3RDLElBQUksYUFBYSxDQUFDO0dBQ2xCLGdCQUFnQixFQUNkLEdBQUcsUUFDTDtHQUNBLGdCQUFnQixjQUFjLFdBQVcsQ0FBQyxTQUFTLGNBQWMsT0FBTyxJQUFJLGNBQWMsVUFBVTtHQUNwRyxjQUFjLHFCQUFxQjtHQUNuQyxPQUFPLGNBQWM7R0FDckIsTUFBTSxjQUFjLFFBQVEsS0FBSyxNQUFNLEVBQUUsSUFBSSxNQUFNLEVBQUUsQ0FBQyxZQUFZLEdBQUcsSUFBSSxJQUFJLE1BQU0sRUFBRSxDQUFDLFFBQVEsS0FBSyxlQUFlO0dBQ2xILElBQUksZ0JBQWdCLElBQUk7SUFDdEIsYUFBYSxNQUFNLEVBQUUsQ0FBQyxNQUFNLFdBQVcsQ0FBQyxDQUFDLE1BQU0sS0FBSyxlQUFlLENBQUMsQ0FBQyxLQUFJLFNBQVEsS0FBSyxLQUFLLENBQUMsQ0FBQyxDQUFDLE9BQU8sT0FBTztJQUM1RyxNQUFNLEtBQUssTUFBTSxFQUFFLENBQUMsTUFBTSxHQUFHLFdBQVc7R0FDMUM7R0FDQSxRQUFRLEdBQUcsaUJBQWlCLEtBQUssTUFBTSxNQUFNLEVBQUUsQ0FBQyxLQUFLLEdBQUcsYUFBYSxHQUFHLGFBQWE7R0FDckYsSUFBSSxTQUFTLE1BQU0sT0FBTyxPQUFPLENBQUMsU0FBUyxLQUFLLEdBQUcsT0FBTztHQUMxRCxJQUFJLENBQUMsU0FBUyxLQUFLLEdBQUcsUUFBUSxXQUFXLEtBQUs7R0FDOUMsSUFBSSxDQUFDLE9BQU87SUFDVixLQUFLLE9BQU8sS0FBSyxxQkFBcUIsTUFBTSxHQUFHLGVBQWUsS0FBSztJQUNuRSxRQUFRO0dBQ1Y7R0FDQSxJQUFJLFdBQVcsUUFDYixRQUFRLFdBQVcsUUFBUSxHQUFHLE1BQU0sS0FBSyxPQUFPLEdBQUcsR0FBRyxRQUFRLEtBQUs7SUFDakUsR0FBRztJQUNILGtCQUFrQixNQUFNLEVBQUUsQ0FBQyxLQUFLO0dBQ2xDLENBQUMsR0FBRyxNQUFNLEtBQUssQ0FBQztHQUVsQixPQUFPLElBQUksTUFBTSxTQUFTLE1BQU0sS0FBSyxJQUFJLFdBQVcsS0FBSztHQUN6RCxVQUFVLGNBQWM7R0FDeEIsS0FBSyxPQUFPLFlBQVk7RUFDMUI7RUFDQSxPQUFPLFVBQVUsTUFBTSxJQUFJLE1BQU0sT0FBTyxJQUFJO0NBQzlDO0FBQ0Y7QUFFQSxJQUFNLGtCQUFpQixjQUFhO0NBQ2xDLElBQUksYUFBYSxVQUFVLFlBQVksQ0FBQyxDQUFDLEtBQUs7Q0FDOUMsTUFBTSxnQkFBZ0IsQ0FBQztDQUN2QixJQUFJLFVBQVUsU0FBUyxHQUFHLEdBQUc7RUFDM0IsTUFBTSxJQUFJLFVBQVUsTUFBTSxHQUFHO0VBQzdCLGFBQWEsRUFBRSxFQUFFLENBQUMsWUFBWSxDQUFDLENBQUMsS0FBSztFQUNyQyxNQUFNLFNBQVMsRUFBRSxFQUFFLENBQUMsTUFBTSxHQUFHLEVBQUU7RUFDL0IsSUFBSSxlQUFlLGNBQWMsQ0FBQyxPQUFPLFNBQVMsR0FBRyxHQUMvQztPQUFBLENBQUMsY0FBYyxVQUFVLGNBQWMsV0FBVyxPQUFPLEtBQUs7RUFBQSxPQUM3RCxJQUFJLGVBQWUsa0JBQWtCLENBQUMsT0FBTyxTQUFTLEdBQUcsR0FDMUQ7T0FBQSxDQUFDLGNBQWMsT0FBTyxjQUFjLFFBQVEsT0FBTyxLQUFLO0VBQUEsT0FHNUQsT0FEb0IsTUFBTSxHQUN2QixDQUFDLENBQUMsU0FBUSxRQUFPO0dBQ2xCLElBQUksS0FBSztJQUNQLE1BQU0sQ0FBQyxLQUFLLEdBQUcsUUFBUSxJQUFJLE1BQU0sR0FBRztJQUNwQyxNQUFNLE1BQU0sS0FBSyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsWUFBWSxFQUFFO0lBQ3hELE1BQU0sYUFBYSxJQUFJLEtBQUs7SUFDNUIsSUFBSSxDQUFDLGNBQWMsYUFBYSxjQUFjLGNBQWM7SUFDNUQsSUFBSSxRQUFRLFNBQVMsY0FBYyxjQUFjO0lBQ2pELElBQUksUUFBUSxRQUFRLGNBQWMsY0FBYztJQUNoRCxJQUFJLENBQUMsTUFBTSxHQUFHLEdBQUcsY0FBYyxjQUFjLFNBQVMsS0FBSyxFQUFFO0dBQy9EO0VBQ0YsQ0FBQztDQUVMO0NBQ0EsT0FBTztFQUNMO0VBQ0E7Q0FDRjtBQUNGO0FBQ0EsSUFBTSx5QkFBd0IsT0FBTTtDQUNsQyxNQUFNLFFBQVEsQ0FBQztDQUNmLFFBQVEsR0FBRyxHQUFHLE1BQU07RUFDbEIsSUFBSSxjQUFjO0VBQ2xCLElBQUksS0FBSyxFQUFFLG9CQUFvQixFQUFFLGdCQUFnQixFQUFFLGFBQWEsRUFBRSxxQkFBcUIsRUFBRSxFQUFFLG1CQUN6RixjQUFjO0dBQ1osR0FBRztJQUNGLEVBQUUsbUJBQW1CLEtBQUE7RUFDeEI7RUFFRixJQUFJO0VBQ0osSUFBSTtHQUNGLE1BQU0sSUFBSSxLQUFLLFVBQVUsV0FBVztFQUN0QyxTQUFTLEdBQUc7R0FDVixPQUFPLEdBQUcsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNuQztFQUNBLElBQUksTUFBTSxNQUFNO0VBQ2hCLElBQUksQ0FBQyxLQUFLO0dBQ1IsTUFBTSxHQUFHLGVBQWUsQ0FBQyxHQUFHLENBQUM7R0FDN0IsTUFBTSxPQUFPO0VBQ2Y7RUFDQSxPQUFPLElBQUksQ0FBQztDQUNkO0FBQ0Y7QUFDQSxJQUFNLDRCQUEyQixRQUFPLEdBQUcsR0FBRyxNQUFNLEdBQUcsZUFBZSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM5RSxJQUFNLFlBQU4sTUFBZ0I7Q0FDZCxZQUFZLFVBQVUsQ0FBQyxHQUFHO0VBQ3hCLEtBQUssU0FBUyxXQUFXLE9BQU8sV0FBVztFQUMzQyxLQUFLLFVBQVU7RUFDZixLQUFLLEtBQUssT0FBTztDQUNuQjtDQUNBLEtBQUssVUFBVSxVQUFVLEVBQ3ZCLGVBQWUsQ0FBQyxFQUNsQixHQUFHO0VBQ0QsS0FBSyxrQkFBa0IsUUFBUSxjQUFjLG1CQUFtQjtFQUNoRSxNQUFNLEtBQUssUUFBUSxzQkFBc0Isd0JBQXdCO0VBQ2pFLEtBQUssVUFBVTtHQUNiLFFBQVEsSUFBSSxLQUFLLFFBQVE7SUFDdkIsTUFBTSxZQUFZLElBQUksS0FBSyxhQUFhLEtBQUssRUFDM0MsR0FBRyxJQUNMLENBQUM7SUFDRCxRQUFPLFFBQU8sVUFBVSxPQUFPLEdBQUc7R0FDcEMsQ0FBQztHQUNELFVBQVUsSUFBSSxLQUFLLFFBQVE7SUFDekIsTUFBTSxZQUFZLElBQUksS0FBSyxhQUFhLEtBQUs7S0FDM0MsR0FBRztLQUNILE9BQU87SUFDVCxDQUFDO0lBQ0QsUUFBTyxRQUFPLFVBQVUsT0FBTyxHQUFHO0dBQ3BDLENBQUM7R0FDRCxVQUFVLElBQUksS0FBSyxRQUFRO0lBQ3pCLE1BQU0sWUFBWSxJQUFJLEtBQUssZUFBZSxLQUFLLEVBQzdDLEdBQUcsSUFDTCxDQUFDO0lBQ0QsUUFBTyxRQUFPLFVBQVUsT0FBTyxHQUFHO0dBQ3BDLENBQUM7R0FDRCxjQUFjLElBQUksS0FBSyxRQUFRO0lBQzdCLE1BQU0sWUFBWSxJQUFJLEtBQUssbUJBQW1CLEtBQUssRUFDakQsR0FBRyxJQUNMLENBQUM7SUFDRCxRQUFPLFFBQU8sVUFBVSxPQUFPLEtBQUssSUFBSSxTQUFTLEtBQUs7R0FDeEQsQ0FBQztHQUNELE1BQU0sSUFBSSxLQUFLLFFBQVE7SUFDckIsTUFBTSxZQUFZLElBQUksS0FBSyxXQUFXLEtBQUssRUFDekMsR0FBRyxJQUNMLENBQUM7SUFDRCxRQUFPLFFBQU8sVUFBVSxPQUFPLEdBQUc7R0FDcEMsQ0FBQztFQUNIO0NBQ0Y7Q0FDQSxJQUFJLE1BQU0sSUFBSTtFQUNaLEtBQUssUUFBUSxLQUFLLFlBQVksQ0FBQyxDQUFDLEtBQUssS0FBSztDQUM1QztDQUNBLFVBQVUsTUFBTSxJQUFJO0VBQ2xCLEtBQUssUUFBUSxLQUFLLFlBQVksQ0FBQyxDQUFDLEtBQUssS0FBSyxzQkFBc0IsRUFBRTtDQUNwRTtDQUNBLE9BQU8sT0FBTyxRQUFRLEtBQUssVUFBVSxDQUFDLEdBQUc7RUFDdkMsSUFBSSxDQUFDLFFBQVEsT0FBTztFQUNwQixJQUFJLFNBQVMsTUFBTSxPQUFPO0VBQzFCLE1BQU0sYUFBYSxPQUFPLE1BQU0sS0FBSyxlQUFlO0VBQ3BELE1BQU0sVUFBVSxDQUFDO0VBQ2pCLEtBQUssSUFBSSxJQUFJLEdBQUcsSUFBSSxXQUFXLFFBQVEsS0FBSztHQUMxQyxJQUFJLElBQUksV0FBVztHQUNuQixPQUFPLEVBQUUsUUFBUSxHQUFHLElBQUksTUFBTSxDQUFDLEVBQUUsU0FBUyxHQUFHLEtBQUssSUFBSSxJQUFJLFdBQVcsUUFDbkUsSUFBSSxHQUFHLElBQUksS0FBSyxrQkFBa0IsV0FBVyxFQUFFO0dBRWpELFFBQVEsS0FBSyxDQUFDO0VBQ2hCO0VBeUJBLE9BeEJlLFFBQVEsUUFBUSxLQUFLLE1BQU07R0FDeEMsTUFBTSxFQUNKLFlBQ0Esa0JBQ0UsZUFBZSxDQUFDO0dBQ3BCLElBQUksS0FBSyxRQUFRLGFBQWE7SUFDNUIsSUFBSSxZQUFZO0lBQ2hCLElBQUk7S0FDRixNQUFNLGFBQWEsU0FBUyxlQUFlLFFBQVEscUJBQXFCLENBQUM7S0FDekUsTUFBTSxJQUFJLFdBQVcsVUFBVSxXQUFXLE9BQU8sUUFBUSxVQUFVLFFBQVEsT0FBTztLQUNsRixZQUFZLEtBQUssUUFBUSxXQUFXLENBQUMsS0FBSyxHQUFHO01BQzNDLEdBQUc7TUFDSCxHQUFHO01BQ0gsR0FBRztLQUNMLENBQUM7SUFDSCxTQUFTLE9BQU87S0FDZCxLQUFLLE9BQU8sS0FBSyxLQUFLO0lBQ3hCO0lBQ0EsT0FBTztHQUNULE9BQ0UsS0FBSyxPQUFPLEtBQUssb0NBQW9DLFlBQVk7R0FFbkUsT0FBTztFQUNULEdBQUcsS0FDUztDQUNkO0FBQ0Y7QUFFQSxJQUFNLGlCQUFpQixHQUFHLFNBQVM7Q0FDakMsSUFBSSxFQUFFLFFBQVEsVUFBVSxLQUFBLEdBQVc7RUFDakMsT0FBTyxFQUFFLFFBQVE7RUFDakIsRUFBRTtDQUNKO0FBQ0Y7QUFDQSxJQUFNLFlBQU4sY0FBd0IsYUFBYTtDQUNuQyxZQUFZLFNBQVMsT0FBTyxVQUFVLFVBQVUsQ0FBQyxHQUFHO0VBQ2xELE1BQU07RUFDTixLQUFLLFVBQVU7RUFDZixLQUFLLFFBQVE7RUFDYixLQUFLLFdBQVc7RUFDaEIsS0FBSyxnQkFBZ0IsU0FBUztFQUM5QixLQUFLLFVBQVU7RUFDZixLQUFLLFNBQVMsV0FBVyxPQUFPLGtCQUFrQjtFQUNsRCxLQUFLLGVBQWUsQ0FBQztFQUNyQixLQUFLLG1CQUFtQixRQUFRLG9CQUFvQjtFQUNwRCxLQUFLLGVBQWU7RUFDcEIsS0FBSyxhQUFhLFFBQVEsY0FBYyxJQUFJLFFBQVEsYUFBYTtFQUNqRSxLQUFLLGVBQWUsUUFBUSxnQkFBZ0IsSUFBSSxRQUFRLGVBQWU7RUFDdkUsS0FBSyxRQUFRLENBQUM7RUFDZCxLQUFLLFFBQVEsQ0FBQztFQUNkLEtBQUssU0FBUyxPQUFPLFVBQVUsUUFBUSxTQUFTLE9BQU87Q0FDekQ7Q0FDQSxVQUFVLFdBQVcsWUFBWSxTQUFTLFVBQVU7RUFDbEQsTUFBTSxTQUFTLENBQUM7RUFDaEIsTUFBTSxVQUFVLENBQUM7RUFDakIsTUFBTSxrQkFBa0IsQ0FBQztFQUN6QixNQUFNLG1CQUFtQixDQUFDO0VBQzFCLFVBQVUsU0FBUSxRQUFPO0dBQ3ZCLElBQUksbUJBQW1CO0dBQ3ZCLFdBQVcsU0FBUSxPQUFNO0lBQ3ZCLE1BQU0sT0FBTyxHQUFHLElBQUksR0FBRztJQUN2QixJQUFJLENBQUMsUUFBUSxVQUFVLEtBQUssTUFBTSxrQkFBa0IsS0FBSyxFQUFFLEdBQ3pELEtBQUssTUFBTSxRQUFRO1NBQ2QsSUFBSSxLQUFLLE1BQU0sUUFBUTtTQUFVLElBQUksS0FBSyxNQUFNLFVBQVUsR0FDM0Q7U0FBQSxRQUFRLFVBQVUsS0FBQSxHQUFXLFFBQVEsUUFBUTtJQUFBLE9BQzVDO0tBQ0wsS0FBSyxNQUFNLFFBQVE7S0FDbkIsbUJBQW1CO0tBQ25CLElBQUksUUFBUSxVQUFVLEtBQUEsR0FBVyxRQUFRLFFBQVE7S0FDakQsSUFBSSxPQUFPLFVBQVUsS0FBQSxHQUFXLE9BQU8sUUFBUTtLQUMvQyxJQUFJLGlCQUFpQixRQUFRLEtBQUEsR0FBVyxpQkFBaUIsTUFBTTtJQUNqRTtHQUNGLENBQUM7R0FDRCxJQUFJLENBQUMsa0JBQWtCLGdCQUFnQixPQUFPO0VBQ2hELENBQUM7RUFDRCxJQUFJLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBQyxVQUFVLE9BQU8sS0FBSyxPQUFPLENBQUMsQ0FBQyxRQUNyRCxLQUFLLE1BQU0sS0FBSztHQUNkO0dBQ0EsY0FBYyxPQUFPLEtBQUssT0FBTyxDQUFDLENBQUM7R0FDbkMsUUFBUSxDQUFDO0dBQ1QsUUFBUSxDQUFDO0dBQ1Q7RUFDRixDQUFDO0VBRUgsT0FBTztHQUNMLFFBQVEsT0FBTyxLQUFLLE1BQU07R0FDMUIsU0FBUyxPQUFPLEtBQUssT0FBTztHQUM1QixpQkFBaUIsT0FBTyxLQUFLLGVBQWU7R0FDNUMsa0JBQWtCLE9BQU8sS0FBSyxnQkFBZ0I7RUFDaEQ7Q0FDRjtDQUNBLE9BQU8sTUFBTSxLQUFLLE1BQU07RUFDdEIsTUFBTSxJQUFJLEtBQUssTUFBTSxHQUFHO0VBQ3hCLE1BQU0sTUFBTSxFQUFFO0VBQ2QsTUFBTSxLQUFLLEVBQUU7RUFDYixJQUFJLEtBQUssS0FBSyxLQUFLLGlCQUFpQixLQUFLLElBQUksR0FBRztFQUNoRCxJQUFJLENBQUMsT0FBTyxNQUNWLEtBQUssTUFBTSxrQkFBa0IsS0FBSyxJQUFJLE1BQU0sS0FBQSxHQUFXLEtBQUEsR0FBVyxFQUNoRSxVQUFVLEtBQ1osQ0FBQztFQUVILEtBQUssTUFBTSxRQUFRLE1BQU0sS0FBSztFQUM5QixJQUFJLE9BQU8sTUFBTSxLQUFLLE1BQU0sUUFBUTtFQUNwQyxNQUFNLFNBQVMsQ0FBQztFQUNoQixLQUFLLE1BQU0sU0FBUSxNQUFLO0dBQ3RCLFNBQVMsRUFBRSxRQUFRLENBQUMsR0FBRyxHQUFHLEVBQUU7R0FDNUIsY0FBYyxHQUFHLElBQUk7R0FDckIsSUFBSSxLQUFLLEVBQUUsT0FBTyxLQUFLLEdBQUc7R0FDMUIsSUFBSSxFQUFFLGlCQUFpQixLQUFLLENBQUMsRUFBRSxNQUFNO0lBQ25DLE9BQU8sS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFDLFNBQVEsTUFBSztLQUNqQyxJQUFJLENBQUMsT0FBTyxJQUFJLE9BQU8sS0FBSyxDQUFDO0tBQzdCLE1BQU0sYUFBYSxFQUFFLE9BQU87S0FDNUIsSUFBSSxXQUFXLFFBQ2IsV0FBVyxTQUFRLE1BQUs7TUFDdEIsSUFBSSxPQUFPLEVBQUUsQ0FBQyxPQUFPLEtBQUEsR0FBVyxPQUFPLEVBQUUsQ0FBQyxLQUFLO0tBQ2pELENBQUM7SUFFTCxDQUFDO0lBQ0QsRUFBRSxPQUFPO0lBQ1QsSUFBSSxFQUFFLE9BQU8sUUFDWCxFQUFFLFNBQVMsRUFBRSxNQUFNO1NBRW5CLEVBQUUsU0FBUztHQUVmO0VBQ0YsQ0FBQztFQUNELEtBQUssS0FBSyxVQUFVLE1BQU07RUFDMUIsS0FBSyxRQUFRLEtBQUssTUFBTSxRQUFPLE1BQUssQ0FBQyxFQUFFLElBQUk7Q0FDN0M7Q0FDQSxLQUFLLEtBQUssSUFBSSxRQUFRLFFBQVEsR0FBRyxPQUFPLEtBQUssY0FBYyxVQUFVO0VBQ25FLElBQUksQ0FBQyxJQUFJLFFBQVEsT0FBTyxTQUFTLE1BQU0sQ0FBQyxDQUFDO0VBQ3pDLElBQUksS0FBSyxnQkFBZ0IsS0FBSyxrQkFBa0I7R0FDOUMsS0FBSyxhQUFhLEtBQUs7SUFDckI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBO0dBQ0YsQ0FBQztHQUNEO0VBQ0Y7RUFDQSxLQUFLO0VBQ0wsTUFBTSxZQUFZLEtBQUssU0FBUztHQUM5QixLQUFLO0dBQ0wsSUFBSSxLQUFLLGFBQWEsU0FBUyxHQUFHO0lBQ2hDLE1BQU0sT0FBTyxLQUFLLGFBQWEsTUFBTTtJQUNyQyxLQUFLLEtBQUssS0FBSyxLQUFLLEtBQUssSUFBSSxLQUFLLFFBQVEsS0FBSyxPQUFPLEtBQUssTUFBTSxLQUFLLFFBQVE7R0FDaEY7R0FDQSxJQUFJLE9BQU8sUUFBUSxRQUFRLEtBQUssWUFBWTtJQUMxQyxpQkFBaUI7S0FDZixLQUFLLEtBQUssS0FBSyxJQUFJLFFBQVEsUUFBUSxHQUFHLE9BQU8sR0FBRyxRQUFRO0lBQzFELEdBQUcsSUFBSTtJQUNQO0dBQ0Y7R0FDQSxTQUFTLEtBQUssSUFBSTtFQUNwQjtFQUNBLE1BQU0sS0FBSyxLQUFLLFFBQVEsT0FBTyxDQUFDLEtBQUssS0FBSyxPQUFPO0VBQ2pELElBQUksR0FBRyxXQUFXLEdBQUc7R0FDbkIsSUFBSTtJQUNGLE1BQU0sSUFBSSxHQUFHLEtBQUssRUFBRTtJQUNwQixJQUFJLEtBQUssT0FBTyxFQUFFLFNBQVMsWUFDekIsRUFBRSxNQUFLLFNBQVEsU0FBUyxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxRQUFRO1NBRW5ELFNBQVMsTUFBTSxDQUFDO0dBRXBCLFNBQVMsS0FBSztJQUNaLFNBQVMsR0FBRztHQUNkO0dBQ0E7RUFDRjtFQUNBLE9BQU8sR0FBRyxLQUFLLElBQUksUUFBUTtDQUM3QjtDQUNBLGVBQWUsV0FBVyxZQUFZLFVBQVUsQ0FBQyxHQUFHLFVBQVU7RUFDNUQsSUFBSSxDQUFDLEtBQUssU0FBUztHQUNqQixLQUFLLE9BQU8sS0FBSyxnRUFBZ0U7R0FDakYsT0FBTyxZQUFZLFNBQVM7RUFDOUI7RUFDQSxJQUFJLFNBQVMsU0FBUyxHQUFHLFlBQVksS0FBSyxjQUFjLG1CQUFtQixTQUFTO0VBQ3BGLElBQUksU0FBUyxVQUFVLEdBQUcsYUFBYSxDQUFDLFVBQVU7RUFDbEQsTUFBTSxTQUFTLEtBQUssVUFBVSxXQUFXLFlBQVksU0FBUyxRQUFRO0VBQ3RFLElBQUksQ0FBQyxPQUFPLE9BQU8sUUFBUTtHQUN6QixJQUFJLENBQUMsT0FBTyxRQUFRLFFBQVEsU0FBUztHQUNyQyxPQUFPO0VBQ1Q7RUFDQSxPQUFPLE9BQU8sU0FBUSxTQUFRO0dBQzVCLEtBQUssUUFBUSxJQUFJO0VBQ25CLENBQUM7Q0FDSDtDQUNBLEtBQUssV0FBVyxZQUFZLFVBQVU7RUFDcEMsS0FBSyxlQUFlLFdBQVcsWUFBWSxDQUFDLEdBQUcsUUFBUTtDQUN6RDtDQUNBLE9BQU8sV0FBVyxZQUFZLFVBQVU7RUFDdEMsS0FBSyxlQUFlLFdBQVcsWUFBWSxFQUN6QyxRQUFRLEtBQ1YsR0FBRyxRQUFRO0NBQ2I7Q0FDQSxRQUFRLE1BQU0sU0FBUyxJQUFJO0VBQ3pCLE1BQU0sSUFBSSxLQUFLLE1BQU0sR0FBRztFQUN4QixNQUFNLE1BQU0sRUFBRTtFQUNkLE1BQU0sS0FBSyxFQUFFO0VBQ2IsS0FBSyxLQUFLLEtBQUssSUFBSSxRQUFRLEtBQUEsR0FBVyxLQUFBLElBQVksS0FBSyxTQUFTO0dBQzlELElBQUksS0FBSyxLQUFLLE9BQU8sS0FBSyxHQUFHLE9BQU8sb0JBQW9CLEdBQUcsZ0JBQWdCLElBQUksVUFBVSxHQUFHO0dBQzVGLElBQUksQ0FBQyxPQUFPLE1BQU0sS0FBSyxPQUFPLElBQUksR0FBRyxPQUFPLG1CQUFtQixHQUFHLGdCQUFnQixPQUFPLElBQUk7R0FDN0YsS0FBSyxPQUFPLE1BQU0sS0FBSyxJQUFJO0VBQzdCLENBQUM7Q0FDSDtDQUNBLFlBQVksV0FBVyxXQUFXLEtBQUssZUFBZSxVQUFVLFVBQVUsQ0FBQyxHQUFHLFlBQVksQ0FBQyxHQUFHO0VBQzVGLElBQUksS0FBSyxVQUFVLE9BQU8sc0JBQXNCLENBQUMsS0FBSyxVQUFVLE9BQU8sbUJBQW1CLFNBQVMsR0FBRztHQUNwRyxLQUFLLE9BQU8sS0FBSyxxQkFBcUIsSUFBSSxzQkFBc0IsVUFBVSx1QkFBdUIsME5BQTBOO0dBQzNUO0VBQ0Y7RUFDQSxJQUFJLFFBQVEsS0FBQSxLQUFhLFFBQVEsUUFBUSxRQUFRLElBQUk7RUFDckQsSUFBSSxLQUFLLFNBQVMsUUFBUTtHQUN4QixNQUFNLE9BQU87SUFDWCxHQUFHO0lBQ0g7R0FDRjtHQUNBLE1BQU0sS0FBSyxLQUFLLFFBQVEsT0FBTyxLQUFLLEtBQUssT0FBTztHQUNoRCxJQUFJLEdBQUcsU0FBUyxHQUNkLElBQUk7SUFDRixJQUFJO0lBQ0osSUFBSSxHQUFHLFdBQVcsR0FDaEIsSUFBSSxHQUFHLFdBQVcsV0FBVyxLQUFLLGVBQWUsSUFBSTtTQUVyRCxJQUFJLEdBQUcsV0FBVyxXQUFXLEtBQUssYUFBYTtJQUVqRCxJQUFJLEtBQUssT0FBTyxFQUFFLFNBQVMsWUFDekIsRUFBRSxNQUFLLFNBQVEsSUFBSSxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsTUFBTSxHQUFHO1NBRXpDLElBQUksTUFBTSxDQUFDO0dBRWYsU0FBUyxLQUFLO0lBQ1osSUFBSSxHQUFHO0dBQ1Q7UUFFQSxHQUFHLFdBQVcsV0FBVyxLQUFLLGVBQWUsS0FBSyxJQUFJO0VBRTFEO0VBQ0EsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLElBQUk7RUFDakMsS0FBSyxNQUFNLFlBQVksVUFBVSxJQUFJLFdBQVcsS0FBSyxhQUFhO0NBQ3BFO0FBQ0Y7QUFFQSxJQUFNLGFBQWE7Q0FDakIsT0FBTztDQUNQLFdBQVc7Q0FDWCxJQUFJLENBQUMsYUFBYTtDQUNsQixXQUFXLENBQUMsYUFBYTtDQUN6QixhQUFhLENBQUMsS0FBSztDQUNuQixZQUFZO0NBQ1osZUFBZTtDQUNmLDBCQUEwQjtDQUMxQixNQUFNO0NBQ04sU0FBUztDQUNULGNBQWM7Q0FDZCxhQUFhO0NBQ2IsaUJBQWlCO0NBQ2pCLGtCQUFrQjtDQUNsQixnQkFBZ0I7Q0FDaEIseUJBQXlCO0NBQ3pCLGFBQWE7Q0FDYixlQUFlO0NBQ2YsZUFBZTtDQUNmLG9CQUFvQjtDQUNwQixtQkFBbUI7Q0FDbkIsNkJBQTZCO0NBQzdCLGFBQWE7Q0FDYix5QkFBeUI7Q0FDekIsWUFBWTtDQUNaLG1CQUFtQjtDQUNuQixlQUFlO0NBQ2YsWUFBWTtDQUNaLHVCQUF1QjtDQUN2Qix3QkFBd0I7Q0FDeEIsNkJBQTZCO0NBQzdCLHlCQUF5QjtDQUN6QixtQ0FBa0MsU0FBUTtFQUN4QyxJQUFJLE1BQU0sQ0FBQztFQUNYLElBQUksT0FBTyxLQUFLLE9BQU8sVUFBVSxNQUFNLEtBQUs7RUFDNUMsSUFBSSxTQUFTLEtBQUssRUFBRSxHQUFHLElBQUksZUFBZSxLQUFLO0VBQy9DLElBQUksU0FBUyxLQUFLLEVBQUUsR0FBRyxJQUFJLGVBQWUsS0FBSztFQUMvQyxJQUFJLE9BQU8sS0FBSyxPQUFPLFlBQVksT0FBTyxLQUFLLE9BQU8sVUFBVTtHQUM5RCxNQUFNLFVBQVUsS0FBSyxNQUFNLEtBQUs7R0FDaEMsT0FBTyxLQUFLLE9BQU8sQ0FBQyxDQUFDLFNBQVEsUUFBTztJQUNsQyxJQUFJLE9BQU8sUUFBUTtHQUNyQixDQUFDO0VBQ0g7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxlQUFlO0VBQ2IsYUFBYTtFQUNiLFFBQVE7RUFDUixRQUFRO0VBQ1IsaUJBQWlCO0VBQ2pCLGdCQUFnQjtFQUNoQixlQUFlO0VBQ2YsZUFBZTtFQUNmLHlCQUF5QjtFQUN6QixhQUFhO0VBQ2IsaUJBQWlCO0NBQ25CO0NBQ0EscUJBQXFCO0FBQ3ZCO0FBQ0EsSUFBTSxvQkFBbUIsWUFBVztDQUNsQyxJQUFJLFNBQVMsUUFBUSxFQUFFLEdBQUcsUUFBUSxLQUFLLENBQUMsUUFBUSxFQUFFO0NBQ2xELElBQUksU0FBUyxRQUFRLFdBQVcsR0FBRyxRQUFRLGNBQWMsQ0FBQyxRQUFRLFdBQVc7Q0FDN0UsSUFBSSxTQUFTLFFBQVEsVUFBVSxHQUFHLFFBQVEsYUFBYSxDQUFDLFFBQVEsVUFBVTtDQUMxRSxJQUFJLFFBQVEsaUJBQWlCLENBQUMsUUFBUSxjQUFjLFNBQVMsUUFBUSxHQUNuRSxRQUFRLGdCQUFnQixRQUFRLGNBQWMsT0FBTyxDQUFDLFFBQVEsQ0FBQztDQUVqRSxPQUFPO0FBQ1Q7QUFFQSxJQUFNLGFBQWEsQ0FBQztBQUNwQixJQUFNLHVCQUFzQixTQUFRO0NBRWxDLE9BRG9CLG9CQUFvQixPQUFPLGVBQWUsSUFBSSxDQUMvRCxDQUFDLENBQUMsU0FBUSxRQUFPO0VBQ2xCLElBQUksT0FBTyxLQUFLLFNBQVMsWUFDdkIsS0FBSyxPQUFPLEtBQUssSUFBSSxDQUFDLEtBQUssSUFBSTtDQUVuQyxDQUFDO0FBQ0g7QUEyZkEsSUFBTSxXQUFXLE1BMWZYLGFBQWEsYUFBYTtDQUM5QixZQUFZLFVBQVUsQ0FBQyxHQUFHLFVBQVU7RUFDbEMsTUFBTTtFQUNOLEtBQUssVUFBVSxpQkFBaUIsT0FBTztFQUN2QyxLQUFLLFdBQVcsQ0FBQztFQUNqQixLQUFLLFNBQVM7RUFDZCxLQUFLLFVBQVUsRUFDYixVQUFVLENBQUMsRUFDYjtFQUNBLG9CQUFvQixJQUFJO0VBQ3hCLElBQUksWUFBWSxDQUFDLEtBQUssaUJBQWlCLENBQUMsUUFBUSxTQUFTO0dBQ3ZELElBQUksQ0FBQyxLQUFLLFFBQVEsV0FBVztJQUMzQixLQUFLLEtBQUssU0FBUyxRQUFRO0lBQzNCLE9BQU87R0FDVDtHQUNBLGlCQUFpQjtJQUNmLEtBQUssS0FBSyxTQUFTLFFBQVE7R0FDN0IsR0FBRyxDQUFDO0VBQ047Q0FDRjtDQUNBLEtBQUssVUFBVSxDQUFDLEdBQUcsVUFBVTtFQUMzQixLQUFLLGlCQUFpQjtFQUN0QixJQUFJLE9BQU8sWUFBWSxZQUFZO0dBQ2pDLFdBQVc7R0FDWCxVQUFVLENBQUM7RUFDYjtFQUNBLElBQUksUUFBUSxhQUFhLFFBQVEsUUFBUSxJQUFJO0dBQzNDLElBQUksU0FBUyxRQUFRLEVBQUUsR0FDckIsUUFBUSxZQUFZLFFBQVE7UUFDdkIsSUFBSSxDQUFDLFFBQVEsR0FBRyxTQUFTLGFBQWEsR0FDM0MsUUFBUSxZQUFZLFFBQVEsR0FBRztFQUVuQztFQUNBLE1BQU0sVUFBVSxJQUFJO0VBQ3BCLEtBQUssVUFBVTtHQUNiLEdBQUc7R0FDSCxHQUFHLEtBQUs7R0FDUixHQUFHLGlCQUFpQixPQUFPO0VBQzdCO0VBQ0EsS0FBSyxRQUFRLGdCQUFnQjtHQUMzQixHQUFHLFFBQVE7R0FDWCxHQUFHLEtBQUssUUFBUTtFQUNsQjtFQUNBLElBQUksUUFBUSxpQkFBaUIsS0FBQSxHQUMzQixLQUFLLFFBQVEsMEJBQTBCLFFBQVE7RUFFakQsSUFBSSxRQUFRLGdCQUFnQixLQUFBLEdBQzFCLEtBQUssUUFBUSx5QkFBeUIsUUFBUTtFQUVoRCxJQUFJLE9BQU8sS0FBSyxRQUFRLHFDQUFxQyxZQUMzRCxLQUFLLFFBQVEsbUNBQW1DLFFBQVE7RUFFMUQsTUFBTSx1QkFBc0Isa0JBQWlCO0dBQzNDLElBQUksQ0FBQyxlQUFlLE9BQU87R0FDM0IsSUFBSSxPQUFPLGtCQUFrQixZQUFZLE9BQU8sSUFBSSxjQUFjO0dBQ2xFLE9BQU87RUFDVDtFQUNBLElBQUksQ0FBQyxLQUFLLFFBQVEsU0FBUztHQUN6QixJQUFJLEtBQUssUUFBUSxRQUNmLFdBQVcsS0FBSyxvQkFBb0IsS0FBSyxRQUFRLE1BQU0sR0FBRyxLQUFLLE9BQU87UUFFdEUsV0FBVyxLQUFLLE1BQU0sS0FBSyxPQUFPO0dBRXBDLElBQUk7R0FDSixJQUFJLEtBQUssUUFBUSxXQUNmLFlBQVksS0FBSyxRQUFRO1FBRXpCLFlBQVk7R0FFZCxNQUFNLEtBQUssSUFBSSxhQUFhLEtBQUssT0FBTztHQUN4QyxLQUFLLFFBQVEsSUFBSSxjQUFjLEtBQUssUUFBUSxXQUFXLEtBQUssT0FBTztHQUNuRSxNQUFNLElBQUksS0FBSztHQUNmLEVBQUUsU0FBUztHQUNYLEVBQUUsZ0JBQWdCLEtBQUs7R0FDdkIsRUFBRSxnQkFBZ0I7R0FDbEIsRUFBRSxpQkFBaUIsSUFBSSxlQUFlLElBQUksRUFDeEMsU0FBUyxLQUFLLFFBQVEsZ0JBQ3hCLENBQUM7R0FDRCxJQUFJLFdBQVc7SUFDYixFQUFFLFlBQVksb0JBQW9CLFNBQVM7SUFDM0MsSUFBSSxFQUFFLFVBQVUsTUFBTSxFQUFFLFVBQVUsS0FBSyxHQUFHLEtBQUssT0FBTztJQUN0RCxLQUFLLFFBQVEsY0FBYyxTQUFTLEVBQUUsVUFBVSxPQUFPLEtBQUssRUFBRSxTQUFTO0dBQ3pFO0dBQ0EsRUFBRSxlQUFlLElBQUksYUFBYSxLQUFLLE9BQU87R0FDOUMsRUFBRSxRQUFRLEVBQ1Isb0JBQW9CLEtBQUssbUJBQW1CLEtBQUssSUFBSSxFQUN2RDtHQUNBLEVBQUUsbUJBQW1CLElBQUksVUFBVSxvQkFBb0IsS0FBSyxRQUFRLE9BQU8sR0FBRyxFQUFFLGVBQWUsR0FBRyxLQUFLLE9BQU87R0FDOUcsRUFBRSxpQkFBaUIsR0FBRyxNQUFNLE9BQU8sR0FBRyxTQUFTO0lBQzdDLEtBQUssS0FBSyxPQUFPLEdBQUcsSUFBSTtHQUMxQixDQUFDO0dBQ0QsSUFBSSxLQUFLLFFBQVEsa0JBQWtCO0lBQ2pDLEVBQUUsbUJBQW1CLG9CQUFvQixLQUFLLFFBQVEsZ0JBQWdCO0lBQ3RFLElBQUksRUFBRSxpQkFBaUIsTUFBTSxFQUFFLGlCQUFpQixLQUFLLEdBQUcsS0FBSyxRQUFRLFdBQVcsS0FBSyxPQUFPO0dBQzlGO0dBQ0EsSUFBSSxLQUFLLFFBQVEsWUFBWTtJQUMzQixFQUFFLGFBQWEsb0JBQW9CLEtBQUssUUFBUSxVQUFVO0lBQzFELElBQUksRUFBRSxXQUFXLE1BQU0sRUFBRSxXQUFXLEtBQUssSUFBSTtHQUMvQztHQUNBLEtBQUssYUFBYSxJQUFJLFdBQVcsS0FBSyxVQUFVLEtBQUssT0FBTztHQUM1RCxLQUFLLFdBQVcsR0FBRyxNQUFNLE9BQU8sR0FBRyxTQUFTO0lBQzFDLEtBQUssS0FBSyxPQUFPLEdBQUcsSUFBSTtHQUMxQixDQUFDO0dBQ0QsS0FBSyxRQUFRLFNBQVMsU0FBUSxNQUFLO0lBQ2pDLElBQUksRUFBRSxNQUFNLEVBQUUsS0FBSyxJQUFJO0dBQ3pCLENBQUM7RUFDSDtFQUNBLEtBQUssU0FBUyxLQUFLLFFBQVEsY0FBYztFQUN6QyxJQUFJLENBQUMsVUFBVSxXQUFXO0VBQzFCLElBQUksS0FBSyxRQUFRLGVBQWUsQ0FBQyxLQUFLLFNBQVMsb0JBQW9CLENBQUMsS0FBSyxRQUFRLEtBQUs7R0FDcEYsTUFBTSxRQUFRLEtBQUssU0FBUyxjQUFjLGlCQUFpQixLQUFLLFFBQVEsV0FBVztHQUNuRixJQUFJLE1BQU0sU0FBUyxLQUFLLE1BQU0sT0FBTyxPQUFPLEtBQUssUUFBUSxNQUFNLE1BQU07RUFDdkU7RUFDQSxJQUFJLENBQUMsS0FBSyxTQUFTLG9CQUFvQixDQUFDLEtBQUssUUFBUSxLQUNuRCxLQUFLLE9BQU8sS0FBSyx5REFBeUQ7RUFHNUU7R0FEa0I7R0FBZTtHQUFxQjtHQUFxQjtFQUNwRSxDQUFDLENBQUMsU0FBUSxXQUFVO0dBQ3pCLEtBQUssV0FBVyxHQUFHLFNBQVMsS0FBSyxNQUFNLE9BQU8sQ0FBQyxHQUFHLElBQUk7RUFDeEQsQ0FBQztFQUVEO0dBRHlCO0dBQWU7R0FBZ0I7R0FBcUI7RUFDL0QsQ0FBQyxDQUFDLFNBQVEsV0FBVTtHQUNoQyxLQUFLLFdBQVcsR0FBRyxTQUFTO0lBQzFCLEtBQUssTUFBTSxPQUFPLENBQUMsR0FBRyxJQUFJO0lBQzFCLE9BQU87R0FDVDtFQUNGLENBQUM7RUFDRCxNQUFNLFdBQVcsTUFBTTtFQUN2QixNQUFNLGFBQWE7R0FDakIsTUFBTSxVQUFVLEtBQUssTUFBTTtJQUN6QixLQUFLLGlCQUFpQjtJQUN0QixJQUFJLEtBQUssaUJBQWlCLENBQUMsS0FBSyxzQkFBc0IsS0FBSyxPQUFPLEtBQUssdUVBQXVFO0lBQzlJLEtBQUssZ0JBQWdCO0lBQ3JCLElBQUksQ0FBQyxLQUFLLFFBQVEsU0FBUyxLQUFLLE9BQU8sSUFBSSxlQUFlLEtBQUssT0FBTztJQUN0RSxLQUFLLEtBQUssZUFBZSxLQUFLLE9BQU87SUFDckMsU0FBUyxRQUFRLENBQUM7SUFDbEIsU0FBUyxLQUFLLENBQUM7R0FDakI7R0FDQSxLQUFLLEtBQUssYUFBYSxLQUFLLHlCQUF5QixDQUFDLEtBQUssZUFBZSxPQUFPLE9BQU8sTUFBTSxLQUFLLEVBQUUsS0FBSyxJQUFJLENBQUM7R0FDL0csS0FBSyxlQUFlLEtBQUssUUFBUSxLQUFLLE1BQU07RUFDOUM7RUFDQSxJQUFJLEtBQUssUUFBUSxhQUFhLENBQUMsS0FBSyxRQUFRLFdBQzFDLEtBQUs7T0FFTCxXQUFXLE1BQU0sQ0FBQztFQUVwQixPQUFPO0NBQ1Q7Q0FDQSxjQUFjLFVBQVUsV0FBVyxNQUFNO0VBQ3ZDLElBQUksZUFBZTtFQUNuQixNQUFNLFVBQVUsU0FBUyxRQUFRLElBQUksV0FBVyxLQUFLO0VBQ3JELElBQUksT0FBTyxhQUFhLFlBQVksZUFBZTtFQUNuRCxJQUFJLENBQUMsS0FBSyxRQUFRLGFBQWEsS0FBSyxRQUFRLHlCQUF5QjtHQUNuRSxJQUFJLFNBQVMsWUFBWSxNQUFNLGFBQWEsQ0FBQyxLQUFLLFFBQVEsV0FBVyxLQUFLLFFBQVEsUUFBUSxXQUFXLElBQUksT0FBTyxhQUFhO0dBQzdILE1BQU0sU0FBUyxDQUFDO0dBQ2hCLE1BQU0sVUFBUyxRQUFPO0lBQ3BCLElBQUksQ0FBQyxLQUFLO0lBQ1YsSUFBSSxRQUFRLFVBQVU7SUFFdEIsS0FEa0IsU0FBUyxjQUFjLG1CQUFtQixHQUN6RCxDQUFDLENBQUMsU0FBUSxNQUFLO0tBQ2hCLElBQUksTUFBTSxVQUFVO0tBQ3BCLElBQUksQ0FBQyxPQUFPLFNBQVMsQ0FBQyxHQUFHLE9BQU8sS0FBSyxDQUFDO0lBQ3hDLENBQUM7R0FDSDtHQUNBLElBQUksQ0FBQyxTQUVILEtBRHVCLFNBQVMsY0FBYyxpQkFBaUIsS0FBSyxRQUFRLFdBQ3BFLENBQUMsQ0FBQyxTQUFRLE1BQUssT0FBTyxDQUFDLENBQUM7UUFFaEMsT0FBTyxPQUFPO0dBRWhCLEtBQUssUUFBUSxTQUFTLFdBQVUsTUFBSyxPQUFPLENBQUMsQ0FBQztHQUM5QyxLQUFLLFNBQVMsaUJBQWlCLEtBQUssUUFBUSxLQUFLLFFBQVEsS0FBSSxNQUFLO0lBQ2hFLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxvQkFBb0IsS0FBSyxVQUFVLEtBQUssb0JBQW9CLEtBQUssUUFBUTtJQUN6RixhQUFhLENBQUM7R0FDaEIsQ0FBQztFQUNILE9BQ0UsYUFBYSxJQUFJO0NBRXJCO0NBQ0EsZ0JBQWdCLE1BQU0sSUFBSSxVQUFVO0VBQ2xDLE1BQU0sV0FBVyxNQUFNO0VBQ3ZCLElBQUksT0FBTyxTQUFTLFlBQVk7R0FDOUIsV0FBVztHQUNYLE9BQU8sS0FBQTtFQUNUO0VBQ0EsSUFBSSxPQUFPLE9BQU8sWUFBWTtHQUM1QixXQUFXO0dBQ1gsS0FBSyxLQUFBO0VBQ1A7RUFDQSxJQUFJLENBQUMsTUFBTSxPQUFPLEtBQUs7RUFDdkIsSUFBSSxDQUFDLElBQUksS0FBSyxLQUFLLFFBQVE7RUFDM0IsSUFBSSxDQUFDLFVBQVUsV0FBVztFQUMxQixLQUFLLFNBQVMsaUJBQWlCLE9BQU8sTUFBTSxLQUFJLFFBQU87R0FDckQsU0FBUyxRQUFRO0dBQ2pCLFNBQVMsR0FBRztFQUNkLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxJQUFJLFFBQVE7RUFDVixJQUFJLENBQUMsUUFBUSxNQUFNLElBQUksTUFBTSwrRkFBK0Y7RUFDNUgsSUFBSSxDQUFDLE9BQU8sTUFBTSxNQUFNLElBQUksTUFBTSwwRkFBMEY7RUFDNUgsSUFBSSxPQUFPLFNBQVMsV0FDbEIsS0FBSyxRQUFRLFVBQVU7RUFFekIsSUFBSSxPQUFPLFNBQVMsWUFBWSxPQUFPLE9BQU8sT0FBTyxRQUFRLE9BQU8sT0FDbEUsS0FBSyxRQUFRLFNBQVM7RUFFeEIsSUFBSSxPQUFPLFNBQVMsb0JBQ2xCLEtBQUssUUFBUSxtQkFBbUI7RUFFbEMsSUFBSSxPQUFPLFNBQVMsY0FDbEIsS0FBSyxRQUFRLGFBQWE7RUFFNUIsSUFBSSxPQUFPLFNBQVMsaUJBQ2xCLGNBQWMsaUJBQWlCLE1BQU07RUFFdkMsSUFBSSxPQUFPLFNBQVMsYUFDbEIsS0FBSyxRQUFRLFlBQVk7RUFFM0IsSUFBSSxPQUFPLFNBQVMsWUFDbEIsS0FBSyxRQUFRLFNBQVMsS0FBSyxNQUFNO0VBRW5DLE9BQU87Q0FDVDtDQUNBLG9CQUFvQixHQUFHO0VBQ3JCLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxXQUFXO0VBQzNCLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQyxDQUFDLFNBQVMsQ0FBQyxHQUFHO0VBQ25DLEtBQUssSUFBSSxLQUFLLEdBQUcsS0FBSyxLQUFLLFVBQVUsUUFBUSxNQUFNO0dBQ2pELE1BQU0sWUFBWSxLQUFLLFVBQVU7R0FDakMsSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDLENBQUMsU0FBUyxTQUFTLEdBQUc7R0FDM0MsSUFBSSxLQUFLLE1BQU0sNEJBQTRCLFNBQVMsR0FBRztJQUNyRCxLQUFLLG1CQUFtQjtJQUN4QjtHQUNGO0VBQ0Y7RUFDQSxJQUFJLENBQUMsS0FBSyxvQkFBb0IsQ0FBQyxLQUFLLFVBQVUsU0FBUyxDQUFDLEtBQUssS0FBSyxNQUFNLDRCQUE0QixDQUFDLEdBQUc7R0FDdEcsS0FBSyxtQkFBbUI7R0FDeEIsS0FBSyxVQUFVLFFBQVEsQ0FBQztFQUMxQjtDQUNGO0NBQ0EsZUFBZSxLQUFLLFVBQVU7RUFDNUIsS0FBSyx1QkFBdUI7RUFDNUIsTUFBTSxXQUFXLE1BQU07RUFDdkIsS0FBSyxLQUFLLG9CQUFvQixHQUFHO0VBQ2pDLE1BQU0sZUFBYyxNQUFLO0dBQ3ZCLEtBQUssV0FBVztHQUNoQixLQUFLLFlBQVksS0FBSyxTQUFTLGNBQWMsbUJBQW1CLENBQUM7R0FDakUsS0FBSyxtQkFBbUIsS0FBQTtHQUN4QixLQUFLLG9CQUFvQixDQUFDO0VBQzVCO0VBQ0EsTUFBTSxRQUFRLEtBQUssTUFBTTtHQUN2QixJQUFJLEdBQ0U7UUFBQSxLQUFLLHlCQUF5QixLQUFLO0tBQ3JDLFlBQVksQ0FBQztLQUNiLEtBQUssV0FBVyxlQUFlLENBQUM7S0FDaEMsS0FBSyx1QkFBdUIsS0FBQTtLQUM1QixLQUFLLEtBQUssbUJBQW1CLENBQUM7S0FDOUIsS0FBSyxPQUFPLElBQUksbUJBQW1CLENBQUM7SUFDdEM7VUFFQSxLQUFLLHVCQUF1QixLQUFBO0dBRTlCLFNBQVMsU0FBUyxHQUFHLFNBQVMsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDO0dBQzdDLElBQUksVUFBVSxTQUFTLE1BQU0sR0FBRyxTQUFTLEtBQUssRUFBRSxHQUFHLElBQUksQ0FBQztFQUMxRDtFQUNBLE1BQU0sVUFBUyxTQUFRO0dBQ3JCLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxLQUFLLFNBQVMsa0JBQWtCLE9BQU8sQ0FBQztHQUM3RCxNQUFNLEtBQUssU0FBUyxJQUFJLElBQUksT0FBTyxRQUFRLEtBQUs7R0FDaEQsTUFBTSxJQUFJLEtBQUssTUFBTSw0QkFBNEIsRUFBRSxJQUFJLEtBQUssS0FBSyxTQUFTLGNBQWMsc0JBQXNCLFNBQVMsSUFBSSxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUk7R0FDNUksSUFBSSxHQUFHO0lBQ0wsSUFBSSxDQUFDLEtBQUssVUFDUixZQUFZLENBQUM7SUFFZixJQUFJLENBQUMsS0FBSyxXQUFXLFVBQVUsS0FBSyxXQUFXLGVBQWUsQ0FBQztJQUMvRCxLQUFLLFNBQVMsa0JBQWtCLG9CQUFvQixDQUFDO0dBQ3ZEO0dBQ0EsS0FBSyxjQUFjLElBQUcsUUFBTztJQUMzQixLQUFLLEtBQUssQ0FBQztHQUNiLENBQUM7RUFDSDtFQUNBLElBQUksQ0FBQyxPQUFPLEtBQUssU0FBUyxvQkFBb0IsQ0FBQyxLQUFLLFNBQVMsaUJBQWlCLE9BQzVFLE9BQU8sS0FBSyxTQUFTLGlCQUFpQixPQUFPLENBQUM7T0FDekMsSUFBSSxDQUFDLE9BQU8sS0FBSyxTQUFTLG9CQUFvQixLQUFLLFNBQVMsaUJBQWlCLE9BQU87R0FDekYsSUFBSSxLQUFLLFNBQVMsaUJBQWlCLE9BQU8sV0FBVyxHQUNuRCxLQUFLLFNBQVMsaUJBQWlCLE9BQU8sQ0FBQyxDQUFDLEtBQUssTUFBTTtRQUVuRCxLQUFLLFNBQVMsaUJBQWlCLE9BQU8sTUFBTTtFQUVoRCxPQUNFLE9BQU8sR0FBRztFQUVaLE9BQU87Q0FDVDtDQUNBLFVBQVUsS0FBSyxJQUFJLFdBQVcsV0FBVztFQUN2QyxNQUFNLFVBQVUsV0FBVztFQUMzQixNQUFNLFVBQVUsS0FBSyxNQUFNLEdBQUcsU0FBUztHQUNyQyxJQUFJO0dBQ0osSUFBSSxPQUFPLFNBQVMsVUFDbEIsSUFBSSxLQUFLLFFBQVEsaUNBQWlDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxPQUFPLElBQUksQ0FBQztRQUUxRSxJQUFJLEVBQ0YsR0FBRyxLQUNMO0dBRUYsRUFBRSxNQUFNLEVBQUUsT0FBTyxPQUFPO0dBQ3hCLEVBQUUsT0FBTyxFQUFFLFFBQVEsT0FBTztHQUMxQixNQUFNLGlCQUFpQixFQUFFLE9BQU8sS0FBQSxLQUFhLEVBQUUsT0FBTztHQUN0RCxFQUFFLEtBQUssRUFBRSxNQUFNLE9BQU87R0FDdEIsSUFBSSxFQUFFLGNBQWMsSUFBSSxFQUFFLFlBQVksRUFBRSxhQUFhLGFBQWEsT0FBTztHQUN6RSxNQUFNLGVBQWU7SUFDbkIsR0FBRyxLQUFLO0lBQ1IsR0FBRztHQUNMO0dBQ0EsSUFBSSxNQUFNLFFBQVEsT0FBTyxLQUFLLENBQUMsZ0JBQWdCLGFBQWEsS0FBSztHQUNqRSxJQUFJLE9BQU8sRUFBRSxjQUFjLFlBQVksRUFBRSxZQUFZLGlCQUFpQixFQUFFLFdBQVcsWUFBWTtHQUMvRixNQUFNLGVBQWUsS0FBSyxRQUFRLGdCQUFnQjtHQUNsRCxJQUFJO0dBQ0osSUFBSSxFQUFFLGFBQWEsTUFBTSxRQUFRLEdBQUcsR0FDbEMsWUFBWSxJQUFJLEtBQUksTUFBSztJQUN2QixJQUFJLE9BQU8sTUFBTSxZQUFZLElBQUksaUJBQWlCLEdBQUcsWUFBWTtJQUNqRSxPQUFPLEdBQUcsRUFBRSxZQUFZLGVBQWU7R0FDekMsQ0FBQztRQUNJO0lBQ0wsSUFBSSxPQUFPLFFBQVEsWUFBWSxNQUFNLGlCQUFpQixLQUFLLFlBQVk7SUFDdkUsWUFBWSxFQUFFLFlBQVksR0FBRyxFQUFFLFlBQVksZUFBZSxRQUFRO0dBQ3BFO0dBQ0EsT0FBTyxLQUFLLEVBQUUsV0FBVyxDQUFDO0VBQzVCO0VBQ0EsSUFBSSxTQUFTLEdBQUcsR0FDZCxPQUFPLE1BQU07T0FFYixPQUFPLE9BQU87RUFFaEIsT0FBTyxLQUFLO0VBQ1osT0FBTyxZQUFZO0VBQ25CLE9BQU87Q0FDVDtDQUNBLEVBQUUsR0FBRyxNQUFNO0VBQ1QsT0FBTyxLQUFLLFlBQVksVUFBVSxHQUFHLElBQUk7Q0FDM0M7Q0FDQSxPQUFPLEdBQUcsTUFBTTtFQUNkLE9BQU8sS0FBSyxZQUFZLE9BQU8sR0FBRyxJQUFJO0NBQ3hDO0NBQ0Esb0JBQW9CLElBQUk7RUFDdEIsS0FBSyxRQUFRLFlBQVk7Q0FDM0I7Q0FDQSxtQkFBbUIsSUFBSSxVQUFVLENBQUMsR0FBRztFQUNuQyxJQUFJLENBQUMsS0FBSyxlQUFlO0dBQ3ZCLEtBQUssT0FBTyxLQUFLLG1EQUFtRCxLQUFLLFNBQVM7R0FDbEYsT0FBTztFQUNUO0VBQ0EsSUFBSSxDQUFDLEtBQUssYUFBYSxDQUFDLEtBQUssVUFBVSxRQUFRO0dBQzdDLEtBQUssT0FBTyxLQUFLLDhEQUE4RCxLQUFLLFNBQVM7R0FDN0YsT0FBTztFQUNUO0VBQ0EsTUFBTSxNQUFNLFFBQVEsT0FBTyxLQUFLLG9CQUFvQixLQUFLLFVBQVU7RUFDbkUsTUFBTSxjQUFjLEtBQUssVUFBVSxLQUFLLFFBQVEsY0FBYztFQUM5RCxNQUFNLFVBQVUsS0FBSyxVQUFVLEtBQUssVUFBVSxTQUFTO0VBQ3ZELElBQUksSUFBSSxZQUFZLE1BQU0sVUFBVSxPQUFPO0VBQzNDLE1BQU0sa0JBQWtCLEdBQUcsTUFBTTtHQUMvQixNQUFNLFlBQVksS0FBSyxTQUFTLGlCQUFpQixNQUFNLEdBQUcsRUFBRSxHQUFHO0dBQy9ELE9BQU8sY0FBYyxNQUFNLGNBQWMsS0FBSyxjQUFjO0VBQzlEO0VBQ0EsSUFBSSxRQUFRLFVBQVU7R0FDcEIsTUFBTSxZQUFZLFFBQVEsU0FBUyxNQUFNLGNBQWM7R0FDdkQsSUFBSSxjQUFjLEtBQUEsR0FBVyxPQUFPO0VBQ3RDO0VBQ0EsSUFBSSxLQUFLLGtCQUFrQixLQUFLLEVBQUUsR0FBRyxPQUFPO0VBQzVDLElBQUksQ0FBQyxLQUFLLFNBQVMsaUJBQWlCLFdBQVcsS0FBSyxRQUFRLGFBQWEsQ0FBQyxLQUFLLFFBQVEseUJBQXlCLE9BQU87RUFDdkgsTUFBTSxFQUNKLGtCQUNFLEtBQUs7RUFDVCxNQUFNLFVBQVUsQ0FBQyxRQUFRLE1BQU0sTUFBTSxjQUFjLGdCQUFnQixHQUFHLEtBQUssY0FBYyxtQkFBbUIsS0FBSyxLQUFLLENBQUMsQ0FBQztFQUN4SCxLQUFLLENBQUMsV0FBVyxlQUFlLFNBQVMsRUFBRSxPQUFPLENBQUMsZUFBZSxlQUFlLFNBQVMsRUFBRSxJQUFJLE9BQU87RUFDdkcsT0FBTztDQUNUO0NBQ0EsZUFBZSxJQUFJLFVBQVU7RUFDM0IsTUFBTSxXQUFXLE1BQU07RUFDdkIsSUFBSSxDQUFDLEtBQUssUUFBUSxJQUFJO0dBQ3BCLElBQUksVUFBVSxTQUFTO0dBQ3ZCLE9BQU8sUUFBUSxRQUFRO0VBQ3pCO0VBQ0EsSUFBSSxTQUFTLEVBQUUsR0FBRyxLQUFLLENBQUMsRUFBRTtFQUMxQixHQUFHLFNBQVEsTUFBSztHQUNkLElBQUksQ0FBQyxLQUFLLFFBQVEsR0FBRyxTQUFTLENBQUMsR0FBRyxLQUFLLFFBQVEsR0FBRyxLQUFLLENBQUM7RUFDMUQsQ0FBQztFQUNELEtBQUssZUFBYyxRQUFPO0dBQ3hCLFNBQVMsUUFBUTtHQUNqQixJQUFJLFVBQVUsU0FBUyxHQUFHO0VBQzVCLENBQUM7RUFDRCxPQUFPO0NBQ1Q7Q0FDQSxjQUFjLE1BQU0sVUFBVTtFQUM1QixNQUFNLFdBQVcsTUFBTTtFQUN2QixJQUFJLFNBQVMsSUFBSSxHQUFHLE9BQU8sQ0FBQyxJQUFJO0VBQ2hDLE1BQU0sWUFBWSxLQUFLLFFBQVEsV0FBVyxDQUFDO0VBQzNDLE1BQU0sVUFBVSxLQUFLLFFBQU8sUUFBTyxDQUFDLFVBQVUsU0FBUyxHQUFHLEtBQUssS0FBSyxTQUFTLGNBQWMsZ0JBQWdCLEdBQUcsQ0FBQztFQUMvRyxJQUFJLENBQUMsUUFBUSxRQUFRO0dBQ25CLElBQUksVUFBVSxTQUFTO0dBQ3ZCLE9BQU8sUUFBUSxRQUFRO0VBQ3pCO0VBQ0EsS0FBSyxRQUFRLFVBQVUsVUFBVSxPQUFPLE9BQU87RUFDL0MsS0FBSyxlQUFjLFFBQU87R0FDeEIsU0FBUyxRQUFRO0dBQ2pCLElBQUksVUFBVSxTQUFTLEdBQUc7RUFDNUIsQ0FBQztFQUNELE9BQU87Q0FDVDtDQUNBLElBQUksS0FBSztFQUNQLElBQUksQ0FBQyxLQUFLLE1BQU0sS0FBSyxxQkFBcUIsS0FBSyxXQUFXLFNBQVMsSUFBSSxLQUFLLFVBQVUsS0FBSyxLQUFLO0VBQ2hHLElBQUksQ0FBQyxLQUFLLE9BQU87RUFDakIsSUFBSTtHQUNGLE1BQU0sSUFBSSxJQUFJLEtBQUssT0FBTyxHQUFHO0dBQzdCLElBQUksS0FBSyxFQUFFLGFBQWE7SUFDdEIsTUFBTSxLQUFLLEVBQUUsWUFBWTtJQUN6QixJQUFJLE1BQU0sR0FBRyxXQUFXLE9BQU8sR0FBRztHQUNwQztFQUNGLFNBQVMsR0FBRyxDQUFDO0VBQ2IsTUFBTSxVQUFVO0dBQUM7R0FBTTtHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU87R0FBTTtHQUFNO0dBQU07R0FBTztHQUFPO0dBQU87R0FBTztHQUFPO0dBQU07R0FBTTtHQUFPO0dBQU87R0FBTztHQUFNO0dBQU07R0FBTztHQUFPO0dBQU87R0FBTTtHQUFPO0dBQU87R0FBTztHQUFPO0dBQU07R0FBTztFQUFLO0VBQ3ZiLE1BQU0sZ0JBQWdCLEtBQUssVUFBVSxpQkFBaUIsSUFBSSxhQUFhLElBQUksQ0FBQztFQUM1RSxJQUFJLElBQUksWUFBWSxDQUFDLENBQUMsUUFBUSxPQUFPLElBQUksR0FBRyxPQUFPO0VBQ25ELE9BQU8sUUFBUSxTQUFTLGNBQWMsd0JBQXdCLEdBQUcsQ0FBQyxLQUFLLElBQUksWUFBWSxDQUFDLENBQUMsUUFBUSxPQUFPLElBQUksSUFBSSxRQUFRO0NBQzFIO0NBQ0EsT0FBTyxlQUFlLFVBQVUsQ0FBQyxHQUFHLFVBQVU7RUFDNUMsTUFBTSxXQUFXLElBQUksS0FBSyxTQUFTLFFBQVE7RUFDM0MsU0FBUyxpQkFBaUIsS0FBSztFQUMvQixPQUFPO0NBQ1Q7Q0FDQSxjQUFjLFVBQVUsQ0FBQyxHQUFHLFdBQVcsTUFBTTtFQUMzQyxNQUFNLG9CQUFvQixRQUFRO0VBQ2xDLElBQUksbUJBQW1CO0dBQ3JCLFVBQVUsRUFDUixHQUFHLFFBQ0w7R0FDQSxPQUFPLFFBQVE7RUFDakI7RUFDQSxNQUFNLGdCQUFnQjtHQUNwQixHQUFHLEtBQUs7R0FDUixTQUFTO0dBQ1QsR0FBRztHQUVELFNBQVM7RUFFYjtFQUNBLE1BQU0sUUFBUSxJQUFJLEtBQUssYUFBYTtFQUNwQyxJQUFJLFFBQVEsVUFBVSxLQUFBLEtBQWEsUUFBUSxXQUFXLEtBQUEsR0FDcEQsTUFBTSxTQUFTLE1BQU0sT0FBTyxNQUFNLE9BQU87RUFHM0M7R0FEdUI7R0FBUztHQUFZO0VBQ2hDLENBQUMsQ0FBQyxTQUFRLE1BQUs7R0FDekIsTUFBTSxLQUFLLEtBQUs7RUFDbEIsQ0FBQztFQUNELE1BQU0sV0FBVyxFQUNmLEdBQUcsS0FBSyxTQUNWO0VBQ0EsTUFBTSxTQUFTLFFBQVEsRUFDckIsb0JBQW9CLE1BQU0sbUJBQW1CLEtBQUssS0FBSyxFQUN6RDtFQUNBLElBQUksbUJBQW1CO0dBQ3JCLE1BQU0sWUFBVyxRQUFPO0lBQ3RCLE1BQU0sU0FBUyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxHQUFHLElBQUksRUFDN0MsR0FBRyxJQUNMO0lBQ0EsT0FBTyxLQUFLLE1BQU0sQ0FBQyxDQUFDLFNBQVEsTUFBSztLQUMvQixJQUFJLE9BQU8sTUFBTSxPQUFPLE9BQU8sT0FBTyxVQUFVLE9BQU8sS0FBSyxTQUFTLE9BQU8sRUFBRTtJQUNoRixDQUFDO0lBQ0QsT0FBTztHQUNUO0dBRUEsTUFBTSxRQUFRLElBQUksY0FEQyxTQUFTLEtBQUssTUFBTSxJQUNQLEdBQVksYUFBYTtHQUN6RCxNQUFNLFNBQVMsZ0JBQWdCLE1BQU07RUFDdkM7RUFDQSxJQUFJLFFBQVEsZUFBZTtHQUV6QixNQUFNLHNCQUFzQjtJQUMxQixHQUZjLElBRUwsQ0FBQyxDQUFDO0lBQ1gsR0FBRyxLQUFLLFFBQVE7SUFDaEIsR0FBRyxRQUFRO0dBQ2I7R0FDQSxNQUFNLHdCQUF3QjtJQUM1QixHQUFHO0lBQ0gsZUFBZTtHQUNqQjtHQUNBLE1BQU0sU0FBUyxlQUFlLElBQUksYUFBYSxxQkFBcUI7RUFDdEU7RUFDQSxNQUFNLGFBQWEsSUFBSSxXQUFXLE1BQU0sVUFBVSxhQUFhO0VBQy9ELE1BQU0sV0FBVyxHQUFHLE1BQU0sT0FBTyxHQUFHLFNBQVM7R0FDM0MsTUFBTSxLQUFLLE9BQU8sR0FBRyxJQUFJO0VBQzNCLENBQUM7RUFDRCxNQUFNLEtBQUssZUFBZSxRQUFRO0VBQ2xDLE1BQU0sV0FBVyxVQUFVO0VBQzNCLE1BQU0sV0FBVyxpQkFBaUIsU0FBUyxRQUFRLEVBQ2pELG9CQUFvQixNQUFNLG1CQUFtQixLQUFLLEtBQUssRUFDekQ7RUFDQSxPQUFPO0NBQ1Q7Q0FDQSxTQUFTO0VBQ1AsT0FBTztHQUNMLFNBQVMsS0FBSztHQUNkLE9BQU8sS0FBSztHQUNaLFVBQVUsS0FBSztHQUNmLFdBQVcsS0FBSztHQUNoQixrQkFBa0IsS0FBSztFQUN6QjtDQUNGO0FBQ0YsRUFDc0IsZUFBZTtBQUVyQyxJQUFNLGlCQUFpQixTQUFTO0FBQ2hDLElBQU0sTUFBTSxTQUFTO0FBQ3JCLElBQU0sT0FBTyxTQUFTO0FBQ3RCLElBQU0sZ0JBQWdCLFNBQVM7QUFDL0IsSUFBTSxrQkFBa0IsU0FBUztBQUNqQyxJQUFNLE1BQU0sU0FBUztBQUNyQixJQUFNLGlCQUFpQixTQUFTO0FBQ2hDLElBQU0sWUFBWSxTQUFTO0FBQzNCLElBQU0sSUFBSSxTQUFTO0FBQ25CLElBQU0sU0FBUyxTQUFTO0FBQ3hCLElBQU0sc0JBQXNCLFNBQVM7QUFDckMsSUFBTSxxQkFBcUIsU0FBUztBQUNwQyxJQUFNLGlCQUFpQixTQUFTO0FBQ2hDLElBQU0sZ0JBQWdCLFNBQVMiLCJ4X2dvb2dsZV9pZ25vcmVMaXN0IjpbMF19