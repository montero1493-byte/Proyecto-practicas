import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/pages/posts/CreatePostPage.tsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=55f59584";
import { useAppDispatch } from "/src/app/store/hooks/hooks.ts";
import { createPost } from "/src/app/store/PostSlice.ts";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=ad611340";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=6824eab0";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/CreatePostPage.tsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
const CreatePostPage = () => {
	_s();
	const [title, setTitle] = useState("");
	const [body, setContent] = useState("");
	const dispatch = useAppDispatch();
	const navigate = useNavigate();
	const { t } = useTranslation();
	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!title.trim() || !body.trim()) {
			alert("completa todos los campos");
			return;
		}
		await dispatch(createPost({
			title,
			body,
			userId: 1
		}));
		navigate("/posts", { state: { successMessage: "Post creado" } });
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "create-post-page",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "create-post-card",
			children: [/* @__PURE__ */ _jsxDEV("h1", { children: t("app.new-post") }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 33,
				columnNumber: 7
			}, this), /* @__PURE__ */ _jsxDEV("form", {
				className: "create-post-form",
				onSubmit: handleSubmit,
				children: [
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", { children: t("app.title") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 37,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("input", {
						type: "text",
						value: title,
						onChange: (e) => setTitle(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("label", { children: t("app.content") }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 46,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("textarea", {
						value: body,
						onChange: (e) => setContent(e.target.value)
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 48,
						columnNumber: 11
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 45,
						columnNumber: 9
					}, this),
					/* @__PURE__ */ _jsxDEV("button", {
						className: "app-button",
						type: "submit",
						children: t("app.create")
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 54,
						columnNumber: 9
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 35,
				columnNumber: 7
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 32,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 31,
		columnNumber: 5
	}, this);
};
_s(CreatePostPage, "cm1WNCHpGGdHpemEmprOOWM1ZEw=", false, function() {
	return [
		useAppDispatch,
		useNavigate,
		useTranslation
	];
});
_c = CreatePostPage;
export default CreatePostPage;
var _c;
$RefreshReg$(_c, "CreatePostPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app/pages/posts/CreatePostPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/CreatePostPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/CreatePostPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/posts/CreatePostPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUSxnQkFBZTtBQUN2QixTQUFTLHNCQUFzQjtBQUMvQixTQUFTLGtCQUFrQjtBQUMzQixTQUFTLG1CQUFtQjtBQUM1QixTQUFTLHNCQUFzQjs7OztBQUUvQixNQUFNLHVCQUF1Qjs7Q0FDM0IsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FDckMsTUFBTSxDQUFDLE1BQU0sY0FBYyxTQUFTLEVBQUU7Q0FFdEMsTUFBTSxXQUFXLGVBQWU7Q0FDaEMsTUFBTSxXQUFXLFlBQVk7Q0FDN0IsTUFBTSxFQUFFLE1BQU0sZUFBZTtDQUc3QixNQUFNLGVBQWUsT0FBTyxNQUF3QztFQUNsRSxFQUFFLGVBQWU7RUFFakIsSUFBSSxDQUFDLE1BQU0sS0FBSyxLQUFLLENBQUMsS0FBSyxLQUFLLEdBQUc7R0FDakMsTUFBTSwyQkFBMkI7R0FDakM7RUFDRjtFQUVBLE1BQU0sU0FBUyxXQUFXO0dBQUU7R0FBYTtHQUFNLFFBQVE7RUFBRSxDQUFDLENBQUM7RUFHM0QsU0FBUyxVQUFVLEVBQUMsT0FBTyxFQUFDLGdCQUFnQixjQUFhLEVBQUMsQ0FBQztDQUM3RDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLFdBQVU7WUFDYix3QkFBQyxPQUFEO0dBQUssV0FBVTthQUFmLENBQ0Esd0JBQUMsTUFBRCxZQUFLLEVBQUUsY0FBYyxFQUFNOzs7O2FBRTNCLHdCQUFDLFFBQUQ7SUFBTSxXQUFVO0lBQW1CLFVBQVU7Y0FBN0M7S0FDRSx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsU0FBRCxZQUFRLEVBQUUsV0FBVyxFQUFTOzs7O2VBRTlCLHdCQUFDLFNBQUQ7TUFDRSxNQUFLO01BQ0wsT0FBTztNQUNQLFdBQVcsTUFBTSxTQUFTLEVBQUUsT0FBTyxLQUFLO0tBQ3pDOzs7O2FBQ0U7Ozs7O0tBQ0wsd0JBQUMsT0FBRCxhQUNFLHdCQUFDLFNBQUQsWUFBUSxFQUFFLGFBQWEsRUFBUzs7OztlQUVoQyx3QkFBQyxZQUFEO01BQ0EsT0FBTztNQUNQLFdBQVcsTUFBTSxXQUFXLEVBQUUsT0FBTyxLQUFLO0tBQ3pDOzs7O2FBRUU7Ozs7O0tBQ0wsd0JBQUMsVUFBRDtNQUFRLFdBQVU7TUFBYSxNQUFLO2dCQUFVLEVBQUUsWUFBWTtLQUFVOzs7OztJQUNsRTs7Ozs7V0FDRDs7Ozs7O0NBQ0Y7Ozs7O0FBRVQ7Ozs7Ozs7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQ3JlYXRlUG9zdFBhZ2UudHN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7dXNlU3RhdGV9IGZyb20gJ3JlYWN0JztcclxuaW1wb3J0IHsgdXNlQXBwRGlzcGF0Y2ggfSBmcm9tIFwiLi4vLi4vc3RvcmUvaG9va3MvaG9va3NcIjtcclxuaW1wb3J0IHsgY3JlYXRlUG9zdCB9IGZyb20gXCIuLi8uLi9zdG9yZS9Qb3N0U2xpY2VcIjtcclxuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tIFwicmVhY3Qtcm91dGVyLWRvbVwiO1xyXG5pbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gJ3JlYWN0LWkxOG5leHQnO1xyXG5cclxuY29uc3QgQ3JlYXRlUG9zdFBhZ2UgPSAoKSA9PiB7XHJcbiAgY29uc3QgW3RpdGxlLCBzZXRUaXRsZV0gPSB1c2VTdGF0ZSgnJyk7XHJcbiAgY29uc3QgW2JvZHksIHNldENvbnRlbnRdID0gdXNlU3RhdGUoJycpO1xyXG5cclxuICBjb25zdCBkaXNwYXRjaCA9IHVzZUFwcERpc3BhdGNoKCk7XHJcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpO1xyXG4gIGNvbnN0IHsgdCB9ID0gdXNlVHJhbnNsYXRpb24oKTtcclxuIFxyXG5cclxuICBjb25zdCBoYW5kbGVTdWJtaXQgPSBhc3luYyAoZTogUmVhY3QuRm9ybUV2ZW50PEhUTUxGb3JtRWxlbWVudD4pID0+IHtcclxuICAgIGUucHJldmVudERlZmF1bHQoKTtcclxuXHJcbiAgICBpZiAoIXRpdGxlLnRyaW0oKSB8fCAhYm9keS50cmltKCkpIHtcclxuICAgICAgYWxlcnQoXCJjb21wbGV0YSB0b2RvcyBsb3MgY2FtcG9zXCIpO1xyXG4gICAgICByZXR1cm47XHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgZGlzcGF0Y2goY3JlYXRlUG9zdCh7IHRpdGxlLCBib2R5OiBib2R5LCB1c2VySWQ6IDEgfSkpO1xyXG5cclxuXHJcbiAgICBuYXZpZ2F0ZShcIi9wb3N0c1wiLCB7c3RhdGU6IHtzdWNjZXNzTWVzc2FnZTogXCJQb3N0IGNyZWFkb1wifX0pO1xyXG4gIH07XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT0nY3JlYXRlLXBvc3QtcGFnZSc+XHJcbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdjcmVhdGUtcG9zdC1jYXJkJz5cclxuICAgICAgPGgxPnt0KFwiYXBwLm5ldy1wb3N0XCIpfTwvaDE+XHJcblxyXG4gICAgICA8Zm9ybSBjbGFzc05hbWU9J2NyZWF0ZS1wb3N0LWZvcm0nIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxyXG4gICAgICAgIDxkaXY+XHJcbiAgICAgICAgICA8bGFiZWw+e3QoXCJhcHAudGl0bGVcIil9PC9sYWJlbD5cclxuXHJcbiAgICAgICAgICA8aW5wdXRcclxuICAgICAgICAgICAgdHlwZT1cInRleHRcIlxyXG4gICAgICAgICAgICB2YWx1ZT17dGl0bGV9XHJcbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0VGl0bGUoZS50YXJnZXQudmFsdWUpfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgPGxhYmVsPnt0KFwiYXBwLmNvbnRlbnRcIil9PC9sYWJlbD5cclxuXHJcbiAgICAgICAgICA8dGV4dGFyZWFcclxuICAgICAgICAgIHZhbHVlPXtib2R5fVxyXG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRDb250ZW50KGUudGFyZ2V0LnZhbHVlKX1cclxuICAgICAgICAgIC8+XHJcblxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICAgIDxidXR0b24gY2xhc3NOYW1lPSdhcHAtYnV0dG9uJyB0eXBlPVwic3VibWl0XCI+e3QoXCJhcHAuY3JlYXRlXCIpfTwvYnV0dG9uPlxyXG4gICAgICA8L2Zvcm0+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IENyZWF0ZVBvc3RQYWdlOyJdfQ==