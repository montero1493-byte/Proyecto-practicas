import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/layout/languageSelector.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=6824eab0";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/languageSelector.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
const LanguageSelector = () => {
	_s();
	const { i18n } = useTranslation();
	const changeLanguage = (lang) => {
		i18n.changeLanguage(lang);
	};
	return /* @__PURE__ */ _jsxDEV("select", {
		value: i18n.language,
		onChange: (e) => changeLanguage(e.target.value),
		children: [/* @__PURE__ */ _jsxDEV("option", {
			value: "es",
			children: "ES"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 17,
			columnNumber: 13
		}, this), /* @__PURE__ */ _jsxDEV("option", {
			value: "en",
			children: "EN"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 18,
			columnNumber: 13
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 13,
		columnNumber: 9
	}, this);
};
_s(LanguageSelector, "iD7vDB/EPQWin5ATG71yacngHuk=", false, function() {
	return [useTranslation];
});
_c = LanguageSelector;
export default LanguageSelector;
var _c;
$RefreshReg$(_c, "LanguageSelector");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/layout/languageSelector.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/languageSelector.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/languageSelector.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/components/layout/languageSelector.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7Ozs7QUFJL0IsTUFBTSx5QkFBeUI7O0NBQzNCLE1BQU0sRUFBRSxTQUFTLGVBQWU7Q0FFaEMsTUFBTSxrQkFBa0IsU0FBbUI7RUFDdkMsS0FBSyxlQUFlLElBQUk7Q0FDNUI7Q0FFQSxPQUNJLHdCQUFDLFVBQUQ7RUFDSSxPQUFPLEtBQUs7RUFDWixXQUFXLE1BQU0sZUFBZSxFQUFFLE9BQU8sS0FBaUI7WUFGOUQsQ0FJSSx3QkFBQyxVQUFEO0dBQVEsT0FBTTthQUFLO0VBQVU7Ozs7WUFDN0Isd0JBQUMsVUFBRDtHQUFRLE9BQU07YUFBSztFQUFVOzs7O1VBQ3pCOzs7Ozs7QUFFaEI7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJsYW5ndWFnZVNlbGVjdG9yLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gXCJyZWFjdC1pMThuZXh0XCI7XHJcblxyXG50eXBlIExhbmd1YWdlID0gXCJlc1wiIHwgXCJlblwiO1xyXG5cclxuY29uc3QgTGFuZ3VhZ2VTZWxlY3RvciA9ICgpID0+IHtcclxuICAgIGNvbnN0IHsgaTE4biB9ID0gdXNlVHJhbnNsYXRpb24oKTtcclxuXHJcbiAgICBjb25zdCBjaGFuZ2VMYW5ndWFnZSA9IChsYW5nOiBMYW5ndWFnZSkgPT4ge1xyXG4gICAgICAgIGkxOG4uY2hhbmdlTGFuZ3VhZ2UobGFuZyk7XHJcbiAgICB9O1xyXG5cclxuICAgIHJldHVybihcclxuICAgICAgICA8c2VsZWN0XHJcbiAgICAgICAgICAgIHZhbHVlPXtpMThuLmxhbmd1YWdlfVxyXG4gICAgICAgICAgICBvbkNoYW5nZT17KGUpID0+IGNoYW5nZUxhbmd1YWdlKGUudGFyZ2V0LnZhbHVlIGFzIExhbmd1YWdlKX1cclxuICAgICAgICA+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJlc1wiPkVTPC9vcHRpb24+XHJcbiAgICAgICAgICAgIDxvcHRpb24gdmFsdWU9XCJlblwiPkVOPC9vcHRpb24+XHJcbiAgICAgICAgPC9zZWxlY3Q+XHJcbiAgICApO1xyXG59O1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgTGFuZ3VhZ2VTZWxlY3RvcjtcclxuIl19