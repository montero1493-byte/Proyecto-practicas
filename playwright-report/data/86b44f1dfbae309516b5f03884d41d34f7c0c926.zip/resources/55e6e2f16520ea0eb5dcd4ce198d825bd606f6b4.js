import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/pages/dashboard/DashboardPage.tsx");const useEffect = __vite__cjsImport1_react["useEffect"]; const useState = __vite__cjsImport1_react["useState"];const Highcharts = __vite__cjsImport3_highcharts;const HighchartsReactModule = __vite__cjsImport4_highchartsReactOfficial;const _jsxDEV = __vite__cjsImport6_react_jsxDevRuntime["jsxDEV"];import { useAppSelector } from "/src/app/store/hooks/hooks.ts";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=55f59584";
import { getComments } from "/src/services/CommentService.ts";
import __vite__cjsImport3_highcharts from "/node_modules/.vite/deps/highcharts.js?v=9d8ff2e7";
import __vite__cjsImport4_highchartsReactOfficial from "/node_modules/.vite/deps/highcharts-react-official.js?v=9c18e908";
import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=6824eab0";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/dashboard/DashboardPage.tsx";
import __vite__cjsImport6_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
const HighchartsReact = HighchartsReactModule.default;
const DashboardPage = () => {
	_s();
	const posts = useAppSelector((state) => state.posts.posts);
	const { t } = useTranslation();
	const totalPosts = posts.length;
	const totalUsers = new Set(posts.map((post) => post.userId)).size;
	const [comments, setComments] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState("");
	const totalComments = comments.length;
	useEffect(() => {
		const loadComments = async () => {
			try {
				setLoading(true);
				const data = await getComments();
				setComments(data);
			} catch {
				setError("No se cargaron los comentarios");
			} finally {
				setLoading(false);
			}
		};
		loadComments();
	}, []);
	const PostsByUser = Array.from({ length: totalUsers }, (_, index) => {
		const userId = index + 1;
		return posts.filter((post) => post.userId === userId).length;
	});
	const commentsByUser = Array.from({ length: totalUsers }, (_, index) => {
		const userId = index + 1;
		const userPosts = posts.filter((post) => post.userId === userId);
		const postIds = userPosts.map((post) => post.id);
		return comments.filter((comment) => postIds.includes(comment.postId)).length;
	});
	const categories = Array.from({ length: totalUsers }, (_, index) => `Usuario ${index + 1}`);
	const chartOptions = {
		chart: { type: "column" },
		title: { text: "Posts y comentarios por usuario" },
		xAxis: { categories },
		yAxis: { title: { text: "Cantidad" } },
		series: [{
			type: "column",
			name: "Posts",
			data: PostsByUser
		}, {
			type: "column",
			name: "Comentarios",
			data: commentsByUser
		}]
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "dashboard-page",
		children: [
			error && /* @__PURE__ */ _jsxDEV("p", { children: error }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 115,
				columnNumber: 16
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "dashboard-stats",
				children: [
					/* @__PURE__ */ _jsxDEV("div", {
						className: "card stat-card",
						children: [/* @__PURE__ */ _jsxDEV("h2", { children: t("dashboard.total-post") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 119,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: totalPosts }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 120,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 118,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "card stat-card",
						children: [/* @__PURE__ */ _jsxDEV("h2", { children: t("dashboard.total-users") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 123,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: totalUsers }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 124,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 122,
						columnNumber: 11
					}, this),
					/* @__PURE__ */ _jsxDEV("div", {
						className: "card stat-card",
						children: [/* @__PURE__ */ _jsxDEV("h2", { children: t("dashboard.total-comments") }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 127,
							columnNumber: 13
						}, this), /* @__PURE__ */ _jsxDEV("p", { children: totalComments }, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 128,
							columnNumber: 13
						}, this)]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 126,
						columnNumber: 11
					}, this)
				]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 117,
				columnNumber: 9
			}, this),
			/* @__PURE__ */ _jsxDEV("div", {
				className: "card chart-card",
				children: loading ? /* @__PURE__ */ _jsxDEV("p", { children: "Cargando grafica" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 134,
					columnNumber: 11
				}, this) : /* @__PURE__ */ _jsxDEV(HighchartsReact, {
					highcharts: Highcharts,
					options: chartOptions
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 135,
					columnNumber: 11
				}, this)
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 132,
				columnNumber: 9
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 114,
		columnNumber: 5
	}, this);
};
_s(DashboardPage, "jZ986OSl14Bw0mo3eQ/PaQCOjuc=", false, function() {
	return [useAppSelector, useTranslation];
});
_c = DashboardPage;
export default DashboardPage;
var _c;
$RefreshReg$(_c, "DashboardPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app/pages/dashboard/DashboardPage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/dashboard/DashboardPage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/dashboard/DashboardPage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/dashboard/DashboardPage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLG1CQUFtQjtBQUM1QixPQUFPLGdCQUFnQjtBQUV2QixPQUFPLDJCQUEyQjtBQUNsQyxTQUFTLHNCQUFzQjs7OztBQUUvQixNQUFNLGtCQUFtQixzQkFBOEI7QUFFdkQsTUFBTSxzQkFBc0I7O0NBQzFCLE1BQU0sUUFBUSxnQkFBZ0IsVUFDNUIsTUFBTSxNQUFNLEtBQUs7Q0FFbkIsTUFBTSxFQUFFLE1BQU0sZUFBZTtDQUU3QixNQUFNLGFBQWEsTUFBTTtDQUV6QixNQUFNLGFBQWEsSUFBSSxJQUNyQixNQUFNLEtBQUssU0FBUyxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUM7Q0FFcEMsTUFBTSxDQUFDLFVBQVUsZUFBZSxTQUFvQixDQUFDLENBQUM7Q0FDdEQsTUFBTSxDQUFDLFNBQVMsY0FBYyxTQUFTLElBQUk7Q0FDM0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLEVBQUU7Q0FFckMsTUFBTSxnQkFBZ0IsU0FBUztDQUUvQixnQkFBZ0I7RUFDZCxNQUFNLGVBQWUsWUFBWTtHQUMvQixJQUFJO0lBQ0YsV0FBVyxJQUFJO0lBRWYsTUFBTSxPQUFPLE1BQU0sWUFBWTtJQUUvQixZQUFZLElBQUk7R0FDbEIsUUFBUTtJQUNOLFNBQVMsZ0NBQWdDO0dBQzNDLFVBQVU7SUFDUixXQUFXLEtBQUs7R0FDbEI7RUFDRjtFQUVBLGFBQWE7Q0FDZixHQUFHLENBQUMsQ0FBQztDQUVMLE1BQU0sY0FBYyxNQUFNLEtBQ3hCLEVBQUMsUUFBUSxXQUFVLElBQUksR0FBRyxVQUFVO0VBQ2xDLE1BQU0sU0FBUyxRQUFRO0VBRXZCLE9BQU8sTUFBTSxRQUNWLFNBQVMsS0FBSyxXQUFXLE1BQzVCLENBQUMsQ0FBQztDQUNKLENBQ0Y7Q0FFQSxNQUFNLGlCQUFpQixNQUFNLEtBQzNCLEVBQUMsUUFBUSxXQUFVLElBQUksR0FBRyxVQUFVO0VBQ2xDLE1BQU0sU0FBUyxRQUFRO0VBRXZCLE1BQU0sWUFBWSxNQUFNLFFBQ3JCLFNBQVMsS0FBSyxXQUFXLE1BQzVCO0VBRUEsTUFBTSxVQUFVLFVBQVUsS0FDdkIsU0FBUyxLQUFLLEVBQ2pCO0VBRUEsT0FBTyxTQUFTLFFBQ2IsWUFDQyxRQUFRLFNBQVMsUUFBUSxNQUFNLENBQ25DLENBQUMsQ0FBQztDQUNKLENBQ0Y7Q0FFQSxNQUFNLGFBQWEsTUFBTSxLQUN2QixFQUFDLFFBQVEsV0FBVSxJQUFJLEdBQUcsVUFDeEIsV0FBVyxRQUFRLEdBQ3ZCO0NBRUEsTUFBTSxlQUFtQztFQUN2QyxPQUFPLEVBQ0wsTUFBTSxTQUNSO0VBRUEsT0FBTyxFQUNMLE1BQU0sa0NBQ1I7RUFFQSxPQUFPLEVBQ0wsV0FDRjtFQUVBLE9BQU8sRUFDTCxPQUFPLEVBQ0wsTUFBTSxXQUNSLEVBQ0Y7RUFFQSxRQUFRLENBQ047R0FDRSxNQUFNO0dBQ04sTUFBTTtHQUNOLE1BQU07RUFDUixHQUNBO0dBQ0UsTUFBTTtHQUNOLE1BQU07R0FDTixNQUFNO0VBQ1IsQ0FDRjtDQUNGO0NBRUEsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0MsU0FBVSx3QkFBQyxLQUFELFlBQUksTUFBUzs7Ozs7R0FFcEIsd0JBQUMsT0FBRDtJQUFLLFdBQVU7Y0FBZjtLQUNFLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFLLEVBQUUsc0JBQXNCLEVBQU07Ozs7Z0JBQ25DLHdCQUFDLEtBQUQsWUFBSSxXQUFjOzs7O2NBQ2I7Ozs7OztLQUNQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFLLEVBQUUsdUJBQXVCLEVBQU07Ozs7Z0JBQ3BDLHdCQUFDLEtBQUQsWUFBSSxXQUFjOzs7O2NBQ2I7Ozs7OztLQUNQLHdCQUFDLE9BQUQ7TUFBSyxXQUFVO2dCQUFmLENBQ0Usd0JBQUMsTUFBRCxZQUFLLEVBQUUsMEJBQTBCLEVBQU07Ozs7Z0JBQ3ZDLHdCQUFDLEtBQUQsWUFBSSxjQUFpQjs7OztjQUNoQjs7Ozs7O0lBQ0o7Ozs7OztHQUVMLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQ2QsVUFDQyx3QkFBQyxLQUFELFlBQUcsbUJBQW1COzs7O2VBQ3RCLHdCQUFDLGlCQUFEO0tBQ0UsWUFBWTtLQUNaLFNBQVM7SUFDVjs7Ozs7R0FFRTs7Ozs7RUFDSjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsZUFBZSIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJEYXNoYm9hcmRQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VBcHBTZWxlY3RvciB9IGZyb20gXCIuLi8uLi9zdG9yZS9ob29rcy9ob29rc1wiO1xyXG5pbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IGdldENvbW1lbnRzIH0gZnJvbSBcIi4uLy4uLy4uL3NlcnZpY2VzL0NvbW1lbnRTZXJ2aWNlXCI7XHJcbmltcG9ydCBIaWdoY2hhcnRzIGZyb20gXCJoaWdoY2hhcnRzXCI7XHJcbmltcG9ydCB0eXBlIHsgQ29tbWVudCB9IGZyb20gXCIuLi8uLi8uLi90eXBlcy9jb21tZW50XCI7XHJcbmltcG9ydCBIaWdoY2hhcnRzUmVhY3RNb2R1bGUgZnJvbSBcImhpZ2hjaGFydHMtcmVhY3Qtb2ZmaWNpYWxcIjtcclxuaW1wb3J0IHsgdXNlVHJhbnNsYXRpb24gfSBmcm9tIFwicmVhY3QtaTE4bmV4dFwiO1xyXG5cclxuY29uc3QgSGlnaGNoYXJ0c1JlYWN0ID0gKEhpZ2hjaGFydHNSZWFjdE1vZHVsZSBhcyBhbnkpLmRlZmF1bHQ7XHJcblxyXG5jb25zdCBEYXNoYm9hcmRQYWdlID0gKCkgPT4ge1xyXG4gIGNvbnN0IHBvc3RzID0gdXNlQXBwU2VsZWN0b3IoKHN0YXRlKSA9PlxyXG4gICAgc3RhdGUucG9zdHMucG9zdHMpO1xyXG5cclxuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XHJcblxyXG4gIGNvbnN0IHRvdGFsUG9zdHMgPSBwb3N0cy5sZW5ndGg7XHJcblxyXG4gIGNvbnN0IHRvdGFsVXNlcnMgPSBuZXcgU2V0KFxyXG4gICAgcG9zdHMubWFwKChwb3N0KSA9PiBwb3N0LnVzZXJJZCkpLnNpemU7XHJcblxyXG4gIGNvbnN0IFtjb21tZW50cywgc2V0Q29tbWVudHNdID0gdXNlU3RhdGU8Q29tbWVudFtdPihbXSk7XHJcbiAgY29uc3QgW2xvYWRpbmcsIHNldExvYWRpbmddID0gdXNlU3RhdGUodHJ1ZSk7XHJcbiAgY29uc3QgW2Vycm9yLCBzZXRFcnJvcl0gPSB1c2VTdGF0ZShcIlwiKTtcclxuXHJcbiAgY29uc3QgdG90YWxDb21tZW50cyA9IGNvbW1lbnRzLmxlbmd0aDtcclxuICBcclxuICB1c2VFZmZlY3QoKCkgPT4ge1xyXG4gICAgY29uc3QgbG9hZENvbW1lbnRzID0gYXN5bmMgKCkgPT4ge1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHNldExvYWRpbmcodHJ1ZSk7XHJcblxyXG4gICAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBnZXRDb21tZW50cygpO1xyXG4gICAgICBcclxuICAgICAgICBzZXRDb21tZW50cyhkYXRhKTtcclxuICAgICAgfSBjYXRjaCB7XHJcbiAgICAgICAgc2V0RXJyb3IoXCJObyBzZSBjYXJnYXJvbiBsb3MgY29tZW50YXJpb3NcIik7XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgc2V0TG9hZGluZyhmYWxzZSk7XHJcbiAgICAgIH1cclxuICAgIH07XHJcblxyXG4gICAgbG9hZENvbW1lbnRzKCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICBjb25zdCBQb3N0c0J5VXNlciA9IEFycmF5LmZyb20oXHJcbiAgICB7bGVuZ3RoOiB0b3RhbFVzZXJzfSwgKF8sIGluZGV4KSA9PiB7XHJcbiAgICAgIGNvbnN0IHVzZXJJZCA9IGluZGV4ICsgMTtcclxuXHJcbiAgICAgIHJldHVybiBwb3N0cy5maWx0ZXIoXHJcbiAgICAgICAgKHBvc3QpID0+IHBvc3QudXNlcklkID09PSB1c2VySWRcclxuICAgICAgKS5sZW5ndGg7XHJcbiAgICB9XHJcbiAgKTtcclxuXHJcbiAgY29uc3QgY29tbWVudHNCeVVzZXIgPSBBcnJheS5mcm9tKFxyXG4gICAge2xlbmd0aDogdG90YWxVc2Vyc30sIChfLCBpbmRleCkgPT4ge1xyXG4gICAgICBjb25zdCB1c2VySWQgPSBpbmRleCArIDE7XHJcblxyXG4gICAgICBjb25zdCB1c2VyUG9zdHMgPSBwb3N0cy5maWx0ZXIoXHJcbiAgICAgICAgKHBvc3QpID0+IHBvc3QudXNlcklkID09PSB1c2VySWRcclxuICAgICAgKTtcclxuXHJcbiAgICAgIGNvbnN0IHBvc3RJZHMgPSB1c2VyUG9zdHMubWFwKFxyXG4gICAgICAgIChwb3N0KSA9PiBwb3N0LmlkXHJcbiAgICAgICk7XHJcblxyXG4gICAgICByZXR1cm4gY29tbWVudHMuZmlsdGVyKFxyXG4gICAgICAgIChjb21tZW50KSA9PlxyXG4gICAgICAgICAgcG9zdElkcy5pbmNsdWRlcyhjb21tZW50LnBvc3RJZClcclxuICAgICAgKS5sZW5ndGg7XHJcbiAgICB9XHJcbiAgKTtcclxuXHJcbiAgY29uc3QgY2F0ZWdvcmllcyA9IEFycmF5LmZyb20oXHJcbiAgICB7bGVuZ3RoOiB0b3RhbFVzZXJzfSwgKF8sIGluZGV4KSA9PiBcclxuICAgICAgYFVzdWFyaW8gJHtpbmRleCArIDF9YFxyXG4gICk7XHJcblxyXG4gIGNvbnN0IGNoYXJ0T3B0aW9uczogSGlnaGNoYXJ0cy5PcHRpb25zID0ge1xyXG4gICAgY2hhcnQ6IHtcclxuICAgICAgdHlwZTogXCJjb2x1bW5cIixcclxuICAgIH0sIFxyXG5cclxuICAgIHRpdGxlOiB7XHJcbiAgICAgIHRleHQ6IFwiUG9zdHMgeSBjb21lbnRhcmlvcyBwb3IgdXN1YXJpb1wiLFxyXG4gICAgfSwgXHJcblxyXG4gICAgeEF4aXM6IHtcclxuICAgICAgY2F0ZWdvcmllcywgXHJcbiAgICB9LCBcclxuXHJcbiAgICB5QXhpczoge1xyXG4gICAgICB0aXRsZToge1xyXG4gICAgICAgIHRleHQ6IFwiQ2FudGlkYWRcIiwgXHJcbiAgICAgIH0sXHJcbiAgICB9LCBcclxuXHJcbiAgICBzZXJpZXM6IFtcclxuICAgICAge1xyXG4gICAgICAgIHR5cGU6IFwiY29sdW1uXCIsIFxyXG4gICAgICAgIG5hbWU6IFwiUG9zdHNcIiwgXHJcbiAgICAgICAgZGF0YTogUG9zdHNCeVVzZXIsXHJcbiAgICAgIH0sIFxyXG4gICAgICB7XHJcbiAgICAgICAgdHlwZTogXCJjb2x1bW5cIixcclxuICAgICAgICBuYW1lOiBcIkNvbWVudGFyaW9zXCIsXHJcbiAgICAgICAgZGF0YTogY29tbWVudHNCeVVzZXJcclxuICAgICAgfVxyXG4gICAgXSxcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdiBjbGFzc05hbWU9XCJkYXNoYm9hcmQtcGFnZVwiPlxyXG4gICAge2Vycm9yICYmICg8cD57ZXJyb3J9PC9wPil9XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGFzaGJvYXJkLXN0YXRzXCI+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc3RhdC1jYXJkXCI+XHJcbiAgICAgICAgICAgIDxoMj57dChcImRhc2hib2FyZC50b3RhbC1wb3N0XCIpfTwvaDI+XHJcbiAgICAgICAgICAgIDxwPnt0b3RhbFBvc3RzfTwvcD5cclxuICAgICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNhcmQgc3RhdC1jYXJkXCI+XHJcbiAgICAgICAgICAgIDxoMj57dChcImRhc2hib2FyZC50b3RhbC11c2Vyc1wiKX08L2gyPlxyXG4gICAgICAgICAgICA8cD57dG90YWxVc2Vyc308L3A+XHJcbiAgICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIHN0YXQtY2FyZFwiPlxyXG4gICAgICAgICAgICA8aDI+e3QoXCJkYXNoYm9hcmQudG90YWwtY29tbWVudHNcIil9PC9oMj5cclxuICAgICAgICAgICAgPHA+e3RvdGFsQ29tbWVudHN9PC9wPlxyXG4gICAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICA8L2Rpdj5cclxuXHJcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjYXJkIGNoYXJ0LWNhcmRcIj5cclxuICAgICAgICB7bG9hZGluZyA/IChcclxuICAgICAgICAgIDxwPkNhcmdhbmRvIGdyYWZpY2E8L3A+KSA6IChcclxuICAgICAgICAgIDxIaWdoY2hhcnRzUmVhY3RcclxuICAgICAgICAgICAgaGlnaGNoYXJ0cz17SGlnaGNoYXJ0c31cclxuICAgICAgICAgICAgb3B0aW9ucz17Y2hhcnRPcHRpb25zfVxyXG4gICAgICAgICAgLz5cclxuICAgICAgICApfVxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IERhc2hib2FyZFBhZ2U7Il19