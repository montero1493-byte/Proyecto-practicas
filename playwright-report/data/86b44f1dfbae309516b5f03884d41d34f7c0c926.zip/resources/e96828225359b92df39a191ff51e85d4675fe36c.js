import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/app/pages/profile/ProfilePage.tsx");const _jsxDEV = __vite__cjsImport1_react_jsxDevRuntime["jsxDEV"];import { useTranslation } from "/node_modules/.vite/deps/react-i18next.js?v=6824eab0";
var _jsxFileName = "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/profile/ProfilePage.tsx";
import __vite__cjsImport1_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=55f59584";
var _s = $RefreshSig$();
const ProfilePage = () => {
	_s();
	const { t } = useTranslation();
	const userType = localStorage.getItem("userType");
	const username = localStorage.getItem("username");
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "profile-page",
		children: /* @__PURE__ */ _jsxDEV("div", {
			className: "profile-card",
			children: [
				/* @__PURE__ */ _jsxDEV("h1", { children: t("app.profile") }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 16,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "profile-info",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: [t("homepage.user"), ":"] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 19,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: username }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 20,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 18,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "profile-info",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Email:" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 24,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: "usuario@test.com" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 25,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 23,
					columnNumber: 9
				}, this),
				/* @__PURE__ */ _jsxDEV("div", {
					className: "profile-info",
					children: [/* @__PURE__ */ _jsxDEV("span", { children: "Rol:" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 29,
						columnNumber: 11
					}, this), /* @__PURE__ */ _jsxDEV("span", { children: userType === "guest" ? "Invitado" : "Usuario" }, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 11
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 28,
					columnNumber: 9
				}, this)
			]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 15,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 14,
		columnNumber: 5
	}, this);
};
_s(ProfilePage, "zlIdU9EjM2llFt74AbE2KsUJXyM=", false, function() {
	return [useTranslation];
});
_c = ProfilePage;
export default ProfilePage;
var _c;
$RefreshReg$(_c, "ProfilePage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/app/pages/profile/ProfilePage.tsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/profile/ProfilePage.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/profile/ProfilePage.tsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "C:/Users/anmoba/Desktop/Proyectos/Proyecto-practicas/src/app/pages/profile/ProfilePage.tsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxzQkFBc0I7Ozs7QUFFL0IsTUFBTSxvQkFBb0I7O0NBQ3hCLE1BQU0sRUFBRSxNQUFNLGVBQWU7Q0FFN0IsTUFBTSxXQUNKLGFBQWEsUUFBUSxVQUFVO0NBRWpDLE1BQU0sV0FDSixhQUFhLFFBQVEsVUFBVTtDQUdqQyxPQUNFLHdCQUFDLE9BQUQ7RUFBSyxXQUFVO1lBQ2Isd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZjtJQUNFLHdCQUFDLE1BQUQsWUFBSyxFQUFFLGFBQWEsRUFBTTs7Ozs7SUFFMUIsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQsYUFBTyxFQUFFLGVBQWUsR0FBRSxHQUFPOzs7O2VBQ2pDLHdCQUFDLFFBQUQsWUFBTyxTQUFlOzs7O2FBQ25COzs7Ozs7SUFFTCx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsUUFBRCxZQUFNLFNBQVk7Ozs7ZUFDbEIsd0JBQUMsUUFBRCxZQUFNLG1CQUFzQjs7OzthQUN6Qjs7Ozs7O0lBRUwsd0JBQUMsT0FBRDtLQUFLLFdBQVU7ZUFBZixDQUNFLHdCQUFDLFFBQUQsWUFBTSxPQUFVOzs7O2VBQ2hCLHdCQUFDLFFBQUQsWUFBTyxhQUFhLFVBQ2hCLGFBQ0EsVUFBZ0I7Ozs7YUFDakI7Ozs7OztHQUNGOzs7Ozs7Q0FDRjs7Ozs7QUFFVDs7Ozs7QUFFQSxlQUFlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlByb2ZpbGVQYWdlLnRzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VUcmFuc2xhdGlvbiB9IGZyb20gXCJyZWFjdC1pMThuZXh0XCI7XHJcblxyXG5jb25zdCBQcm9maWxlUGFnZSA9ICgpID0+IHtcclxuICBjb25zdCB7IHQgfSA9IHVzZVRyYW5zbGF0aW9uKCk7XHJcblxyXG4gIGNvbnN0IHVzZXJUeXBlID0gXHJcbiAgICBsb2NhbFN0b3JhZ2UuZ2V0SXRlbShcInVzZXJUeXBlXCIpO1xyXG5cclxuICBjb25zdCB1c2VybmFtZSA9IFxyXG4gICAgbG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJ1c2VybmFtZVwiKTtcclxuXHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtcGFnZVwiPlxyXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtY2FyZFwiPlxyXG4gICAgICAgIDxoMT57dChcImFwcC5wcm9maWxlXCIpfTwvaDE+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1pbmZvXCI+XHJcbiAgICAgICAgICA8c3Bhbj57dChcImhvbWVwYWdlLnVzZXJcIil9Ojwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuPnt1c2VybmFtZX08L3NwYW4+XHJcbiAgICAgICAgPC9kaXY+XHJcblxyXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJvZmlsZS1pbmZvXCI+XHJcbiAgICAgICAgICA8c3Bhbj5FbWFpbDo8L3NwYW4+XHJcbiAgICAgICAgICA8c3Bhbj51c3VhcmlvQHRlc3QuY29tPC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG5cclxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInByb2ZpbGUtaW5mb1wiPlxyXG4gICAgICAgICAgPHNwYW4+Um9sOjwvc3Bhbj5cclxuICAgICAgICAgIDxzcGFuPnt1c2VyVHlwZSA9PT0gXCJndWVzdFwiXHJcbiAgICAgICAgICAgID8gXCJJbnZpdGFkb1wiXHJcbiAgICAgICAgICAgIDogXCJVc3VhcmlvXCJ9PC9zcGFuPlxyXG4gICAgICAgIDwvZGl2PlxyXG4gICAgICA8L2Rpdj4gIFxyXG4gICAgPC9kaXY+XHJcbiAgKTtcclxufTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IFByb2ZpbGVQYWdlOyJdfQ==